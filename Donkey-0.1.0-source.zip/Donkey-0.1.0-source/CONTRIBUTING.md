# Contributing to Donkey (Windows)

Thanks for helping. Donkey reads people's screens, so the two rules that matter most are about
privacy. Both are below.

## Set up

```powershell
cd donkey
powershell -ExecutionPolicy Bypass -File setup.ps1
.venv\Scripts\python -m donkey doctor
```

Donkey needs x64 Python 3.11 (on ARM PCs too: it runs under Windows 11's emulation). Windows asks
for no permissions; `doctor` checks the API key, the keyboard hook, text recognition and reading a
field.

## Use a throwaway memory

Point Donkey at a separate home so your own memory never ends up in a bug report or a test:

```powershell
$env:DONKEY_HOME = "$env:TEMP\donkey-dev"; .venv\Scripts\python -m donkey app
```

That folder gets its own `config.json` and `data\`, and runs beside your normal Donkey.

## Check your change

```powershell
.venv\Scripts\python -m donkey doctor                  # API key, key hook, reading a field
foreach ($f in "memory_jobs", "loop_guards", "update", "person_lines", "delivery", "new_view") {
  .venv\Scripts\python -X utf8 tools\check_$f.py }      # offline, no model
.venv\Scripts\python -m donkey eval --rewrites         # replays saved rewrites (uses your model, costs tokens)
.venv\Scripts\python -m donkey eval --scenarios --runs 3   # end to end on made-up memory (costs tokens)
```

For a change you can see, run the app and try it in a plain edit box (Notepad), a browser (Chrome
or Edge) and an Electron app. Say in the pull request what you tried.

## Privacy rules

1. **Never commit `config.json` or `data\`.** They hold API keys and someone's memory, and
   `.gitignore` already excludes them. Screenshots, logs and OCR samples for issues must be made
   up, or from a throwaway memory.
2. **Never send more off the PC than is needed.** Text that goes to a model passes the blocklist
   and redaction first. New capture paths must do the same, and must skip password fields,
   private windows and blocked apps.

## Style

- Match the code around you: small modules, plain functions, short comments that explain *why*.
- Windows calls live in a few modules (`winui.py`, `ax.py`, `keys.py`, `deliver.py`, `ocr.py`,
  `capture.py`, `notify.py`, `instance.py`); keep the rest free of them.
- Keep prompts general. Don't tune a prompt to pass one scenario.
- Write commit messages that say what changed for the user, like the ones already in the log.
- One change per pull request.

## Reporting a bug

Include your Windows version (Win+R, `winver`), whether the PC is x64 or ARM, the app you were in,
what you pressed, and the lines from `data\donkey.log` around it. Check them for private text
before posting.

## Security

If you find a way Donkey leaks screen text, keys or memory, please report it privately through
GitHub's **Report a vulnerability** (Security tab) instead of opening an issue.
