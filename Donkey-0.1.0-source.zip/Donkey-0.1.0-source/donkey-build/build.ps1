<#
Build Donkey for Windows: dist\Donkey\ (Donkey.exe, donkey-cli.exe and everything they need) and,
when Inno Setup 6 is installed, dist\Donkey-<version>-setup.exe.

Uses the Donkey project at $env:DONKEY_SRC (default: the donkey folder beside this one) and its
.venv (x64 Python 3.11; run setup.ps1 there first). It runs vendor.py first (downloads once, then
keeps what's there) and stops if the embedding model or either llama-server is missing: a Donkey
without them can't search memory, so there is no build without them.

  powershell -ExecutionPolicy Bypass -File build.ps1
#>
$ErrorActionPreference = "Stop"
$Kit = $PSScriptRoot
if (-not $env:DONKEY_SRC) { $env:DONKEY_SRC = (Resolve-Path (Join-Path $Kit "..\donkey")).Path }
$Py = Join-Path $env:DONKEY_SRC ".venv\Scripts\python.exe"
if (-not (Test-Path $Py)) { throw "No .venv in $env:DONKEY_SRC: run setup.ps1 there first." }
$Version = (Get-Content (Join-Path $Kit "VERSION") -Raw).Trim()

& $Py -m pip install -q -r (Join-Path $Kit "requirements.txt")
if ($LASTEXITCODE) { throw "pip failed" }

# What Donkey ships with instead of fetching: the embedding model and llama-server (x64 and ARM64)
& $Py (Join-Path $Kit "vendor.py") --arch both
if ($LASTEXITCODE) { throw "vendor.py failed: the embedding model or llama-server couldn't be fetched" }
& $Py (Join-Path $Kit "vendor.py") --check
if ($LASTEXITCODE) { throw "vendor\ is incomplete (see above); not building without it" }

# comtypes writes its UI Automation wrapper on first use: make it now, so PyInstaller packs it
& $Py -c "import comtypes.client; comtypes.client.GetModule('UIAutomationCore.dll')"
if ($LASTEXITCODE) { throw "couldn't generate the UI Automation wrapper" }

# The icon: icon.png at the sizes Windows asks for, in one .ico
$env:DONKEY_ICO = Join-Path $Kit "icon.ico"
$png = Join-Path $env:DONKEY_SRC "donkey\assets\icon.png"
& $Py -c @"
import struct, sys
from PySide6.QtCore import QBuffer, QByteArray, QIODevice, Qt
from PySide6.QtGui import QImage
src = QImage(sys.argv[1])
images = []
for side in (16, 24, 32, 48, 64, 128, 256):
    data = QByteArray(); buf = QBuffer(data); buf.open(QIODevice.WriteOnly)
    src.scaled(side, side, Qt.KeepAspectRatio, Qt.SmoothTransformation).save(buf, 'PNG')
    images.append((side, bytes(data)))
out = struct.pack('<HHH', 0, 1, len(images))
offset = 6 + 16 * len(images)
for side, blob in images:
    out += struct.pack('<BBBBHHII', side % 256, side % 256, 0, 0, 1, 32, len(blob), offset)
    offset += len(blob)
open(sys.argv[2], 'wb').write(out + b''.join(blob for _, blob in images))
"@ $png $env:DONKEY_ICO
if ($LASTEXITCODE) { throw "couldn't make icon.ico" }

# Version resource, so Windows shows "Donkey" and the version in Task Manager and Properties
$parts = ($Version.Split(".") + @("0", "0", "0"))[0..3] -join ", "
@"
VSVersionInfo(
  ffi=FixedFileInfo(filevers=($parts), prodvers=($parts)),
  kids=[StringFileInfo([StringTable('040904B0', [
    StringStruct('CompanyName', 'Donkey'), StringStruct('FileDescription', 'Donkey'),
    StringStruct('ProductName', 'Donkey'), StringStruct('FileVersion', '$Version'),
    StringStruct('ProductVersion', '$Version'), StringStruct('OriginalFilename', 'Donkey.exe')])]),
    VarFileInfo([VarStruct('Translation', [1033, 1200])])]
)
"@ | Set-Content -Encoding utf8 (Join-Path $Kit "version_info.txt")

Push-Location $Kit
try {
  & $Py -m PyInstaller --noconfirm --clean --distpath dist --workpath build donkey.spec
  if ($LASTEXITCODE) { throw "PyInstaller failed" }
} finally { Pop-Location }
Write-Host "Built $Kit\dist\Donkey\Donkey.exe"

$Iscc = @("${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe", "$env:ProgramFiles\Inno Setup 6\ISCC.exe",
          "$env:LOCALAPPDATA\Programs\Inno Setup 6\ISCC.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
if ($Iscc) {
  & $Iscc "/DAppVersion=$Version" "/DSourceDir=$Kit\dist\Donkey" "/DIconFile=$env:DONKEY_ICO" "/O$Kit\dist" (Join-Path $Kit "installer.iss")
  if ($LASTEXITCODE) { throw "Inno Setup failed" }
  Write-Host "Built $Kit\dist\Donkey-$Version-setup.exe"
} else {
  Write-Host "Inno Setup 6 isn't installed (winget install JRSoftware.InnoSetup), so no installer; dist\Donkey runs as is."
}
