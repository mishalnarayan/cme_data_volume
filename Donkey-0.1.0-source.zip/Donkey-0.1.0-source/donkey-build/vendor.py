"""Fill vendor/ (next to this file) with everything Donkey would otherwise fetch or find on the PC;
build.ps1 puts it inside the app folder (as donkey/vendor, where Donkey looks first), so the app
works offline and without winget:

- EmbeddingGemma 2's 8-bit GGUF (Gemma terms of use, 310 MB)
- llama-server.exe and its DLLs from llama.cpp's own Windows CPU builds (MIT): x64, and ARM64 so
  memory search runs natively on ARM PCs while the x64 app runs under Windows' emulation

Every download is pinned, so each copy embeds exactly the same way. Run it again any time: what's
already there is kept. Usage: <donkey>\\.venv\\Scripts\\python vendor.py
(DONKEY_SRC is the Donkey project, the donkey folder beside this one unless set.)
"""
import argparse
import hashlib
import os
import shutil
import sys
import tempfile
import urllib.request
import zipfile
from pathlib import Path

SRC = Path(os.environ.get("DONKEY_SRC", Path(__file__).resolve().parent.parent / "donkey")).expanduser()
sys.path.insert(0, str(SRC))
from donkey import embed  # noqa: E402  (its config also points the HF cache at data/models)

VENDOR = Path(__file__).resolve().parent / "vendor"
LLAMA_BUILD = "b11669"
LLAMA = {  # arch -> (release asset, sha256)
    "x64": (f"llama-{LLAMA_BUILD}-bin-win-cpu-x64.zip",
            "37b3efcf962847ca869745fd4ccf7f5e7e8dacfeff9fa3523b4ca8cdc66d632b"),
    "arm64": (f"llama-{LLAMA_BUILD}-bin-win-cpu-arm64.zip",
              "9cff39ffed17edcd03a7d876073f74d7b48cd43a1e5eafdd59ee094185ad871b"),
}
LLAMA_URL = f"https://github.com/ggml-org/llama.cpp/releases/download/{LLAMA_BUILD}/"


def say(msg: str) -> None:
    print(msg, flush=True)


def gemma() -> None:
    dest = VENDOR / embed.GGUF_FILE
    if dest.exists():
        return say(f"ok    {dest.name}")
    from huggingface_hub import hf_hub_download
    # The copy Donkey already downloaded (data/models) when there is one; fetched only otherwise
    try:
        src = hf_hub_download(embed.GGUF_REPO, embed.GGUF_FILE, revision=embed.GGUF_REVISION, local_files_only=True)
        how = "from Donkey's downloaded copy"
    except Exception:
        src = hf_hub_download(embed.GGUF_REPO, embed.GGUF_FILE, revision=embed.GGUF_REVISION)
        how = "downloaded"
    tmp = dest.with_suffix(".part")
    tmp.unlink(missing_ok=True)
    try:
        os.link(os.path.realpath(src), tmp)   # same file on disk, no second 310 MB
    except OSError:
        shutil.copyfile(src, tmp)             # another drive: copy
    tmp.replace(dest)
    say(f"added {dest.name} ({how})")


def llama(arch: str) -> None:
    """llama-server.exe plus the DLLs beside it in the release zip."""
    asset, sha = LLAMA[arch]
    dest = VENDOR / "llama" / arch
    stamp = dest / "BUILD"
    if (dest / "llama-server.exe").exists() and stamp.exists() and stamp.read_text().strip() == LLAMA_BUILD:
        return say(f"ok    llama-server {LLAMA_BUILD} ({arch})")
    with tempfile.TemporaryDirectory() as tmp:
        zpath = Path(tmp) / asset
        urllib.request.urlretrieve(LLAMA_URL + asset, zpath)
        if hashlib.sha256(zpath.read_bytes()).hexdigest() != sha:
            sys.exit(f"{asset} doesn't match its pinned checksum; not using it")
        shutil.rmtree(dest, ignore_errors=True)
        dest.mkdir(parents=True)
        with zipfile.ZipFile(zpath) as z:
            names = z.namelist()
            server = next(n for n in names if n.lower().endswith("llama-server.exe"))
            base = server.rsplit("/", 1)[0] + "/" if "/" in server else ""
            keep = [n for n in names if n.startswith(base) and "/" not in n[len(base):]
                    and (n.lower().endswith(".dll") or n == server or n.lower().endswith("license"))]
            for n in keep:
                (dest / Path(n).name).write_bytes(z.read(n))
    stamp.write_text(LLAMA_BUILD + "\n")
    say(f"added llama-server {LLAMA_BUILD} ({arch}, {len(keep)} files)")


def required() -> list[Path]:
    """What a build must carry; donkey.spec and build.ps1 refuse to build without each."""
    return [VENDOR / embed.GGUF_FILE] + [VENDOR / "llama" / a / "llama-server.exe" for a in LLAMA]


def check() -> list[str]:
    """What's missing or broken in vendor/, as messages (empty when complete)."""
    problems = [f"missing {p.relative_to(VENDOR)}" for p in required() if not p.exists()]
    gguf = VENDOR / embed.GGUF_FILE
    if gguf.exists() and gguf.stat().st_size < 100_000_000:
        problems.append(f"{gguf.name} is only {gguf.stat().st_size} bytes (a broken download?)")
    for arch in LLAMA:
        stamp = VENDOR / "llama" / arch / "BUILD"
        if (VENDOR / "llama" / arch / "llama-server.exe").exists() and \
                (not stamp.exists() or stamp.read_text().strip() != LLAMA_BUILD):
            problems.append(f"llama/{arch} isn't build {LLAMA_BUILD}")
    return problems


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--arch", choices=["x64", "arm64", "both"], default="both",
                    help="which llama-server builds to fetch (default both; a build needs both)")
    ap.add_argument("--check", action="store_true", help="fetch nothing; exit 1 if anything is missing")
    args = ap.parse_args()
    if args.check:
        problems = check()
        for p in problems:
            say(f"FAIL  {p}")
        if problems:
            sys.exit(1)
        return say("ok    vendor/ complete")
    VENDOR.mkdir(parents=True, exist_ok=True)
    gemma()
    for arch in (("x64", "arm64") if args.arch == "both" else (args.arch,)):
        llama(arch)
    total = sum(f.stat().st_size for f in VENDOR.rglob("*") if f.is_file())
    say(f"{VENDOR}: {total / 1e6:.0f} MB")


if __name__ == "__main__":
    main()
