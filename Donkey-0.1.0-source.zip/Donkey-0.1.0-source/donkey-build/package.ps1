<#
Make the shareable source code of Donkey for Windows: dist\release\Donkey-<version>-source.zip
(a few MB), plus SHA256SUMS.txt. Just the code: no .venv, no Donkey.exe, no model, and none of
your own files (config.json with your API keys, data\ with your memory, logs). Whoever gets it runs
setup.ps1, which installs Python, the packages, llama.cpp and the model on their PC.

It refuses to make the zip if anything private would go in, or if any of your API keys appears in
any file. (package_app.ps1 makes the built app instead: Donkey.exe and everything, ~570 MB.)

  powershell -ExecutionPolicy Bypass -File package.ps1
#>
$ErrorActionPreference = "Stop"
$Kit = $PSScriptRoot
$Root = (Resolve-Path (Join-Path $Kit "..")).Path           # windows\: donkey\, donkey-build\, LICENSE...
$Version = (Get-Content (Join-Path $Kit "VERSION") -Raw).Trim()
$Out = Join-Path $Kit "dist\release"
$Name = "Donkey-$Version-source"

# Left out: what setup.ps1 or a build makes, and everything of yours
$SkipDirs = @(".venv", "data", "__pycache__", "dist", "build", "vendor", ".git", "ocr-shots", "donkey-public", ".pytest_cache")
$SkipFiles = @("config.json", "icon.ico", "version_info.txt", "Thumbs.db", "desktop.ini")
$SkipExt = @(".pyc", ".log", ".db", ".db-wal", ".db-shm", ".gguf", ".exe", ".dll", ".zip", ".part")

$files = Get-ChildItem $Root -Recurse -File -Force | Where-Object {
  $rel = $_.FullName.Substring($Root.Length + 1)
  $parts = $rel.Split("\")
  -not ($parts[0..($parts.Count - 2)] | Where-Object { $SkipDirs -contains $_ }) -and
  $SkipFiles -notcontains $_.Name -and $SkipExt -notcontains $_.Extension.ToLower()
}
if (-not ($files | Where-Object { $_.FullName -like "*\donkey\donkey\__main__.py" })) { throw "Didn't find the Donkey code under $Root" }

# ---------------------------------------------------------------- nothing private goes out
$secrets = @()
$cfgPath = Join-Path $Root "donkey\config.json"
if (Test-Path $cfgPath) {
  function Find-Secrets($o) {
    foreach ($p in $o.PSObject.Properties) {
      if ($p.Value -is [pscustomobject]) { Find-Secrets $p.Value }
      elseif ($p.Value -is [string] -and $p.Value.Length -ge 12 -and $p.Name -match "key|token|secret|password") { $p.Value }
    }
  }
  [string[]]$secrets = @(Find-Secrets (Get-Content $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json))
}
$latin = [Text.Encoding]::GetEncoding(28591)   # one character per byte: any file can be searched
[string[]]$needles = foreach ($s in $secrets) { $latin.GetString([Text.Encoding]::UTF8.GetBytes($s)) }
foreach ($f in $files) {
  if ($f.Length -gt 20MB) { throw "$($f.FullName) is $([math]::Round($f.Length / 1MB)) MB: not code. Not packaging." }
  $text = $latin.GetString([IO.File]::ReadAllBytes($f.FullName))
  foreach ($n in $needles) { if ($text.Contains($n)) { throw "An API key from config.json is in $($f.FullName). Not packaging." } }
}
Write-Host "Checked $($files.Count) files: no config, data, logs or API keys ($($secrets.Count) key(s) checked)"

# ---------------------------------------------------------------- the zip
New-Item -ItemType Directory -Force $Out | Out-Null
$zip = Join-Path $Out "$Name.zip"
if (Test-Path $zip) { Remove-Item $zip -Force -Confirm:$false }

$start = @"
Donkey $Version for Windows (source code)
=========================================

Donkey sits in your system tray, remembers what you work on (on your PC only), and rewrites
whatever you're typing, in any app, when you tap Right Alt.

Set up (once, about 10 minutes: it downloads Python packages, llama.cpp and a 310 MB model)
--------------------------------------------------------------------------------------------
1. Unzip this folder somewhere you'll keep it (not inside the zip).
2. Open PowerShell in the donkey folder (Shift+right-click it > Open in Terminal) and run:

     powershell -ExecutionPolicy Bypass -File setup.ps1

   It installs 64-bit Python 3.11 for you if you don't have it (from python.org, no admin).

Run
---
     .venv\Scripts\python -m donkey doctor      checks everything
     .venv\Scripts\pythonw -m donkey app        starts Donkey in the tray

On first start Donkey asks for an AI provider and API key (OpenRouter, Anthropic, or a local LM
Studio). It's saved in donkey\config.json on your PC, next to data\, where Donkey keeps what it
remembers. Then click into any text box, type a rough draft, and tap Right Alt.

Needs Windows 11, 64-bit (Intel/AMD or ARM). More in donkey\README.md.
"@

Add-Type -AssemblyName System.IO.Compression, System.IO.Compression.FileSystem
$archive = [IO.Compression.ZipFile]::Open($zip, [IO.Compression.ZipArchiveMode]::Create)
try {
  foreach ($f in $files) {
    $entry = "$Name/" + $f.FullName.Substring($Root.Length + 1).Replace("\", "/")
    [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive, $f.FullName, $entry, [IO.Compression.CompressionLevel]::Optimal)
  }
  $e = $archive.CreateEntry("$Name/START_HERE.txt")
  $w = New-Object IO.StreamWriter($e.Open(), (New-Object Text.UTF8Encoding($false)))
  try { $w.Write($start.Replace("`r`n", "`n").Replace("`n", "`r`n")) } finally { $w.Dispose() }
} finally { $archive.Dispose() }

$hash = (Get-FileHash $zip -Algorithm SHA256).Hash.ToLower()
Set-Content (Join-Path $Out "SHA256SUMS.txt") "$hash  $Name.zip" -Encoding ASCII
Write-Host ("`nReady to share: {0} ({1:N1} MB, {2} files)" -f $zip, ((Get-Item $zip).Length / 1MB), $files.Count)
