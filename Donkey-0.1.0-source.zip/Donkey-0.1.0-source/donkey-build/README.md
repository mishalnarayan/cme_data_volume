# donkey-build

Packaging for Donkey on Windows. `build.ps1` makes `dist\Donkey\` (Donkey.exe and donkey-cli.exe
with everything they need) and, with Inno Setup 6 installed, `dist\Donkey-<version>-setup.exe`, from
the project at `DONKEY_SRC` (default `..\donkey`, beside this folder).

- `vendor.py`: fetches the pinned embedding model and llama-server (x64 and ARM64 builds) into `vendor\` (not in git)
- `donkey.spec`: the PyInstaller recipe; `app_entry.py`: the programs' entry point
- `installer.iss`: the Inno Setup installer (per user, no admin rights; Start menu entry, optional sign-in shortcut)
- `VERSION`: the version the programs and the installer carry
- `requirements.txt`: PyInstaller; `build.ps1` installs it into Donkey's .venv

```powershell
cd ..\donkey; powershell -ExecutionPolicy Bypass -File setup.ps1    # once: the x64 .venv
.\.venv\Scripts\python ..\donkey-build\vendor.py                     # once: model + llama-server
cd ..\donkey-build; powershell -ExecutionPolicy Bypass -File build.ps1
```

To share it:
- `package.ps1`: the code only, `dist\release\Donkey-<version>-source.zip` (~1 MB). No .venv, exe
  or model; whoever gets it runs `setup.ps1`. Refuses if your config.json, data, logs or any API key
  would go in.
- `package_app.ps1` (`-SkipBuild` reuses the last build): the built app as a ~570 MB zip, plus the
  installer with Inno Setup, after the same privacy check. `-Publish` makes a GitHub release with `gh`.

The build is x64. It runs natively on Intel and AMD PCs and through Windows 11's built-in emulation
on ARM PCs; there llama-server (memory search) runs as its native ARM64 build.
