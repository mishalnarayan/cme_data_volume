﻿<#
Make the shareable BUILT Donkey (Donkey.exe, ~570 MB zip) in dist\release\. For the code only, use package.ps1.

  Donkey-<version>-setup.exe         the installer (needs Inno Setup 6: winget install JRSoftware.InnoSetup)
  Donkey-<version>-windows.zip       the portable app: unzip anywhere, run Donkey.exe
  SHA256SUMS.txt                     checksums, so whoever downloads can check the files
  RELEASE_NOTES.md                   text for a GitHub release

It builds first (build.ps1) unless -SkipBuild, and refuses to package if anything private got in:
your config.json, API keys, memory database or logs.

  powershell -ExecutionPolicy Bypass -File package_app.ps1               # build, then package
  powershell -ExecutionPolicy Bypass -File package_app.ps1 -SkipBuild    # package the last build
  powershell -ExecutionPolicy Bypass -File package_app.ps1 -SkipBuild -Publish
      # also make GitHub release v<version> with these files (needs the GitHub CLI, gh, signed in,
      # run from inside the GitHub repository's folder)
#>
param([switch]$SkipBuild, [switch]$Publish)
$ErrorActionPreference = "Stop"
$Kit = $PSScriptRoot
$Src = if ($env:DONKEY_SRC) { $env:DONKEY_SRC } else { (Resolve-Path (Join-Path $Kit "..\donkey")).Path }
$Version = (Get-Content (Join-Path $Kit "VERSION") -Raw).Trim()
$App = Join-Path $Kit "dist\Donkey"
$Out = Join-Path $Kit "dist\release"

if (-not $SkipBuild) {
  & powershell -ExecutionPolicy Bypass -File (Join-Path $Kit "build.ps1")
  if ($LASTEXITCODE) { throw "build.ps1 failed" }
}
if (-not (Test-Path (Join-Path $App "Donkey.exe"))) { throw "No build in $App; run without -SkipBuild." }

# ---------------------------------------------------------------- nothing private goes out
Write-Host "Checking the build for anything private..."
$private = Get-ChildItem $App -Recurse -File -Include config.json, *.db, *.db-wal, *.db-shm, *.log, profile.md, digest.txt
if ($private) { throw "Private files in the build: $($private.FullName -join ', ')" }

# Every secret-looking value in your config.json (API keys, tokens) must appear in no file of the build.
$secrets = @()
$cfgPath = Join-Path $Src "config.json"
if (Test-Path $cfgPath) {
  function Find-Secrets($o) {
    foreach ($p in $o.PSObject.Properties) {
      if ($p.Value -is [pscustomobject]) { Find-Secrets $p.Value }
      elseif ($p.Value -is [string] -and $p.Value.Length -ge 12 -and $p.Name -match "key|token|secret|password") { $p.Value }
    }
  }
  $secrets = @(Find-Secrets (Get-Content $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json))
}
if ($secrets.Count) {
  # Compared as Latin-1 text, which maps each byte to one character, so any binary file can be searched
  $latin = [Text.Encoding]::GetEncoding(28591)
  [string[]]$needles = foreach ($s in $secrets) { $latin.GetString([Text.Encoding]::UTF8.GetBytes($s)) }
  foreach ($f in Get-ChildItem $App -Recurse -File | Where-Object { $_.Length -lt 200MB }) {
    $text = $latin.GetString([IO.File]::ReadAllBytes($f.FullName))
    foreach ($n in $needles) {
      if ($text.Contains($n)) {
        throw "An API key from config.json is inside $($f.FullName). Not packaging."
      }
    }
  }
}
Write-Host "  ok: no config, keys, memory or logs ($($secrets.Count) key(s) checked)"

# ---------------------------------------------------------------- the files
if (Test-Path $Out) { Remove-Item $Out -Recurse -Force -Confirm:$false }
New-Item -ItemType Directory $Out | Out-Null

$readme = @"
Donkey $Version for Windows
===========================

Donkey sits in your system tray, remembers what you work on (on your PC only), and rewrites
whatever you're typing, in any app, when you tap Right Alt.

Install
-------
Installer: run Donkey-$Version-setup.exe. No administrator rights needed; it adds Donkey to the
Start menu and, if you leave the box ticked, starts it when you sign in.

Portable zip: unzip the whole folder anywhere (not inside the zip), then run Donkey.exe.

The app isn't code-signed, so Windows may say "Windows protected your PC". Click "More info",
then "Run anyway". Antivirus may scan it for a while on the first start.

First start
-----------
Donkey asks for an AI provider and API key (OpenRouter, Anthropic, or a local LM Studio). The key
stays on your PC in %APPDATA%\Donkey\config.json, with everything Donkey remembers.

Then click into any text box, type a rough draft, and tap Right Alt.

Needs: Windows 11, 64-bit, Intel/AMD or ARM (Windows 10 is untested). About 1 GB of disk space.
Problems: open a terminal in Donkey's folder and run   donkey-cli doctor
Uninstall: Settings > Apps > Donkey (your data in %APPDATA%\Donkey stays; delete it to remove it).
"@

$notice = @"
Donkey $Version includes third-party software:

- EmbeddingGemma 2 (embeddinggemma-2-Q8_0.gguf), by Google. Gemma is provided under and subject to
  the Gemma Terms of Use found at https://ai.google.dev/gemma/terms
- llama.cpp (llama-server and its libraries), MIT License; see donkey\vendor\llama\*\LICENSE
- Qt and PySide6, LGPL v3 (https://www.qt.io/licensing); Python, PSF License; and the Python
  packages listed by pip in the build, each under its own license.
"@

$readmePath = Join-Path $Out "README.txt"
$noticePath = Join-Path $Out "NOTICE.txt"
Set-Content $readmePath $readme -Encoding UTF8
Set-Content $noticePath $notice -Encoding UTF8

# The portable zip: Donkey\ with the README and NOTICE inside it
$zip = Join-Path $Out "Donkey-$Version-windows.zip"
Write-Host "Zipping (a few minutes: ~1 GB)..."
Add-Type -AssemblyName System.IO.Compression, System.IO.Compression.FileSystem
[IO.Compression.ZipFile]::CreateFromDirectory($App, $zip, [IO.Compression.CompressionLevel]::Optimal, $true)
$archive = [IO.Compression.ZipFile]::Open($zip, [IO.Compression.ZipArchiveMode]::Update)
try {
  [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive, $readmePath, "Donkey/README.txt")
  [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive, $noticePath, "Donkey/NOTICE.txt")
} finally { $archive.Dispose() }

# The installer, when Inno Setup is there (build.ps1 made it if so; otherwise make it now)
$Iscc = @("${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe", "$env:ProgramFiles\Inno Setup 6\ISCC.exe",
          "$env:LOCALAPPDATA\Programs\Inno Setup 6\ISCC.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
$setup = Join-Path $Kit "dist\Donkey-$Version-setup.exe"
if ($Iscc) {
  if (-not (Test-Path $setup) -or (Get-Item $setup).LastWriteTime -lt (Get-Item (Join-Path $App "Donkey.exe")).LastWriteTime) {
    $ico = Join-Path $Kit "icon.ico"
    & $Iscc "/DAppVersion=$Version" "/DSourceDir=$App" "/DIconFile=$ico" "/O$Kit\dist" (Join-Path $Kit "installer.iss")
    if ($LASTEXITCODE) { throw "Inno Setup failed" }
  }
  Copy-Item $setup $Out
} else {
  Write-Host "  no installer: Inno Setup 6 isn't installed (winget install JRSoftware.InnoSetup); the zip is enough to share"
}

# ---------------------------------------------------------------- checksums, size, notes
$assets = Get-ChildItem $Out -File | Where-Object { $_.Extension -in ".zip", ".exe" }
$sums = $assets | ForEach-Object { "$((Get-FileHash $_.FullName -Algorithm SHA256).Hash.ToLower())  $($_.Name)" }
Set-Content (Join-Path $Out "SHA256SUMS.txt") $sums -Encoding ASCII
foreach ($a in $assets) {
  if ($a.Length -ge 2GB) { throw "$($a.Name) is $([math]::Round($a.Length / 1GB, 2)) GB: over GitHub's 2 GB limit per release file" }
}

$downloads = ($assets | ForEach-Object { "- ``$($_.Name)`` ($([math]::Round($_.Length / 1MB)) MB)" }) -join "`n"
Set-Content (Join-Path $Out "RELEASE_NOTES.md") -Encoding UTF8 @"
Donkey $Version for Windows (64-bit; Intel/AMD and ARM).

$downloads

The installer needs no administrator rights. Or unzip the portable zip and run ``Donkey.exe``.
The app isn't code-signed yet: if Windows says "Windows protected your PC", choose More info > Run anyway.
On first start Donkey asks for an AI provider and API key; everything it remembers stays on your PC.

Includes EmbeddingGemma 2 (Gemma Terms of Use: https://ai.google.dev/gemma/terms) and llama.cpp (MIT); see NOTICE.txt.

SHA-256:
``````
$($sums -join "`n")
``````
"@

Write-Host "`nReady to share in $Out"
Get-ChildItem $Out -File | ForEach-Object { "  {0,-34} {1,8:N0} MB" -f $_.Name, ($_.Length / 1MB) }

if ($Publish) {
  if (-not (Get-Command gh -ErrorAction SilentlyContinue)) { throw "-Publish needs the GitHub CLI: winget install GitHub.cli, then gh auth login" }
  $files = @($assets.FullName) + (Join-Path $Out "SHA256SUMS.txt")
  & gh release create "v$Version" @files --title "Donkey $Version for Windows" --notes-file (Join-Path $Out "RELEASE_NOTES.md")
  if ($LASTEXITCODE) { throw "gh release create failed" }
}

