"""Entry point of the built app. Donkey.exe (no console) is the tray app when opened with no
arguments, from the Start menu or a shortcut; donkey-cli.exe (console) is `donkey <command>` for
the terminal and for MCP clients. Both take the same commands as `python -m donkey`."""
import os
import sys

# Output to a pipe or file (MCP clients, `donkey-cli doctor > x`) otherwise comes out in the ANSI
# code page and fails on the first ✓; the terminal and MCP clients read UTF-8.
for stream in (sys.stdout, sys.stderr):
    if stream is not None and (stream.encoding or "").lower().replace("-", "") != "utf8":
        stream.reconfigure(encoding="utf-8")

from donkey.__main__ import main  # noqa: E402

gui = os.path.basename(sys.executable).lower() == "donkey.exe"
if gui and len(sys.argv) == 1:
    sys.argv.append("app")
main()
