; Inno Setup script for Donkey (build.ps1 passes AppVersion, SourceDir and IconFile).
; Installs per user (no administrator rights): into %LOCALAPPDATA%\Programs\Donkey, with a Start
; menu entry and, if ticked, a sign-in shortcut. Donkey's data stays in %APPDATA%\Donkey and is
; kept on uninstall.

#ifndef AppVersion
  #define AppVersion "0.0.0"
#endif

[Setup]
AppId={{6D3F2A5B-9C1E-4E7A-B8D2-3F4A5C6D7E8F}
AppName=Donkey
AppVersion={#AppVersion}
AppPublisher=Donkey
DefaultDirName={localappdata}\Programs\Donkey
DefaultGroupName=Donkey
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
OutputBaseFilename=Donkey-{#AppVersion}-setup
SetupIconFile={#IconFile}
UninstallDisplayIcon={app}\Donkey.exe
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
CloseApplications=yes

[Tasks]
Name: "login"; Description: "Open Donkey when I sign in to Windows"; Flags: checkedonce

[Files]
Source: "{#SourceDir}\*"; DestDir: "{app}"; Flags: recursesubdirs ignoreversion

[Icons]
Name: "{userprograms}\Donkey"; Filename: "{app}\Donkey.exe"
Name: "{userstartup}\Donkey"; Filename: "{app}\Donkey.exe"; Parameters: "app --login"; Tasks: login

[Run]
Filename: "{app}\Donkey.exe"; Description: "Open Donkey"; Flags: nowait postinstall skipifsilent

[UninstallRun]
Filename: "{cmd}"; Parameters: "/C taskkill /IM Donkey.exe /F"; Flags: runhidden; RunOnceId: "StopDonkey"

[UninstallDelete]
Type: files; Name: "{userstartup}\Donkey.lnk"

[Registry]
; the notification sender and the donkey:// links that clicked notifications open (Donkey also
; writes these itself on launch; here so the uninstaller removes them)
Root: HKCU; Subkey: "Software\Classes\AppUserModelId\Donkey.App"; Flags: uninsdeletekey
Root: HKCU; Subkey: "Software\Classes\donkey"; Flags: uninsdeletekey
