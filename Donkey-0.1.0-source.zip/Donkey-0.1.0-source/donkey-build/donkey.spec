# PyInstaller recipe for Donkey on Windows; build.ps1 runs it. Two programs share one folder:
# Donkey.exe (no console: the tray app) and donkey-cli.exe (console: the terminal and MCP clients).
# Everything Donkey reads at run time goes inside: its pages and icons, the blocklist, and vendor/
# as donkey/vendor (the embedding model and llama-server).
import os
from pathlib import Path

from PyInstaller.utils.hooks import collect_data_files, collect_submodules

KIT = Path(SPECPATH)
ROOT = Path(os.environ["DONKEY_SRC"])
PKG = ROOT / "donkey"
VENDOR = KIT / "vendor"
ICON = os.environ["DONKEY_ICO"]

# No build without the embedding model and llama-server: the app would install fine and then fail
# every memory search. vendor.py fetches them (build.ps1 runs it).
_missing = [str(p) for p in (VENDOR / "embeddinggemma-2-Q8_0.gguf", VENDOR / "llama/x64/llama-server.exe",
                             VENDOR / "llama/arm64/llama-server.exe") if not p.exists()]
if _missing:
    raise SystemExit("vendor/ is incomplete; run vendor.py first. Missing: " + ", ".join(_missing))

datas = [(str(PKG / "assets"), "donkey/assets"),(str(PKG / "blocklist.txt"), "donkey"),
         (str(PKG / "scenarios.json"), "donkey")]
binaries = []
for f in VENDOR.rglob("*"):
    if f.is_file():
        dest = str(Path("donkey/vendor") / f.parent.relative_to(VENDOR))
        (binaries if f.suffix.lower() in (".exe", ".dll") else datas).append((str(f), dest))
for pkg in ("certifi", "mcp", "anthropic"):
    datas += collect_data_files(pkg)

a = Analysis(
    [str(KIT / "app_entry.py")],
    pathex=[str(ROOT)],
    binaries=binaries,
    datas=datas,
    # mcp.cli is the `mcp` command (needs typer); Donkey only runs a server
    hiddenimports=collect_submodules("donkey") + collect_submodules("mcp", filter=lambda n: not n.startswith("mcp.cli"))
    + collect_submodules("winrt")
    + collect_submodules("comtypes.gen") + ["win32timezone", "pycaw.pycaw", "win32com.client"],
    excludes=["tkinter", "matplotlib", "IPython", "pytest", "torch"],
)
pyz = PYZ(a.pure)
# Donkey reads and writes its files as UTF-8. The bootloader knows this as "X utf8" (like python -X
# utf8); "X utf8_mode=1" is silently ignored. `donkey-cli doctor` checks it took.
utf8 = [("X utf8", None, "OPTION")]
version = KIT / "version_info.txt"
gui = EXE(pyz, a.scripts, utf8, exclude_binaries=True, name="Donkey", console=False, icon=ICON,
          version=str(version) if version.exists() else None, target_arch="x86_64")
cli = EXE(pyz, a.scripts, utf8, exclude_binaries=True, name="donkey-cli", console=True, icon=ICON,
          version=str(version) if version.exists() else None, target_arch="x86_64")
coll = COLLECT(gui, cli, a.binaries, a.datas, name="Donkey")
