<#
One-time setup from source: the .venv (64-bit x64 Python 3.11), llama.cpp, and EmbeddingGemma in
data\models. Safe to run again. -NoModels skips the download (Donkey then fetches it on first use).

  powershell -ExecutionPolicy Bypass -File setup.ps1 [-NoModels]

Donkey needs x64 Python even on an ARM PC: Qt's web engine has no ARM64 build for Windows yet, and
x64 programs run on ARM PCs through Windows 11's built-in emulation.
#>
param([switch]$NoModels)
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

function Test-X64Python($exe) {
  try { return (& $exe -c "import platform, sys; print(sys.version_info[:2] == (3, 11) and platform.machine() == 'AMD64')") -eq "True" }
  catch { return $false }
}

$Py = $null
$candidates = @()
if (Get-Command py -ErrorAction SilentlyContinue) {
  foreach ($tag in "3.11-64", "3.11") {
    try { $p = (& py "-$tag" -c "import sys; print(sys.executable)" 2>$null); if ($p) { $candidates += $p } } catch {}
  }
}
$candidates += @("$env:LOCALAPPDATA\Programs\Python\Python311\python.exe", "$env:ProgramFiles\Python311\python.exe")
foreach ($c in $candidates) { if ($c -and (Test-Path $c) -and (Test-X64Python $c)) { $Py = $c; break } }
if (-not $Py) {
  # Not winget: on an ARM PC that already has ARM64 Python 3.11 it counts that as installed and adds nothing.
  # The python.org installer goes to its own folder (Python311), next to an ARM64 one (Python311-arm64).
  Write-Host "Needs 64-bit (x64) Python 3.11. Installing it from python.org (just for you, no admin)..."
  $installer = Join-Path $env:TEMP "python-3.11.9-amd64.exe"
  Invoke-WebRequest "https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe" -OutFile $installer -UseBasicParsing
  $sig = Get-AuthenticodeSignature $installer
  if ($sig.Status -ne "Valid" -or $sig.SignerCertificate.Subject -notmatch "Python Software Foundation") {
    throw "The Python installer's signature didn't check out; not running it."
  }
  Start-Process $installer -Wait -ArgumentList "/quiet", "InstallAllUsers=0", "PrependPath=0", "Include_launcher=0", "Include_test=0", "Shortcuts=0"
  Remove-Item $installer -ErrorAction SilentlyContinue
  $Py = "$env:LOCALAPPDATA\Programs\Python\Python311\python.exe"
  if (-not (Test-X64Python $Py)) { throw "Couldn't find x64 Python 3.11 after installing it. Install it from python.org (Windows installer (64-bit)) and run this again." }
}
Write-Host "Using $Py"

if (-not (Test-Path ".venv\Scripts\python.exe")) { & $Py -m venv .venv }
$V = Resolve-Path ".venv\Scripts\python.exe"
& $V -m pip install -q --upgrade pip
& $V -m pip install -q -r requirements.txt
if ($LASTEXITCODE) { throw "pip install failed" }
# comtypes builds its UI Automation wrapper on first use; do it now rather than on Donkey's first key tap
& $V -c "import comtypes.client; comtypes.client.GetModule('UIAutomationCore.dll')"

# EmbeddingGemma runs in llama-server; memory search doesn't work without it.
if (-not (& $V -X utf8 -c "from donkey import embed; print(embed.llama_binary() or '')")) {
  if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
    throw "Donkey needs llama.cpp for memory search, and winget isn't here to install it. Install winget (App Installer, from the Microsoft Store) and run this again."
  }
  winget install --id ggml.llamacpp -e --accept-package-agreements --accept-source-agreements
  if (-not (& $V -X utf8 -c "from donkey import embed; print(embed.llama_binary() or '')")) {
    throw "Installed llama.cpp, but llama-server.exe isn't where Donkey looks. Open a new terminal and run this again."
  }
}

if (-not $NoModels) {
  Write-Host "Fetching EmbeddingGemma into data\models (310 MB)..."
  # Same repo, file and pinned revision Donkey loads; importing donkey.config points HF_HUB_CACHE at data\models.
  & $V -X utf8 -c "from donkey import config, embed; from huggingface_hub import hf_hub_download; print(hf_hub_download(embed.GGUF_REPO, embed.GGUF_FILE, revision=embed.GGUF_REVISION))"
}

Write-Host ""
Write-Host "Done. Next:"
Write-Host "  .venv\Scripts\python -m donkey doctor"
Write-Host "  .venv\Scripts\pythonw -m donkey app"
