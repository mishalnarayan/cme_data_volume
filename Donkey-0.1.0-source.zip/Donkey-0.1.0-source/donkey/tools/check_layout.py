"""Score OCR layout against hand-checked screenshots: python tools/check_layout.py [shots dir].

The shots (and expect.json, what a correct layout must satisfy for each) live outside the repo,
in gadha/ocr-shots: they hold private screen text. Recognition runs once per shot and is cached
as JSON next to them, so a layout change can be re-scored in a second.
"""
import dataclasses
import json
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from donkey import ocr  # noqa: E402

SHOTS = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else pathlib.Path(__file__).resolve().parents[2] / "ocr-shots")


def load(path: pathlib.Path):
    return ocr.load_image(path)


def boxes_of(path: pathlib.Path, image) -> list:
    cache = path.with_suffix(".boxes.json")
    if not cache.exists():
        cache.write_text(json.dumps([dataclasses.asdict(b) for b in ocr.recognize(image)]))
    return [ocr.Box(**b) for b in json.loads(cache.read_text())]


def check(text: str, want: dict) -> list[str]:
    lines = text.splitlines()
    find = lambda s: [ln for ln in lines if s in ln]
    first = lambda s: next((i for i, ln in enumerate(lines) if s in ln), None)
    bad = []
    for s in want.get("own", []):
        if not any(ln.lstrip().startswith("→") for ln in find(s)):
            bad.append(f"not marked own: {s!r}")
    for s in want.get("other", []):
        if any(ln.lstrip().startswith("→") for ln in find(s)):
            bad.append(f"marked own: {s!r}")
    for a, b in want.get("apart", []):
        if any(a in ln and b in ln for ln in lines):
            bad.append(f"glued: {a!r} + {b!r}")
    for a, b in want.get("together", []):
        if not any(a in ln and b in ln for ln in lines):
            bad.append(f"split: {a!r} / {b!r}")
    for a, b in want.get("before", []):
        i, j = first(a), first(b)
        if i is None or j is None or i > j:
            bad.append(f"order: {a!r} should come before {b!r}")
    return bad


def main() -> None:
    expect = json.loads((SHOTS / "expect.json").read_text())
    shots = sorted(SHOTS.glob("*.png"))
    total = failed = 0
    for n, path in enumerate(shots, 1):
        key = path.stem if path.stem in expect else f"{n:02d}"  # the first shots are known by number
        if key not in expect:
            continue
        image = load(path)
        text = ocr.layout(boxes_of(path, image), image)
        (SHOTS / f"{key}.layout.txt").write_text(text)
        bad = check(text, expect[key])
        n_checks = sum(len(v) for k, v in expect[key].items() if not k.startswith("_"))
        total += n_checks
        failed += len(bad)
        print(f"{key} {n_checks - len(bad)}/{n_checks}" + "".join(f"\n     {b}" for b in bad))
    print(f"\n{total - failed}/{total} checks pass")


if __name__ == "__main__":
    main()
