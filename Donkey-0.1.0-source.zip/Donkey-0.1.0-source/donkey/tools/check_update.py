"""Self-check for the Update button's rules: an hour written up before it settled is written up again
once it has, its claims are read again, and only one memory pass runs at a time."""
import pathlib, sys, tempfile, time; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from donkey import chronicle, claims, memory
from donkey.db import DB

db = DB(pathlib.Path(tempfile.mkdtemp()) / "check.db")
now = time.time()
early, settled = chronicle.hour_key(now - 3 * 3600), chronicle.hour_key(now - 4 * 3600)
for key in (early, settled):
    start, end = chronicle.hour_bounds(key)
    db.execute("INSERT INTO snapshots (app, window_title, content, captured_at, last_seen_at) VALUES ('App', 'w', 'x', ?, ?)",
               (start + 60, start + 120))
    made = start + 1800 if key == early else end + chronicle.SETTLE_S + 5  # Update mid-hour / the timer
    db.execute("INSERT INTO chronicle (period, period_key, summary, snapshot_count, model, created_at) "
               "VALUES ('hour', ?, 's', 1, 'm', ?)", (key, made))
    db.execute("INSERT INTO claim_hours (hour_key, claims, done_at) VALUES (?, 0, ?)", (key, made + 10))
assert chronicle.pending_hours(db, now) == [early], chronicle.pending_hours(db, now)
assert claims.pending(db, now) == []
db.execute("UPDATE chronicle SET created_at = ? WHERE period_key = ?", (now, early))  # written up again
assert claims.pending(db, now) == [early], claims.pending(db, now)
memory._busy.acquire()
assert memory.update_now(None, db) is None  # the timer's pass is running
memory._busy.release()
print("update ok")
