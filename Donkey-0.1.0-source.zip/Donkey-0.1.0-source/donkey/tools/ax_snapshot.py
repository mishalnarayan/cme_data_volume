"""Save an app's front window as a layout test case: python tools/ax_snapshot.py "Google Chrome" ig-anmol

Writes <shots>/ax-<name>.png (the window's picture) and ax-<name>.boxes.json (its text elements
from the accessibility tree, at their exact places), which tools/check_layout.py scores like an
OCR'd screenshot; add the case to expect.json under "ax-<name>". The shots folder holds private
screen text and stays out of the repo.
"""
import ctypes
import dataclasses
import json
import os
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from donkey import ax, ocr, web  # noqa: E402

SHOTS = pathlib.Path(__file__).resolve().parents[2] / "ocr-shots"


def _windows_of(app_name: str) -> list[int]:
    """Visible top-level windows whose app (the exe's description, as Donkey names apps) is app_name."""
    found: list[int] = []

    def visit(hwnd, _):
        if ctypes.windll.user32.IsWindowVisible(hwnd) and ax.window_title(hwnd):
            path = ax.process_path(ax._owner_pid(hwnd))
            if path and app_name.lower() in (ax.app_name(path).lower(), os.path.basename(path).lower()):
                found.append(hwnd)
        return True
    ctypes.windll.user32.EnumWindows(ax.WNDENUMPROC(visit), 0)
    return found


def main() -> None:
    app_name, name = sys.argv[1], sys.argv[2]
    hwnds = _windows_of(app_name)
    if not hwnds:
        sys.exit(f"{app_name} has no window open")
    hwnd = hwnds[0]  # EnumWindows goes front to back
    ax._wake_chromium(hwnd)  # Chromium builds its tree only when asked
    window = ax.from_handle(hwnd)
    root = ax.find_web_area(window) or window
    boxes = web.text_boxes(root, window)
    image = ocr._grab(hwnd)
    if image is None:
        sys.exit("can't take the window's picture")
    SHOTS.mkdir(parents=True, exist_ok=True)
    png = SHOTS / f"ax-{name}.png"
    ocr.save_image(image, png)
    png.with_suffix(".boxes.json").write_text(json.dumps([dataclasses.asdict(b) for b in boxes]))
    marked = ocr.layout(boxes, image)
    print(f"{png.name}: {len(boxes)} text elements, {sum(b.own for b in boxes)} the user's\n\n{marked[-1500:]}")


if __name__ == "__main__":
    main()
