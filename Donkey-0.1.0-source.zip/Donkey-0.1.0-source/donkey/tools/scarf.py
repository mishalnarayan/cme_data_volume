"""Generate the scarf tails for creature.svg: ribbons whose outline ripples (SMIL path morphs).

Prints the <g id="dk-scarf-tails"> block; paste it over the one in donkey/assets/creature.svg.
Usage: python3 tools/scarf.py > /tmp/tails.svg
"""
import math, sys

N = 8          # samples per edge
FRAMES = 8     # keyframes per cycle (the last repeats the first)


def f(v):
    return f"{v:.2f}".rstrip("0").rstrip(".")


def ribbon(start, angle, length, w0, w1, amp, waves, bend, phase, fringe=1.0):
    """Outline points (top edge, fringe, bottom edge) of a ribbon at wave phase `phase`."""
    dx, dy = math.cos(angle), math.sin(angle)
    nx, ny = -dy, dx
    def center(t):
        off = bend * t * t + amp * (t ** 1.3) * math.sin(2 * math.pi * waves * t - phase)
        return (start[0] + dx * length * t + nx * off, start[1] + dy * length * t + ny * off)
    ts = [i / (N - 1) for i in range(N)]
    pts = [center(t) for t in ts]
    top, bot, tang = [], [], []
    for i, t in enumerate(ts):
        a, b = pts[max(i - 1, 0)], pts[min(i + 1, N - 1)]
        tx, ty = b[0] - a[0], b[1] - a[1]
        L = math.hypot(tx, ty); tx, ty = tx / L, ty / L
        w = (w0 + (w1 - w0) * t) / 2
        top.append((pts[i][0] - ty * w, pts[i][1] + tx * w))
        bot.append((pts[i][0] + ty * w, pts[i][1] - tx * w))
        tang.append((tx, ty))
    # fringe: little tassels across the end
    tx, ty = tang[-1]
    fr = []
    k = 5
    for j in range(1, k * 2):
        u = j / (k * 2)
        x = top[-1][0] + (bot[-1][0] - top[-1][0]) * u
        y = top[-1][1] + (bot[-1][1] - top[-1][1]) * u
        out = fringe if j % 2 else 0.15
        fr.append((x + tx * out, y + ty * out))
    return top, fr, bot, center, tang


def smooth(points):
    """Catmull-Rom through points -> cubic Bezier commands (without the initial M)."""
    cmds = []
    for i in range(len(points) - 1):
        p0 = points[max(i - 1, 0)]; p1 = points[i]; p2 = points[i + 1]; p3 = points[min(i + 2, len(points) - 1)]
        c1 = (p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6)
        c2 = (p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6)
        cmds.append(f"C{f(c1[0])} {f(c1[1])} {f(c2[0])} {f(c2[1])} {f(p2[0])} {f(p2[1])}")
    return " ".join(cmds)


def outline(r):
    top, fr, bot, _, _ = r
    d = f"M{f(top[0][0])} {f(top[0][1])} " + smooth(top)
    d += " " + " ".join(f"L{f(x)} {f(y)}" for x, y in fr + [bot[-1]])
    d += " " + smooth(bot[::-1]) + " Z"
    return d


def band(r, t0, t1):
    """A cross stripe between t0 and t1 along the ribbon (as a quad following the edges)."""
    top, _, bot, _, _ = r
    def at(edge, t):
        x = t * (N - 1); i = min(int(x), N - 2); u = x - i
        return (edge[i][0] + (edge[i + 1][0] - edge[i][0]) * u, edge[i][1] + (edge[i + 1][1] - edge[i][1]) * u)
    a, b, c, d = at(top, t0), at(top, t1), at(bot, t1), at(bot, t0)
    return f"M{f(a[0])} {f(a[1])} L{f(b[0])} {f(b[1])} L{f(c[0])} {f(c[1])} L{f(d[0])} {f(d[1])} Z"


def shine(r):
    """A soft highlight along the ribbon's upper third."""
    _, _, _, center, tang = r
    pts = []
    for i in range(N - 1):
        t = i / (N - 1)
        x, y = center(t)
        pts.append((x, y))
    top = r[0]
    pts = [((p[0] * 2 + q[0]) / 3, (p[1] * 2 + q[1]) / 3) for p, q in zip(pts, top)]
    return f"M{f(pts[0][0])} {f(pts[0][1])} " + smooth(pts[: N - 2])


def anim(attr_fn, dur, offset):
    vals = ";".join(attr_fn(2 * math.pi * k / (FRAMES - 1) + offset) for k in range(FRAMES))
    return vals


def tail(spec, dur, fill, offset, gid):
    mk = lambda ph: ribbon(phase=ph, **spec)
    static = mk(offset)
    parts = []
    for kind, color, extra in (("outline", fill, ""), ("band1", "#ffe3c4", ' opacity=".9"'),
                               ("band2", "#ffe3c4", ' opacity=".9"'), ("shine", None, "")):
        if kind == "outline":
            fn = lambda ph: outline(mk(ph))
        elif kind == "band1":
            fn = lambda ph: band(mk(ph), .62, .7)
        elif kind == "band2":
            fn = lambda ph: band(mk(ph), .76, .82)
        else:
            fn = lambda ph: shine(mk(ph))
        vals = ";".join(fn(2 * math.pi * k / (FRAMES - 1) + offset) for k in range(FRAMES))
        a = f'<animate attributeName="d" dur="{dur}" repeatCount="indefinite" values="{vals}"/>'
        if kind == "shine":
            parts.append(f'<path d="{fn(offset)}" stroke="#ff9a5c" stroke-width=".55" stroke-linecap="round" '
                         f'fill="none" opacity=".75">{a}</path>')
        else:
            parts.append(f'<path d="{fn(offset)}" fill="{color}"{extra}>{a}</path>')
    return f'<g class="{gid}">' + "".join(parts) + "</g>"


# phase advances with time, so subtracting it in sin() sends the wave from knot to tip
deg = math.radians
IDLE = [
    (dict(start=(32.8, 38.8), angle=deg(114), length=13, w0=3.4, w1=3.1, amp=1.6, waves=.75, bend=-2.0), "#d94d18", 0.0),
    (dict(start=(34.8, 39.6), angle=deg(86), length=10.5, w0=3.2, w1=2.9, amp=1.3, waves=.75, bend=1.4), "#c24113", 2.2),
]
RUN = [
    (dict(start=(32.6, 36.4), angle=deg(190), length=17, w0=3.4, w1=3.0, amp=1.5, waves=1.0, bend=-1.4), "#d94d18", 0.0),
    (dict(start=(32.8, 38.4), angle=deg(170), length=14, w0=3.2, w1=2.8, amp=1.4, waves=1.0, bend=1.2), "#c24113", 1.9),
]
out = ['  <!-- scarf ends: soft ribbons whose outline ripples from the knot to the fringe (SMIL), hanging and\n'
       '       swaying when idle, streaming back and flapping fast while galloping -->',
       '  <g id="dk-scarf-tails">', '    <g id="dk-scarf-idle">']
for spec, fill, off in IDLE[::-1]:
    out.append("      " + tail(spec, "2.8s", fill, off, "scarf-end"))
out.append('    </g>')
out.append('    <g id="dk-scarf-run" display="none">')
for spec, fill, off in RUN[::-1]:
    out.append("      " + tail(spec, ".42s", fill, off, "scarf-end"))
out.append('    </g>')
out.append('  </g>')
sys.stdout.write("\n".join(out) + "\n")
