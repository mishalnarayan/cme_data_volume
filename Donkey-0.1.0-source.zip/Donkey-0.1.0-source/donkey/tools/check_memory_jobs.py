"""Self-check for the memory pass: a botched reply skips only its own job (an outage still stops the
pass), mail and to-dos run with nudges off, and observed habits are written only when they change
(ids kept, the user's turn-off kept). No model calls."""
import dataclasses, pathlib, sys, tempfile, time; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from donkey import attention, chronicle, config, learn, llm, loops, memory, nudges
from donkey.db import DB

db = DB(pathlib.Path(tempfile.mkdtemp()) / "check.db")
cfg = dataclasses.replace(config.Config(), nudges_enabled=False)


def no_model(*a, **k):
    raise AssertionError("unexpected model call")


llm.parse = llm.complete = no_model
llm.has_credentials = lambda: True

# _job: botched -> skipped and counted, given up after MAX_TRIES; an outage raises; success resets.
cut = llm.LLMError("incomplete structured output (cut off)")
def botch(): raise cut
for i in range(memory.MAX_TRIES):
    assert memory._job("t", botch) is False
assert memory._gave_up("t")
try:
    memory._job("u", lambda: (_ for _ in ()).throw(llm.LLMError("Out of credits (402): x")))
    raise AssertionError("an outage must stop the pass")
except llm.LLMError:
    pass
memory._failures["v"] = 2
assert memory._job("v", lambda: None) and "v" not in memory._failures

# run_pass: a botched hour doesn't stop the pass; mail and to-dos run with nudges off.
memory._failures.clear()
ran = []
chronicle.pending_hours = lambda db, now: ["2026-01-01T09", "2026-01-01T10"]
chronicle.process_hour = lambda cfg, db, key: botch() if key.endswith("09") else ran.append(key)
attention.process_queue = lambda cfg, db: ran.append("mail")
loops.needs_run = lambda db: True
loops.run_tracker = lambda cfg, db: ran.append("to-dos")
nudges_ran = []
real_nudges = nudges.run_pass
nudges.run_pass = lambda cfg, db: (nudges_ran.append(1), real_nudges(cfg, db))
done = memory.run_pass(cfg, db)
assert done["hours"] == 1 and ran[:1] == ["2026-01-01T10"] and "mail" in ran and "to-dos" in ran, (done, ran)
assert nudges_ran  # called, and returns at once because nudges are off

# observe_style: a daily read, then quiet passes change nothing; the user's turn-off survives.
msgs = [("Anna", f"hey there message number {i} ok") for i in range(15)]
learn.own_messages = lambda db, since: {("Chrome", "web.whatsapp.com"): msgs}
bullets = ["Starts with hey (with Anna)", "No sign-off (with Anna)", "Lowercase (with Anna)"]
learn.llm.parse = lambda *a, **k: learn.ObservedStyle(bullets=bullets)
first = learn.observe_style(cfg, db, force=True)
rows = lambda: {r["rule"]: (r["id"], r["enabled"]) for r in
                db.query("SELECT id, rule, enabled FROM style_rules WHERE source = 'observed'")}
before = rows()
assert first == 4 and len(before) == 4, (first, before)
learn.llm.parse = no_model
assert learn.observe_style(cfg, db) == 0 and rows() == before  # quiet pass: nothing rewritten
learn.disable_rule(db, before[bullets[0]][0])
db.execute("UPDATE style_rules SET enabled = 0, retired = 'repeats #99' WHERE id = ?", (before[bullets[1]][0],))
assert learn.observe_style(cfg, db) == 0
assert rows()[bullets[0]][1] == 0 and rows()[bullets[1]][1] == 0  # both stay off between daily reads
learn.llm.parse = lambda *a, **k: learn.ObservedStyle(bullets=bullets[:2] + ["Uses haha (with Anna)"])
db.execute("INSERT INTO style_rules (rule, scope, source, evidence, created_at, updated_at) "
           "VALUES (?, 'web.whatsapp.com', 'observed', 1, 0, 0)", (bullets[0],))  # a stray duplicate
assert learn.observe_style(cfg, db, force=True) == 3  # duplicate gone, Lowercase gone, haha added
after = rows()
assert after[bullets[0]] == (before[bullets[0]][0], 0)  # same id, still off: the user's choice
assert after[bullets[1]] == (before[bullets[1]][0], 1)  # back on, for consolidate to check again
assert bullets[2] not in after and "Uses haha (with Anna)" in after
print("memory jobs ok")
