"""Self-check for loops.person_lines: the chat where a person wrote beats newer screens that only list
their name, and Donkey's own log lines never count as their messages."""
import pathlib, sys, tempfile; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from donkey import loops
from donkey.db import DB

db = DB(pathlib.Path(tempfile.mkdtemp()) / "check.db")
add = lambda t, content: db.execute("INSERT INTO snapshots (app, window_title, content, captured_at, last_seen_at) "
                                    "VALUES ('App', 'w', ?, ?, ?)", (content, t, t))
add(100, "Chat\nBasu, Ananya 4:59 PM\nok, cool\nType a message")
for t in range(101, 120):  # newer screens that only name her: a contact list, and Donkey's log in a terminal
    add(t, "\n".join(f"Contact {i}\nBasu, Ananya" for i in range(8)) +
        "\n14:14:53 INFO donkey.wiki: wiki page regenerated: ananya-basu 12:00")
lines = loops.person_lines(db, "Ananya Basu", 0)
assert lines[:2] == ["Chat", "Basu, Ananya 4:59 PM"] and "ok, cool" in lines, lines
assert not any("donkey.wiki" in ln for ln in lines), lines
print("person_lines ok")
