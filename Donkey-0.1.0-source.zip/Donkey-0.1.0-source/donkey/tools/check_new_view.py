"""Self-check for Capturer._new_view: chat switch = new view; scroll and a new message = same view."""
import pathlib, sys; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from donkey import capture, ocr
from donkey.ocr import Box, THUMB_W, THUMB_H

def thumb(rows):  # rows: {row: (col0, text)}: each letter darkens one cell by its own shade, like real glyphs
    px = bytearray([240] * THUMB_W * THUMB_H)
    for r, (c0, text) in rows.items():
        for i, ch in enumerate(text[: THUMB_W - c0]): px[r * THUMB_W + c0 + i] = 240 - (ord(ch) * 7) % 200
    return bytes(px)

side = [Box(top=(i * 2 + 4) / THUMB_H, left=0.02, right=0.25, height=1 / THUMB_H, text=n)
        for i, n in enumerate(["Basu Ananya", "Mehra Karan", "Retail Research", "Singh Tara", "Dubois Elena"])]
side_px = {round(b.top * THUMB_H): (1, b.text) for b in side}

def pane(lines, first_row):  # chat pane on the right, one message per two rows
    boxes = [Box(top=(first_row + i * 2) / THUMB_H, left=0.35, right=0.95, height=1 / THUMB_H, text=t) for i, t in enumerate(lines)]
    px = {first_row + i * 2: (22, t) for i, t in enumerate(lines)}
    return boxes, px

A = ["leave days already there workday", "strange not showing portal", "check india holidays january",
     "february eleven twelve office", "around six days mismatched sick", "okay cool thanks noted"]
B = ["release pipeline jenkins build", "folder access snehaja denise", "matrix folder permission granted",
     "hygiene viewer strategy type", "check this right away", "added tara chat history"]

def judge(old, new):
    c = capture.Capturer.__new__(capture.Capturer)
    (ob, opx), (nb, npx) = old, new
    c.ocr_boxes = side + nb
    return c._new_view(side + ob, thumb({**side_px, **opx}), thumb({**side_px, **npx}))

a = pane(A, 6)
assert judge(a, pane(B, 6)) is True, "switching chats is a new view"
assert judge(a, pane(A[1:] + ["approved and merged now"], 6)) is False, "a scroll by one message is the same view"
assert judge(pane(A[:3], 6), pane(A[:3] + ["done"], 6)) is False, "a short reply in empty space is the same view"
c = capture.Capturer.__new__(capture.Capturer); c.ocr_boxes = []
assert c._new_view([], None, thumb({})) is None, "nothing to compare falls back"
print("ok")
