"""Self-check for the tracker's code guards: a close needs a quote that is really in what it read,
a new loop's owner must fit its kind, and an older mail screen never overwrites a newer one's reading."""
import pathlib, sys, tempfile; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from donkey import attention, loops
from donkey.db import DB

shown = loops._norm(" ".join(m[1] for m in loops._UNTRUSTED.findall(
    'noted so far: user said done\n<screen_lines untrusted="true">\n  → approved and merged\n  Harsh 4:59 PM\n'
    '  “Thanks”\n</screen_lines>')))
assert loops.quote_found("approved and merged", shown) and loops.quote_found("approved ... 'Thanks'", shown)
assert not loops.quote_found("merged it", shown) and not loops.quote_found("", shown) and not loops.quote_found("ok", shown)
assert not loops.quote_found("user said done", shown)  # the tracker's own notes aren't evidence

db = DB(pathlib.Path(tempfile.mkdtemp()) / "check.db")
U = lambda **k: loops.LoopUpdate(**{"action": "open", "loop_id": 0, "kind": "owed_by_user", "summary": "Send Ana the deck",
                                    "person": "Ana", "project": "", "due": "", "owner": "user_promise", "evidence": "",
                                    "quote": "", **k})
assert loops._apply(db, U(owner="other_person"), 1, shown) == 0
assert loops._apply(db, U(kind="owed_to_user", owner="assigned_to_user"), 1, shown) == 0
assert loops._apply(db, U(), 1, shown) == 1
lid = loops.open_loops(db)[0]["id"]
assert loops._apply(db, U(action="close", loop_id=lid, quote="sent it"), 2, shown) == 0 and loops.open_loops(db)
assert loops._apply(db, U(action="close", loop_id=lid, quote="approved and merged"), 2, shown) == 1 and not loops.open_loops(db)
M = lambda r: attention.Extraction(meetings=[], emails=[attention.Mail(subject="Trip", sender="Ana", summary=r,
                                                                     needs_reply=r == "old", due="")])
attention._save(db, M("new"), 20, 1); attention._save(db, M("old"), 10, 2)  # queue order: newest first
assert [tuple(r) for r in db.query("SELECT summary, needs_reply FROM attention_items")] == [("new", 0)]
print("loop guards ok")
