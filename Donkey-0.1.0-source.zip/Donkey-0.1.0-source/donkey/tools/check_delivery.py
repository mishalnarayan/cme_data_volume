"""Self-check for two delivery and calendar guards, with no real fields or model calls:
- a paste counts only when the field shows it changed (else focus it, paste once more, else give up);
- a meeting moved, or gone from a calendar day shown in full, stops being active."""
import pathlib, sys, tempfile; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from donkey import attention, ax, deliver
from donkey.db import DB
from donkey.field import Target

# ---- paste: fake keyboard, field and clipboard; `fields` is what the field reads after each Ctrl+V
app = ax.FrontApp(pid=1, name="Google Chrome", bundle_id="chrome.exe", element=None)
pastes, focused = [], []
deliver.Clipboard = type("C", (), {"put": lambda s, t: None, "restore": lambda s: None})
deliver._select_slice = lambda t: True
deliver.ax.front_app = lambda: app
deliver.ax.set_attr = lambda el, name, v: focused.append(name) or True
deliver.time.sleep = lambda s: None
deliver.PASTE_WAIT_S = 0


def paste(fields, value="hi there", text="Hi there!"):
    pastes.clear(); focused.clear()
    deliver._chord = lambda vk: pastes.append(vk) if vk == deliver.VK_V else None
    deliver._wait_for_value = lambda el, accept, s: fields[len(pastes) - 1]
    t = Target(app=app, element=None, value=value, kind="draft", slice_start=0, slice_end=len(value))
    return deliver._paste(t, text, lambda: False)


assert paste(["Hi there!"]) == "paste" and len(pastes) == 1 and not focused         # landed first time
assert paste(["hi there", "Hi there!"]) == "paste" and len(pastes) == 2 and focused  # refocus, then landed
assert paste(["hi there", "hi there"]) is None and len(pastes) == 2                  # never landed: clipboard
assert paste(["hi there"], text="hi there") == "paste" and len(pastes) == 1          # nothing to change

# ---- meetings
db = DB(pathlib.Path(tempfile.mkdtemp()) / "check.db")
for sid, app_name, domain in ((1, "Google Chrome", "calendar.google.com"), (2, "Microsoft Outlook", None),
                              (3, "Google Chrome", "calendar.google.com"), (4, "Mail", None)):
    db.execute("INSERT INTO snapshots (id, app, domain, window_title, content, captured_at, last_seen_at) "
               "VALUES (?, ?, ?, '', '', 0, 0)", (sid, app_name, domain))
M = lambda title, at, moved="": attention.Meeting(title=title, starts_at=at, ends_at="", participants=[], location="",
                                                  status="confirmed", moved_from=moved)
X = lambda meetings, days=(): attention.Extraction(meetings=meetings, emails=[], calendar_days=list(days))
active = lambda: sorted((r["title"], r["status"]) for r in db.query("SELECT title, status FROM attention_items"))

attention._save(db, X([M("Sync", "2026-11-03T10:00"), M("Lunch w/ Ana", "2026-11-03T13:00")]), 1, 1)
attention._save(db, X([M("Board", "2026-11-03T15:00")]), 2, 1)  # another calendar (Outlook)
# The Google day view later shows Sync at 11 and no lunch: Sync at 10 and lunch are gone; Outlook's Board stays.
attention._save(db, X([M("Sync", "2026-11-03T11:00")], ["2026-11-03"]), 3, 2)
assert active() == [("Board", "active"), ("Lunch w/ Ana", "gone"), ("Sync", "active"), ("Sync", "gone")], active()
# An updated invitation names the old time: that occurrence moves.
attention._save(db, X([M("Sync", "2026-11-04T09:00", moved="2026-11-03T11:00")]), 4, 3)
rows = {(r["starts_at"], r["status"]) for r in db.query("SELECT starts_at, status FROM attention_items WHERE title = 'Sync'")}
assert sorted(s for _, s in rows) == ["active", "gone", "moved"], rows
# A full list at the cap proves nothing about missing events.
full = [M(f"M{i}", "2026-11-05T08:00") for i in range(attention.MAX_ITEMS)]
attention._save(db, X([M("Keep", "2026-11-05T09:00")]), 1, 4)
attention._save(db, X(full, ["2026-11-05"]), 3, 5)
assert db.query("SELECT status FROM attention_items WHERE title = 'Keep'")[0]["status"] == "active"
print("delivery and meeting guards ok")
