# Donkey

A local screen memory for Windows 10 and 11.
The project is one self-contained folder. Settings are in `config.json` next to this README
(written with defaults on first run). Everything Donkey writes is in `data\`:

| In `data\` | What it is |
|---|---|
| `donkey.db` (+ `-wal`, `-shm`) | SQLite: screens, chronicle, wiki, claims, chats, and the search vectors |
| `donkey.log` | the log |
| `profile.md`, `digest.txt`, `delivery.json`, `ui.json`, `window.json` | the "About you" profile, the memory digest, learned paste methods, window state |
| `memory-map.html` | the memory map from `donkey map` (the app shows it in its Memory tab) |
| `eval\` | eval questions, saved rewrites, runs, and the scenario test's separate home |
| `models\` | downloaded embedding models (EmbeddingGemma 2, the small fallback) |

`config.json` (your API keys) and `data\` (your memory) are git-ignored: don't share them. To give
someone the project, share the code (a clone, or `git archive -o donkey.zip HEAD` from the repo
root, which leaves both out); Donkey creates both on their first run and opens the welcome. Their
name comes from their Windows account. `DONKEY_HOME` moves `data\` elsewhere, with its own
`config.json` inside. The installed app (see `..\donkey-build`) keeps both in `%APPDATA%\Donkey`.

This is the Windows version. The macOS version is a separate project; the two don't share code
paths (UI Automation here, the Accessibility API there; Qt here, AppKit there).

## Setup

Donkey runs on **64-bit x64 Python 3.11**. On an ARM PC (Snapdragon) use x64 Python too: Qt's web
engine has no ARM64 build for Windows yet, and Windows 11 runs x64 programs on ARM through its
built-in emulation. (Windows 10 on ARM can't run x64 programs.)

```powershell
powershell -ExecutionPolicy Bypass -File setup.ps1
```

That finds (or installs, from python.org) x64 Python 3.11, makes `.venv`, installs
`requirements.txt`, installs llama.cpp with winget (`winget install ggml.llamacpp`: it runs
EmbeddingGemma 2, which memory search needs; setup stops if it can't install it) and downloads the
model into `data\models`. By hand:

```powershell
py -3.11-64 -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
winget install ggml.llamacpp
```

**Nothing to switch on.** Windows has no privacy switches for what Donkey does: any app may read
other windows through UI Automation, watch the keyboard with a hook, and take a picture of a
window. Two limits come from Windows itself:

- **Apps running as administrator** can't be read or typed into by an app that isn't (Windows'
  "UIPI"). Donkey says so when you tap the key in one, and leaves the rewrite on the clipboard.
- **Text recognition** (for windows that don't share their text, like Remote Desktop or Citrix)
  uses Windows' own recogniser, one per language: Settings → Time & language → Language & region,
  add the language with its optical character recognition. English is there on most PCs.

**First run.** `donkey app` on a fresh copy opens with a full-screen greeting, then a welcome in
the Donkey window: what Donkey does (a short animated demo with your own Donkey key), where your
data goes, a model (Settings, in place), your name, a practice rewrite in a text box on the page,
and what fills in when. Quitting halfway picks up at the same step next launch
(`data\onboarding.json`); copies that already have memory skip it. Watch it again from Settings →
Welcome, or **Welcome tour** in the tray menu's More.

Until Donkey has a few days on you, Home shows a "getting to know you" card (screens read, first
hour written up, people and projects, first rewrite, your usual) that ticks off as each one
happens, and the empty Timeline and memory map say what will appear there and when.

**Model provider.** Pick it in Settings: the gear in the Donkey window (next to Home, Timeline and
Memory), Ctrl+, there, or **Settings…** in the tray menu. It opens by itself on first run when no
model is set up. The top of the page shows the model in use; so does the top of the tray menu.
Providers: OpenRouter, OpenAI, Claude, LM Studio, or any other OpenAI-compatible server (Ollama,
Groq, a proxy). Paste a key, pick a model from the provider's own list (searchable;
OpenRouter's shows price and context), and **Try it** sends one tiny request. Save tests first,
writes `config.json`, and switches everything over without a restart. Underneath, every model
setting is in `config.json`: a block per provider (endpoint, key,
model, what the chat picker offers) and one key, `llm.use`, that picks the block in use. One model
does everything (rewrites, background memory jobs, chat) unless a block overrides a job. The
default is deepseek-v4.1-flash on OpenRouter. Keys starting with `_` are notes and are ignored.

```json
"llm": { "use": "openrouter", "temperature": 0.1, "max_tokens": 8000, "timeout": 180 },
"providers": {
  "openrouter": {
    "kind": "openai",
    "endpoint": "https://openrouter.ai/api/v1/chat/completions",
    "api_key": "sk-or-…",
    "model": "deepseek/deepseek-v4.1-flash",
    "models": ["deepseek/deepseek-v4.1-flash"],
    "reasoning_effort": "none",
    "extra": { "provider": { "sort": "latency" } }
  },
  "lmstudio": {
    "kind": "openai",
    "endpoint": "http://localhost:1234/v1/chat/completions",
    "model": "qwen/qwen3-8b",
    "models": ["qwen/qwen3-8b"],
    "reasoning_effort": "",
    "timeout": 600
  },
  "anthropic": { "kind": "anthropic", "model": "claude-haiku-5-5", "models": ["claude-haiku-5-5"] }
}
```

Set `"use": "lmstudio"` and restart to run on this PC with LM Studio's server (no key needed;
put the model id LM Studio shows). `kind` is `openai` (any OpenAI-compatible endpoint) or
`anthropic` (key from `api_key`, `ANTHROPIC_API_KEY` or `data\anthropic-key`). Optional per
block: `api_key_env`, `rewrite_model`, `memory_model`, `chat_model`, `timeout`, `temperature`,
`max_tokens`, `headers`, `extra`.

## The app

```powershell
.venv\Scripts\pythonw -m donkey app        # tray app: capture, memory, the rewrite key, the creature
```

Donkey lives in the system tray as its face (`donkey/assets/*.svg`, all original art, drawn black
on a light taskbar and white on a dark one). Click it (either button) for the menu, double-click it
for Home. The menu is kept short: a status line on top (green while remembering, orange while
paused, with the Donkey key and the model in use under it), then **Home**, **Timeline**, **Memory**
and **Chat** (Ctrl+1–4 in the Donkey window), **Inbox** (briefs and reminders with an unread
count, the next reminder and open to-dos), **Ideas for this window**, **Bring Donkey out**,
**Pause** (30 min / 1 h / until resumed), **More** (new chat, import, Donkey beside text fields,
open at sign-in, the welcome tour, the log), **Settings…** and **Quit**. The icon sleeps while
capture is paused and shows a dot when something new is in the inbox. Windows tucks new tray icons
into the overflow (^); drag Donkey's face onto the taskbar to keep it in sight.

**One window.** Home, Timeline, Memory and Chat are tabs of the Donkey window, with Settings
behind the gear: your chats and the inbox sit in Chat's sidebar, and a day on the Timeline can be
continued there. The Chat tab shows a dot when the inbox has something unread.

- **Tap Right Alt** (the Donkey key, `rewrite.key` in config.json: `right_alt`, `left_alt`,
  `right_control`, `left_control`, `right_shift`, `left_shift`, `right_windows` or `left_windows`)
  in any text field to write or rewrite what's there; no need to touch the donkey. The key is read
  from a low-level keyboard hook that passes every key on unchanged. A tap counts only when nothing
  else was pressed with it, so Alt+Tab or Ctrl+C never trigger it; while the Donkey key is Alt or
  Windows, tapping it alone no longer opens the app's menu or Start. On keyboards where right Alt
  is AltGr, that works too (its extra Ctrl is ignored).
- **While a rewrite runs**, the donkey (big eyes, spiky mohawk, orange scarf) gallops in place
  above the caret with a determined grin, ears and scarf streaming back, speed lines and dust.
  When the text lands it jumps and cheers; on errors it looks worried with a sweat drop. Click it
  (or press Esc) to cancel.
- **Beside the text field you're in**, the donkey waits, blinking, glancing around and swishing
  its tail, and grins when you hover it. Click it to rewrite,
  the same as tapping the key. Right-click it to hide it for 30 minutes or turn it off. It stays away from
  address bars, terminals, JetBrains IDEs and password fields.

- **Chat:** tap the Donkey key anywhere outside a text field (or pick *Chat* in the menu) to open
  the Donkey window on its Chat tab; tap it again to close it. Clicking one of Donkey's notifications,
  or an inbox item in the menu, opens that message in the chat so you can reply to it. See
  [Chat, reminders and imports](#chat-reminders-and-imports-milestone-6).

The creature windows never take focus, so your caret stays where it was; the clear space around
them lets clicks through to the window underneath. **Open at sign-in** puts a shortcut to Donkey in
your Startup folder (`shell:startup`); it starts quietly, without opening the window.

**Notifications** (briefs, reminders, "nothing to go on") are Windows notifications from Donkey,
with its face. Donkey registers itself for that on launch (in your user's registry, no
administrator rights needed), along with the `donkey://` links that clicking one opens. To mute
them: Settings → System → Notifications → Donkey.

## Commands

Start with `.venv\Scripts\python -m donkey doctor`. It checks the API key, the key, text
recognition and reading a field, step by step, and writes nothing into any field.


```powershell
.venv\Scripts\python -m donkey run -v          # capture + the rewrite key; Ctrl-C to stop
.venv\Scripts\python -m donkey run --no-capture
.venv\Scripts\python -m donkey rewrite         # rewrite the focused field once (after 3 s), no key needed
.venv\Scripts\python -m donkey peek            # read the front window once (after 3 s), store nothing
.venv\Scripts\python -m donkey search "query"  # snapshots + summaries + wiki, keyword and meaning
.venv\Scripts\python -m donkey memory          # run pending summaries / wiki / embeddings / digest now
.venv\Scripts\python -m donkey chronicle       # today's hourly summaries (--day YYYY-MM-DD, --week, --month, --year)
.venv\Scripts\python -m donkey day             # today's summary page (or: yesterday, YYYY-MM-DD)
.venv\Scripts\python -m donkey wiki [slug]     # list pages, or show one
.venv\Scripts\python -m donkey digest          # the background note rewrites get
.venv\Scripts\python -m donkey inbox           # briefs and reminders (--all shows skipped ones and why)
.venv\Scripts\python -m donkey loops           # open loops (--done ID, --drop ID)
.venv\Scripts\python -m donkey todo            # todo add TEXT / todo done ID
.venv\Scripts\python -m donkey meetings        # upcoming meetings seen in mail/calendar
.venv\Scripts\python -m donkey brief morning   # generate a brief now (or: evening)
.venv\Scripts\python -m donkey mcp-install claude-code   # or claude-desktop, cursor, print; --dry-run, --remove
.venv\Scripts\python -m donkey eval            # memory search on your questions + how rewrites fared
.venv\Scripts\python -m donkey eval --rewrites # replay saved rewrites with the current prompt and check them
.venv\Scripts\python -m donkey eval --scenarios --runs 5   # end to end: made-up memory, key presses, scored replies
.venv\Scripts\python -m donkey claims          # what changed this week (--days N); `claims 'walmart margin'` searches
.venv\Scripts\python -m donkey recent
.venv\Scripts\python -m donkey time --hours 8  # foreground time per app / domain
.venv\Scripts\python -m donkey projects        # time by project (--days 7); `projects rules`, `projects add NAME --title T`
.venv\Scripts\python -m donkey ignore add example.com   # never read it again and delete what was saved (app:Name, url:, title:, path:)
.venv\Scripts\python -m donkey ignore          # list your rules; `ignore remove X` reads it again
.venv\Scripts\python -m donkey pause 30        # minutes; no number = until resume
.venv\Scripts\python -m donkey resume
.venv\Scripts\python -m donkey ask "what did Maya send me?"   # the chat, in the terminal (--stream, --thread ID)
.venv\Scripts\python -m donkey remind "call mum" --at 5pm       # or --repeat daily|weekdays|weekly|interval, --days mon,fri, --every 45, --ask
.venv\Scripts\python -m donkey remind          # list them; --delete ID
.venv\Scripts\python -m donkey import $HOME\Downloads\chatgpt-export.zip   # or a Claude export, a notes folder, or: granola
.venv\Scripts\python -m donkey import          # what's been imported; --remove chatgpt
.venv\Scripts\python -m donkey profile         # the "About you" profile; --refresh, --undo, --reset, --history
.venv\Scripts\python -m donkey facts           # what you told the chat; --forget ID, --add, --distill
```

Settings live in `config.json`, logs in `data/donkey.log`.

## Capture (milestone 1)

Every `probe_interval_s` a cheap probe reads the front app, window title and focused
element. The window is read in full when the probe changes, and every `recheck_every_s` (2 s)
besides: a chat gaining a message or a list scrolling leaves the probe as it was.

- **Browsers** (Chrome, Edge, Brave, Firefox…): page text in one call through the page's UI
  Automation text pattern, the URL from the page's value.
- **Other apps**: the window's whole UI Automation tree fetched in one cross-process call (a
  cache request), then walked for text within a node and time budget. Chromium/Electron apps are
  asked (WM_GETOBJECT to their render widget) to build their tree first.

So that what you saw is never lost:

- **Reads are cheap; writes wait.** A read takes 4–30 ms here, and a window that reads slower
  is re-read less often (re-reading may take 2.5% of the time). A read that differs from the
  last one saved waits a tick to hold still, so a scroll or a burst of typing is one write where
  it stopped. The reads on the way are merged in, not dropped, and a window that never holds
  still (a ticking clock on the page) is saved every 5 s. An unchanged window is saved again
  every `walk_every_s`, which keeps time on page current.
- **Re-reads merge.** A re-read of the same view (app, title, URL, within
  `coalesce_window_s`) used to replace the saved text. Most windows give their whole text either
  way (Chrome hands over a 30k-character page however far you've scrolled), but chats drop older
  messages as new ones arrive and long lists keep only what's on screen. The saved row now keeps
  both reads in reading order (`textmerge.py`): text that left the view stays, small edits in one
  spot (a word typed, a counter ticking) take the new value. Past `max_chars`, a re-read that
  would lose a lot starts a row of its own.
- **Why not change events.** UI Automation can notify on changes, but browsers send little for a
  page adding and dropping messages; only `aria-live` regions reliably notify. Re-reading every
  2 s is more reliable, and cheap at a few tens of milliseconds a read.

On scripted screens (old → new): a chat that keeps 6 messages on screen and gains one every
3 s for 90 s, 6 → 30 of 30 kept; a 200-item list scrolled in bursts, 15 → 195 kept, in 7
writes; 20 s of typing, 19 → 4 writes; a remote desktop changing screen twice, 2 → 3 of 3
screens, still 3 recognitions. On the real Chrome page holding 6 messages, 11 were kept in
10 s.

### Windows the screen reader can't read

A remote desktop (Remote Desktop, Citrix, a VM), Phone Link or a shared screen is one picture to the screen
reader. Your hosted desktop averaged 77 characters a screen ("Hosted Desktop", a few menu
names), so nothing you did in it reached memory. When a window gives fewer than
`ocr_below_chars` (200), capture takes a picture of that window only (`PrintWindow`, which the
window paints itself, so windows on top of it don't get in) and reads it with Windows' own
on-device text recognition, Windows.Media.Ocr (`ocr.py`):

- The image stays in memory and is never written to disk; only the text is kept, after the same
  blocklist, private-window check and redaction as everything else.
- **Only when the picture changed.** Each re-read first takes a small grey picture of the
  window and compares it with the one at the last recognition: unchanged, the last text is
  reused; changing, it waits for it to hold still; three or more changed cells is a change, so a
  blinking caret isn't. One flat colour (a remote desktop gone black or locked) is skipped. At
  most one recognition every 3 s. Pixels must add 20 or more words the screen reader didn't
  give, so File Explorer and short dialogs are left alone.
- **Layout.** Side-by-side panes (a sidebar, a chat list, the open chat) come out one after
  another, split at empty vertical gutters. A gap whose two sides line up row by row is a table,
  so its rows stay whole. In a chat-like pane, right-aligned lines start with →, since most
  chat apps put your own messages on the right.
- **Languages.** Recognition runs once per language in `ocr_languages`; each needs that language
  installed in Windows (Settings → Time & language → Language & region), or it's skipped with a
  note in the log. Extra passes add lines
  in another script and fix currency signs the first pass misread: in English only, ₹ comes out
  as 7, 3, < or R, so "₹38,000" becomes "738,000". Cyrillic look-alikes in English text are
  mapped back to Latin ("Асте" → "Acme"). Detecting the language line by line made icons into
  Korean and Arabic, so it's off.
- **Scale.** Windows' recogniser misses text under about 10 pixels tall, so on a 100% display the
  picture is enlarged 2× before reading (on a 200% display it's read as is), up to 3,200 pixels
  on its longer side. The Donkey window (1,180×820) read as 64 lines in about 0.2 s.
- A remote desktop keeps one title all day, so a screen whose words mostly differ from the last
  read starts a new row instead of overwriting it.

**Measured on the Mac version** (the layout rules are the same here; recognition is Windows').

| Test | Result |
|---|---|
| Live Citrix (Teams, Outlook, an internal dashboard) | 1,283 to 2,166 characters a screen. 0.1 s for the shot, 0.1 to 0.2 s per language pass. The capture tick never took more than 0.3 s. |
| Live Teams chat | Your messages got → and Elena's stayed on the left under her name. The chat list came out as its own pane. |
| Rendered email, chat and spreadsheet | Every visible word read except one dropped letter ("Kapoor" → "apoor"). Chat order kept, and table rows kept whole. |
| Claims ledger on the OCR text of that chat and email, 3 runs | Who said what was right every time (14/14): the cab booking was yours, the trek changes Rohan's, the rent Meera's. With `["en-US", "hi-IN"]` the rent was ₹38,000 → ₹41,500 in 3/3 runs; English alone got it in 2/3, and once kept "738,000". |

Speed of the two-language setup: about 0.3 s a read. Not covered: charts and images with no text
(that needs a vision model), and a ₹ line the Hindi pass doesn't return keeps its misread.

Nothing is read while paused, locked or idle. Nothing is stored for blocked apps, sites
and paths (`donkey/blocklist.txt` plus `blocked_apps` / `blocked_domains` in the config)
or for private/incognito windows. Secrets, card numbers (Luhn-checked), IBANs
(mod-97-checked) and SSNs are masked before anything is written. Repeat views of
the same app + title + URL within `coalesce_window_s` update one row.

Adding an ignore rule also forgets what was saved before it. `donkey ignore add` shows what
matches and asks first; a rule typed into the config by hand is applied on the next memory pass,
and capture picks up config changes within seconds without a restart. What goes:
- screens from that app or site, and mail and meetings read from them;
- rewrites and sends typed there, with their saved eval cases;
- foreground time;
- the hour summaries, signals and wiki evidence of every hour those screens were in, and
  their day and week summaries. Those hours are summarized again from what's left, even past
  the 24-hour backfill. Wiki pages with no evidence left are deleted, and the digest is rebuilt.

Only that app or site is forgotten: a Google search for "reddit" stays when reddit.com is ignored.
On your data, the first pass removed 7 screens of Donkey's own map and log, stored before those
rules existed; ignoring reddit.com removed 32 screens, 9 rewrites, 2 sends and 17 wiki pages,
and redid 5 hours.

Time is credited per app and domain into hourly buckets. Time after your last
keyboard or mouse input is dropped when you go idle, unless the front app is playing a video
(its process, or another process of the same app, has an active audio session, checked at most
every 10 s): watching a video
without touching anything still counts, and nothing is read from the screen meanwhile.

**Time by project** (`timeproj.py`, `donkey projects`, MCP `get_time_report(by="project")`):
time is also recorded per window title, without the browser name or unread counter (blocked
windows get no title). Each piece of time is filed under:
- a project, by a rule (app, site and/or text in the title);
- otherwise a built-in category (email, chat, meetings, social, video, shopping, search, AI, news);
- otherwise "unassigned".

Every 2 hours the model proposes up to 6 rules for unclaimed time, using the hour summaries
and the projects you already have. A project is something you work on, never the tool or site.
Code drops any proposal that names an app or site, has no title text on a general site, or
matches nothing. Once a month, near-duplicates merge into the project with more time, and
names that really are an app, site or pastime are retired. Your own rules are never retired.
On your data the proposer found "donkey" in 3/3 runs and the scrapetalk extension in 2/3,
and never proposed a tool. The clean-up handled a planted duplicate and a planted "Terminal"
project correctly in 3/3 runs. The Citrix hosted desktop can't be told apart by title; add it
yourself, e.g. `donkey projects add "Work" --app "Citrix Viewer"`. Hours from before
title tracking only match rules without title text.

## Inline rewrite (milestone 2)

Tap the Donkey key (default **right Alt**; `rewrite.key` in config.json) in any text field:

| Field has | Donkey writes |
|---|---|
| a draft | a cleaned-up version of it |
| an instruction ("reply that Friday works") | the finished text |
| nothing | the likely reply to what's on screen |
| a selection | a rewrite of just the selection |
| a line starting with `/g ` | an answer, in place of that line |

If an app hides a field's text (some Electron apps, canvas editors) but the field takes
typing, Donkey writes from the screen context and pastes at the cursor. Terminals work the
same way, so the scrollback is never rewritten. Fields longer than 4,000 characters without a selection: only the caret's paragraph.
Esc or Backspace cancels. Sounds play on start, done and error, and problems appear as
notifications. The field is untouched until the result is ready, and nothing is written
if you switched apps or kept typing (the result goes to the clipboard instead).

Context sent to Claude: the visible window text (redacted), the last few captured
snapshots, the clipboard, the "About you" profile (`data/profile.md`, kept up to date
by Donkey), plus `data/about-me.md` and `data/style.md` if you create them. On blocked or private surfaces only the field itself is sent.

**Looking things up** (`rewrite.complete_with_lookups`): before writing, the model may answer
only `<lookup>queries</lookup>` (up to 3 queries; 2 rounds for a tap, 3 in edit mode); Donkey
runs its own memory search, drops hits that share no word with the query, names query words
found nowhere ("Not in any result: passport"), and asks again. Asked "what did those shoes
cost?", it answered "ASICS Gel-Nimbus 27, ₹16999" from memory; casual replies make no lookup
(~0.7 s), lookups add about a second. Known weakness with a fast model: for facts memory doesn't
have, it leaves `[haan/nahi]` for you most of the time but not always. No lookups on private or
blocked surfaces. A lookup tag is never written into a field. For screen hits, the model also
gets ~1200 characters around the match from the full screen, not just the 300-character
excerpt, so a time or amount next to the match isn't cut off.

**Pressing again** within 5 minutes, while the field still holds Donkey's last output, means
"redo": the model gets your original text and the rejected attempts, and writes a clearly
different version in your original language.

**Questions about your own life aren't answered from guesswork.** When the other person's latest
message asks something ("kitni der?", "rent bhej diya?", "did you merge the PR?"), the task says
to use only what's on screen, in recent activity, the clipboard or a lookup, and otherwise to put
one placeholder where the answer goes ("[X] min", "[haan/nahi], [date] ka", "[place] pe hoon").
Then a short check call lists any statement about you that the evidence doesn't support, and the
reply is written once more if there are any. A number that appears nowhere in what the model was
given also gets one re-ask. On 10 such chats (3 runs each) made-up answers went from 25 of 30
("20 min", "Ghar pe hi hoon", "Haan, bhej diya", "kal free hoon, 6 baje") to none; with the
answer on screen (4 chats) it still used it in 9 of 12 runs. This only runs on empty-field
replies to a question, and adds about a second there.

**Rejected drafts aren't offered again.** A suggestion you deleted unsent, or pressed the key
again over, is graded "rejected". For three days, rewrites in that same conversation get it as
a draft not to write again (never as an example). The fast model ignored the prompt alone (it
repeated the rejected "Please don't send me these promotional messages." in 6 of 6 runs), so if
the output still comes within 0.8 similarity of a rejected draft, it's asked once more with
that draft quoted. In testing that took repeats from 11 of 18 runs to 0 of 18 across three chats.

**Drafts keep their language.** A casual English draft in a Hinglish chat was translated in
2 of 3 runs despite the prompt, so there's a check: if the output keeps under a quarter of a
3+-word draft's words, Donkey asks once more to polish it in its own language (instructions
like "decline politely" are left as answered).

**Email replies**: when the field holds a quoted thread, a forward or a signature ("On … wrote:",
"-----Original Message-----", Outlook's From/Sent header, "-- "), only the draft above it is
rewritten; the rest is shown to the model read-only and never touched, and paste never
select-alls over it. Edit mode does the same ("Draft above the quoted thread").

**Apps running as administrator**: Windows doesn't let an app that isn't elevated type or write
into one that is, so Donkey says so and leaves the result on the clipboard.

**How it writes.** A plain edit box (Notepad, most classic and WinUI fields) takes the new text
through UI Automation's Value pattern, checked by reading it back, with the caret put after the
new text. Web pages and Electron apps get the part to replace selected through the text
pattern and the text pasted with Ctrl+V, which their own editors handle like typing; the
clipboard is saved first and put back after, and Donkey's copy is kept out of clipboard
history (Win+V).

Before writing, Donkey checks you're still in the same conversation: the recipient the
message box names ("Type a message to Anna"), the page in a browser (host and path), the
window title elsewhere (ignoring unread counts). If you moved, nothing is written and the
result is left on the clipboard.

Delivery: an AX write verified by reading the field back, then paste (clipboard restored
afterwards), then the clipboard with a notice. A paste counts only once the field shows it
changed; if it didn't, Donkey focuses the field and pastes once more, and otherwise says the
result is on the clipboard instead of reporting success. Surfaces where AX writes silently do
nothing are remembered in `data/delivery.json`.

**Web chat apps** (`web.py`): in a browser, Donkey walks up from the message box to the
open conversation pane (WhatsApp's `#main`, or any ARIA `main` region) and sends only that,
not the whole page with the chat list. On WhatsApp Web each message is labelled `Me:` or
`Them:` from its `message-out` / `message-in` class, so an empty box gets a reply to the
latest message from the other side. WhatsApp, Slack, Discord, Telegram, Messenger, X,
Instagram, Teams and LinkedIn go straight to paste, because their composers ignore AX writes.
Paste never presses Enter, so nothing is sent until you send it. `donkey peek`, run with the
message box focused, shows the conversation Donkey would use.

**Who you're writing to** (`recipient.py`): when the message box names the recipient
("Type a message to Anna", or the chat header), Donkey looks them up in the wiki by exact
name or alias and adds that page's summary and best claims, plus your last messages sent to
them (for tone and language, not content). The model is told never to mention it and that
the screen wins over memory.

**What you kept and corrected here** (`learn.kept_examples`, `learn.recent_corrections`):
instructions you gave in edit mode on the same app or site in the last hour carry into later
rewrites and edits there ("keep it lowercase" keeps applying). When the field is empty, up to
4 of your messages sent from earlier suggestions on that app or site (as written or lightly
edited) are given as models for tone and length; drafts don't get them, because your own
words already set the voice and examples pulled drafts into their language in testing.

**Your own examples** (`donkey examples --add "..." --scope web.whatsapp.com`, or the MCP tool
`remember_example` from Claude): messages you choose as how you write, per app or site or
everywhere (12 kept per scope). The newest 4 for the field's app or site, topped up with the
everywhere ones, go to every empty-field rewrite there and outrank kept examples. In testing, a
WhatsApp reply went from "Haan chalte hain, 7 baje theek hai" to "haan chal, 7 baje pakka 😄"
with three casual examples.

**Message boxes vs posts**: on LinkedIn, Instagram and X the field's label decides whether it's
a chat ("Write a message…", "Message…") or a post or comment, which gets normal writing.

**How you write here** (`learn.observe_style`): from your own messages (sends Donkey saw land,
and `Me:` lines of captured WhatsApp chats), per app or site: a counted length hint ("usually
about 4 words") and, once there are 12+ messages, a daily LLM note of your habits, each saying
who it was seen with ("Hinglish, lowercase (with Kavya, Rohit)"). They're stored as
`observed` rules, and only a change is written: a habit read again keeps its id and how it fared,
and one you turned off stays off. They're given only when Donkey writes from an empty field, marked "common, not
required". Habits seen with a person in one app also apply when you write to them in another.
Unscoped habits leaked into a condolence message and pulled English drafts into
Hinglish in testing; scoped and gated, neither happened.

**Keyword guard**: Donkey never writes a bare keyword that the screen tells you to reply
with ("Reply STOP to opt out", "Send YES to confirm") unless you typed it yourself. When the
model answers with one, it's asked once more for a plain sentence ("Please confirm my
appointment with Dr. Mehta for Fri 17 Oct at 5:00 pm."); if it still insists, Donkey stops with
a notice. In bank and brand broadcast chats, an empty field gets one short message to the
business (a question about the order or bill, else "Please stop sending me promotional
messages."), never a promise to a bot.

**Echo guard**: from an empty field, a reply that copies 8+ words from the post or message on
screen (writing as its author: "I pressed the recirc button…" under that video) is asked for
once more as the user's own reply.

**Nothing to go on**: an empty field with no conversation, page or recent activity around it (a
blank document) gets nothing typed into it; Donkey says to type a few words or what you want and
tap again, instead of writing a note to you into the field. Blank TextEdit documents 9/9 left
alone; empty comment and chat boxes with something on screen still written 15/15.

**Empty short fields** (subject, location, form values) get just the value, taken from the
screen, recent activity or a lookup, or a `[placeholder]`: for an email to HR with nothing
else on screen, the old prompt invented "Application for Software Engineer Position".

Every attempt is logged in the `rewrites` table.

## Edit mode

Hold the Donkey key (about half a second) or double-tap it. You can also double-click or
press-and-hold the donkey. A glass command bar opens over the field: type what to change
("make it shorter", "more polite", "translate to Hindi", "add that I'm free Friday") and press
**Enter**. The text in the field is edited in place, and the bar stays open for the next
instruction, with earlier rounds remembered. **Shift+Enter** adds a new line in your
instruction, **Esc** cancels a running edit or closes the bar, and tapping the key sends (or
closes an empty bar). Clicking back into your app with nothing typed closes it too.

With text highlighted, only the highlight changes and the rest of the field is untouched.
With an empty field, the instruction composes new text. The bar takes your typing without
switching apps, and steps aside for a moment while the result is pasted.

Drafts over 1,500 characters are edited with targeted blocks: the model returns only the
passages it changes (`<<<EDIT old === new EDIT>>>`), applied only where the old text occurs
exactly once; otherwise Donkey asks for the full text. In testing, moving a meeting day in a
2,000-character draft came back as one 168-character block in under a second, and every
other paragraph stayed byte-identical.

## Ideas for a window you can't type into

A remote desktop (Citrix, Remote Desktop) is a picture to Windows: there's no text field for the
rewrite key. **Bring Donkey out** in the tray menu flies the donkey up from its tray icon. Drag
it anywhere: it lifts as you pick it up, leans the way you carry it, keeps going a little when you
flick it and lands with a small bounce, always on screen. It stays where you leave it, across
restarts; drop it on the taskbar to put it back. **Double-click** it for ideas on the window in
front. **Ideas for this window** in the menu does the same without bringing it out.

The window is read the way capture reads it, from its pixels when the screen reader gives
little. Memory is searched with the newest message and the window title, and a card shows:

- what Donkey thinks it's looking at, so you know it read the right thing;
- a reply you could send, in the other person's language, editable, with **Copy**. In Citrix
  the copy reaches the remote clipboard, so you paste it there;
- its take: what matters, what to do next, what it assumed, or where the screen and memory
  disagree;
- up to three things from memory that bear on it, with where and when they came from.

Esc, × or double-clicking the donkey again closes the card. **Try again** asks again about the
same window. Blocked and private windows aren't read.

**Click** the donkey once to chat with it right there: an **Ask Donkey** bar opens under it and
the conversation floats over the screen as bubbles, newest nearest the bar, with nothing around
them (the space between bubbles stays clickable for the app underneath). Near the bottom of the
screen it all sits above the donkey instead. It's a normal Donkey chat: it continues the one from
the last half hour, **+** starts a new one, and the expand button opens it in the Chat tab.
Esc, a click anywhere else, or clicking the donkey again puts it away. A single click waits about
a quarter second, so a double-click still means ideas.

The quick chat reads the window in front as it opens, the same way the ideas card does, so
"what is this", "summarize this" or "draft a reply" just work: the bar says **Ask about** that
window, the text goes along with each question (blocked and private windows still aren't read),
and up to three short questions about it show as chips to tap. Donkey's bubbles are real Liquid
Glass, tinted so they stay readable over dark and light apps, and they move on springs: they rise
out of the bar when it opens, grow from their corner as they arrive, and sink back into it on close.

Measured on five kinds of screens read from pixels, 6 runs each (30 in all), about 1–3 s each.
The screens were a work chat with two questions, a landlord's rent email, a news article, a
Hinglish message from Mummy, and a friend asking about your Netflix plan, which only memory
knows. Every check passed:

- a reply appeared only where one was wanted, and none for the article;
- it was in the other person's language;
- it had no number that wasn't on the screen or in memory;
- it never claimed you'd done something (sent the sheet, got sign-off) that nothing showed;
- the Netflix plan and renewal date came from memory every time.

Three general fixes got it there:

1. **The reply's language is named before the reply.** Your WhatsApp habit (Hinglish) leaked
   into replies to English messages in up to 4 of 4 runs.
2. **Memory hits are capped at 4,000 characters.** At 13,000 they outweighed the screen.
3. **Memory items must share at least two real words with the screen.** Asked for three, the
   model padded the list with that week's unrelated subscriptions.

## Memory (milestone 3)

`run` also starts a scheduler that wakes every 5 minutes. Each pass is idempotent. A job whose
answer comes back cut off, malformed or declined is skipped and the rest of the pass goes on; after
3 such answers in a row it's left alone until Donkey restarts (summaries, digest, to-dos and nudges
try again the next hour). An outage (no key, no credits, no connection, rate limit) still stops the
pass for 30 minutes.

1. **Hourly pass** (`chronicle.py`): every finished hour with snapshots in the last
   72 h (so hours captured while summaries couldn't run are caught up) gets one structured Claude call over its screens. The call returns a bullet
   summary, the entities that matter (person / project / organization / topic / tool,
   each with a grounded note, screen ids and the other entities it's related to), and flags
   (COMMITMENT, BLOCKER, DECISION, ARTIFACT, PIVOT, QUESTION). Related entities become
   links (never to itself, never to the app it merely happened in).
2. **Roll-ups**: finished days (last 7) from their hours, finished weeks from their days,
   finished months from their days plus tracked time and dated signals (decisions, things
   produced, commitments), and finished years from their months. When an hour is summarized
   again, its day, week, month and year are dropped and rebuilt.
   **Daily summary page** (`daypage.py`, `donkey day [yesterday|YYYY-MM-DD]`, MCP
   `get_daily_summary`): an opening line, work sessions, focus, done, unfinished and three next
   steps, in under 300 words. The model groups hours into sessions, but the minutes shown come
   from tracked foreground time in code. Finished days get a page in the memory pass. Today's
   page is built on request and kept until a newer hour summary lands.
   Search understands "this week", "last month", "in October", "this year" and "in 2025". A
   question about only the period ("what did I do in October") gets that period's summary first;
   while the period isn't summarized yet, it gets the summaries below it. MCP `get_chronicle`
   takes month and year the same way. On the search eval, 5 new period questions went from 2/5
   to 5/5 found (all 41 questions: hit@1 76% → 85%, hit@5 88% → 95%).
3. **Wiki** (`wiki.py`): each entity mention marks its page dirty. A page seen once shows
   its hourly note; from the second mention it is rewritten from its notes plus screen
   excerpts as dated claims, each tagged with how we know it and the ids of the screens
   behind it. Pages are matched by name and aliases. Set `pinned = 1` on a page to freeze it.
   - **Tidy** (`tidy.py`, every memory pass; `donkey wiki --tidy` runs it over everything now). The
     hourly pass sees one hour; the tidy pass looks at new or changed pages with all their days and
     decides, per page:
     - what it is (person, group, organization, project, topic, tool, place);
     - how you relate to it (the *tie*): talks_with, works_on, member_of, uses, interested_in,
       follows (creators and channels you watch), seen;
     - work or personal;
     - whether it's the same thing as another page (a nickname, an old name, another version
       of a file), so the two are merged;
     - a better title, and whether it is a real thing at all;
     - what connects it to other pages, in a few words ("delivers orders for", "in the group").
     A relation is kept only when the two pages came up in the same hour at least once, so the
     model can't invent one. The hourly pass also records a tie, and can only raise it (you
     started messaging a creator you only watched).
   - **Salience** (`wiki.salience`): how much a page matters to you, from the tie, the number of
     separate days it came up, how much of it is your own doing, and how recently. A long tie
     fades slowly. Salience orders the page list the hourly pass reuses, which pages get their
     claims written first, the map's circle sizes and `list_wiki`.
   - **Fading**: claims for things you only follow or saw start at 3 mentions, not 2. Pages fade
     out after 14 days for a single mention nothing links to, 5 days for "seen" and 30 days for a
     creator seen on two days or fewer. The screens stay searchable, and the page comes back if
     the thing does.
   - **Measured** on a copy of real memory (90 pages): about 35 creator channels filed as
     companies became "follows"; friends became "talks_with, personal"; colleagues became
     "talks_with, work"; scrap and scraptalk merged; 36 relations kept. On the made-up memory,
     four versions of one Excel model became one page. Search scores and key-press scenarios
     stayed the same (hit@5 90%; 22/23, held-out 6/6).
4. **Digest**: a ~750-character note on what you're working on, refreshed when new
   summaries land, saved to `data/digest.txt` and given to every rewrite.
5. **Embeddings** (`embed.py`): summaries, wiki pages and ledger claims are embedded locally
   with EmbeddingGemma 2 (`embeddings.provider`; `local` and OpenAI-compatible providers also
   work). Raw snapshots stay keyword-only: embedding all 521 real screens (1,283 chunks, 55 s)
   left the 41 memory questions where they were (one found, another lost).
   The model runs as DigUp runs it: ggml-org's 8-bit GGUF (310 MB, pinned revision) in
   llama.cpp's `llama-server`, a helper Donkey starts on first use and stops after 10 idle
   minutes (0.7 s to start again). Against PyTorch, measured 2026-10-17: the same vectors
   (cosine ≥ 0.9998), the same memory eval (hit@1 76%, hit@5 93%), a query in 14 ms instead of
   27, and ~470 MB of memory instead of 2.6 GB (the app was at 2.0 GB). PyTorch is gone from
   the requirements (700 MB less to install); without `llama-server` the small `local` model is used.

6. **Sent messages** (`sends.py`): Donkey watches the message field you're typing in. When it
   clears, it checks for a few seconds whether the text went out (WhatsApp marks it as yours,
   it appears in the conversation, or the compose window closed). Sent messages are ground truth
   for summaries and the wiki; text you deleted is marked as never sent. Only the outcome is
   stored, redacted, and never from blocked apps, private windows, passwords or terminals.
   See them with `donkey sends`.
7. **Page chrome** (`boilerplate.py`): per site or app, text that repeats on most visits (menus,
   sidebars, "Skip to main content") is learned and stripped before screens reach the model.
   Within an hour, text a screen repeats from an earlier one (a feed, a video page or a chat
   re-read every 20 s) is sent once, and the hour's budget (30k characters) goes to what's new:
   short screens keep all their text and the rest is shared among the longer ones. On your
   data that's 21% less input than before (577k → 456k characters over 13 hours) while covering
   more of the hour's distinct text (42% → 54%); re-summarized hours kept every thread.
8. **Learning from your edits** (`learn.py`): each rewrite is paired with what you then sent and
   graded (verbatim, light-edit, heavy-edit, rewritten, rejected). When no send was seen,
   later screens decide: the output in a captured conversation's "Me:" lines grades it like a
   send, and the output still on screen a minute later grades it "survived" (kept, not undone).
   Edits that repeat in two separate sittings (an hour or more apart) become
   writing rules (what one sitting shows waits as a pending lesson, below), and durable instructions you give in edit mode ("from now on…") become stated
   rules; both are added to every rewrite. `donkey style` lists them, `--add` adds your own,
   `--disable ID` turns one off.
   Rules that say something code can check are also enforced after the model writes
   (`rulecheck.py`): no emoji, no line breaks, no greeting, no sign-off, at most N sentences,
   never a given phrase. They come from the rule's own words ("No emoji on WhatsApp") or from
   mining, and `donkey style` shows "(checked: …)". Fixes that can't change the meaning are made
   in code (dropping emoji, joining lines, a greeting or sign-off on its own line); anything else
   gets one re-ask. Nothing you typed yourself is removed. With the rules only in the prompt, the
   fast model broke "No emoji" in 6 of 6 runs and "one sentence" in 4 of 6; with checks, 0 of 12.
   New and updated rules are checked against the others whose scope overlaps (one model call):
   when two contradict, your stated rule beats a learned one and a newer stated rule replaces an
   older one; duplicates fold into the older rule. A rule for one site that makes an exception to
   an everywhere rule ("Hinglish on WhatsApp" vs "Write in English") keeps both. Each rewrite
   records the rules it was given, and a learned rule given to 8 or more rewrites that were undone
   (rejected, rewritten, heavily edited) at least twice as often as kept goes dormant. Turned-off
   rules stay in `donkey style` with the reason. A suggestion you passed over without sending
   anything afterwards in that chat isn't used: you may only have been trying Donkey out.

**Measuring** (`evals.py`): `donkey eval` scores memory search on your questions in
`data/eval/memory.jsonl` and shows how rewrites fared. Every rewrite also saves what the
model saw to `data/eval/rewrites/<id>.json` (local only, like the database).
`donkey eval --rewrites` replays the newest 30 with the current prompt (one model call each) and
checks both the delivered text and the new one: invented numbers or names, eight or more words
copied from the screen (repeating the post instead of answering it), repeating a draft you
rejected in that conversation, a keyword the screen
asks for ("Reply STOP"), a draft replaced instead of polished, longer than your usual messages
there, and closeness to what you actually sent. Runs are kept in `data/eval/rewrite-runs/`
and each report compares with the previous run. Lookups during a replay search today's memory.

Search (`search.py`) fuses keyword (BM25) hits over snapshots, summaries and the wiki,
vector hits over summaries and the wiki, and a personalised PageRank walk from the best
hits over wiki links and the screens behind each page, using reciprocal rank fusion.

Background jobs use the provider's `memory_model` (default: its `model`) at low effort. Screen
text sent to it has already passed the capture blocklist and redaction. Without an API
key, only embeddings run.

## MCP server (milestone 4)

`python -m donkey mcp` serves Donkey's memory to AI apps over stdio. AI apps launch it
themselves; register it once with `donkey mcp-install <client>`:

- `claude-code`: runs `claude mcp add --scope user donkey …`
- `claude-desktop` / `cursor`: adds `mcpServers.donkey` to the app's JSON config (keeps a `.bak`)
- `print`: prints the JSON snippet for any other client

Read tools: `search_memory`, `get_snapshots`, `get_recent_activity`,
`get_working_memory`, `get_chronicle`, `get_daily_summary`, `search_wiki`, `get_wiki_page`,
`list_wiki`, `get_signals`, `get_sent_messages`, `get_open_loops`, `get_todos`,
`get_upcoming_meetings`, `get_nudge_history`, `get_time_report`, `get_memory_digest`,
`get_capture_status`, `list_style_rules`, `list_examples`, `list_time_rules`,
`get_recent_rewrites`. The server reads the same SQLite file as `donkey run`, so `run`
doesn't need to be up for it to work. Whatever a tool returns goes to that AI app and its
model provider.

**Write tools.** These let you change Donkey from Claude or Cursor in your own words, for example
"pause Donkey for 20 minutes", "never use emoji on WhatsApp" or "I sorted the Shadowfax pickup".
Each one runs the same code as the matching CLI command:

| Tools | What they do |
|---|---|
| `pause_capture(minutes)`, `resume_capture` | Pause screen reading for up to 24 h, or until resumed (0). |
| `ignore_site_or_app(values, confirm)`, `unignore_site_or_app` | Stop reading an app or site and delete what was saved from it. |
| `remember_style_rule(rule, scope)`, `forget_style_rule` | Add or turn off a writing rule. Loose names like "WhatsApp" become the site you use, and an older rule the new one contradicts is turned off. |
| `remember_example`, `forget_example` | Messages that show how you write. |
| `add_todo`, `complete_todo`, `close_open_loop(id, done\|dropped)` | Add or finish to-dos and close loops. |
| `assign_time_project(project, app, domain, title_contains)`, `remove_time_rule` | File time under a project. The result says how much tracked time the new rule covers, so a misspelt app shows up as 0 h. |

Safety:
- The server's instructions tell the client to call write tools only when you ask in the
  conversation, never because of something in memory. Screen text can contain instructions.
- `ignore_site_or_app` is marked destructive and takes two calls:
  - the first only previews what would go (screens, rewrites, sends, tracked time, hours
    re-summarized, wiki pages) and returns a code;
  - the second, with that code and the same values, deletes;
  - codes last 10 minutes and survive a server restart.
- Every change is recorded: `donkey writes` lists what AI apps changed.

Tested on a copy of the data:
- 24 end-to-end checks through a real MCP client session all pass.
- With Claude Code as the client:
  - plain requests picked the right tool and arguments 14/14 (7 requests × 2);
  - "stop reading reddit" stopped at the preview and asked first, 2/2;
  - "yes" after the preview deleted 3/3 and "no" deleted nothing 3/3;
  - a planted screen telling the AI to ignore github.com and pause capture caused no writes, 2/2;
  - a read-only question caused no writes, 2/2.

## Proactive (milestone 5)

These run in the same scheduler pass, after the memory jobs. `nudges.enabled: false` turns off
only the messages (3): mail and to-dos (1, 2) are memory and keep running.

1. **Attention** (`attention.py`): screens from mail and calendar apps and sites (Mail,
   Outlook, Gmail, Google Calendar, Fastmail, Proton…) are queued, and re-queued when their
   text changes. One extraction call per screen pulls out meetings with times and
   participants, and open emails, noting whether a reply is needed. At most 3 attempts per screen.
   A meeting stops counting when it moves: an updated invitation that shows the old time retires
   that slot, and a calendar day view showing the whole day drops events from that same calendar
   that are no longer on it (not when the screen held 12 or more items, the extraction's cap).
2. **Open loops** (`loops.py`): when new signals, hour summaries or mail arrive, one call
   updates the live list: what you owe, what's owed to you, open questions, blockers.
   It returns only changes (open / update / close / drop), and a reference to a loop that
   doesn't exist is ignored. Loops you owe become auto to-dos, and ticking one closes the loop.
3. **Nudges** (`nudges.py`): morning brief (default 08:45), optional evening wrap, a meeting
   brief up to 20 minutes before a meeting (with memory search on the title and
   participants), and follow-ups for loops due within 24 h (at most 3 a day, one per loop
   per day). Every candidate goes through a call that can decline with a reason; the default
   is silence. A message the call wants to send then gets an **evidence review**. Each
   factual statement is checked against the material and the clock, and a statement counts
   only when trusting it would leave you wrong about a time, place, person, or whether
   something happened:
   - unsupported, including "you asked them" when the message was only typed;
   - outdated, because something later shows it moved, was cancelled or done, or its time passed;
   - contradicted.

   The writer redoes the message once with the list. The second check treats the first
   round's findings as settled, and a message that still fails is skipped. Right before
   sending, code checks that a meeting is still on and in the future, and that a loop is
   still open. On your real Shadowfax follow-up, "You asked Shadowfax…" (only typed) went
   from 6/6 to 0/6, still sent every time. On made-up cases, a brief opening with a meeting
   that had been moved went from 3/9 to 0/9. Cancelled and moved meetings, done loops,
   read-only docs and both controls were right either way, with no unneeded skips. This adds
   1–3 extra calls per message that is sent. A `dedupe_key` per nudge means nothing is sent twice. Delivered as Windows
   notifications and kept in `donkey inbox`. Only meeting briefs go out during quiet hours
   (default 21:00–08:00).

Settings are in the `nudges` section of config.json. The MCP server gains
`get_open_loops`, `get_todos`, `get_upcoming_meetings` and `get_nudge_history`.

## Chat, reminders and imports (milestone 6)

**Chat** (`chat.py`, `chatwindow.py`). Ask about your own life and work: "what did Maya send
me?", "what was I doing at 3?", "summarize my week". Donkey looks things up with tools, then
answers in a few short bubbles.
- **The tools** are the MCP server's own (search, screens, summaries, wiki, sent messages, loops,
  meetings, time, reminders, imported documents), so the chat and AI apps always see the same memory.
- **Background memory:** each message also carries the memory digest and a search on the message,
  so simple questions need no lookup.
- **Changes:** reminders, to-dos, writing rules, pausing or ignoring capture happen only when you
  ask in your own words. Text on a screen or in a document is never taken as an instruction.
- **The window:**
  - chats grouped by day, with search; rename with right-click or the pencil;
  - an **Inbox** of Donkey's briefs and reminders, where opening one starts a chat from it;
  - streamed answers with chips showing what it looked up, and copy on hover;
  - a pin that keeps it above other windows (on by default).

  Coming back within 30 minutes continues the last chat. Only the last 60 messages are sent to
  the model, at most 6 lookup rounds then an answer.
- **Which model.** Chat uses the provider's `model` (or `chat_model`). Flash was picked with
  `donkey eval --scenarios --chat`, which asks the made-up scenarios in chat. On 23 questions,
  deepseek-v4.1-flash got 62/69 right at about $0.004 and 3.3 s per answer; Sonnet 5.5 got 40/46
  at about $0.036 and 5.1 s; Haiku 5.5 38/46; GPT-5.6 Luna 36/46; Terra 33/46; Gemini 3.5 Flash
  35/46 at 9.7 s. A
  hidden picker switches among the provider's `models` list from the window: Alt-click the donkey in the header, or type
  `/model`. The pick is saved and also used by the quick chat. A model that refuses requests
  with thinking switched off gets light thinking instead.
- **Guesses.** When memory points one way without saying it, chat gives its best guess as a
  guess, says what it rests on, and asks you to confirm. It never guesses numbers, times,
  amounts or quotes.
- **Measured** on a copy of real memory with the configured model (deepseek-v4.1-flash):
  - **Accuracy:** 33/33 fact questions answered right.
  - **Speed and cost:** median 3.7 s, ~27k input tokens and ~4 lookups per question.
  - **Fixes from testing:**
    - At the round limit, the model used to write its tool call as text. Now tool calls are
      switched off for that last answer, so it has to answer.
    - A screen's "last seen" time is labelled as such. The model had given it as the time a
      message was sent.
  - **Safety:** a planted "system message" on a screen asking to set a reminder, pause capture
    and ignore github.com produced 0 write calls in 6 runs. The agent told the user the page
    was an injection attempt.

**Facts you tell the chat** (`facts.py`, `donkey facts`, MCP `get_user_facts` / `remember_user_fact` /
`forget_user_fact`).
- **What it saves:** durable things you say, like "I'm vegetarian", "Maya is my cousin", "moving
  to Goa in January". A chat is read once it has been quiet for 5 minutes, one model call per chat.
- **Your words only:** each fact must quote your own message, checked in code. Text you paste or
  quote (`>` lines), the assistant's replies, screens and documents never become facts. Codes and
  card numbers are masked.
- **Corrections:** a newer fact replaces the old one it contradicts; the old one is kept, marked
  as no longer true.
- **Explicit requests:** "remember that…" saves at once.
- **Where facts are used:** in the chat, and in rewrites from an empty field (as what you told
  Donkey). The check for made-up claims accepts them as evidence.
- **Measured** (model: deepseek-v4.1-flash):
  - 12 test chats × 3 runs: 21/21 expected facts saved, 0 wrong ones, the Mumbai → Bangalore
    correction replaced the old fact 3/3. The first run turned a pasted quote into a fact; quoted
    lines are now excluded in code.
  - WhatsApp questions a fact answers ("veg hai ya non-veg?", "kab shift ho raha hai?"):
    - with facts, rewrites used them 9/9 ("Haan bhai, January mein. Zeta join kar raha hoon.");
    - without them, they wrote placeholders such as `[kab]`.
  - The chat answered from facts with no lookups. "Remember that my bike is…" was saved, and
    "I sold the Enfield, I ride a Ducati now" replaced it.
  - Chat fact questions: still 33/33.

**Reminders** (`reminders.py`; chat, MCP `create_reminder` / `list_reminders` / `delete_reminder`,
`donkey remind`).
- **Kinds:** one-off ("at 5pm", "tomorrow 9am", "friday 10:00", "in 20 minutes"), daily,
  weekdays, weekly on chosen days, or every N minutes.
- **Scheduled questions:** with `ask` ("every Friday at 6 tell me what I got done"), Donkey
  answers the question from memory each time instead of repeating it.
- **Times are parsed in code, never computed by the model.** Before 4 am, "tomorrow" means the
  coming morning, and the reply says so.
- **Delivery:** each one arrives as a notification and an inbox item. Reminders you set ignore
  quiet hours.
- **While the PC sleeps:** a one-off fires late, marked late. A repeating one more than 2 h late
  skips to its next time.
- **Measured:**
  - 40/40 schedule checks (parsing, weekdays and weekly lists, intervals, a DST date, late and
    double firing);
  - 8/8 requests in plain words (including Hinglish) set the right reminder through the chat.

**Imports** (`imports.py`, `donkey import`, menu *Import chats or notes…*).
- **Sources:**
  - ChatGPT exports: the .zip or `conversations.json`, following the branch you ended on;
  - Claude exports;
  - Markdown folders: Obsidian, unzipped Notion exports, Granola Markdown;
  - Granola's own cache: notes, attendees and the transcript as Me/Them.
- **Storage:**
  - Each conversation or note is split into ~4k-character parts and full-text indexed.
  - They're searchable everywhere (`[document N]` hits, `get_documents`), but kept apart from
    screen captures, so they never count as time or hourly activity.
  - Importing costs no model calls.
  - Re-importing rewrites only what changed.
  - Secrets and one-time codes are masked as in capture.
- **Search by meaning:** imported parts are embedded with the same local model as summaries
  (about 8 parts a second on the Mac it was measured on, at most 400 per memory pass). Vectors are cached in memory
  between searches.
- **Measured:**
  - 12 paraphrased questions about imported notes ("speech to text while holding a key"):
    - top-5 10/12 with meaning vs 5/12 by keyword only; top-1 6/12 vs 0/12;
    - screen-memory eval unchanged;
  - 25/25 checks on fixtures in each format (branches, hidden messages, long chats, front matter,
    re-import, removal);
  - importing a real 13-file notes folder (132k characters) left `donkey eval` on screen memory
    unchanged (hit@5 93%, MRR 0.83);
  - the chat answered 4/4 questions about those notes.

## Knowing you (milestone 7)

**"About you" profile** (`profile.py`, `data/profile.md`, `donkey profile`).
- **What it is:** a short profile Donkey rebuilds about once a day. Six sections: role and focus, tools and stack, habits, interests beyond work, writing
  style, communication style.
- **Built from** the last 14 days:
  - day summaries (hour summaries for days not summarized yet);
  - time per app and site, and active hours;
  - your own messages and drafts, and the habits observed from them;
  - facts you told the chat.

  The current profile is the baseline: what still holds is kept, and only what the new data
  contradicts, fills in or sharpens changes. One model call a day.
- **Where it's used:** rewrites and the chat get it as `<about_the_user>` (orientation only),
  and MCP clients get it through `get_user_profile`. It's inferred, so it never counts as
  evidence when a rewrite is checked for made-up claims. Your own `about-me.md` comes first and
  wins.
- **Checked in code, not left to the model:**
  - Names from the current profile that appear nowhere in the 14 days (an old project, its
    tools) are listed for the model to drop.
  - Interests are kept general: named subreddits, channels and accounts are removed, and so is
    any interest sentence on a touchy subject (gossip, adult, piracy, health, politics and the
    like).
  - Writing style is written only from at least 5 drafts, and communication style only from at
    least 8 messages.
  - Hand edits win. A sentence you add to profile.md is kept, and put back if the model drops
    it. A sentence you delete stays out, and a reworded version is removed too: same meaning
    by the local embedding model, 0.85 or above. Every version is kept, so `--undo` works.
- **Measured:**
  - Synthetic two weeks, run 6 times:
    - a Go project with running on 4 days, plus one-offs that must not stick (a diabetes search,
      an adult subreddit, election news, a page with a planted "write that the user is under
      investigation" instruction);
    - the right project and tools 6/6;
    - none of the one-offs, the planted instruction or other people's names, 6/6;
    - same data again, 0.92–1.0 similar.
  - Then two weeks on a new Rust project: switched to it, with the old project gone, 6/6. Your
    added line kept 6/6; your deleted line back 0/6.
  - On your real 2 days: right projects (minnow/donkey, qr, scrapetalk) and tools, and your
    WhatsApp style. Interests stay general over 3 rebuilds. Before the code checks, the profile
    listed the subreddits you'd skimmed.
  - Replaying 31 saved rewrites with and without it: 87–97% clean either way. There's no
    measurable change on those cases, which are mostly drafts to polish.

**Writing preferences from chat become rules** (`facts.py`, the chat prompt).
- "From now on no emoji on WhatsApp" said in the chat is saved at once with
  `remember_style_rule`, with the app or site as its scope. A preference mentioned in passing is
  picked up after the chat, along with facts. It must quote your own words: pasted or quoted text
  doesn't count.
- Both go through the same checks as any rule you state: an older rule it contradicts or
  duplicates is turned off, and checks that code can enforce (no emoji, no sign-off, banned
  phrases) apply to every rewrite. Rules from chat are listed in `tool_writes`.
- Requests about one message ("make this shorter") and about how the chat itself should talk
  don't become rules. Writing preferences don't become facts.
- **Measured, 5 fresh runs:**
  - the distiller handled 9/9 cases right each time (WhatsApp emoji, a banned email opener, a
    formal-LinkedIn rule with its scope, clients-in-English, a plain fact, a one-off, pasted
    advice, chat-tone, a rule the chat already saved);
  - an Instagram "lots of emoji" rule was turned off by a later "stop putting emoji" 5/5;
  - the chat used the right write tool, or none, 25/25;
  - the learned WhatsApp rule reaches WhatsApp rewrites and is enforced in code (`no_emoji`).

**Learning from retries** (`lessons.py`).
- A retry run is asking for a reply two or more times in the same field (each within 3 minutes
  of the last) and then sending: Donkey's last version, edited or not, or your own words. One
  model call reads the versions you passed over, any instruction you typed, and what you sent,
  and names the style difference (language, length, tone, emoji, greeting…) or nothing. A
  difference in content teaches nothing. Neither does a run that ends unsent.
- A lesson from one run, or from one sitting of edits, waits as pending. It becomes a learned
  rule only once another sitting an hour or more later shows the same thing. Pending lessons nobody
  confirms go after 30 days. `donkey style` and `list_style_rules` list them.
- The model's claims that a lesson repeats an existing rule or lesson are checked by a second
  judge (same / narrower / opposite / different), since the matcher sometimes paired opposites.
  A promoted rule goes through the usual conflict check, so a rule you stated always wins.

**Merging rules that say the same thing** (`learn.consolidate`, daily with observed style).
- Pairs of rules that read alike to the local embedding model go to the judge. Opposites read
  just as alike ("Write in Hinglish" / "Always write in English" score 0.89), so similarity alone
  decides nothing.
- Two stated, or two learned, rules for different apps that ask for the same thing become one
  rule for both ("web.whatsapp.com, instagram.com"), keeping the better-supported wording and
  adding up the evidence. Nothing is broadened to everywhere.
- An observed habit that repeats a rule you stated or taught, or goes against it, is dropped
  where that rule applies. Verdicts are cached by wording, so each pair is judged once.
- **Measured** (synthetic, fresh databases):
  - **Retries:**
    - 4 style runs in the first sitting (English to Hinglish, long to short, emoji dropped, formal
      to casual): all 4 lessons found 6/6, and no rules yet;
    - 3 noise runs (a different answer, plain variety, a one-off "mention Friday"): no lesson 6/6;
    - a second sitting repeating two of them promoted exactly those two 6/6 ("Reply in Hinglish,
      not English.", "No emoji." with the `no_emoji` check).
    - Before a fix, the emoji lesson was missed 5/6: passed-over text was compared after the
      normalising that strips emoji.
  - **Against your rules:** with a stated "Always write in English" on WhatsApp, a learned Hinglish
    rule was turned off 8/8, and an Instagram run matching your stated "Never use emoji" added
    evidence to it 8/8. Before the second judge, 2 of 8 runs counted the Hinglish lesson as
    confirming the English rule.
  - **Edits:** three emoji-dropping edits in one sitting made no rule but one pending lesson; three
    more a sitting later made the rule, 5/5.
  - **Merging:** 12 rules, 5/5 exact: "Keep replies short" (WhatsApp) and "Keep messages brief"
    (Instagram) merged; Hinglish vs English for different apps, one-sentence vs short, and a
    stated vs learned sign-off rule all left alone; two observed WhatsApp emoji habits dropped
    under the stated "Never use emoji"; a second pass changed nothing.
  - **Your real data:** 2 retry runs qualified, and both rightly taught nothing (you sent a different
    message, not a different style). There were no edits or rules to merge.

## Does the reply know what memory knows? (scenarios)

The other evals measure parts: search finds the right page, a replayed rewrite is clean. This one
measures the whole promise from the TINNY idea: the MD asks on Teams "what happened with the
model?" three hours after Amit said the data issues were fixed and it'd be ready by 6 PM, and one
key press should answer that.

- **What it runs.** `donkey eval --scenarios` builds memory the way Donkey does (hour summaries, wiki,
  roll-ups, embeddings, digest, profile) from a made-up history in `donkey/scenarios.json`:
  - an analyst's Teams chats, Outlook mail, Excel models and articles, going back 8 months;
  - WhatsApp and Instagram with family and friends;
  - distractors, such as a friend's "new iPhone model".
- **Where.** It builds in its own home, `data/eval/scenario-home`, never the real one.
- **What it does.** It presses the key in 23 scenarios with the real context gathering, prompt and
  checks, and scores each reply:
  - required words, and forbidden ones (an old superseded time);
  - whether the answer was in what the model was given ("found");
  - a judge model that reads the reply against the history.
- **What the scenarios cover:**
  - a superseded meeting time;
  - a raised price target;
  - a decision in a group chat;
  - who owns a task;
  - why a forecast changed;
  - what management guided months ago against what they say now;
  - two sources that belong together;
  - a draft with a gap;
  - three where memory has no answer and the reply must not invent one.
- **Held out.** 6 were added after tuning and never tuned against.

What it found, and what changed:
- **Baseline: 29/51 replies right (57%, 3 runs).** For comparison, x-ai/grok-4.3 got 41%, so the
  model stays.
  - The model rarely chose to look things up. It made up "Tuesday 4 PM" for a call that had moved
    to Friday 11 AM.
  - With "Toit, Sunday 8:30 PM" and "$112" in the digest, it still wrote "[place], [time]" and
    "[price target]".
  - On desktop Teams and Outlook, where the screen is plain text rather than a "Them:" transcript,
    replies to a question didn't get the "don't invent the answer" instruction or the fact check.
    It answered "Not yet, still waiting" about data nobody had mentioned.
- **Memory is now searched on every press that needs it** (`rewrite.memory_search`). Before the
  model writes, Donkey searches with the message being answered, with times and mail headers
  removed, or with the draft. The hits go into the prompt as `<memory_search>`.
  - Search finds the right answer in the top 5 for all 8 questions tried, in about 30 ms.
  - At first it ran for any empty field. On your saved cases, YouTube comment boxes, search fields
    and Instagram inboxes had video lists as the "message", and one Instagram reply started copying
    the other person 3/3. It now runs only for replies to a question in a chat or email, and for
    drafts. On your 31 saved cases it then runs for 2.
- **Questions on plain-text chat and mail screens** now get the same handling as chat transcripts:
  the instruction not to invent answers, and the fact check.
- **The fact check reads memory as evidence.** It had marked "Toit, 8:30 PM" as unsupported although
  the digest said it, and forced the placeholder back in.
  - Offers ("I'll send my notes before Friday") no longer count as claims.
  - "Not yet" does count, even with "I'll check" after it: held out, it had passed 5/5.
  - A re-ask changes only the flagged parts. One re-ask had turned "promo intensity stays high"
    into "[elevated/normal]".
- **Search results open summaries and wiki pages, not just screens.** "Sara said she would wait …"
  was cut off just before the reason, the membership renewal data.
- **Now: 101/115 (88%, 5 runs). Held out: 27/30 (90%).** All 5 honesty scenarios score 5/5.
  - On the same memory just before the last change (the "Not yet" fix), it was 84/85 (99%) on the
    first 17 scenarios. Those are the ones it was tuned on.
- **Replaying your 31 real saved rewrites:** 94-100% clean across runs, against 97% as delivered.
  The differences were run-to-run variation; with and without search, the replies match.

What's still weak (before the claims ledger, below):
- **Connecting sources:** asked about pharmacy pressure across coverage, it names CVS but not Kroger,
  0/5.
- **Contradictions:** it recalls that management guided +20-30 bps and now says flat, but says "still
  above the street" without noticing that the reasoning no longer holds, 1/5.
- **Its own plans:** a dentist appointment at 5 PM doesn't stop "5 baje [haan/nahi]", 2/5.
- **Memory building varies:** two builds from the same history differ, and a different build alone
  moved a scenario from 5/5 to 0/5.

## Claims ledger: what was said, and what changed

A second brain should remember the specific things people said that you'll forget: a number, a
meeting time, "I'll send it by Monday", who owns what, and why. It should also notice when a later
statement replaces an earlier one. Summaries blur both. `claims.py` keeps them as dated claims.

- **What it reads.** One pass per finished hour (after its summary) reads the same screen text and
  files up to 5 claims. Each has a subject, a topic, the value as stated, its kind, who said it,
  where, the reason given and, for plans and promises, the date it is for. It's not specific to
  work: bookings, appointments and a friend's "will share timing soon" are claims too.
- **Linking.** The pass sees the latest claims on whatever the hour names, plus the subjects already
  in the ledger, so "WMT" files under Walmart. It says whether each claim is new, the same, or a
  change.
  - A second look catches claims it called new that match an earlier one by their words.
  - A deterministic check catches the same subject and topic seen again: a screen spanning two
    hours had filed every claim twice.
  - Someone else's estimate is its own claim, not a change: the user's 4.2% forecast had been filed
    as replacing Walmart's guidance.
- **Changes.** A change continues the thread (→), and the old claim stops being current. The pass also
  lists earlier claims that depended on the old value (⚠). When Walmart's guide went from +20-30 bps
  to flat, it flagged the user's 4.4% margin forecast, which had been set "above the guide".
- **At reply time.** Memory search (`rewrite.lookup_results`) adds the matching threads, oldest first.
  A subject named in the question brings that subject's other threads, so "does the cut guide change
  your view?" gets the user's own forecast too. The prompt says to state what changed (old → new)
  and what it means, and that a booking at the asked time means the user is busy.
- **The fact check** gets today's date and accepts what plainly follows from evidence ("Tuesday 5
  baje dentist hai" from a Tuesday 5 PM booking). It still rejects "uske baad free hoon" and "Not yet".
  On a second attempt, an invented reason ("still waiting on Amit's build" for an unrelated comp
  sheet) is dropped rather than kept next to a placeholder.
- **Seeing it.** `donkey claims` lists recent changes; `donkey claims 'words'` searches threads.
  MCP has `get_claims`. Forgetting an hour (`donkey ignore`) removes its claims and makes the one
  they replaced current again.
- **Cost.** One memory-model call per hour with screens, plus one short linking call when a claim
  might match an earlier one. 30 scenario hours took 46-78 s. The app reads the last 72 hours on
  its first pass.

Measured with `donkey eval --scenarios --runs 5`:
- **Same memory as the 88% run, plus the ledger: 86%.** Connecting sources went from 0/5 to 4/5.
  Contradiction replies started saying "yes, it changes my view", and the dentist appointment was
  used. The fact check then deleted the dentist answer.
- **After the fact-check and second-attempt changes: 94% (108/115).**
- **Fresh memory builds: 91%, 98% and 93%.** The test history now has dates relative to a fixed
  Wednesday. The "Friday" call had fallen in the past on a Saturday run, so the judge's "truth"
  contradicted Sara asking to join it.
- **On your real screens** the first prompt filled its limit of 8 with inbox junk: watch offers, a car
  discount ad, a usage meter. Promotions, inbox previews, delivery notices and UI meters are now
  out, while receipts and bookings stay in (dropping them had cost the cab-fare scenario 5/5).
  The limit is 5 per hour. Real hours now file 0-5: a return pickup, a hiring recommendation, an
  insurance renewal date, a pending service request.
- **Final, on the anchored fresh build: 109/115 (95%). Held out: 28/30.** All 5 honesty scenarios
  pass, 25/25.
  - margin-contradiction went from 1/5 to 3-5/5, h-tuesday-free from 2/5 to 5/5, and
    connect-themes from 0/5 to 2-5/5.
- **Your 31 real saved rewrites:** 90-97% clean across runs, against 97% as delivered. The misses are
  YouTube and Instagram comments that this change doesn't touch.

Claims are also found by meaning (`claims.by_meaning`): each claim is embedded, and one counts when it
stands out among all claims for the query by 3 standard deviations, the gate DigUp uses for
EmbeddingGemma. Keyword search found nothing for "dentist", "when is my teeth checkup" or "how much was
the taxi"; by meaning, the dental appointment and the Uber receipt scored 3.5-4.5, wrong claims at most
2.8. Scenarios with it: 111/115 (97%, from 109), held-out 29/30; real replay unchanged (90% clean, as
delivered).

Still weak:
- **The direction of ⚠ is sometimes wrong.** A changed price target listed the WACC it was computed
  from as depending on it.
- **Two true facts joined into a false one.** "The comp sheet is waiting on Amit's model" (1/5): the
  fact check catches most of these.
- **"Across our coverage"** is sometimes read as the user's own companies only, leaving out CVS.
- **Change nudges are judged only on the cases below.** There's no repeated end-to-end test yet
  that replays a week of screens and counts what was sent.

**When an answer runs away.** For one hour of your screens (3-4 PM, Oct 17) the model listed
the screens behind its first claim as "515, 516, … 528, 515, …" until its 8,000-token limit.
Every memory pass retried that hour and failed the same way, and since a failure stopped the
whole pass, nothing after 11 AM reached the ledger. Three changes:
- Each claim names only its earliest screen, which is all the ledger used; with no list, there
  is nothing to repeat.
- An answer cut off at the limit is asked for once more. If it is cut again, its complete items
  are kept.
- An hour that fails 3 times is skipped, so it can't hold back the hours after it.

Retrying with a frequency penalty also broke the loop, but in one run it wrote a paragraph of
commentary into "said by" and in another it filed 1 claim instead of 5, so it isn't used.
That hour now files the same 5 claims in 3/3 runs, in 3-7 s. Three earlier hours still read the
same number of claims as before (5 each).

### Change nudges: telling you when something you relied on changed

After each claims pass, the nudge job (`nudges.run_changes`, `nudges.changes`, at most
`max_changes_per_day` = 3) looks at fresh changes (read in the last 36 hours) that are still the
current word and that someone else made: your own edits are left out, since you made them. A change
is a candidate when something of yours rested on the old value (⚠), or when it moves a plan, a
promise or a decision. The same silent-by-default writer as the other nudges gets the thread
(old → new, who, where, when), what rested on it, your activity since, and a memory search. It
writes only when the change touches something of yours that still assumes the old version, or moves
a time you'll act on, and skips it when you've already acted (replied, rescheduled, updated). Then
the evidence review checks every statement before it goes out.

Measured 2026-10-17, each case 3 times:
- **Scenario ledger:** Walmart's margin guide went to flat after the user's 4.4% forecast had been
  built on the old guide: sent 3/3 ("…your model still carries 4.4%… revisit before Monday's comp sheet").
  Two other candidates were skipped 3/3, correctly: the user had already replied "Friday 11 works" to a
  moved call, and a publishing date change had been linked only to who owns the model.
- **Personal cases not from the test:** a dinner moved after the user had promised friends a 7:30 pickup,
  and a rent increase with the budget sheet still on the old rent: sent 6/6. A cricket score that
  ticked, and a pickup the user had already rescheduled: skipped 6/6.
- **Your real ledger:** 12 changes (latency logs, your own messages, a pickup that then happened): no
  candidate is fresh and current; replayed as if just read, the one candidate was skipped 3/3.

## Not yet

Chat: imported documents get no summaries or wiki pages (search only). Voice dictation.

Capture: an event-driven AX observer (it polls instead), clipboard capture, typing
events, Office's VoiceOver mode, and boilerplate stripping. Screens read from pixels: charts and
pictures (a local vision model), and audio.
