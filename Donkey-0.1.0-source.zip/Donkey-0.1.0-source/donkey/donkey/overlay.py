"""On-screen creature overlays: a small donkey by the caret that gallops while a rewrite runs,
cheers when it lands, and idles beside the text field you're in.

Each creature is a borderless, always-on-top window that never takes the keyboard or activates
Donkey, so clicking it leaves focus (and the caret) in the app you're typing in. It hosts a
transparent web view with the SVG and CSS animations; a clear widget on top takes the clicks, and
everywhere else the window lets clicks through. Coordinates are Qt's: logical pixels, top-left.
All methods here must run on the main thread.
"""
import json
import math
from pathlib import Path

from PySide6.QtCore import QPoint, Qt, QTimer
from PySide6.QtWidgets import QWidget

from . import motion, winui

ASSETS = Path(__file__).with_name("assets")
HOLD_S = 0.5  # press-and-hold on a creature

# The donkey's moves, shared with the edit bar. Body classes: field (idle: blinks, glances
# around, swishes its tail), working (gallops in place with a grin, determined brows, ears and
# scarf ends streaming back and flapping, speed lines and dust), done (jumps and cheers: happy eyes, open grin,
# burst lines), error (worried brows, ears down, a sweat drop and a small shake).
DONKEY_CSS = """
#dk-leg-fl, #dk-leg-fr, #dk-leg-bl, #dk-leg-br, #dk-head, #dk-ear-l, #dk-ear-r, #dk-tail, #dk-eyes-open,
#dk-pupils, #dk-brow-l, #dk-brow-r, #dk-burst, .dust, .spd { transform-box: fill-box; }
#dk-leg-fl, #dk-leg-fr, #dk-leg-bl, #dk-leg-br { transform-origin: 50% 8%; }
#dk-head { transform-origin: 50% 90%; transition: transform .25s ease; }
#dk-ear-l { transform-origin: 100% 100%; transition: transform .25s ease; }
#dk-ear-r { transform-origin: 0% 100%; transition: transform .25s ease; }
#dk-brow-l, #dk-brow-r { transform-origin: 50% 50%; transition: transform .2s ease; }
#dk-tail { transform-origin: 100% 100%; }
#dk-eyes-open { transform-origin: 50% 50%; }
#dk-burst { transform-origin: 50% 50%; }
.dust, .spd { transform-origin: 50% 50%; }

/* idle: blink, glance around, swish, twitch an ear */
#dk-eyes-open { animation: dk-blink 4.8s infinite; }
#dk-pupils { animation: dk-glance 7s ease-in-out infinite; }
#dk-tail { animation: dk-swish 2.6s ease-in-out infinite; }
#dk-ear-r { animation: dk-twitch 5.5s ease-in-out infinite; }
/* the scarf ends ripple by themselves (SMIL in creature.svg): they hang and sway, and stream back while running */
#dk-scarf-run { display: none; }

/* hover: grin and perk up */
.hover #dk-mouth-smile { display: none !important; }
.hover #dk-mouth-open { display: inline !important; }
.hover #dk-ear-l { transform: rotate(8deg); }
.hover #dk-ear-r { transform: rotate(-8deg); animation: none; }

/* working: a full gallop */
.working #critter { animation: dk-bounce .18s ease-in-out infinite alternate; }
.working #dk-leg-fr, .working #dk-leg-bl { animation: dk-stride .36s ease-in-out infinite; }
.working #dk-leg-fl, .working #dk-leg-br { animation: dk-stride .36s ease-in-out -.18s infinite; }
.working #dk-head { animation: dk-nod .18s ease-in-out infinite alternate; }
.working #dk-ear-l { animation: dk-stream-l .36s ease-in-out infinite; }
.working #dk-ear-r { animation: dk-stream-r .36s ease-in-out infinite; }
.working #dk-brow-l { transform: translateY(.8px) rotate(12deg); }
.working #dk-brow-r { transform: translateY(1.6px) rotate(-12deg); }
.working #dk-pupils { animation: none; transform: translateX(1px); }
.working #dk-mouth-smile, .done #dk-mouth-smile, .error #dk-mouth-smile { display: none !important; }
.working #dk-mouth-open, .done #dk-mouth-open { display: inline !important; }
.working #dk-tail { animation: dk-flick .36s ease-in-out infinite; }
.working #dk-scarf-idle { display: none; }
.working #dk-scarf-run { display: inline; }
.working #dk-speed, .working #dk-dust { opacity: 1; }
.working .spd { animation: dk-zoom .36s linear infinite; }
.working .s2 { animation-delay: -.12s; }
.working .s3 { animation-delay: -.24s; }
.working .dust { animation: dk-puff .36s ease-out infinite; }
.working .d2 { animation-delay: -.12s; }
.working .d3 { animation-delay: -.24s; }

/* done: jump and cheer */
.done #dk-eyes-open { display: none !important; }
.done #dk-eyes-happy { display: inline !important; }
.done #critter { animation: dk-jump .7s cubic-bezier(.3, 0, .3, 1) 1; }
.done #dk-leg-fr, .done #dk-leg-fl { transform: rotate(-35deg); }
.done #dk-leg-br, .done #dk-leg-bl { transform: rotate(25deg); }
.done #dk-ear-l { transform: rotate(10deg); }
.done #dk-ear-r { transform: rotate(-10deg); animation: none; }
.done #dk-brow-l, .done #dk-brow-r { transform: translateY(-1.4px); }
.done #dk-burst { animation: dk-pop .7s ease-out 1 forwards; }
.done #dk-tail { animation: dk-flick .3s ease-in-out 3; }

/* error: worried */
.error #dk-mouth-worry, .error #dk-sweat { display: inline !important; }
.error #dk-brow-l { transform: rotate(-16deg); }
.error #dk-brow-r { transform: rotate(16deg); }
.error #dk-ear-l { transform: rotate(-34deg); }
.error #dk-ear-r { transform: rotate(34deg); animation: none; }
.error #dk-pupils { animation: none; transform: translateY(1px); }
.error #critter { animation: dk-shake .45s ease-in-out 1; }

@keyframes dk-blink { 0%, 93%, 100% { transform: scaleY(1); } 95% { transform: scaleY(.08); } }
@keyframes dk-glance { 0%, 30%, 100% { transform: translate(0, 0); } 36%, 52% { transform: translate(-1.3px, .3px); }
                       58%, 74% { transform: translate(1.2px, -.2px); } 80% { transform: translate(0, 0); } }
@keyframes dk-swish { 0%, 100% { transform: rotate(0deg); } 50% { transform: rotate(-14deg); } }
@keyframes dk-twitch { 0%, 86%, 100% { transform: rotate(0deg); } 89% { transform: rotate(14deg); } 92% { transform: rotate(-4deg); } }
@keyframes dk-stride { 0%, 100% { transform: rotate(-32deg); } 50% { transform: rotate(30deg); } }
@keyframes dk-bounce { from { transform: translateY(0); } to { transform: translateY(-2px); } }
@keyframes dk-nod { from { transform: rotate(-2deg); } to { transform: rotate(3deg); } }
@keyframes dk-stream-l { 0%, 100% { transform: rotate(-22deg); } 50% { transform: rotate(-12deg); } }
@keyframes dk-stream-r { 0%, 100% { transform: rotate(-30deg); } 50% { transform: rotate(-18deg); } }
@keyframes dk-flick { 0%, 100% { transform: rotate(-6deg); } 50% { transform: rotate(-30deg); } }
@keyframes dk-zoom { 0% { opacity: 0; transform: translateX(6px); } 30% { opacity: 1; }
                     100% { opacity: 0; transform: translateX(-6px); } }
@keyframes dk-puff { 0% { opacity: .8; transform: translate(0, 0) scale(.5); }
                     100% { opacity: 0; transform: translate(-7px, -3px) scale(1.8); } }
@keyframes dk-jump { 0% { transform: translateY(0) scale(1, 1); } 12% { transform: translateY(1px) scale(1.08, .9); }
                     45% { transform: translateY(-9px) scale(.96, 1.06) rotate(-6deg); }
                     80% { transform: translateY(0) scale(1.06, .94); } 100% { transform: translateY(0) scale(1, 1); } }
@keyframes dk-pop { 0% { opacity: 0; transform: scale(.4); } 30% { opacity: 1; transform: scale(1.1); }
                    100% { opacity: 0; transform: scale(1.35); } }
@keyframes dk-shake { 0%, 100% { transform: translateX(0); } 20% { transform: translateX(-2.5px) rotate(-3deg); }
                      60% { transform: translateX(2.5px) rotate(3deg); } }
"""

CSS = """
#dk-leg-fl, #dk-leg-fr, #dk-leg-bl, #dk-leg-br, #dk-head, #dk-ears, #dk-ear-near, #dk-ear-far,
#dk-tail, #dk-eye-open, .dust { transform-box: fill-box; }
#dk-leg-fl, #dk-leg-fr { transform-origin: 50% 0%; }
#dk-leg-bl, #dk-leg-br { transform-origin: 45% 0%; }
#dk-head { transform-origin: 18% 62%; transition: transform .3s ease; }
#dk-ears { transform-origin: 45% 100%; transition: transform .3s ease; }
#dk-ear-near, #dk-ear-far { transform-origin: 50% 100%; }
#dk-tail { transform-origin: 80% 0%; }
#dk-eye-open { transform-origin: 50% 50%; animation: dk-blink 5.2s infinite; }
.dust { transform-origin: 50% 50%; opacity: 0; }

/* idle: a slow tail swish, an ear twitch now and then */
#dk-tail { animation: dk-swish 3.8s ease-in-out infinite; }
#dk-ear-near { animation: dk-twitch 6.5s ease-in-out infinite; }

/* working: a donkey trot */
.working #critter { animation: dk-bounce .23s ease-in-out infinite alternate; }
.working #dk-leg-fr, .working #dk-leg-bl { animation: dk-stride .46s ease-in-out infinite; }
.working #dk-leg-fl, .working #dk-leg-br { animation: dk-stride .46s ease-in-out -.23s infinite; }
.working #dk-head { animation: dk-nod .23s ease-in-out infinite alternate; }
.working #dk-ears { animation: dk-flop .46s ease-in-out infinite; }
.working #dk-ear-near { animation: none; }
.working #dk-tail { animation: dk-flick .46s ease-in-out infinite; }
.working #dk-dust { opacity: 1; }
.working .dust { animation: dk-puff .46s ease-out infinite; }
.working .d2 { animation-delay: -.15s; }
.working .d3 { animation-delay: -.3s; }

/* done: happy eyes, ears up, a hop */
.done #dk-eye-open, .error #dk-eye-open { display: none !important; }
.done #dk-eye-happy { display: inline !important; }
.done #critter { animation: dk-hop .5s ease-out 1; }
.done #dk-ears { transform: rotate(4deg); }

/* error: ears back, head down, a small shake */
.error #dk-eye-sad { display: inline !important; }
.error #dk-ears { transform: rotate(-38deg); }
.error #dk-head { transform: rotate(9deg); }
.error #critter { animation: dk-shake .45s ease-in-out 1; }

@keyframes dk-blink { 0%, 94%, 100% { transform: scaleY(1); } 96% { transform: scaleY(.1); } }
@keyframes dk-swish { 0%, 100% { transform: rotate(0deg); } 50% { transform: rotate(9deg); } }
@keyframes dk-twitch { 0%, 88%, 100% { transform: rotate(0deg); } 91% { transform: rotate(-12deg); } 94% { transform: rotate(3deg); } }
@keyframes dk-stride { 0%, 100% { transform: rotate(-24deg); } 50% { transform: rotate(22deg); } }
@keyframes dk-bounce { from { transform: translateY(0); } to { transform: translateY(-1.4px); } }
@keyframes dk-nod { from { transform: rotate(-2deg); } to { transform: rotate(5deg); } }
@keyframes dk-flop { 0%, 100% { transform: rotate(-10deg); } 50% { transform: rotate(4deg); } }
@keyframes dk-flick { 0%, 100% { transform: rotate(4deg); } 50% { transform: rotate(26deg); } }
@keyframes dk-puff { 0% { opacity: .75; transform: translate(0, 0) scale(.5); }
                     100% { opacity: 0; transform: translate(-6px, -3px) scale(1.7); } }
@keyframes dk-hop { 0% { transform: translateY(0); } 40% { transform: translateY(-6px); } 100% { transform: translateY(0); } }
@keyframes dk-shake { 0%, 100% { transform: translateX(0); } 25% { transform: translateX(-2.5px); }
                      75% { transform: translateX(2.5px); } }
"""

CSS = """
html, body { margin: 0; padding: 0; background: transparent; overflow: hidden; }
body { width: 100vw; height: 100vh; display: flex; align-items: flex-end; justify-content: center;
       box-sizing: border-box; padding-bottom: 2px;
       transition: opacity .35s ease; -webkit-user-select: none; cursor: pointer; }
body.gone { opacity: 0; }
#critter { width: var(--size); height: var(--size); position: relative; }
#critter svg { width: 100%; height: 100%; overflow: visible;
               filter: drop-shadow(0 1px 1.5px rgba(50, 36, 24, .3)); }
/* field creature: a bit translucent until hovered */
.field #critter { opacity: .88; transition: opacity .2s, transform .2s; }
.field.hover #critter { opacity: 1; transform: scale(1.1) translateY(-1px); }
/* picked up, carried and put down: a wrapper, so it adds to whatever the donkey itself is doing */
#lift { transform-origin: 50% 80%; transform: rotate(var(--tilt, 0deg));
        transition: transform .3s cubic-bezier(.34, 1.56, .64, 1); }
#critter svg { transition: filter .2s ease; }
html.lifted #lift { transform: translateY(-3px) scale(1.15) rotate(var(--tilt, 0deg));
                    transition: transform .2s cubic-bezier(.34, 1.56, .64, 1); }
html.lifted #critter svg { filter: drop-shadow(0 5px 4px rgba(50, 36, 24, .32)); }
html.lifted .field #critter { opacity: 1; }
html.landed #lift { animation: dk-land .45s cubic-bezier(.3, 0, .3, 1); }
html.popin #lift { animation: dk-popin .5s cubic-bezier(.34, 1.56, .64, 1); }
html.popout #lift { animation: dk-popout .32s ease-in forwards; }
@keyframes dk-land { 0% { transform: translateY(-3px) scale(1.15); } 40% { transform: translateY(1px) scale(1.12, .86); }
                     72% { transform: scale(.97, 1.05); } 100% { transform: none; } }
@keyframes dk-popin { 0% { opacity: 0; transform: translateY(-12px) scale(.25); } 60% { opacity: 1; transform: scale(1.1); }
                      100% { transform: none; } }
@keyframes dk-popout { to { opacity: 0; transform: translateY(-8px) scale(.25); } }
""" + DONKEY_CSS + """
/* the pulled-out donkey (free): fully there, a softer shadow on the ground under it, slow breathing,
   and every so often one small trick (the t-* class on <html>, set by the script below) */
#lift { position: relative; }
#ground { display: none; position: absolute; left: 44%; bottom: 0; width: calc(var(--size) * .56); height: 5px;
          transform: translateX(-50%); border-radius: 50%; background: rgba(42, 31, 23, .2); filter: blur(1.2px); }
.free #ground { display: block; }
.free #dk-shadow { display: none; }
#trick { transform-origin: 50% 96%; }
/* which way it faces. Turning around is a little hop: it crouches, springs up, and at the top of the
   hop, stretched thin, it is facing the other way (swapped in one frame, so it never squeezes flat
   like a page); it lands with a squash, ears flopping a beat behind */
#face { position: relative; transform-origin: 45% 50%; }
.face-left #face { transform: scaleX(-1); }
#turn { transform-origin: 50% 96%; }
.turning #turn { animation: dk-turn .34s; }
.turning #ground { animation: dk-turn-ground .34s; }
.turning #dk-ear-l { animation: dk-t-ears-l .5s ease-in-out .03s; }
.turning #dk-ear-r { animation: dk-t-ears-r .5s ease-in-out .06s; }
@keyframes dk-turn {
  0% { transform: none; animation-timing-function: cubic-bezier(.3, 0, .5, 1); }
  25% { transform: translateY(1px) scale(1.1, .88); animation-timing-function: cubic-bezier(.2, .75, .35, 1); }
  45% { transform: translateY(-6px) scale(.9, 1.08); animation-timing-function: cubic-bezier(.6, 0, .85, .45); }
  75% { transform: translateY(0) scale(1.08, .92); animation-timing-function: ease-in-out; } 100% { transform: none; } }
@keyframes dk-turn-ground { 0%, 25%, 75%, 100% { transform: translateX(-50%) scale(1); } 45% { transform: translateX(-50%) scale(.75); } }
.face-left #ground { left: 56%; }
/* running along the chat bar: a quicker gallop than the working trot */
.running .working #critter { animation-duration: .16s; }
.running .working #dk-leg-fr, .running .working #dk-leg-bl, .running .working #dk-leg-fl,
.running .working #dk-leg-br, .running .working #dk-ears, .running .working #dk-tail,
.running .working .dust { animation-duration: .32s; }
#fx { position: absolute; inset: 0; pointer-events: none; overflow: visible; }
.free #critter svg { filter: drop-shadow(0 2px 2px rgba(50, 36, 24, .22)); }
.free #critter { animation: dk-breathe 4.2s ease-in-out infinite; transform-origin: 50% 100%;
                 transition: transform .25s cubic-bezier(.34, 1.56, .64, 1); }
.free.hover #critter { animation: none; transform: scale(1.08) translateY(-1px); }
.free.hover #dk-eyes-open { display: none !important; }
.free.hover #dk-eyes-happy { display: inline !important; }
#dk-mouth-open, #dk-eyes-happy, #dk-burst { transform-box: fill-box; }

/* Every trick moves like a body: it crouches before it jumps, eases up and falls faster, squashes when
   it lands and settles with a small overshoot; ears and tail follow a beat behind. */
/* hop: a double bounce */
.t-hop .free #trick { animation: dk-t-hop 1.3s; }
.t-hop .free #ground { animation: dk-t-ground-hop 1.3s; }
.t-hop .free #dk-ear-l { animation: dk-t-ears-l 1.3s ease-in-out .04s; }
.t-hop .free #dk-ear-r { animation: dk-t-ears-r 1.3s ease-in-out .07s; }
.t-hop .free #dk-tail { animation: dk-flick .32s ease-in-out .1s 3; }
/* flip: a backflip, a cheer when it lands */
.t-flip .free #trick { transform-origin: 50% 55%; animation: dk-t-flip 1.5s; }
.t-flip .free #ground { animation: dk-t-ground-flip 1.5s; }
.t-flip .free #dk-ear-l { animation: dk-t-ears-l 1.5s ease-in-out .05s; }
.t-flip .free #dk-ear-r { animation: dk-t-ears-r 1.5s ease-in-out .08s; }
.t-flip .free #dk-burst { animation: dk-pop .7s ease-out 1.05s 1 forwards; }
/* dance: sways and bobs to a beat, head swaying the other way, eyes shut with joy */
.t-dance .free #trick { animation: dk-t-dance 2.2s ease-in-out; }
.t-dance .free #dk-head { animation: dk-t-headsway 2.2s ease-in-out .08s; }
.t-dance .free #dk-ear-l { animation: dk-t-flop .55s ease-in-out .1s 4; }
.t-dance .free #dk-ear-r { animation: dk-t-flop .55s ease-in-out .37s 4; }
.t-dance .free #dk-tail { animation: dk-flick .55s ease-in-out 4; }
/* curious: tilts its head one way then the other, ears up, looks around */
.t-curious .free #dk-head { animation: dk-t-tilt 2.2s; }
.t-curious .free #dk-ear-l { animation: dk-t-perk 2.2s ease-in-out .1s; }
.t-curious .free #dk-ear-r { animation: dk-t-perk-r 2.2s ease-in-out .16s; }
.t-curious .free #dk-pupils { animation: dk-t-lookup 2.2s ease-in-out; }
.t-curious .free #trick { animation: dk-t-lean 2.2s ease-in-out; }
/* wag: looks back over its shoulder and wags its tail */
.t-wag .free #dk-tail { animation: dk-t-wagging 1.6s ease-in-out; }
.t-wag .free #dk-pupils { animation: dk-t-lookback 1.6s ease-in-out; }
.t-wag .free #dk-head { animation: dk-t-turnback 1.6s ease-in-out; }
.t-wag .free #trick { animation: dk-t-wag 1.6s ease-in-out; }
/* stretch: a play bow and a yawn, then shakes itself off */
.t-stretch .free #trick { animation: dk-t-stretch 2.6s ease-in-out; }
.t-stretch .free #dk-head { animation: dk-t-yawn-head 2.6s ease-in-out; }
.t-stretch .free #dk-ear-l, .t-stretch .free #dk-ear-r { animation: dk-t-flop .2s ease-in-out 1.9s 3; }
.t-stretch .free #dk-eyes-open, .t-dance .free #dk-eyes-open, .t-flip .free #dk-eyes-open { display: none !important; }
.t-stretch .free #dk-eyes-happy, .t-dance .free #dk-eyes-happy, .t-flip .free #dk-eyes-happy { display: inline !important; }
.t-stretch .free #dk-mouth-smile, .t-hop .free #dk-mouth-smile, .t-dance .free #dk-mouth-smile,
.t-flip .free #dk-mouth-smile { display: none !important; }
.t-stretch .free #dk-mouth-open, .t-hop .free #dk-mouth-open, .t-dance .free #dk-mouth-open,
.t-flip .free #dk-mouth-open { display: inline !important; }
/* whistle: bops its head to a little tune, eyes up, tail ticking the beat; notes drift up */
.t-whistle .free #trick { animation: dk-t-bop 2.4s ease-in-out; }
.t-whistle .free #dk-head { animation: dk-t-headsway 2.4s ease-in-out .06s; }
.t-whistle .free #dk-pupils { animation: dk-t-lookup 2.4s ease-in-out; }
.t-whistle .free #dk-tail { animation: dk-flick .6s ease-in-out 4; }
.t-whistle .free #dk-ear-l { animation: dk-t-flop .6s ease-in-out .15s 4; }
.note { position: absolute; width: 10px; height: 12px; left: 75%; bottom: calc(var(--size) * .55); opacity: 0;
        animation: dk-t-note 1.6s cubic-bezier(.3, .6, .4, 1) forwards; }
.note.n2 { width: 8px; height: 9px; animation-delay: .55s; }
.note.n3 { animation-delay: 1.1s; }
.note svg { width: 100%; height: 100%; display: block; overflow: visible; }

/* kick: a donkey buck. Weight forward onto the front feet, the rear pops up and both hind legs kick
   out behind, then it lands with a squash and a puff of dust, pleased with itself */
.t-kick .free #trick { transform-origin: 58% 93%; animation: dk-t-buck 1.5s; }
.t-kick .free #dk-leg-bl, .t-kick .free #dk-leg-br { animation: dk-t-hindkick 1.5s; }
.t-kick .free #dk-leg-fl, .t-kick .free #dk-leg-fr { animation: dk-t-brace 1.5s ease-in-out; }
.t-kick .free #dk-head { animation: dk-t-buck-head 1.5s ease-in-out; }
.t-kick .free #dk-ear-l { animation: dk-t-ears-l 1.5s ease-in-out .08s; }
.t-kick .free #dk-ear-r { animation: dk-t-ears-r 1.5s ease-in-out .11s; }
.t-kick .free #dk-tail { animation: dk-t-tailup 1.5s ease-in-out; }
.t-kick .free #dk-brow-l { transform: translateY(.8px) rotate(12deg); }
.t-kick .free #dk-brow-r { transform: translateY(1.6px) rotate(-12deg); }

/* sneeze: ah... ah... nose up, eyes squeezing shut, then ACHOO with a jolt back and a little puff */
.t-sneeze .free #trick { animation: dk-t-sneeze 2s; }
.t-sneeze .free #dk-head { animation: dk-t-sneeze-head 2s; }
.t-sneeze .free #dk-eyes-open { animation: dk-t-squeeze 2s; }
.t-sneeze .free #dk-ear-l { animation: dk-t-ears-l 1.1s ease-in-out .95s; }
.t-sneeze .free #dk-ear-r { animation: dk-t-ears-r 1.1s ease-in-out .98s; }
.t-sneeze .free #dk-tail { animation: dk-flick .3s ease-in-out 1s 2; }

/* doze: gets drowsy, head nods down, eyes shut, a few z's float up... then it snaps awake with a
   start, ears up, and shakes it off as if nothing happened */
.t-doze .free #trick { animation: dk-t-doze 3.6s; }
.t-doze .free #dk-head { animation: dk-t-doze-head 3.6s; }
.t-doze .free #dk-eyes-open { animation: dk-t-doze-eyes 3.6s; }
.t-doze .free #dk-pupils { animation: none; }
.t-doze .free #dk-ear-l { animation: dk-t-doze-ear-l 3.6s; }
.t-doze .free #dk-ear-r { animation: dk-t-doze-ear-r 3.6s; }
.t-doze .free #dk-tail { animation: none; }
.zz { position: absolute; left: 66%; bottom: calc(var(--size) * .78); opacity: 0; color: #6d5a4c;
      font: 700 9px/1 "Inter", "Segoe UI Variable", "Segoe UI", system-ui, sans-serif; animation: dk-t-z 1.5s ease-out forwards; }
.zz.z2 { font-size: 7px; animation-delay: .45s; }
.zz.z3 { font-size: 10px; animation-delay: .9s; }

/* prance: a proud high-stepping trot in place, chin up, tail high */
.t-prance .free #trick { animation: dk-t-prance .55s ease-in-out 4; }
.t-prance .free #dk-leg-fr, .t-prance .free #dk-leg-bl { animation: dk-t-step .55s ease-in-out 4; }
.t-prance .free #dk-leg-fl, .t-prance .free #dk-leg-br { animation: dk-t-step .55s ease-in-out -.275s 4; }
.t-prance .free #dk-head { animation: dk-t-proud 2.2s ease-in-out; }
.t-prance .free #dk-tail { animation: dk-t-tailup 2.2s ease-in-out; }
.t-prance .free #dk-ear-l, .t-prance .free #dk-ear-r { animation: dk-t-flop .55s ease-in-out .1s 4; }

.t-kick .free #dk-mouth-smile, .t-prance .free #dk-mouth-smile, .t-sneeze .free #dk-mouth-smile { display: none !important; }
.t-kick .free #dk-mouth-open, .t-prance .free #dk-mouth-open, .t-sneeze .free #dk-mouth-open { display: inline !important; }
.puff { position: absolute; border-radius: 50%; background: rgba(214, 200, 184, .9); opacity: 0;
        animation: dk-t-puff .8s ease-out forwards; }
.puff.kd { left: 22%; bottom: 2%; width: 8px; height: 6px; animation-delay: .62s; }
.puff.kd.p2 { left: 12%; bottom: 6%; width: 6px; height: 5px; animation-delay: .68s; }
.puff.sn { left: 76%; bottom: 46%; width: 7px; height: 7px; background: rgba(232, 235, 240, .95);
           box-shadow: 0 0 0 .6px rgba(120, 120, 135, .35);
           animation: dk-t-snpuff .7s ease-out 1s forwards; }
.puff.sn.p2 { left: 80%; bottom: 52%; width: 5px; height: 5px; animation-delay: 1.05s; }
.puff.sn.p3 { left: 81%; bottom: 41%; width: 5px; height: 5px; animation-delay: 1.08s; }

@keyframes dk-t-bop { 0%, 100% { transform: none; } 12.5%, 37.5%, 62.5%, 87.5% { transform: translateY(.6px) scale(1.02, .98); }
                      25%, 75% { transform: rotate(-2deg) translateY(-1px); } 50% { transform: rotate(2deg) translateY(-1px); } }
@keyframes dk-t-note {
  0% { opacity: 0; transform: translate(0, 2px) scale(.4) rotate(-10deg); } 18% { opacity: 1; transform: translate(2px, -2px) scale(1) rotate(6deg); }
  55% { opacity: 1; transform: translate(7px, -12px) rotate(-8deg); } 100% { opacity: 0; transform: translate(10px, -24px) rotate(10deg); } }
@keyframes dk-t-buck {
  0% { transform: none; animation-timing-function: cubic-bezier(.3, 0, .5, 1); }
  18% { transform: translateY(1px) rotate(-3deg) scale(1.05, .95); animation-timing-function: cubic-bezier(.2, .8, .3, 1); }
  36% { transform: translateY(-1px) rotate(17deg); animation-timing-function: ease-in-out; }
  46% { transform: translateY(-1px) rotate(15deg); animation-timing-function: cubic-bezier(.6, 0, .85, .5); }
  60% { transform: translateY(.5px) rotate(-2deg) scale(1.07, .93); animation-timing-function: cubic-bezier(.2, .75, .35, 1); }
  74% { transform: rotate(1deg) scale(.98, 1.02); animation-timing-function: ease-in-out; } 86% { transform: rotate(-.5deg); } 100% { transform: none; } }
@keyframes dk-t-hindkick { 0%, 20%, 62%, 100% { transform: rotate(0deg); } 34% { transform: rotate(58deg); animation-timing-function: ease-out; }
                           46% { transform: rotate(48deg); } }
@keyframes dk-t-brace { 0%, 100% { transform: rotate(0deg); } 18% { transform: rotate(6deg); } 36%, 46% { transform: rotate(-10deg); } 62% { transform: rotate(3deg); } }
@keyframes dk-t-buck-head { 0%, 100% { transform: rotate(0deg); } 18% { transform: rotate(4deg); } 36%, 46% { transform: rotate(-12deg); } 62% { transform: rotate(3deg); } }
@keyframes dk-t-tailup { 0%, 100% { transform: rotate(0deg); } 20%, 80% { transform: rotate(-32deg); } 50% { transform: rotate(-24deg); } }
@keyframes dk-t-sneeze {
  0% { transform: none; } 18% { transform: translateY(-.5px) scale(.98, 1.03); } 32% { transform: translateY(-1px) scale(.97, 1.05); }
  46% { transform: translateY(-1.5px) scale(.96, 1.07); animation-timing-function: cubic-bezier(.7, 0, .9, .5); }
  51% { transform: translate(-3px, .5px) scale(1.09, .9) rotate(2deg); animation-timing-function: cubic-bezier(.2, .8, .3, 1); }
  64% { transform: translate(-1px, 0) scale(.98, 1.02); animation-timing-function: ease-in-out; } 78% { transform: scale(1.01, .99); } 100% { transform: none; } }
@keyframes dk-t-sneeze-head {
  0% { transform: rotate(0deg); } 18% { transform: rotate(-7deg); } 26% { transform: rotate(-5deg); } 34% { transform: rotate(-11deg); }
  46% { transform: rotate(-16deg); animation-timing-function: cubic-bezier(.7, 0, .9, .5); }
  51% { transform: rotate(15deg); animation-timing-function: cubic-bezier(.2, .8, .3, 1); }
  62% { transform: rotate(-3deg); } 72% { transform: rotate(2deg); } 82%, 100% { transform: rotate(0deg); } }
@keyframes dk-t-squeeze { 0%, 14% { transform: scaleY(1); } 30% { transform: scaleY(.6); } 42%, 60% { transform: scaleY(.08); }
                          66% { transform: scaleY(1.08); } 74%, 100% { transform: scaleY(1); } 86% { transform: scaleY(.08); } 90% { transform: scaleY(1); } }
@keyframes dk-t-doze {
  0%, 100% { transform: none; } 14% { transform: translateY(.5px) scale(1.01, .99); }
  30%, 46% { transform: translateY(1px) scale(1.025, .975); } 38%, 54% { transform: translateY(.6px) scale(1.01, .99); }
  60% { transform: translateY(1px) scale(1.03, .97); animation-timing-function: cubic-bezier(.2, .8, .3, 1); }
  66% { transform: translateY(-7px) scale(.95, 1.06); animation-timing-function: cubic-bezier(.6, 0, .85, .45); }
  73% { transform: translateY(0) scale(1.06, .94); animation-timing-function: ease-in-out; }
  80% { transform: rotate(-2deg); } 85% { transform: rotate(2deg); } 90% { transform: rotate(-1deg); } 95% { transform: none; } }
@keyframes dk-t-doze-head {
  0% { transform: rotate(0deg); } 14% { transform: rotate(6deg); } 22% { transform: rotate(3deg); }
  32%, 58% { transform: rotate(13deg); } 44% { transform: rotate(11deg); }
  64% { transform: rotate(-8deg); animation-timing-function: cubic-bezier(.2, .8, .3, 1); }
  76% { transform: rotate(0deg); } 81% { transform: rotate(-6deg); } 86% { transform: rotate(6deg); } 91% { transform: rotate(-3deg); } 100% { transform: rotate(0deg); } }
@keyframes dk-t-doze-eyes { 0% { transform: scaleY(1); } 12% { transform: scaleY(.45); } 18% { transform: scaleY(.7); }
  26%, 60% { transform: scaleY(.08); } 64% { transform: scaleY(1.22); } 74% { transform: scaleY(1.1); } 82%, 100% { transform: scaleY(1); } }
@keyframes dk-t-doze-ear-l { 0%, 100% { transform: rotate(0deg); } 26%, 60% { transform: rotate(-26deg); }
  65% { transform: rotate(14deg); } 72% { transform: rotate(-6deg); } 80% { transform: rotate(3deg); } }
@keyframes dk-t-doze-ear-r { 0%, 100% { transform: rotate(0deg); } 26%, 60% { transform: rotate(26deg); }
  65% { transform: rotate(-14deg); } 72% { transform: rotate(6deg); } 80% { transform: rotate(-3deg); } }
@keyframes dk-t-z { 0% { opacity: 0; transform: translate(0, 0) scale(.5); } 20% { opacity: .9; transform: translate(2px, -3px) scale(1); }
                    100% { opacity: 0; transform: translate(9px, -16px) scale(1.1) rotate(12deg); } }
@keyframes dk-t-prance { 0%, 50%, 100% { transform: translateY(0) scale(1.02, .98); animation-timing-function: cubic-bezier(.2, .7, .4, 1); }
                         25%, 75% { transform: translateY(-2.5px) scale(.99, 1.01); animation-timing-function: cubic-bezier(.6, 0, .8, .4); } }
@keyframes dk-t-step { 0%, 55%, 100% { transform: rotate(0deg); } 22% { transform: rotate(-48deg) translateY(-1.5px); } 40% { transform: rotate(-14deg); } }
@keyframes dk-t-proud { 0%, 100% { transform: rotate(0deg); } 12%, 88% { transform: rotate(-7deg); } 50% { transform: rotate(-5deg); } }
@keyframes dk-t-puff { 0% { opacity: 0; transform: scale(.3); } 25% { opacity: .9; transform: scale(1); }
                       100% { opacity: 0; transform: translate(-6px, -4px) scale(1.9); } }
@keyframes dk-t-snpuff { 0% { opacity: 0; transform: scale(.3); } 20% { opacity: 1; transform: translate(2px, 0) scale(1.1); }
                         100% { opacity: 0; transform: translate(9px, -2px) scale(2); } }

@keyframes dk-breathe { 0%, 100% { transform: scale(1, 1); } 50% { transform: scale(1.01, 1.025); } }
@keyframes dk-t-hop {
  0% { transform: none; animation-timing-function: cubic-bezier(.3, 0, .5, 1); }
  12% { transform: translateY(1.5px) scale(1.1, .88); animation-timing-function: cubic-bezier(.2, .75, .35, 1); }
  38% { transform: translateY(-16px) scale(.95, 1.06) rotate(-3deg); animation-timing-function: cubic-bezier(.6, 0, .85, .45); }
  56% { transform: translateY(0) scale(1.12, .86); animation-timing-function: cubic-bezier(.2, .75, .35, 1); }
  68% { transform: translateY(-5px) scale(.98, 1.03) rotate(1deg); animation-timing-function: cubic-bezier(.6, 0, .85, .45); }
  79% { transform: translateY(0) scale(1.05, .95); animation-timing-function: ease-in-out; }
  90% { transform: scale(.99, 1.01); } 100% { transform: none; } }
@keyframes dk-t-ground-hop {
  0%, 12%, 56%, 79%, 100% { transform: translateX(-50%) scale(1); opacity: 1; animation-timing-function: cubic-bezier(.2, .75, .35, 1); }
  38% { transform: translateX(-50%) scale(.55); opacity: .45; animation-timing-function: cubic-bezier(.6, 0, .85, .45); }
  68% { transform: translateX(-50%) scale(.85); opacity: .8; animation-timing-function: cubic-bezier(.6, 0, .85, .45); } }
@keyframes dk-t-flip {
  0% { transform: none; animation-timing-function: cubic-bezier(.3, 0, .5, 1); }
  15% { transform: translateY(2px) scale(1.12, .86); animation-timing-function: cubic-bezier(.25, .6, .45, 1); }
  42% { transform: translateY(-22px) rotate(-170deg) scale(.94); animation-timing-function: cubic-bezier(.5, 0, .75, .6); }
  70% { transform: translateY(0) rotate(-360deg) scale(1.12, .88); animation-timing-function: cubic-bezier(.2, .75, .35, 1); }
  82% { transform: translateY(-2px) rotate(-360deg) scale(.97, 1.04); animation-timing-function: ease-in-out; }
  92% { transform: rotate(-360deg) scale(1.02, .98); } 100% { transform: rotate(-360deg); } }
@keyframes dk-t-ground-flip {
  0%, 15%, 70%, 100% { transform: translateX(-50%) scale(1); opacity: 1; animation-timing-function: cubic-bezier(.25, .6, .45, 1); }
  42% { transform: translateX(-50%) scale(.45); opacity: .4; animation-timing-function: cubic-bezier(.5, 0, .75, .6); } }
@keyframes dk-t-ears-l { 0%, 100% { transform: rotate(0deg); } 12% { transform: rotate(6deg); } 35% { transform: rotate(-22deg); }
                         58% { transform: rotate(10deg); } 72% { transform: rotate(-7deg); } 86% { transform: rotate(3deg); } }
@keyframes dk-t-ears-r { 0%, 100% { transform: rotate(0deg); } 12% { transform: rotate(-6deg); } 35% { transform: rotate(22deg); }
                         58% { transform: rotate(-10deg); } 72% { transform: rotate(7deg); } 86% { transform: rotate(-3deg); } }
@keyframes dk-t-dance { 0%, 100% { transform: none; }
  12.5%, 62.5% { transform: translate(-1.5px, -3px) rotate(-7deg); } 25%, 75% { transform: translateY(.5px) scale(1.04, .96); }
  37.5%, 87.5% { transform: translate(1.5px, -3px) rotate(7deg); } 50% { transform: translateY(.5px) scale(1.04, .96); } }
@keyframes dk-t-headsway { 0%, 100% { transform: rotate(0deg); } 12.5%, 62.5% { transform: rotate(6deg); }
                           37.5%, 87.5% { transform: rotate(-6deg); } }
@keyframes dk-t-flop { 0%, 100% { transform: rotate(0deg); } 50% { transform: rotate(-16deg); } }
@keyframes dk-t-tilt {
  0% { transform: rotate(0deg); animation-timing-function: cubic-bezier(.34, 1.5, .64, 1); }
  16%, 44% { transform: rotate(-13deg); animation-timing-function: cubic-bezier(.34, 1.5, .64, 1); }
  60%, 78% { transform: rotate(7deg); animation-timing-function: cubic-bezier(.45, 0, .3, 1); } 100% { transform: rotate(0deg); } }
@keyframes dk-t-perk { 0%, 100% { transform: rotate(0deg); } 16%, 78% { transform: rotate(10deg); } 50% { transform: rotate(4deg); } }
@keyframes dk-t-perk-r { 0%, 100% { transform: rotate(0deg); } 16%, 78% { transform: rotate(-12deg); } 50% { transform: rotate(-5deg); } }
@keyframes dk-t-lookup { 0%, 100% { transform: translate(0, 0); } 16%, 44% { transform: translate(.6px, -1.2px); }
                         60%, 80% { transform: translate(-1.2px, -.5px); } }
@keyframes dk-t-lean { 0%, 100% { transform: none; } 16%, 44% { transform: translateY(-1px) rotate(-1.5deg); }
                       60%, 80% { transform: rotate(1deg); } }
@keyframes dk-t-wagging { 0%, 100% { transform: rotate(0deg); } 10%, 30%, 50%, 70% { transform: rotate(-30deg); }
                          20%, 40%, 60%, 80% { transform: rotate(8deg); } 90% { transform: rotate(-10deg); } }
@keyframes dk-t-lookback { 0%, 100% { transform: translate(0, 0); } 12%, 85% { transform: translate(-1.5px, 0); } }
@keyframes dk-t-turnback { 0%, 100% { transform: rotate(0deg); } 14%, 82% { transform: rotate(-7deg); } }
@keyframes dk-t-wag { 0%, 100% { transform: none; } 14%, 82% { transform: rotate(-2.5deg); }
                      30%, 50%, 70% { transform: rotate(-2.5deg) translateY(-1px); } 40%, 60% { transform: rotate(-2.5deg); } }
@keyframes dk-t-stretch { 0%, 100% { transform: none; }
  22%, 52% { transform: translateY(1px) rotate(7deg) scale(1.08, .92); } 62% { transform: scale(.97, 1.05); }
  70% { transform: none; } 74% { transform: rotate(-3deg); } 78% { transform: rotate(3deg); } 82% { transform: rotate(-2deg); }
  86% { transform: rotate(1.5deg); } 90% { transform: rotate(-.5deg); } }
@keyframes dk-t-yawn-head { 0%, 70%, 100% { transform: rotate(0deg); } 22%, 52% { transform: rotate(-16deg); } }

/* bray: a hee-haw. Breathes in with its chin up, ears laid back, eyes squeezed; the mouth opens on
   every hee and haw and the belly heaves with it */
.t-bray .free #trick { animation: dk-t-bray 2.6s ease-in-out; }
.t-bray .free #dk-head { animation: dk-t-bray-head 2.6s ease-in-out; }
.t-bray .free #dk-mouth-smile { display: none !important; }
.t-bray .free #dk-mouth-open { display: inline !important; transform-origin: 50% 0%; animation: dk-t-bray-mouth 2.6s ease-in-out; }
.t-bray .free #dk-eyes-open { animation: dk-t-bray-eyes 2.6s ease-in-out; }
.t-bray .free #dk-pupils { animation: none; transform: translate(.4px, -1px); }
.t-bray .free #dk-ear-l { animation: dk-t-bray-ear-l 2.6s ease-in-out; }
.t-bray .free #dk-ear-r { animation: dk-t-bray-ear-r 2.6s ease-in-out; }
.t-bray .free #dk-tail { animation: dk-t-tailup 2.6s ease-in-out; }
.ah { position: absolute; left: 80%; bottom: 48%; width: 9px; height: 12px; opacity: 0;
      animation: dk-t-ah .45s ease-out .62s forwards; }
.ah.a2 { animation-delay: 1.09s; } .ah.a3 { animation-delay: 1.61s; } .ah.a4 { animation-delay: 2.08s; }
.ah svg { width: 100%; height: 100%; display: block; overflow: visible; }

/* graze: dips to a tuft of grass, tugs a blade free and stands back up chewing it, the blade sticking
   out of its mouth and getting shorter, eyes half shut, content; an ear and the tail flick at flies */
.t-graze .free #trick { transform-origin: 30% 96%; animation: dk-t-graze 3.6s ease-in-out; }
.t-graze .free #dk-head { animation: dk-t-graze-head 3.6s ease-in-out; }
.t-graze .free #dk-scarf, .t-graze .free #dk-scarf-tails { transform-box: fill-box; transform-origin: 50% 0%;
  animation: dk-t-graze-scarf 3.6s ease-in-out; }
.t-graze .free #dk-mouth-smile { transform-box: fill-box; transform-origin: 50% 30%; animation: dk-t-chew .32s ease-in-out 1.05s 7; }
.t-graze .free #dk-pupils { animation: dk-t-graze-eyes 3.6s ease-in-out; }
.t-graze .free #dk-eyes-open { animation: dk-t-graze-lids 3.6s ease-in-out; }
.t-graze .free #dk-ear-r { animation: dk-t-ears-r .6s ease-in-out 2s; }
.t-graze .free #dk-tail { animation: dk-t-swat-soft 1s ease-in-out 1.4s; }
.grass { position: absolute; left: 57%; bottom: 2%; width: 17px; height: 24px; transform-origin: 50% 100%;
         opacity: 0; animation: dk-t-grass 3.6s ease-in-out forwards; }
.grass svg, .blade svg { width: 100%; height: 100%; display: block; overflow: visible; }
/* the blade in its mouth: rides with the chewing, gets shorter, then the last bit is gone */
.blade { position: absolute; left: 71%; bottom: 54%; width: 9px; height: 3px; transform-origin: 0 50%; opacity: 0;
         animation: dk-t-blade 3.6s linear forwards; }
.blade i { position: absolute; inset: 0; animation: dk-t-chew .32s ease-in-out 1.05s 7; }

/* paw: scrapes the ground with a front hoof three times, head down watching it, dust flying back */
.t-paw .free #trick { animation: dk-t-paw-body .7s ease-in-out .2s 3; }
.t-paw .free #dk-leg-fr { animation: dk-t-paw .7s ease-in-out .2s 3; }
.t-paw .free #dk-head { animation: dk-t-paw-head 2.5s ease-in-out; }
.t-paw .free #dk-pupils { animation: none; transform: translate(.6px, 1.2px); }
.t-paw .free #dk-brow-l { transform: translateY(.8px) rotate(12deg); }
.t-paw .free #dk-brow-r { transform: translateY(1.6px) rotate(-12deg); }
.t-paw .free #dk-tail { animation: dk-flick .35s ease-in-out .2s 6; }
.puff.pw { left: 50%; bottom: 3%; width: 7px; height: 5px; animation-delay: .64s; }
.puff.pw.p2 { animation-delay: 1.34s; } .puff.pw.p3 { animation-delay: 2.04s; }

/* swat: a fly buzzes in and lands on its back; the ear flicks at the buzz, the skin shivers, it looks
   round and swats it off with the tail */
.t-swat .free #trick { animation: dk-t-shiver 2.4s; }
.t-swat .free #dk-ear-l { animation: dk-t-ears-l .5s ease-in-out .6s; }
.t-swat .free #dk-head { animation: dk-t-swat-head 2.4s ease-in-out; }
.t-swat .free #dk-pupils { animation: dk-t-swat-eyes 2.4s ease-in-out; }
.t-swat .free #dk-tail { animation: dk-t-swat 2.4s ease-in-out; }
.fly { position: absolute; left: 34%; bottom: 44%; width: 6px; height: 5px; opacity: 0;
       animation: dk-t-fly 2.4s linear forwards; }
.fly svg { width: 100%; height: 100%; display: block; overflow: visible; }
.fly .w { transform-box: fill-box; transform-origin: 50% 100%; animation: dk-t-buzz .06s linear infinite alternate; }

/* rest: shifts its weight, cocks a hind hoof, lets its head and ears droop and blinks slowly, a sigh */
.t-rest .free #trick { animation: dk-t-rest 3.6s ease-in-out; }
.t-rest .free #dk-leg-br { animation: dk-t-cock 3.6s ease-in-out; }
.t-rest .free #dk-head { animation: dk-t-rest-head 3.6s ease-in-out; }
.t-rest .free #dk-eyes-open { animation: dk-t-rest-eyes 3.6s ease-in-out; }
.t-rest .free #dk-ear-l { animation: dk-t-rest-ear-l 3.6s ease-in-out; }
.t-rest .free #dk-ear-r { animation: dk-t-rest-ear-r 3.6s ease-in-out; }

/* snort: breathes in, shakes its head with the ears whipping round, and blows two puffs from its nose */
.t-snort .free #trick { animation: dk-t-snort 1.7s ease-in-out; }
.t-snort .free #dk-head { animation: dk-t-snort-head 1.7s ease-in-out; }
.t-snort .free #dk-eyes-open { animation: dk-t-snort-eyes 1.7s ease-in-out; }
.t-snort .free #dk-ear-l { animation: dk-t-ears-l .9s ease-in-out .3s; }
.t-snort .free #dk-ear-r { animation: dk-t-ears-r .9s ease-in-out .34s; }
.puff.nz { left: 52%; bottom: 52%; width: 5px; height: 4px; background: rgba(226, 229, 236, .9);
           box-shadow: 0 0 0 .5px rgba(120, 120, 135, .25); animation: dk-t-nzpuff .6s ease-out .3s forwards; }
.puff.nz.p2 { left: 74%; animation-name: dk-t-nzpuff-r; animation-delay: .34s; }

/* walk: a few steps forward, a look round, turns, walks back and turns again (the script turns it) */
.t-walk .free #trick { animation: dk-t-walk 4.4s ease-in-out; }
.t-walk .free #ground { animation: dk-t-walk-ground 4.4s ease-in-out; }
.t-walk .free #critter { animation: dk-t-walkbob .27s ease-in-out 6 alternate, dk-t-walkbob .27s ease-in-out 2.2s 6 alternate; }
.t-walk .free #dk-leg-fr, .t-walk .free #dk-leg-bl { animation: dk-t-step .54s ease-in-out 3, dk-t-step .54s ease-in-out 2.2s 3; }
.t-walk .free #dk-leg-fl, .t-walk .free #dk-leg-br { animation: dk-t-step .54s ease-in-out .27s 3, dk-t-step .54s ease-in-out 2.47s 3; }
.t-walk .free #dk-head { animation: dk-t-walk-head 4.4s ease-in-out; }
.t-walk .free #dk-pupils { animation: dk-t-walk-eyes 4.4s ease-in-out; }

@keyframes dk-t-bray { 0%, 100% { transform: none; } 14% { transform: translateY(-1px) scale(.98, 1.04); }
  24%, 62% { transform: scale(1.03, .97); } 32%, 52%, 70% { transform: scale(.99, 1.02); } 42%, 80% { transform: scale(1.04, .96); }
  92% { transform: scale(.99, 1.01); } }
@keyframes dk-t-bray-head { 0%, 100% { transform: rotate(0deg); } 14% { transform: rotate(-12deg); } 24% { transform: rotate(-16deg); }
  42% { transform: rotate(-18deg); } 62% { transform: rotate(-14deg); } 80% { transform: rotate(-17deg); } 92% { transform: rotate(2deg); } }
@keyframes dk-t-bray-mouth { 0%, 14%, 90%, 100% { transform: scaleY(.1); } 24% { transform: scaleY(1); } 32%, 70% { transform: scaleY(.25); }
  42%, 80% { transform: scaleY(1.15); } 52% { transform: scaleY(.2); } 62% { transform: scaleY(.95); } }
@keyframes dk-t-bray-eyes { 0%, 10%, 100% { transform: scaleY(1); } 20%, 84% { transform: scaleY(.3); } 42%, 80% { transform: scaleY(.2); } 92% { transform: scaleY(1.05); } }
@keyframes dk-t-bray-ear-l { 0%, 100% { transform: rotate(0deg); } 14% { transform: rotate(-12deg); } 24%, 82% { transform: rotate(-30deg); }
  42% { transform: rotate(-34deg); } 92% { transform: rotate(6deg); } }
@keyframes dk-t-bray-ear-r { 0%, 100% { transform: rotate(0deg); } 14% { transform: rotate(12deg); } 24%, 82% { transform: rotate(30deg); }
  42% { transform: rotate(34deg); } 92% { transform: rotate(-6deg); } }
@keyframes dk-t-ah { 0% { opacity: 0; transform: scale(.5); } 30% { opacity: .9; } 100% { opacity: 0; transform: translateX(4px) scale(1.25); } }

@keyframes dk-t-graze { 0%, 100% { transform: none; } 16%, 24% { transform: rotate(3deg) translateY(.4px); }
  29% { transform: rotate(-1deg) translateY(-.4px); } 36% { transform: none; } }
@keyframes dk-t-graze-head { 0%, 100% { transform: rotate(0deg); } 16% { transform: translate(1px, 6px) rotate(8deg); }
  24% { transform: translate(1px, 7px) rotate(10deg); animation-timing-function: cubic-bezier(.2, .8, .3, 1); }
  30% { transform: translateY(-.6px) rotate(-4deg); } 38%, 88% { transform: rotate(-1deg); } 63% { transform: rotate(1deg); } }
@keyframes dk-t-graze-scarf { 0%, 36%, 100% { transform: none; } 16% { transform: translate(.8px, 4.6px) rotate(3deg); }
  24% { transform: translate(.8px, 5.4px) rotate(4deg); } 30% { transform: translateY(-.3px); } }
@keyframes dk-t-graze-eyes { 0%, 100% { transform: translate(0, 0); } 12%, 26% { transform: translate(.6px, 1.5px); } 34%, 90% { transform: translate(.2px, .5px); } }
@keyframes dk-t-graze-lids { 0%, 10%, 100% { transform: scaleY(1); } 18%, 26% { transform: scaleY(.75); } 34%, 88% { transform: scaleY(.5); } 94% { transform: scaleY(1.05); } }
@keyframes dk-t-grass { 0% { opacity: 0; transform: scale(.3, 0); } 10% { opacity: 1; transform: scale(1); } 20% { transform: scale(1); }
  25% { transform: scale(.95, 1.12) rotate(4deg); } 28% { transform: scale(1, .82) rotate(-3deg); } 32% { transform: scale(1, .86) rotate(1deg); }
  36% { transform: scale(1, .8); } 80% { opacity: 1; transform: scale(1, .8); } 100% { opacity: 0; transform: scale(1, .8); } }
@keyframes dk-t-blade { 0%, 26% { opacity: 0; transform: scale(.6, 1); } 29% { opacity: 1; transform: rotate(18deg) scale(1.05, 1); }
  36% { transform: rotate(10deg) scale(1, 1); } 60% { transform: rotate(14deg) scale(.7, 1); } 80% { opacity: 1; transform: rotate(8deg) scale(.4, 1); }
  88%, 100% { opacity: 0; transform: rotate(8deg) scale(.15, 1); } }
@keyframes dk-t-chew { 0%, 100% { transform: none; } 50% { transform: translate(.5px, .8px) scale(.9, 1.15); } }
@keyframes dk-t-swat-soft { 0%, 100% { transform: rotate(0deg); } 30% { transform: rotate(-30deg); } 60% { transform: rotate(10deg); } }

@keyframes dk-t-paw { 0%, 100% { transform: rotate(0deg); } 30% { transform: rotate(-42deg) translateY(-1px); animation-timing-function: cubic-bezier(.5, 0, .7, 1); }
  55% { transform: rotate(-8deg); animation-timing-function: cubic-bezier(.2, .7, .4, 1); } 80% { transform: rotate(16deg); } }
@keyframes dk-t-paw-body { 0%, 100% { transform: none; } 30% { transform: translateY(-.6px) rotate(-1deg); }
  80% { transform: translateY(.4px) rotate(.8deg) scale(1.01, .99); } }
@keyframes dk-t-paw-head { 0%, 100% { transform: rotate(0deg); } 10%, 88% { transform: rotate(6deg); } 50% { transform: rotate(4deg); } }

@keyframes dk-t-fly { 0% { opacity: 0; transform: translate(-30px, -22px); } 8% { opacity: 1; transform: translate(-20px, -14px); }
  16% { transform: translate(-10px, -22px); } 24% { transform: translate(-2px, -12px); } 31% { transform: translate(-12px, -8px); }
  38% { transform: translate(-3px, -4px); } 42%, 52% { transform: translate(0, 0); } 58% { transform: translate(-8px, -12px); }
  72% { opacity: 1; transform: translate(-3px, -24px); } 100% { opacity: 0; transform: translate(-26px, -42px); } }
@keyframes dk-t-buzz { from { transform: scaleY(1); } to { transform: scaleY(.35); } }
@keyframes dk-t-shiver { 0%, 44%, 53%, 100% { transform: none; } 45.5% { transform: translateX(.5px); } 47% { transform: translateX(-.5px); }
  48.5% { transform: translateX(.5px); } 50% { transform: translateX(-.4px); } 51.5% { transform: translateX(.2px); } }
@keyframes dk-t-swat-head { 0%, 44%, 100% { transform: rotate(0deg); } 52%, 76% { transform: rotate(-9deg); } 64% { transform: rotate(-7deg); } 88% { transform: rotate(1deg); } }
@keyframes dk-t-swat-eyes { 0%, 100% { transform: translate(0, 0); } 10% { transform: translate(-1px, -1.2px); } 20% { transform: translate(.4px, -1.4px); }
  32% { transform: translate(-1.2px, -.6px); } 46%, 66% { transform: translate(-1.6px, 0); } 74% { transform: translate(-1px, -1.4px); } 86% { transform: translate(0, 0); } }
@keyframes dk-t-swat { 0%, 46%, 100% { transform: rotate(0deg); } 52% { transform: rotate(-50deg); animation-timing-function: ease-in; }
  57% { transform: rotate(14deg); } 62% { transform: rotate(-38deg); } 68% { transform: rotate(8deg); } 80% { transform: rotate(-8deg); } }

@keyframes dk-t-rest { 0%, 100% { transform: none; } 16%, 82% { transform: rotate(-1deg) translateY(.6px); }
  52% { transform: rotate(-1deg) translateY(.8px) scale(1.02, .975); } 60% { transform: rotate(-1deg) translateY(.5px) scale(.995, 1.005); } }
@keyframes dk-t-cock { 0%, 100% { transform: rotate(0deg); } 18%, 80% { transform: translateY(-1.8px) rotate(12deg); } }
@keyframes dk-t-rest-head { 0%, 100% { transform: rotate(0deg); } 22%, 80% { transform: rotate(6deg); } 52% { transform: rotate(8deg); } }
@keyframes dk-t-rest-eyes { 0%, 100% { transform: scaleY(1); } 18%, 36%, 48%, 80% { transform: scaleY(.5); } 42% { transform: scaleY(.08); } 90% { transform: scaleY(1.05); } }
@keyframes dk-t-rest-ear-l { 0%, 100% { transform: rotate(0deg); } 20%, 82% { transform: rotate(-18deg); } }
@keyframes dk-t-rest-ear-r { 0%, 100% { transform: rotate(0deg); } 20%, 82% { transform: rotate(18deg); } 60% { transform: rotate(14deg); } 64% { transform: rotate(20deg); } }

@keyframes dk-t-snort { 0%, 100% { transform: none; } 12% { transform: translateY(-.5px) scale(.98, 1.03); } 20% { transform: scale(1.03, .97); }
  32% { transform: rotate(-1.5deg); } 44% { transform: rotate(1.5deg); } 56% { transform: rotate(-1deg); } 68% { transform: rotate(.5deg); } 80% { transform: none; } }
@keyframes dk-t-snort-head { 0%, 100% { transform: rotate(0deg); } 12% { transform: rotate(-4deg); } 22% { transform: rotate(10deg); }
  32% { transform: rotate(-10deg); } 42% { transform: rotate(8deg); } 52% { transform: rotate(-5deg); } 62% { transform: rotate(3deg); } 74% { transform: rotate(0deg); } }
@keyframes dk-t-snort-eyes { 0%, 14%, 70%, 100% { transform: scaleY(1); } 20%, 60% { transform: scaleY(.25); } }
@keyframes dk-t-nzpuff { 0% { opacity: 0; transform: scale(.3); } 20% { opacity: 1; transform: translate(-2px, 1px) scale(1); }
  100% { opacity: 0; transform: translate(-8px, 4px) scale(1.8); } }
@keyframes dk-t-nzpuff-r { 0% { opacity: 0; transform: scale(.3); } 20% { opacity: 1; transform: translate(2px, 1px) scale(1); }
  100% { opacity: 0; transform: translate(8px, 4px) scale(1.8); } }

@keyframes dk-t-walk { 0% { transform: none; } 36%, 50% { transform: translateX(calc(var(--dir, 1) * 12px)); } 86%, 100% { transform: none; } }
@keyframes dk-t-walk-ground { 0% { transform: translateX(-50%); } 36%, 50% { transform: translateX(calc(-50% + var(--dir, 1) * 12px)); } 86%, 100% { transform: translateX(-50%); } }
@keyframes dk-t-walkbob { from { transform: translateY(0) scale(1.01, .99); } to { transform: translateY(-1.2px) scale(.995, 1.005); } }
@keyframes dk-t-walk-head { 0%, 34%, 50%, 100% { transform: rotate(0deg); } 10%, 26% { transform: rotate(2deg); } 40% { transform: rotate(-6deg); } }
@keyframes dk-t-walk-eyes { 0%, 34%, 52%, 100% { transform: translate(0, 0); } 38% { transform: translate(1.2px, -.8px); } 44% { transform: translate(-1.2px, -.4px); } }
"""

JS = """
function setState(s) { document.body.className = s; s === 'free' ? tricks.start() : tricks.stop(); }
function setHover(on) { document.body.classList.toggle('hover', on); }
const root = document.documentElement;
function lift(on) { root.classList.toggle('lifted', on); if (!on) root.style.setProperty('--tilt', '0deg'); }
function face(d) { const left = d < 0; if (root.classList.contains('face-left') === left) return;
  once('turning', 360); setTimeout(() => root.classList.toggle('face-left', left), 150); }
function tilt(deg) { root.style.setProperty('--tilt', deg + 'deg'); }
function once(cls, ms) { root.classList.remove(cls); void root.offsetWidth; root.classList.add(cls);
  if (ms) setTimeout(() => root.classList.remove(cls), ms); }
// The pulled-out donkey does one small trick every 4 to 9 seconds, never while you hover over it,
// carry it, or it's busy (any state but free). The bigger ones (kick, bray) come up less often; the backflip
// never comes up by itself, only from the menu.
// play(name) does one on request (the right-click menu), right away.
const NOTE = ["<svg viewBox='0 0 10 12'><path fill='#6d5a4c' d='M8.6 0v8.3a2.3 1.9 -20 1 1 -1.4 -1.7V2.6L3.6 3.6v5.7a2.3 1.9 -20 1 1 -1.4 -1.7V1.6z'/></svg>",
              "<svg viewBox='0 0 10 12'><path fill='#6d5a4c' d='M6.2 0c.4 2.2 3.2 2.6 3.2 5-.8-1.2-2-1.6-3.2-1.7v5.6a2.3 1.9 -20 1 1 -1.4 -1.7z'/></svg>"];
const ARC = "<svg viewBox='0 0 9 12'><path d='M2 3 Q4.5 6 2 9 M5.5 1 Q9.5 6 5.5 11' stroke='#8c7f75' stroke-width='1.3' stroke-linecap='round' fill='none'/></svg>";
const GRASS = "<svg viewBox='0 0 17 24'><g fill='#7aa553' stroke='#5e8a3c' stroke-width='.5' stroke-linejoin='round'><path d='M3 24 Q3.4 14 .4 6 Q5.4 13 5.6 24 Z'/><path d='M5.4 24 Q6.6 11 4.6 .6 Q9 11 8.4 24 Z'/><path d='M8 24 Q9.4 13 13.6 4 Q11.6 14 10.8 24 Z'/><path d='M10.4 24 Q12.6 17 16.6 12 Q14.4 18 13.4 24 Z'/><path d='M6.8 24 Q8.6 16 7.8 8 Q10.6 16 9.6 24 Z' fill='#8bb862'/></g></svg>";
const BLADE = "<i><svg viewBox='0 0 9 3'><path d='M0 1.4 Q4.5 .4 9 1.2 Q4.5 2.6 0 2.2 Z' fill='#7aa553' stroke='#5e8a3c' stroke-width='.35'/></svg></i>";
const FLY = "<svg viewBox='0 0 6 5'><ellipse class='w' cx='2.2' cy='1.6' rx='1.3' ry='1.5' fill='rgba(200,215,230,.85)'/><ellipse class='w' cx='3.6' cy='1.6' rx='1.3' ry='1.5' fill='rgba(200,215,230,.85)'/><ellipse cx='3' cy='3.4' rx='1.6' ry='1.2' fill='#2a2420'/></svg>";
const FX = {
  whistle: [['note', NOTE[0]], ['note n2', NOTE[1]], ['note n3', NOTE[0]]],
  kick: [['puff kd', ''], ['puff kd p2', '']],
  sneeze: [['puff sn', ''], ['puff sn p2', ''], ['puff sn p3', '']],
  doze: [['zz', 'z'], ['zz z2', 'z'], ['zz z3', 'Z']],
  bray: [['ah', ARC], ['ah a2', ARC], ['ah a3', ARC], ['ah a4', ARC]],
  graze: [['grass', GRASS], ['blade', BLADE]],
  paw: [['puff pw', ''], ['puff pw p2', ''], ['puff pw p3', '']],
  swat: [['fly', FLY]],
  snort: [['puff nz', ''], ['puff nz p2', '']],
};
const tricks = {
  moves: [['hop', 1300, 4], ['curious', 2200, 4], ['wag', 1600, 3], ['dance', 2200, 3], ['prance', 2200, 3],
          ['whistle', 2400, 3], ['sneeze', 2000, 2], ['stretch', 2600, 2], ['doze', 3600, 2], ['kick', 1500, 2],
          ['graze', 3600, 3], ['swat', 2400, 3], ['rest', 3600, 2], ['paw', 2500, 2], ['snort', 1700, 2],
          ['walk', 4400, 2], ['bray', 2600, 1], ['flip', 1500, 0]],
  timer: null, end: null, last: null, turns: [],
  start(first) { clearTimeout(this.timer); this.timer = setTimeout(() => this.play(), first || 4000 + Math.random() * 5000); },
  stop() { clearTimeout(this.timer); clearTimeout(this.end); this.timer = null; this.clear(); },
  clear() { for (const [n] of this.moves) root.classList.remove('t-' + n); this.turns.forEach(clearTimeout); this.turns = [];
    document.getElementById('fx').querySelectorAll('.note, .puff, .zz, .ah, .grass, .blade, .fly').forEach(e => e.remove()); },
  pick() { const pool = this.moves.filter(m => m[0] !== this.last);
    let r = Math.random() * pool.reduce((a, m) => a + m[2], 0);
    for (const m of pool) { if ((r -= m[2]) < 0) return m; } return pool[0]; },
  play(name) {
    if (!document.body.classList.contains('free') || root.classList.contains('lifted')) { if (!name) this.start(3000); return; }
    if (!name && document.body.classList.contains('hover')) { this.start(3000); return; }
    const move = (name && this.moves.find(m => m[0] === name)) || this.pick();
    const [n, ms] = move; this.last = n;
    clearTimeout(this.timer); clearTimeout(this.end);
    document.body.classList.remove('hover');
    this.clear(); void root.offsetWidth; root.classList.add('t-' + n);
    for (const [cls, html] of FX[n] || []) { const e = document.createElement('div');
      e.className = cls; e.innerHTML = html; document.getElementById('fx').appendChild(e); setTimeout(() => e.remove(), ms + 800); }
    if (n === 'walk') {  // turns round twice on the way; --dir keeps "forward" the way it started
      const left = root.classList.contains('face-left'); root.style.setProperty('--dir', left ? -1 : 1);
      this.turns = [setTimeout(() => face(left ? 1 : -1), 1900), setTimeout(() => face(left ? -1 : 1), 3850)]; }
    this.end = setTimeout(() => { root.classList.remove('t-' + n); this.start(); }, ms);
  },
};
"""


def _html(size: int, state: str) -> str:
    svg = (ASSETS / "creature.svg").read_text()
    return (f"<!doctype html><html><head><meta charset='utf-8'><style>:root{{--size:{size}px}}{CSS}</style>"
            f"<script>{JS}</script></head><body class='{state}'><div id='lift'><div id='ground'></div><div id='trick'><div id='turn'><div id='face'><div id='critter'>{svg}</div><div id='fx'></div></div></div></div></div></body></html>")


class ClickLayer(QWidget):
    """A see-through widget over the creature that takes its clicks, drags, hovers and right-clicks
    (the web page under it never sees them). `handler(kind, info)` hears "click" (info: 1 or 2
    clicks), "hold", "menu" (info: the pointer), "enter" and "exit"."""

    def __init__(self, parent, creature, handler, draggable: bool):
        super().__init__(parent)
        self.creature, self.handler = creature, handler
        self.drag = creature if draggable else None
        self.setAttribute(Qt.WA_NoSystemBackground)
        self.setAttribute(Qt.WA_AlwaysShowToolTips)
        self.setMouseTracking(True)
        self.setCursor(Qt.PointingHandCursor)
        self.held = self.dragged = False
        self.clicks = 1
        self.press_at = None
        self.hold = QTimer(self)
        self.hold.setSingleShot(True)
        self.hold.setInterval(int(HOLD_S * 1000))
        self.hold.timeout.connect(self._hold_fired)

    def _emit(self, kind, info=None):
        if self.handler:
            try:
                self.handler(kind, info)
            except Exception:
                import logging
                logging.getLogger("donkey.overlay").exception("creature %s", kind)

    def mousePressEvent(self, ev):
        if ev.button() == Qt.RightButton:
            self._emit("menu", winui.cursor())
            return
        if ev.button() != Qt.LeftButton:
            return
        self.held = self.dragged = False
        self.clicks = 1
        self.press_at = ev.globalPosition()
        if self.drag is not None:
            self.drag.grab()
        self.hold.start()

    def mouseDoubleClickEvent(self, ev):
        if ev.button() != Qt.LeftButton:
            return
        self.held = self.dragged = False
        self.clicks = 2
        self.press_at = ev.globalPosition()
        self.hold.stop()

    def mouseMoveEvent(self, ev):
        if self.drag is None or not ev.buttons() & Qt.LeftButton or self.press_at is None:
            return
        if not self.dragged:
            d = ev.globalPosition() - self.press_at
            if math.hypot(d.x(), d.y()) < 3:
                return
            self.hold.stop()
            self.dragged = True
            self.drag.lift()
        self.drag.follow_pointer()

    def _hold_fired(self):
        self.held = True
        self._emit("hold")

    def mouseReleaseEvent(self, ev):
        if ev.button() != Qt.LeftButton:
            return
        self.hold.stop()
        self.press_at = None
        if self.dragged:
            self.dragged = False
            self.drag.drop()
            return
        if self.held:
            return  # a press-and-hold already did its thing
        self._emit("click", self.clicks)

    def enterEvent(self, ev):
        self._emit("enter")

    def leaveEvent(self, ev):
        self._emit("exit")


class Creature:
    """One creature window. `box` is the window size in pixels; the creature is drawn at `size`.

    A draggable one is picked up (it grows a little and its shadow drops), leans into the way it's
    carried, keeps its momentum when let go, and lands with a small squash. The handler hears
    "moving" while it travels and "moved" once it rests; `on_release(x, y)` may claim a drop at that
    pointer position (return True) before it's thrown."""

    def __init__(self, size: int, box: tuple[int, int], state: str, handler=None, tooltip: str | None = None,
                 hit: tuple[int, int] | None = None, draggable: bool = False):
        self.box = box
        self.visible = False
        self.frame = None
        self.handler = handler
        self.on_release = None
        self.grip = (box[0] / 2, box[1] / 2)
        self.velocity = motion.Velocity()
        self.tilted = 0.0
        panel = winui.Panel(box[0], box[1], focusable=False)
        panel.load(_html(size, state))
        # Only the creature is clickable (bottom-centre), not the space above it kept for the hop.
        hw, hh = hit or box
        rect = ((box[0] - hw) / 2, box[1] - hh, hw, hh)
        clicks = ClickLayer(panel, self, handler, draggable)
        clicks.setGeometry(int(rect[0]), int(rect[1]), int(hw), int(hh))
        if tooltip:
            clicks.setToolTip(tooltip)
        clicks.raise_()
        panel.set_hit([rect])
        self.panel, self.clicks = panel, clicks
        panel.park()  # up but invisible from the start, so its first appearance is already drawn
        self.spring = motion.Spring(panel, on_step=self._travelling)
        self.tween = motion.Tween(panel)

    def js(self, code: str) -> None:
        self.panel.js(code)

    def set_state(self, state: str) -> None:
        self.js(f"setState({json.dumps(state)})")

    def show_at(self, x: float, y: float) -> None:
        """Place the window's top-left corner at (x, y) and show it."""
        frame = (round(x), round(y))
        if frame != self.frame:
            self.panel.move_to(*frame)
            self.frame = frame
        if not self.visible:
            self.panel.set_alpha(1.0)
            self.panel.present()
            self.visible = True

    def hide(self, after: float = 0.0, fade: bool = True) -> None:
        def _hide():
            if fade:
                self.js("document.body.classList.add('gone')")
                winui.call_later(0.35, self._order_out)
            else:
                self._order_out()
        if after:
            winui.call_later(after, _hide)
        else:
            _hide()

    # -------------------------------------------------------------- carried around

    def grab(self, grip: tuple[float, float] | None = None) -> None:
        """The pointer took hold: at `grip` (window pixels), else where it is over the window."""
        self.spring.stop()
        self.tween.stop()
        self.js("root.classList.remove('running')")
        if grip is None:
            (px, py), (ox, oy) = winui.cursor(), self.panel.origin()
            grip = (px - ox, py - oy)
        self.grip = grip
        self.velocity.clear()

    def lift(self) -> None:
        self.js("lift(true)")

    def follow_pointer(self) -> None:
        px, py = winui.cursor()
        self.panel.move_to(px - self.grip[0], py - self.grip[1])
        self.velocity.add(px, py)
        self._lean(self.velocity.get()[0])
        if self.handler:
            self.handler("moving", None)

    def drop(self) -> None:
        """Let go: thrown on with the pointer's speed, kept on screen, settling where it lands."""
        self.js("lift(false)")
        self.frame = None
        px, py = winui.cursor()
        if self.on_release and self.on_release(px, py):
            return
        vx, vy = self.velocity.get()
        ox, oy = self.panel.origin()
        x, y = motion.project(ox, oy, vx, vy)
        x, y = clamp_to_screen(x, y, *self.box)
        self.spring.to(x, y, vx, vy, on_done=self._landed)

    def fly_to(self, x: float, y: float, then=None) -> None:
        """Glide (with a small overshoot) to window origin (x, y)."""
        self.frame = None
        self.spring.to(x, y, response=0.5, damping=0.72, on_done=then)

    def run_to(self, x: float, y: float, then=None) -> None:
        """Run to window origin (x, y): turn to face that way, gallop there leaning in, speeding up
        and slowing down, then skid to a stop leaning back. `then(direction)` once it's there (1 for
        right, -1 for left). The handler hears nothing on the way; the caller placed things around it."""
        ox, oy = self.panel.origin()
        dx = x - ox
        if abs(dx) < 4:
            if then:
                then(1)
            return
        d = 1 if dx > 0 else -1
        self.spring.stop()
        self.js(f"face({d})")
        duration = min(1.1, max(0.45, math.hypot(dx, y - oy) / 240))

        def arrive():
            self.frame = None
            self.js(f"root.classList.remove('running'); tilt({-5 * d})")
            winui.call_later(0.2, lambda: self.js("tilt(0)"))
            if then:
                then(d)

        def go():
            self.js(f"root.classList.add('running'); setState('working'); tilt({6 * d})")
            self.tween.run(frame=(x, y, *self.box), duration=duration, ease="inout", then=arrive)
        winui.call_later(0.3, go)  # it turns around first

    def face(self, direction: int) -> None:
        self.js(f"face({direction})")

    def trick(self, name: str = "") -> None:
        """Do one trick now (a name from TRICKS; empty picks one at random)."""
        self.js(f"tricks.play({json.dumps(name) if name else ''})")

    def pop_in(self) -> None:
        self.js("once('popin', 600)")

    def fly_away(self, x: float, y: float) -> None:
        """Shrink into the point (x, y) (window origin there) and go."""
        self.js("once('popout', 0)")
        self.spring.to(x, y, response=0.32, damping=0.95, on_done=self._order_out)

    def _travelling(self, x, y, vx, vy) -> None:
        self._lean(vx)
        if self.handler:
            self.handler("moving", None)

    def _lean(self, vx: float) -> None:
        deg = max(-14.0, min(14.0, vx / 90))
        if abs(deg - self.tilted) >= 0.5 or (deg == 0 and self.tilted):
            self.tilted = deg
            self.js(f"tilt({deg:.1f})")

    def _landed(self) -> None:
        self._lean(0.0)
        self.js("once('landed', 500)")
        if self.handler:
            self.handler("moved", None)

    def origin(self) -> tuple[float, float]:
        """Where the window is now (it may have been dragged since show_at)."""
        return self.panel.origin()

    def _order_out(self) -> None:
        self.spring.stop()
        self.panel.dismiss()
        self.visible = False
        self.frame = None
        self.js("document.body.classList.remove('gone'); root.classList.remove('popout', 'lifted')")


# ------------------------------------------------------------------ geometry

def clamp_to_screen(x: float, y: float, w: float, h: float) -> tuple[float, float]:
    """Keep a box (top-left x, y) fully on the screen that contains its centre, clear of the taskbar."""
    return winui.clamp_to_screen(x, y, w, h)

# The pulled-out donkey's tricks, as the right-click menu names them (ids match tricks.moves in JS)
TRICKS = [("hop", "Hop"), ("flip", "Backflip"), ("kick", "Buck kick"), ("dance", "Dance"), ("prance", "Prance"),
          ("whistle", "Whistle a tune"), ("sneeze", "Sneeze"), ("doze", "Doze off"), ("stretch", "Stretch"),
          ("curious", "Look around"), ("wag", "Wag its tail"), ("bray", "Bray"), ("graze", "Graze"),
          ("paw", "Paw the ground"), ("swat", "Swat a fly"), ("rest", "Rest a hind leg"), ("snort", "Snort"),
          ("walk", "Walk and turn")]


def context_menu(items: list, at=None) -> None:
    """Pop up a small menu at the pointer. Items are (title, callable[, argument]), (title, [items])
    for a submenu, or None for a separator."""
    winui.context_menu(items, at)