"""SQLite storage: snapshots with full-text search, events, and rewrite history."""
import sqlite3
import threading
import time

from . import textmerge
from .config import DB_PATH

SCHEMA = """
CREATE TABLE IF NOT EXISTS snapshots (
    id             INTEGER PRIMARY KEY,
    app            TEXT NOT NULL,
    bundle_id      TEXT,
    window_title   TEXT NOT NULL DEFAULT '',
    url            TEXT,
    domain         TEXT,
    content        TEXT NOT NULL,
    focused_role   TEXT,
    captured_at    REAL NOT NULL,
    last_seen_at   REAL NOT NULL,
    duration_s     REAL NOT NULL DEFAULT 0,
    sighting_count INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_snap_seen ON snapshots(last_seen_at);
CREATE INDEX IF NOT EXISTS idx_snap_key ON snapshots(app, window_title, url);

CREATE VIRTUAL TABLE IF NOT EXISTS snapshots_fts USING fts5(
    content, app, window_title, domain,
    content='snapshots', content_rowid='id', tokenize='porter unicode61'
);
CREATE TRIGGER IF NOT EXISTS snap_ai AFTER INSERT ON snapshots BEGIN
    INSERT INTO snapshots_fts(rowid, content, app, window_title, domain)
    VALUES (new.id, new.content, new.app, new.window_title, new.domain);
END;
CREATE TRIGGER IF NOT EXISTS snap_ad AFTER DELETE ON snapshots BEGIN
    INSERT INTO snapshots_fts(snapshots_fts, rowid, content, app, window_title, domain)
    VALUES ('delete', old.id, old.content, old.app, old.window_title, old.domain);
END;
CREATE TRIGGER IF NOT EXISTS snap_au AFTER UPDATE OF content, app, window_title, domain ON snapshots BEGIN
    INSERT INTO snapshots_fts(snapshots_fts, rowid, content, app, window_title, domain)
    VALUES ('delete', old.id, old.content, old.app, old.window_title, old.domain);
    INSERT INTO snapshots_fts(rowid, content, app, window_title, domain)
    VALUES (new.id, new.content, new.app, new.window_title, new.domain);
END;

CREATE TABLE IF NOT EXISTS rewrites (
    id           INTEGER PRIMARY KEY,
    ts           REAL NOT NULL,
    app          TEXT,
    domain       TEXT,
    mode         TEXT,
    input_text   TEXT,
    output_text  TEXT,
    method       TEXT,
    latency_ms   INTEGER,
    error        TEXT
);

-- Foreground time per hour bucket ("YYYY-MM-DDTHH", local time).
CREATE TABLE IF NOT EXISTS time_ledger (
    hour_key  TEXT NOT NULL,
    app       TEXT NOT NULL,
    domain    TEXT NOT NULL DEFAULT '',
    seconds   REAL NOT NULL DEFAULT 0,
    PRIMARY KEY (hour_key, app, domain)
);

-- The same foreground time per window title, for time by project ('' = no title: blocked or unread).
CREATE TABLE IF NOT EXISTS time_titles (
    hour_key  TEXT NOT NULL,
    app       TEXT NOT NULL,
    domain    TEXT NOT NULL DEFAULT '',
    title     TEXT NOT NULL DEFAULT '',
    seconds   REAL NOT NULL DEFAULT 0,
    PRIMARY KEY (hour_key, app, domain, title)
);

-- Rules that file time under a project: every given field must match (title_contains: substring).
CREATE TABLE IF NOT EXISTS time_rules (
    id             INTEGER PRIMARY KEY,
    project        TEXT NOT NULL,
    app            TEXT NOT NULL DEFAULT '',
    domain         TEXT NOT NULL DEFAULT '',
    title_contains TEXT NOT NULL DEFAULT '',
    source         TEXT NOT NULL,              -- user | learned
    enabled        INTEGER NOT NULL DEFAULT 1,
    created_at     REAL NOT NULL
);

-- Summaries per period: hour ("2026-10-15T09"), day ("2026-10-15"), week ("2026-W42").
CREATE TABLE IF NOT EXISTS chronicle (
    id             INTEGER PRIMARY KEY,
    period         TEXT NOT NULL,
    period_key     TEXT NOT NULL,
    summary        TEXT NOT NULL,
    snapshot_count INTEGER NOT NULL DEFAULT 0,
    model          TEXT,
    created_at     REAL NOT NULL,
    UNIQUE (period, period_key)
);
CREATE VIRTUAL TABLE IF NOT EXISTS chronicle_fts USING fts5(
    summary, period_key, content='chronicle', content_rowid='id', tokenize='porter unicode61'
);
CREATE TRIGGER IF NOT EXISTS chron_ai AFTER INSERT ON chronicle BEGIN
    INSERT INTO chronicle_fts(rowid, summary, period_key) VALUES (new.id, new.summary, new.period_key);
END;
CREATE TRIGGER IF NOT EXISTS chron_ad AFTER DELETE ON chronicle BEGIN
    INSERT INTO chronicle_fts(chronicle_fts, rowid, summary, period_key)
    VALUES ('delete', old.id, old.summary, old.period_key);
END;
CREATE TRIGGER IF NOT EXISTS chron_au AFTER UPDATE ON chronicle BEGIN
    INSERT INTO chronicle_fts(chronicle_fts, rowid, summary, period_key)
    VALUES ('delete', old.id, old.summary, old.period_key);
    INSERT INTO chronicle_fts(rowid, summary, period_key) VALUES (new.id, new.summary, new.period_key);
END;

-- The wiki: one page per person / project / organization / topic / tool.
CREATE TABLE IF NOT EXISTS wiki_pages (
    id             INTEGER PRIMARY KEY,
    slug           TEXT NOT NULL UNIQUE,
    page_type      TEXT NOT NULL,
    title          TEXT NOT NULL,
    aliases        TEXT NOT NULL DEFAULT '[]',   -- JSON list
    summary        TEXT NOT NULL DEFAULT '',
    body           TEXT NOT NULL DEFAULT '',
    links          TEXT NOT NULL DEFAULT '[]',   -- JSON list of slugs
    mention_count  INTEGER NOT NULL DEFAULT 0,
    first_seen     REAL,
    last_seen      REAL,
    is_dirty       INTEGER NOT NULL DEFAULT 1,
    pinned         INTEGER NOT NULL DEFAULT 0,   -- user-edited: never regenerated
    regen_failures INTEGER NOT NULL DEFAULT 0,
    model          TEXT,
    updated_at     REAL
);
CREATE VIRTUAL TABLE IF NOT EXISTS wiki_fts USING fts5(
    title, aliases, summary, body, content='wiki_pages', content_rowid='id', tokenize='porter unicode61'
);
CREATE TRIGGER IF NOT EXISTS wiki_ai AFTER INSERT ON wiki_pages BEGIN
    INSERT INTO wiki_fts(rowid, title, aliases, summary, body)
    VALUES (new.id, new.title, new.aliases, new.summary, new.body);
END;
CREATE TRIGGER IF NOT EXISTS wiki_ad AFTER DELETE ON wiki_pages BEGIN
    INSERT INTO wiki_fts(wiki_fts, rowid, title, aliases, summary, body)
    VALUES ('delete', old.id, old.title, old.aliases, old.summary, old.body);
END;
CREATE TRIGGER IF NOT EXISTS wiki_au AFTER UPDATE OF title, aliases, summary, body ON wiki_pages BEGIN
    INSERT INTO wiki_fts(wiki_fts, rowid, title, aliases, summary, body)
    VALUES ('delete', old.id, old.title, old.aliases, old.summary, old.body);
    INSERT INTO wiki_fts(rowid, title, aliases, summary, body)
    VALUES (new.id, new.title, new.aliases, new.summary, new.body);
END;

-- Evidence for wiki pages: what the hourly pass saw about an entity in one hour.
CREATE TABLE IF NOT EXISTS wiki_mentions (
    id           INTEGER PRIMARY KEY,
    slug         TEXT NOT NULL,
    hour_key     TEXT NOT NULL,
    note         TEXT NOT NULL,
    snapshot_ids TEXT NOT NULL DEFAULT '[]',
    created_at   REAL NOT NULL,
    UNIQUE (slug, hour_key)
);

-- How wiki pages connect. Together: the hourly pass linked them in the same hour (one row per hour,
-- so the count is how often). Relations: what the tidy pass says connects them, in a few words.
CREATE TABLE IF NOT EXISTS wiki_together (
    a        TEXT NOT NULL,   -- slugs, a < b
    b        TEXT NOT NULL,
    hour_key TEXT NOT NULL,
    PRIMARY KEY (a, b, hour_key)
);
CREATE TABLE IF NOT EXISTS wiki_relations (
    a          TEXT NOT NULL,   -- the page the tidy pass was looking at
    b          TEXT NOT NULL,
    label      TEXT NOT NULL,
    updated_at REAL NOT NULL,
    PRIMARY KEY (a, b)
);
-- Names the tidy pass found are not real things (a UI word, the user themselves): never paged again.
CREATE TABLE IF NOT EXISTS wiki_rejects (
    slug   TEXT PRIMARY KEY,
    title  TEXT NOT NULL,
    at     REAL NOT NULL
);

-- Typed signals from the hourly pass (feed open loops / nudges later).
CREATE TABLE IF NOT EXISTS flags (
    id         INTEGER PRIMARY KEY,
    hour_key   TEXT NOT NULL,
    kind       TEXT NOT NULL,
    text       TEXT NOT NULL,
    slugs      TEXT NOT NULL DEFAULT '[]',
    created_at REAL NOT NULL
);

-- Embedding vectors (float32) for chronicle rows and wiki pages.
CREATE TABLE IF NOT EXISTS embeddings (
    kind      TEXT NOT NULL,      -- chronicle | wiki
    ref_id    INTEGER NOT NULL,
    model     TEXT NOT NULL,
    text_hash TEXT NOT NULL,
    vec       BLOB NOT NULL,
    PRIMARY KEY (kind, ref_id)
);

-- Mail/calendar screens waiting for attention extraction (re-queued when their text changes).
CREATE TABLE IF NOT EXISTS attention_queue (
    snapshot_id  INTEGER PRIMARY KEY,
    content_hash TEXT NOT NULL,
    attempts     INTEGER NOT NULL DEFAULT 0,
    done         INTEGER NOT NULL DEFAULT 0,
    last_error   TEXT,
    queued_at    REAL NOT NULL
);

-- Meetings and mail seen on screen.
CREATE TABLE IF NOT EXISTS attention_items (
    id                 INTEGER PRIMARY KEY,
    kind               TEXT NOT NULL,              -- meeting | email
    dedupe_key         TEXT NOT NULL UNIQUE,
    title              TEXT NOT NULL,
    participants       TEXT NOT NULL DEFAULT '[]',
    summary            TEXT NOT NULL DEFAULT '',
    starts_at          REAL,
    ends_at            REAL,
    location           TEXT,
    needs_reply        INTEGER NOT NULL DEFAULT 0,
    due_at             REAL,
    status             TEXT NOT NULL DEFAULT 'active',  -- active | done | cancelled | moved | gone (not on its calendar day)
    source_snapshot_id INTEGER,
    created_at         REAL NOT NULL,
    updated_at         REAL NOT NULL
);

-- Unfinished business: what the user owes, what is owed to them, open questions, blockers.
CREATE TABLE IF NOT EXISTS open_loops (
    id             INTEGER PRIMARY KEY,
    kind           TEXT NOT NULL,       -- owed_by_user | owed_to_user | question | blocker
    summary        TEXT NOT NULL,
    person         TEXT,
    project        TEXT,
    due_at         REAL,
    status         TEXT NOT NULL DEFAULT 'open',    -- open | done | dropped
    evidence       TEXT NOT NULL DEFAULT '[]',      -- JSON list of short evidence notes
    close_evidence TEXT,
    todo_id        INTEGER,
    last_nudged_at REAL,
    created_at     REAL NOT NULL,
    updated_at     REAL NOT NULL,
    closed_at      REAL
);

CREATE TABLE IF NOT EXISTS todos (
    id         INTEGER PRIMARY KEY,
    text       TEXT NOT NULL,
    done       INTEGER NOT NULL DEFAULT 0,
    source     TEXT NOT NULL DEFAULT 'user',   -- user | auto
    loop_id    INTEGER,
    created_at REAL NOT NULL,
    done_at    REAL
);

-- Every proactive message, sent or deliberately skipped. dedupe_key makes jobs idempotent.
CREATE TABLE IF NOT EXISTS nudges (
    id           INTEGER PRIMARY KEY,
    kind         TEXT NOT NULL,     -- morning_brief | evening_wrap | meeting_brief | followup | reminder | scheduled_prompt
    dedupe_key   TEXT NOT NULL UNIQUE,
    title        TEXT NOT NULL DEFAULT '',
    body         TEXT NOT NULL DEFAULT '',
    status       TEXT NOT NULL,     -- delivered | seen | skipped | failed
    skip_reason  TEXT,
    created_at   REAL NOT NULL,
    delivered_at REAL,
    seen_at      REAL
);

CREATE TABLE IF NOT EXISTS job_state (
    key        TEXT PRIMARY KEY,
    value      TEXT,
    updated_at REAL
);

-- What the user sent (or typed and cleared) from a message field, with how we know.
CREATE TABLE IF NOT EXISTS sends (
    id           INTEGER PRIMARY KEY,
    ts           REAL NOT NULL,
    kind         TEXT NOT NULL,      -- sent (the app marked it as the user's) | cleared (field emptied)
    proof        TEXT NOT NULL,      -- sent: outgoing | cleared: not_sent (app would have marked it) / unknown
    app          TEXT NOT NULL,
    domain       TEXT,
    window_title TEXT NOT NULL DEFAULT '',
    surface      TEXT NOT NULL DEFAULT '',   -- chat header (contact or group) or window title
    text         TEXT NOT NULL,
    rewrite_id   INTEGER
);
CREATE INDEX IF NOT EXISTS idx_sends_ts ON sends(ts);

-- Lines that repeat on most screens of one site or app (page chrome), learned per surface.
CREATE TABLE IF NOT EXISTS boilerplate (
    surface TEXT NOT NULL,
    key     TEXT NOT NULL,
    df      REAL NOT NULL,       -- share of that surface's screens containing it
    PRIMARY KEY (surface, key)
);
CREATE TABLE IF NOT EXISTS boilerplate_fit (
    surface   TEXT PRIMARY KEY,
    screens   INTEGER NOT NULL,
    fitted_at REAL NOT NULL
);

-- Writing rules: learned from the user's edits to rewrites, or stated by them ("from now on…").
-- Messages the user chose as examples of how they write, per app or site ('' = everywhere).
CREATE TABLE IF NOT EXISTS user_examples (
    id         INTEGER PRIMARY KEY,
    text       TEXT NOT NULL,
    scope      TEXT NOT NULL DEFAULT '',
    created_at REAL NOT NULL
);

-- Changes made through the MCP write tools, so one the user didn't ask for can be seen and undone.
CREATE TABLE IF NOT EXISTS tool_writes (
    id     INTEGER PRIMARY KEY,
    ts     REAL NOT NULL,
    tool   TEXT NOT NULL,
    args   TEXT NOT NULL,   -- JSON
    result TEXT NOT NULL
);

-- The daily summary page: sessions, focus, done, unfinished, next steps (daypage.py).
CREATE TABLE IF NOT EXISTS day_pages (
    day        TEXT PRIMARY KEY,
    body       TEXT NOT NULL,
    built_from REAL NOT NULL,   -- created_at of the newest hour summary it was built from
    created_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS style_rules (
    id         INTEGER PRIMARY KEY,
    rule       TEXT NOT NULL,
    scope      TEXT NOT NULL DEFAULT '',  -- '' = everywhere, else apps or sites, comma-separated
    source     TEXT NOT NULL,             -- learned | stated
    evidence   INTEGER NOT NULL DEFAULT 1,
    enabled    INTEGER NOT NULL DEFAULT 1,
    created_at REAL NOT NULL,
    updated_at REAL NOT NULL
);
-- Style preferences seen once (one retry run or one sitting of edits), waiting to be seen again (lessons.py).
CREATE TABLE IF NOT EXISTS style_lessons (
    id         INTEGER PRIMARY KEY,
    lesson     TEXT NOT NULL,
    scope      TEXT NOT NULL DEFAULT '',
    checks     TEXT,
    seen       TEXT NOT NULL DEFAULT '[]',   -- JSON timestamps of the evidence
    source     TEXT NOT NULL,                -- retries | edits
    rule_id    INTEGER,                      -- the learned rule it became
    created_at REAL NOT NULL,
    updated_at REAL NOT NULL
);
-- Reminders and scheduled prompts the user set (reminders.py). next_fire_at NULL = done.
CREATE TABLE IF NOT EXISTS reminders (
    id            INTEGER PRIMARY KEY,
    title         TEXT NOT NULL,
    text          TEXT NOT NULL,              -- what to say, or (ask = 1) the question to answer
    ask           INTEGER NOT NULL DEFAULT 0,
    repeat        TEXT NOT NULL,              -- once | daily | weekdays | weekly | interval
    fire_at       REAL,                       -- once
    hour          INTEGER,                    -- daily | weekdays | weekly
    minute        INTEGER,
    days          TEXT,                       -- weekly: JSON [1..7], 1 = Monday
    every_minutes INTEGER,                    -- interval
    next_fire_at  REAL,
    last_fired_at REAL,
    enabled       INTEGER NOT NULL DEFAULT 1,
    source        TEXT NOT NULL DEFAULT 'user',   -- user (CLI) | chat | mcp
    created_at    REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_reminders_next ON reminders(enabled, next_fire_at);

-- Chat with Donkey (chat.py). title_set = the user named it, so it's never retitled.
CREATE TABLE IF NOT EXISTS chat_threads (
    id         INTEGER PRIMARY KEY,
    title      TEXT NOT NULL DEFAULT '',
    title_set  INTEGER NOT NULL DEFAULT 0,
    nudge_id   INTEGER,                       -- a thread opened from an inbox message
    created_at REAL NOT NULL,
    updated_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS chat_messages (
    id         INTEGER PRIMARY KEY,
    thread_id  INTEGER NOT NULL,
    role       TEXT NOT NULL,                 -- user | assistant
    content    TEXT NOT NULL,
    tools      TEXT NOT NULL DEFAULT '[]',    -- JSON [{name, arguments, ok}] the reply used
    created_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_chat_thread ON chat_messages(thread_id, id);

-- Durable facts the user told Donkey in chat (facts.py). quote = their own words it came from.
CREATE TABLE IF NOT EXISTS user_facts (
    id            INTEGER PRIMARY KEY,
    fact          TEXT NOT NULL,
    quote         TEXT NOT NULL DEFAULT '',
    kind          TEXT NOT NULL,              -- preference | personal | person | plan | work | correction
    source        TEXT NOT NULL,              -- chat (distilled) | tool (remember_user_fact) | cli
    thread_id     INTEGER,
    message_id    INTEGER,
    active        INTEGER NOT NULL DEFAULT 1,
    superseded_by INTEGER,
    created_at    REAL NOT NULL,
    updated_at    REAL NOT NULL
);

-- Versions of the "About you" profile (profile.py): auto | edited (by the user) | reset.
CREATE TABLE IF NOT EXISTS profile_versions (
    id         INTEGER PRIMARY KEY,
    text       TEXT NOT NULL,
    source     TEXT NOT NULL,
    created_at REAL NOT NULL
);

-- Imported chats and notes (imports.py): ChatGPT and Claude exports, Markdown folders, Granola.
-- Kept apart from screen captures, so they never count as time, hourly activity or page chrome.
CREATE TABLE IF NOT EXISTS documents (
    id          INTEGER PRIMARY KEY,
    source      TEXT NOT NULL,                -- chatgpt | claude | markdown | granola
    external_id TEXT NOT NULL,
    title       TEXT NOT NULL DEFAULT '',
    path        TEXT,
    created_at  REAL,
    updated_at  REAL,
    hash        TEXT NOT NULL,
    chars       INTEGER NOT NULL DEFAULT 0,
    imported_at REAL NOT NULL,
    UNIQUE (source, external_id)
);
CREATE TABLE IF NOT EXISTS document_parts (
    id      INTEGER PRIMARY KEY,
    doc_id  INTEGER NOT NULL,
    seq     INTEGER NOT NULL,
    ts      REAL,
    text    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_parts_doc ON document_parts(doc_id, seq);
CREATE VIRTUAL TABLE IF NOT EXISTS document_fts USING fts5(
    text, content='document_parts', content_rowid='id', tokenize='porter unicode61'
);
CREATE TRIGGER IF NOT EXISTS docpart_ai AFTER INSERT ON document_parts BEGIN
    INSERT INTO document_fts(rowid, text) VALUES (new.id, new.text);
END;
CREATE TRIGGER IF NOT EXISTS docpart_ad AFTER DELETE ON document_parts BEGIN
    INSERT INTO document_fts(document_fts, rowid, text) VALUES ('delete', old.id, old.text);
END;
-- Claims ledger (claims.py): dated statements, linked into threads so a change shows.
CREATE TABLE IF NOT EXISTS claims (
    id           INTEGER PRIMARY KEY,
    thread       INTEGER,                    -- id of the first claim on this subject and topic
    replaces     INTEGER,                    -- the earlier claim this one changed
    subject      TEXT NOT NULL,
    topic        TEXT NOT NULL,
    value        TEXT NOT NULL,
    kind         TEXT NOT NULL,              -- number | plan | promise | decision | view | fact
    said_by      TEXT NOT NULL DEFAULT '',
    source       TEXT NOT NULL DEFAULT '',
    why          TEXT NOT NULL DEFAULT '',
    about_when   TEXT NOT NULL DEFAULT '',   -- the date or time it is about (a meeting, a deadline)
    affects      TEXT NOT NULL DEFAULT '[]', -- ids of earlier claims that rested on what this one changed
    snapshot_ids TEXT NOT NULL DEFAULT '[]',
    hour_key     TEXT NOT NULL,
    said_at      REAL NOT NULL,
    last_seen_at REAL NOT NULL,
    seen_count   INTEGER NOT NULL DEFAULT 1,
    current      INTEGER NOT NULL DEFAULT 1, -- 0 once a later claim replaced it
    created_at   REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_claims_thread ON claims(thread, said_at);
CREATE INDEX IF NOT EXISTS idx_claims_hour ON claims(hour_key);
CREATE VIRTUAL TABLE IF NOT EXISTS claims_fts USING fts5(
    subject, topic, value, why, source, said_by, about_when,
    content='claims', content_rowid='id', tokenize='porter unicode61'
);
CREATE TRIGGER IF NOT EXISTS claims_ai AFTER INSERT ON claims BEGIN
    INSERT INTO claims_fts(rowid, subject, topic, value, why, source, said_by, about_when)
    VALUES (new.id, new.subject, new.topic, new.value, new.why, new.source, new.said_by, new.about_when);
END;
CREATE TRIGGER IF NOT EXISTS claims_ad AFTER DELETE ON claims BEGIN
    INSERT INTO claims_fts(claims_fts, rowid, subject, topic, value, why, source, said_by, about_when)
    VALUES ('delete', old.id, old.subject, old.topic, old.value, old.why, old.source, old.said_by, old.about_when);
END;
CREATE TABLE IF NOT EXISTS claim_hours (
    hour_key TEXT PRIMARY KEY,
    claims   INTEGER NOT NULL,
    done_at  REAL NOT NULL
);
"""


# Columns added after a table first shipped: (table, column, declaration).
MIGRATIONS = [
    ("wiki_pages", "body_claims", "TEXT NOT NULL DEFAULT '[]'"),
    ("wiki_pages", "related_links", "TEXT NOT NULL DEFAULT '[]'"),
    ("wiki_pages", "tie", "TEXT NOT NULL DEFAULT ''"),       # how the user relates to it (wiki.TIES)
    ("wiki_pages", "sphere", "TEXT NOT NULL DEFAULT ''"),    # work | personal | '' (not clear)
    ("wiki_pages", "salience", "REAL NOT NULL DEFAULT 0"),   # how much it matters in the user's life (wiki.salience)
    ("wiki_pages", "tidied_at", "REAL"),
    ("wiki_pages", "tidied_mentions", "INTEGER NOT NULL DEFAULT 0"),
    ("snapshots", "body", "TEXT"),                      # content minus learned page chrome
    ("rewrites", "window_title", "TEXT"),
    ("rewrites", "surface", "TEXT"),
    ("rewrites", "sent_text", "TEXT"),                  # what the user actually sent after it
    ("rewrites", "sent_at", "REAL"),
    ("rewrites", "grade", "TEXT"),                      # verbatim | light-edit | heavy-edit | rewritten | rejected | survived | unknown | superseded
    ("rewrites", "similarity", "REAL"),
    ("rewrites", "mined_at", "REAL"),
    ("rewrites", "rejected_by", "TEXT"),                # clear (deleted unsent) | repress (pressed again)
    ("style_rules", "checks", "TEXT"),                  # JSON list of code checks given by mining (rulecheck.py)
    ("style_rules", "checked_at", "REAL"),              # when it was checked against the other rules
    ("style_rules", "retired", "TEXT"),                 # why it was turned off: "contradicts #3", "dormant", ...
    ("style_rules", "shown", "INTEGER NOT NULL DEFAULT 0"),   # rewrites with an outcome it was given to
    ("style_rules", "kept", "INTEGER NOT NULL DEFAULT 0"),    # ... kept (verbatim, light-edit, survived)
    ("style_rules", "undone", "INTEGER NOT NULL DEFAULT 0"),  # ... rejected, rewritten or heavily edited
    ("rewrites", "rule_ids", "TEXT"),                   # JSON ids of the style rules this rewrite was given
    ("rewrites", "rules_counted", "REAL"),
    ("chat_threads", "distilled_upto", "INTEGER NOT NULL DEFAULT 0"),   # last message read for facts (facts.py)
]


class DB:
    """One connection shared across threads, serialised with a lock."""

    def __init__(self, path=DB_PATH):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.executescript(SCHEMA)
        for table, column, decl in MIGRATIONS:
            cols = {r[1] for r in self.conn.execute(f"PRAGMA table_info({table})")}
            if column not in cols:
                self.conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {decl}")
        self.lock = threading.Lock()

    def upsert_snapshot(self, s: dict, coalesce_window_s: float, max_chars: int = 60000) -> int:
        """Insert a snapshot, or fold it into a recent row for the same view: the row keeps what
        the earlier reads saw as well (textmerge), unless that grows past `max_chars`."""
        now = s["captured_at"]
        with self.lock, self.conn:
            row = self.conn.execute(
                """SELECT id, last_seen_at, content FROM snapshots
                   WHERE app = ? AND window_title = ? AND COALESCE(url, '') = COALESCE(?, '')
                     AND last_seen_at >= ?
                   ORDER BY last_seen_at DESC LIMIT 1""",
                (s["app"], s["window_title"], s.get("url"), now - coalesce_window_s),
            ).fetchone()
            merged = textmerge.merge(row["content"] or "", s["content"], max_chars) if row else None
            if merged is not None:
                gap = min(now - row["last_seen_at"], coalesce_window_s)
                self.conn.execute(
                    """UPDATE snapshots SET content = ?, focused_role = ?, last_seen_at = ?,
                       duration_s = duration_s + ?, sighting_count = sighting_count + 1
                       WHERE id = ?""",
                    (merged, s.get("focused_role"), now, gap, row["id"]),
                )
                return row["id"]
            cur = self.conn.execute(
                """INSERT INTO snapshots (app, bundle_id, window_title, url, domain, content,
                   focused_role, captured_at, last_seen_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (s["app"], s.get("bundle_id"), s["window_title"], s.get("url"), s.get("domain"),
                 s["content"], s.get("focused_role"), now, now),
            )
            return cur.lastrowid

    def search(self, query: str, limit: int = 10) -> list[sqlite3.Row]:
        with self.lock:
            return self.conn.execute(
                """SELECT s.id, s.app, s.window_title, s.url, s.last_seen_at,
                          snippet(snapshots_fts, 0, '[', ']', ' … ', 24) AS excerpt
                   FROM snapshots_fts JOIN snapshots s ON s.id = snapshots_fts.rowid
                   WHERE snapshots_fts MATCH ?
                   ORDER BY bm25(snapshots_fts) LIMIT ?""",
                (query, limit),
            ).fetchall()

    def recent(self, limit: int = 10, exclude_id: int | None = None) -> list[sqlite3.Row]:
        with self.lock:
            return self.conn.execute(
                """SELECT id, app, window_title, url, content, last_seen_at, duration_s
                   FROM snapshots WHERE id != ? ORDER BY last_seen_at DESC LIMIT ?""",
                (exclude_id or -1, limit),
            ).fetchall()

    def record_rewrite(self, **r) -> int:
        with self.lock, self.conn:
            return self.conn.execute(
                """INSERT INTO rewrites (ts, app, domain, window_title, surface, mode, input_text, output_text,
                   method, latency_ms, error, rule_ids) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (time.time(), r.get("app"), r.get("domain"), r.get("window_title"), r.get("surface"), r.get("mode"),
                 r.get("input_text"), r.get("output_text"), r.get("method"), r.get("latency_ms"), r.get("error"),
                 r.get("rule_ids")),
            ).lastrowid

    def credit_time(self, app: str, domain: str | None, seconds: float, at: float, title: str | None = None) -> None:
        hour_key = time.strftime("%Y-%m-%dT%H", time.localtime(at))
        with self.lock, self.conn:
            self.conn.execute(
                """INSERT INTO time_titles (hour_key, app, domain, title, seconds) VALUES (?, ?, ?, ?, ?)
                   ON CONFLICT (hour_key, app, domain, title) DO UPDATE SET seconds = seconds + excluded.seconds""",
                (hour_key, app, domain or "", title or "", seconds),
            )
            self.conn.execute(
                """INSERT INTO time_ledger (hour_key, app, domain, seconds) VALUES (?, ?, ?, ?)
                   ON CONFLICT (hour_key, app, domain) DO UPDATE SET seconds = seconds + excluded.seconds""",
                (hour_key, app, domain or "", seconds),
            )

    def time_report(self, since_hour_key: str) -> list[sqlite3.Row]:
        with self.lock:
            return self.conn.execute(
                """SELECT app, domain, SUM(seconds) AS seconds FROM time_ledger
                   WHERE hour_key >= ? GROUP BY app, domain ORDER BY seconds DESC""",
                (since_hour_key,),
            ).fetchall()

    def query(self, sql: str, params=()) -> list[sqlite3.Row]:
        with self.lock:
            return self.conn.execute(sql, params).fetchall()

    def execute(self, sql: str, params=()) -> int:
        """Run one write; returns lastrowid."""
        with self.lock, self.conn:
            return self.conn.execute(sql, params).lastrowid

    def get_state(self, key: str) -> str | None:
        row = self.query("SELECT value FROM job_state WHERE key = ?", (key,))
        return row[0]["value"] if row else None

    def set_state(self, key: str, value: str) -> None:
        self.execute("""INSERT INTO job_state (key, value, updated_at) VALUES (?, ?, ?)
                        ON CONFLICT (key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at""",
                     (key, value, time.time()))

    def stats(self) -> dict:
        out = {}
        with self.lock:
            snaps = self.conn.execute("SELECT COUNT(*), COALESCE(SUM(sighting_count),0) FROM snapshots").fetchone()
            out["snapshots"], out["sightings"] = snaps[0], snaps[1]
            for table in ("rewrites", "wiki_pages", "wiki_mentions", "flags", "embeddings"):
                out[table] = self.conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
            for period, n in self.conn.execute("SELECT period, COUNT(*) FROM chronicle GROUP BY period"):
                out[f"chronicle_{period}"] = n
        return out
