"""Folding a fresh read of a window into the earlier read of the same view, losing nothing seen.

A re-read of the same window used to replace the saved text. Most windows give their whole text
either way, but some only hold what's visible: a chat that drops older messages as new ones come
in, a long list as it scrolls, a remote desktop read from pixels. There, replacing threw away
what the user had just seen. The merge keeps both, in reading order: text only in the old read
(scrolled out of view) stays where it was, text only in the new read goes where it appeared.
A small change on one spot (a word typed or deleted, a number ticking up) takes the new value.
"""
import logging
import re
from difflib import SequenceMatcher

log = logging.getLogger("donkey.textmerge")

SMALL_EDIT = 4  # tokens: a change this short in one spot is an edit, not text that left the view
MIN_ANCHOR = 3  # tokens: shorter matches ("the", "Message", a name) don't tie two reads together
_TOKEN = re.compile(r"\s*\S+|\s+$")


def _tokens(text: str) -> list[str]:
    return _TOKEN.findall(text)


def _anchored(ops: list[tuple]) -> list[tuple]:
    """Opcodes with short matches folded into the changes around them: list items built alike
    ("Invoice 1041 due 5 May", "Invoice 1187 due 9 June") otherwise look like small edits of each
    other, and the older item would be dropped."""
    out: list[list] = []
    for tag, i1, i2, j1, j2 in ops:
        if tag == "equal" and i2 - i1 < MIN_ANCHOR and len(ops) > 1:
            tag = "replace"
        if out and out[-1][0] != "equal" and tag != "equal":
            out[-1][2], out[-1][4] = i2, j2
            out[-1][0] = "replace"
        else:
            out.append([tag, i1, i2, j1, j2])
    for op in out:  # a folded run may have no old or no new side left
        if op[0] == "replace" and op[1] == op[2]:
            op[0] = "insert"
        elif op[0] == "replace" and op[3] == op[4]:
            op[0] = "delete"
    return [tuple(op) for op in out]


def merge(old: str, new: str, max_chars: int) -> str | None:
    """`_merge`, or the new read if merging fails: a bug here must not stop capture saving."""
    try:
        return _merge(old, new, max_chars)
    except Exception:
        log.exception("merging two reads failed; keeping the new one")
        return new


def _merge(old: str, new: str, max_chars: int) -> str | None:
    """The two reads as one text, or None when that is longer than `max_chars` and the old read
    holds a lot the new one lacks (the caller saves the new read as a row of its own). Overlong
    but losing little (a window cut off at `max_chars` where the user is typing): the new read."""
    if old == new or not old:
        return new
    a, b = _tokens(old), _tokens(new)
    ka, kb = [t.strip() for t in a], [t.strip() for t in b]
    out, kept_old = [], 0
    for tag, i1, i2, j1, j2 in _anchored(SequenceMatcher(None, ka, kb, autojunk=False).get_opcodes()):
        if tag in ("equal", "insert"):
            out += b[j1:j2]
        elif tag == "delete":
            if i2 - i1 > SMALL_EDIT:
                out += a[i1:i2]
                kept_old += sum(map(len, a[i1:i2]))
        else:  # replace
            if i2 - i1 > SMALL_EDIT or j2 - j1 > SMALL_EDIT:
                out += a[i1:i2]
                kept_old += sum(map(len, a[i1:i2]))
            out += b[j1:j2]
    text = "".join(t if i == 0 or t[:1].isspace() or out[i - 1][-1:].isspace() else "\n" + t
                   for i, t in enumerate(out))  # a piece kept from the old read meets the new one
    if len(text) <= max_chars:
        return text
    return new if kept_old <= max_chars // 10 else None
