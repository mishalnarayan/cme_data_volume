"""Reminders and scheduled prompts: "remind me at 5 to call mum", "every Friday, summarize my week".

A reminder says its text when it fires. A scheduled prompt (ask=True) is a question Donkey answers
from memory each time it fires, with the chat agent and read-only tools. Either way the result
becomes a nudge (so it's in the inbox and the chat) and a notification.

Times are parsed here, never computed by a model: tools and the CLI pass `at` as "17:00",
"5pm", "2026-10-18 09:30", "tomorrow 9am" or "in 20 minutes". Reminders the user set ignore quiet
hours. A one-off reminder missed while the PC slept fires late; a repeating one more than
LATE_SKIP_S late skips to its next time.
"""
import datetime as dt
import json
import logging
import re
import threading
import time

from . import notify
from .config import Config
from .db import DB

log = logging.getLogger("donkey.reminders")

TICK_S = 15
LATE_SKIP_S = 2 * 3600
NIGHT_OWL_H = 4           # before 04:00, "tomorrow" is the coming morning (the same date)
REPEATS = ("once", "daily", "weekdays", "weekly", "interval")
DAY_NAMES = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]


class ReminderError(ValueError):
    """Shown to the user (or the model) as-is."""


# ------------------------------------------------------------------ parsing times

_IN = re.compile(r"^in\s+(?:(\d+(?:\.\d+)?)\s*(d|day|days))?\s*(?:(\d+(?:\.\d+)?)\s*(h|hr|hrs|hour|hours))?\s*"
                 r"(?:(?:and\s+)?(\d+)\s*(m|min|mins|minute|minutes))?$")
_CLOCK = re.compile(r"^(\d{1,2})(?::(\d{2}))?\s*(am|pm)?$")


def parse_clock(text: str) -> tuple[int, int]:
    """'9', '09:30', '5pm', '5:30 pm', 'noon', 'midnight' → (hour, minute)."""
    t = text.strip().lower().replace(".", "")
    if t in ("noon", "midday"):
        return 12, 0
    if t == "midnight":
        return 0, 0
    m = _CLOCK.match(t)
    if not m:
        raise ReminderError(f"Couldn't read the time {text!r}. Use 17:00, 5pm or 5:30 pm.")
    h, mi = int(m[1]), int(m[2] or 0)
    if m[3]:
        if not 1 <= h <= 12:
            raise ReminderError(f"{text!r} isn't a time.")
        h = h % 12 + (12 if m[3] == "pm" else 0)
    if h > 23 or mi > 59:
        raise ReminderError(f"{text!r} isn't a time.")
    return h, mi


def parse_when(text: str, now: dt.datetime | None = None) -> dt.datetime:
    """A one-off moment: 'in 20 minutes', '17:00' (the next one), 'tomorrow 9am', 'friday 10:00',
    '2026-10-18 09:30'. Local time."""
    now = now or dt.datetime.now()
    t = " ".join(text.strip().lower().replace(" at ", " ").split())
    if t.startswith("in "):
        m = _IN.match(t)
        if not m or not any((m[1], m[3], m[5])):
            raise ReminderError(f"Couldn't read {text!r}. Try 'in 20 minutes' or 'in 2 hours'.")
        delta = dt.timedelta(days=float(m[1] or 0), hours=float(m[3] or 0), minutes=int(m[5] or 0))
        return (now + delta).replace(second=0, microsecond=0)
    if m := re.match(r"^(\d{4}-\d{2}-\d{2})(?:[ t](.+))?$", t):
        day = dt.date.fromisoformat(m[1])
        h, mi = parse_clock(m[2]) if m[2] else (9, 0)
        return dt.datetime.combine(day, dt.time(h, mi))
    day = None
    if t.startswith("today"):
        day, t = now.date(), t[5:].strip()
    elif t.startswith("tomorrow"):
        # Before NIGHT_OWL_H, "tomorrow" means after you sleep: later today.
        day, t = now.date() + dt.timedelta(days=0 if now.hour < NIGHT_OWL_H else 1), t[8:].strip()
    else:
        for i, name in enumerate(DAY_NAMES):
            if m := re.match(rf"^(?:next\s+|on\s+)?{name}[a-z]*\b\s*(.*)$", t):
                ahead = (i - now.weekday()) % 7 or 7
                day, t = now.date() + dt.timedelta(days=ahead), m[1]
                break
    h, mi = parse_clock(t) if t else (9, 0)
    if day is None:  # a bare time: the next one
        cand = now.replace(hour=h, minute=mi, second=0, microsecond=0)
        return cand if cand > now else cand + dt.timedelta(days=1)
    return dt.datetime.combine(day, dt.time(h, mi))


def parse_days(days) -> list[int]:
    """['mon', 'fri'] / 'mon,fri' / [1, 5] → [1, 5] (1 = Monday … 7 = Sunday)."""
    if isinstance(days, str):
        days = [d for d in re.split(r"[,\s]+", days) if d]
    out = []
    for d in days or []:
        s = str(d).strip().lower()
        if s.isdigit() and 1 <= int(s) <= 7:
            out.append(int(s))
        elif s[:3] in DAY_NAMES:
            out.append(DAY_NAMES.index(s[:3]) + 1)
        else:
            raise ReminderError(f"{d!r} isn't a day of the week.")
    return sorted(set(out))


# ------------------------------------------------------------------ schedules

def next_fire(r: dict, after: dt.datetime) -> dt.datetime | None:
    """The first time strictly after `after` that this schedule fires, or None when it's done."""
    repeat = r["repeat"]
    if repeat == "once":
        at = dt.datetime.fromtimestamp(r["fire_at"])
        return at if not r.get("last_fired_at") else None
    if repeat == "interval":
        step = dt.timedelta(minutes=r["every_minutes"])
        base = dt.datetime.fromtimestamp(r.get("last_fired_at") or r["created_at"])
        nxt = base + step
        while nxt <= after:
            nxt += step
        return nxt.replace(microsecond=0)
    days = {"daily": range(1, 8), "weekdays": range(1, 6)}.get(repeat) or json.loads(r["days"] or "[]")
    if not days:
        return None
    for ahead in range(0, 8):
        day = after.date() + dt.timedelta(days=ahead)
        if day.isoweekday() in days:
            cand = dt.datetime.combine(day, dt.time(r["hour"], r["minute"]))
            if cand > after:
                return cand
    return None


def describe(r) -> str:
    r = dict(r)
    hm = f"{r['hour']:02d}:{r['minute']:02d}" if r["hour"] is not None else ""
    if r["repeat"] == "once":
        when = time.strftime("%a %d %b %H:%M", time.localtime(r["fire_at"]))
    elif r["repeat"] == "interval":
        when = f"every {r['every_minutes']} min"
    elif r["repeat"] == "weekly":
        when = "every " + ", ".join(DAY_NAMES[d - 1].title() for d in json.loads(r["days"])) + f" at {hm}"
    else:
        when = f"{'every day' if r['repeat'] == 'daily' else 'weekdays'} at {hm}"
    nxt = time.strftime("%a %d %b %H:%M", time.localtime(r["next_fire_at"])) if r["next_fire_at"] else "done"
    what = "asks: " if r["ask"] else ""
    state = "" if r["enabled"] else " [off]"
    return f"#{r['id']} {r['title']}: {what}{r['text']} ({when}; next: {nxt}){state}"


# ------------------------------------------------------------------ create / list / delete

def create(db: DB, text: str, at: str = "", repeat: str = "once", days=None, every_minutes: int = 0,
           ask: bool = False, title: str = "", source: str = "user", now: dt.datetime | None = None) -> dict:
    now = now or dt.datetime.now()
    text = " ".join((text or "").split())
    if not text:
        raise ReminderError("Say what to remind you about.")
    repeat = (repeat or "once").strip().lower()
    if repeat not in REPEATS:
        raise ReminderError(f"repeat must be one of {', '.join(REPEATS)}.")
    r = {"text": text, "title": " ".join((title or "").split())[:80] or text[:60], "repeat": repeat,
         "ask": int(bool(ask)), "fire_at": None, "hour": None, "minute": None, "days": None,
         "every_minutes": None, "created_at": now.timestamp(), "last_fired_at": None}
    if repeat == "once":
        if not at:
            raise ReminderError("Say when: a time like 17:00, 'tomorrow 9am' or 'in 20 minutes'.")
        when = parse_when(at, now)
        if when <= now - dt.timedelta(minutes=1):
            raise ReminderError(f"{when:%a %d %b %H:%M} has already passed.")
        r["fire_at"] = when.timestamp()
    elif repeat == "interval":
        if not every_minutes or int(every_minutes) < 5:
            raise ReminderError("An interval reminder needs every_minutes of 5 or more.")
        r["every_minutes"] = int(every_minutes)
        first = parse_when(at, now) if at else None
        if first and first - now > dt.timedelta(minutes=2):  # the first one at a set time, then every N minutes
            r["created_at"] = (first - dt.timedelta(minutes=r["every_minutes"])).timestamp()
    else:
        r["hour"], r["minute"] = parse_clock(at or "9:00")
        if repeat == "weekly":
            parsed = parse_days(days)
            if not parsed:
                raise ReminderError("A weekly reminder needs days, e.g. ['mon', 'fri'].")
            r["days"] = json.dumps(parsed)
    nxt = next_fire(r, now)
    r["next_fire_at"] = nxt.timestamp() if nxt else None
    r["id"] = db.execute(
        """INSERT INTO reminders (title, text, ask, repeat, fire_at, hour, minute, days, every_minutes,
           next_fire_at, enabled, source, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)""",
        (r["title"], r["text"], r["ask"], repeat, r["fire_at"], r["hour"], r["minute"], r["days"],
         r["every_minutes"], r["next_fire_at"], source, r["created_at"]))
    r["enabled"] = 1
    r["note"] = ""
    if repeat == "once" and "tomorrow" in at.lower() and now.hour < NIGHT_OWL_H:
        r["note"] = (f"It's after midnight, so 'tomorrow' was read as the coming morning, "
                     f"{dt.datetime.fromtimestamp(r['fire_at']):%A %d %b}.")
    log.info("reminder set: %s", describe(r))
    return r


def listing(db: DB, include_done: bool = False) -> list:
    where = "" if include_done else "WHERE enabled = 1"
    return db.query(f"SELECT * FROM reminders {where} ORDER BY COALESCE(next_fire_at, 9e18), id")


def delete(db: DB, reminder_id: int) -> str:
    row = db.query("SELECT * FROM reminders WHERE id = ?", (int(reminder_id),))
    if not row:
        return f"No reminder #{reminder_id}."
    db.execute("DELETE FROM reminders WHERE id = ?", (int(reminder_id),))
    return f"Deleted {describe(row[0])}"


# ------------------------------------------------------------------ firing

def _answer(cfg: Config, db: DB, question: str) -> str:
    from . import chat
    return chat.answer_once(cfg, db, question)


def fire(cfg: Config, db: DB, r, now: float | None = None) -> str | None:
    """Deliver one due reminder and move it to its next time. Returns the delivered body, or None
    when it was skipped as too late."""
    now = now or time.time()
    r = dict(r)
    due = r["next_fire_at"]
    late = now - due
    body = None
    if r["repeat"] != "once" and late > LATE_SKIP_S:
        log.info("reminder #%s skipped: %.0f min late", r["id"], late / 60)
    else:
        if r["ask"]:
            try:
                body = _answer(cfg, db, r["text"]).strip() or "(nothing to report)"
            except Exception as e:
                log.exception("scheduled prompt #%s", r["id"])
                body = f"Couldn't answer \"{r['text']}\": {e}"
        else:
            body = r["text"]
        if late > 120:
            body = f"(late: due {time.strftime('%H:%M', time.localtime(due))}) {body}"
        key = f"reminder:{r['id']}:{int(due)}"
        kind = "scheduled_prompt" if r["ask"] else "reminder"
        if not db.query("SELECT 1 FROM nudges WHERE dedupe_key = ?", (key,)):
            nid = db.execute("""INSERT OR IGNORE INTO nudges (kind, dedupe_key, title, body, status, created_at, delivered_at)
                                VALUES (?, ?, ?, ?, 'delivered', ?, ?)""", (kind, key, r["title"], body, now, now))
            notify.send(_plain(body)[:220], subtitle=r["title"][:60], sound=cfg.sounds, nudge_id=nid)
            log.info("reminder #%s fired: %s", r["id"], r["title"])
    r["last_fired_at"] = now
    nxt = next_fire(r, dt.datetime.fromtimestamp(max(now, due)))
    db.execute("UPDATE reminders SET last_fired_at = ?, next_fire_at = ?, enabled = ? WHERE id = ?",
               (now, nxt.timestamp() if nxt else None, 1 if nxt else 0, r["id"]))
    return body


def _plain(text: str) -> str:
    """Markdown → banner text: no bold markers, bullets as dots, lines joined."""
    text = re.sub(r"\*\*(.+?)\*\*", r"\1", text.replace("|||", "\n"))
    lines = [re.sub(r"^\s*(?:[-*•]|\d+[.)])\s+", "· ", ln).strip() for ln in text.splitlines()]
    return " ".join(ln for ln in lines if ln)


def tick(cfg: Config, db: DB, now: float | None = None) -> int:
    now = now or time.time()
    due = db.query("SELECT * FROM reminders WHERE enabled = 1 AND next_fire_at <= ? ORDER BY next_fire_at", (now,))
    for r in due:
        fire(cfg, db, r, now)
    return len(due)


class Ticker:
    def __init__(self, cfg: Config, db: DB):
        self.cfg, self.db = cfg, db

    def run(self, stop: threading.Event) -> None:
        while not stop.is_set():
            try:
                tick(self.cfg, self.db)
            except Exception:
                log.exception("reminder tick")
            stop.wait(TICK_S)
