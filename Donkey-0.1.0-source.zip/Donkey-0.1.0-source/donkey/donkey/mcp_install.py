"""Register Donkey's MCP server with AI apps on this PC."""
import json
import os
import shutil
import subprocess
from pathlib import Path

from . import config

JSON_CLIENTS = {
    "claude-desktop": Path(os.environ.get("APPDATA") or Path.home() / "AppData" / "Roaming") / "Claude" / "claude_desktop_config.json",
    "cursor": Path.home() / ".cursor/mcp.json",
}
CLIENTS = ["claude-code", *JSON_CLIENTS]


def server_spec() -> dict:
    """How a client launches the server: the installed donkey-cli.exe, or this venv's python.exe
    running donkey\__main__.py (console programs: MCP talks over standard input and output)."""
    cmd = config.command("mcp")
    return {"command": cmd[0], "args": cmd[1:], "env": config.command_env()}


def install(client: str, dry_run: bool = False) -> str:
    spec = server_spec()
    if client == "claude-code":
        claude = shutil.which("claude") or shutil.which("claude.cmd")
        if not claude:
            return "Claude Code CLI (`claude`) not found on PATH."
        cmd = [claude, "mcp", "add", "--scope", "user", "donkey"]
        for k, v in spec["env"].items():
            cmd += ["-e", f"{k}={v}"]
        cmd += ["--", spec["command"], *spec["args"]]
        if dry_run:
            return "Would run: " + " ".join(cmd)
        subprocess.run([claude, "mcp", "remove", "--scope", "user", "donkey"], capture_output=True)
        done = subprocess.run(cmd, capture_output=True, text=True)
        return (done.stdout + done.stderr).strip() or "Added to Claude Code (user scope)."

    path = JSON_CLIENTS[client]
    data = {}
    if path.exists():
        try:
            data = json.loads(path.read_text() or "{}")
        except ValueError:
            return f"{path} is not valid JSON; not touching it. Add this under mcpServers:\n" + \
                   json.dumps({"donkey": spec}, indent=2)
    data.setdefault("mcpServers", {})["donkey"] = spec
    if dry_run:
        return f"Would write {path}:\n" + json.dumps(data, indent=2)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        shutil.copy2(path, path.with_suffix(path.suffix + ".bak"))
    path.write_text(json.dumps(data, indent=2) + "\n")
    note = " Restart Claude Desktop to load it." if client == "claude-desktop" else ""
    return f"Added donkey to {path} (backup: {path.name}.bak).{note}"


def uninstall(client: str) -> str:
    if client == "claude-code":
        claude = shutil.which("claude") or shutil.which("claude.cmd") or "claude"
        done = subprocess.run([claude, "mcp", "remove", "--scope", "user", "donkey"], capture_output=True, text=True)
        return (done.stdout + done.stderr).strip()
    path = JSON_CLIENTS[client]
    if not path.exists():
        return f"{path} doesn't exist."
    data = json.loads(path.read_text() or "{}")
    if data.get("mcpServers", {}).pop("donkey", None) is None:
        return f"donkey isn't in {path}."
    shutil.copy2(path, path.with_suffix(path.suffix + ".bak"))
    path.write_text(json.dumps(data, indent=2) + "\n")
    return f"Removed donkey from {path}."
