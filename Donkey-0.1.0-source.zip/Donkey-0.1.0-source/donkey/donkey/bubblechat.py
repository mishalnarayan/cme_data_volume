"""Quick chat beside the creature you pulled out: a single click on it opens an "Ask Donkey" bar,
and the conversation floats over the screen as bubbles, with no window around them.

The panel is clear and larger than what it shows, so it lets the mouse through everywhere except
on the bar and the bubbles (the page reports where they are; a timer follows the pointer).
The page draws the bubbles itself (Windows can't blur behind a see-through web view). Like the
edit bar it takes the keyboard while open. It goes away when you click elsewhere, press Esc, or
click the creature again.

Opening it reads the window in front, as the ideas card does, so "what's this about?" needs no
explaining: every message sent while it's open carries that read, the placeholder names the
window, and a few questions about it are offered. The chat is a normal Donkey chat: it continues
the last one from the past half hour, and "open in a window" shows it in the chat window. All
methods run on the main thread unless named _bg.
"""
import hashlib
import json
import logging
import os
import threading
import time

from . import ax, chat, llm, motion, suggest, winui
from .suggestcard import copy

log = logging.getLogger("donkey.bubblechat")

W, MAX_H = 322, 600   # the bubbles' column, with room for their shadows
GAP = 2               # between the creature and the bar
HISTORY = 12          # earlier messages shown on opening; the rest scroll
CLOSE_MAX_S = 1.0     # the page says when its closing animation is done; this is the fallback
SCREEN_WAIT_S = 4.0   # a message sent while the window is still being read waits this long for it
PROMPT_CACHE = 24     # window reads whose offered questions are kept, so reopening costs nothing


class BubbleChat:
    """Callbacks: on_expand(thread_id) opens the chat window; on_working(bool) as a reply starts
    and ends; on_close() once it has gone."""

    def __init__(self, cfg, db, on_expand, on_working=None, on_close=None):
        self.cfg, self.db = cfg, db
        self.on_expand, self.on_close = on_expand, on_close
        self.on_working = on_working or (lambda on: None)
        self.is_open = False
        self.closed_at = 0.0
        self.thread_id: int | None = None
        self.running: dict[int, threading.Event] = {}
        self.ready = False
        self.pending: list[str] = []
        self.down = True   # the bar under the creature, newest bubble nearest it; False: all above
        self.anchor = None  # (centre x, top, bottom) of the creature
        self.offset = 0.0
        self.shown = 0
        self.came_from = 0  # the window that had the keyboard before the chat took it
        self.read: dict | None = None  # this opening's read of the window in front: {"event", "screen"}
        self.prompt_cache: dict[str, list[str]] = {}

        panel = winui.Panel(W, MAX_H, focusable=True)
        panel.on_message("donkey", self._on_message)
        panel.on_deactivate = self._on_resign_key
        panel.load(PAGE)
        panel.set_hit([])  # nothing takes the mouse until the page says where the bar is
        self.panel = panel
        self.fader = motion.Tween(panel)
        self._call("setNative", False)

    # -------------------------------------------------------------- page bridge

    def js(self, code: str) -> None:
        if not self.ready:
            self.pending.append(code)
            return
        self.panel.js(code)

    def _call(self, fn: str, *args) -> None:
        self.js(f"dk.{fn}({', '.join(json.dumps(a, ensure_ascii=False) for a in args)})")

    def _on_message(self, msg: dict) -> None:
        kind = msg.get("type")
        if kind == "ready":
            self.ready = True
            for code in self.pending:
                self.panel.js(code)
            self.pending.clear()
        elif kind == "rects":  # where the bar and bubbles are: only there does the panel take the mouse
            rects = [tuple(float(v) for v in r) for r in msg.get("rects") or []]
            self.panel.set_hit([(x0, y0, x1 - x0, y1 - y0) for x0, y0, x1, y1 in rects])
        elif kind == "glass":
            pass  # the page draws its own bubbles here
        elif kind == "closed":
            self._gone(self.shown)
        elif kind == "send":
            self._send(str(msg.get("text") or "").strip())
        elif kind == "cancel":
            if (ev := self.running.get(self.thread_id)) is not None:
                ev.set()
        elif kind == "new":
            self.thread_id = None
            self._call("setThread", [], False)
        elif kind == "expand":
            tid = self.thread_id
            self.close()
            self.on_expand(tid)
        elif kind == "open_url":
            url = str(msg.get("url") or "")
            if url.startswith(("http://", "https://", "mailto:")):
                winui.open_url(url)
        elif kind == "copy":
            copy(str(msg.get("text") or ""))
        elif kind == "close":
            self.close()

    def _on_resign_key(self) -> None:
        self.close()  # a click anywhere else puts it away; the chat is kept

    # -------------------------------------------------------------- showing

    def toggle(self, anchor) -> None:
        if self.is_open:
            self.close()
        elif time.monotonic() - self.closed_at > 0.3:  # that click on the creature is what closed it
            self.open(anchor)

    def open(self, anchor) -> None:
        if self.thread_id not in self.running:
            self.thread_id = chat.recent_thread(self.db)
        front = ax.front_app()  # before the panel takes the keyboard
        self._read_screen(front if front is not None and front.pid != os.getpid() else None)
        fg = winui.foreground()
        if fg and fg != self.panel.hwnd:
            self.came_from = fg
        self.anchor = anchor
        self.offset = 0.0
        self.follow(anchor)
        self.push_thread()
        self.shown += 1
        self.panel.set_alpha(1.0)
        self.panel.present(activate=True)
        self._call("open", self.down)
        self.is_open = True

    def close(self) -> None:
        if not self.is_open:
            return
        self.is_open = False
        self.closed_at = time.monotonic()
        if self.panel.isActiveWindow() and self.came_from:
            winui.activate(self.came_from)
        self.panel.set_hit([])
        self._call("close")
        shown = self.shown
        winui.call_later(CLOSE_MAX_S, lambda: self._gone(shown))

    def _gone(self, shown: int) -> None:
        if shown != self.shown or self.is_open or not self.panel.isVisible():
            return
        self.panel.dismiss()
        if self.on_close:
            self.on_close()

    def follow(self, anchor) -> None:
        """Hang the bar under the creature with the bubbles below it, or, with more room above,
        sit everything above the creature. Called as the creature is dragged."""
        self.anchor = anchor
        x, top, bottom = anchor
        x += self.offset  # the creature ran off to one end of the bar
        sx, sy, sw, sh = winui.work_area(x, (top + bottom) / 2)
        below, above = sy + sh - bottom, top - sy
        down = below >= MAX_H or below >= above
        room = (below if down else above) - GAP - 8
        h = max(120.0, min(MAX_H, room))
        y = bottom + GAP if down else top - GAP - h
        x = min(max(x - W / 2, sx), sx + sw - W)
        self.panel.set_frame(round(x), round(y), W, round(h))
        if down != self.down:
            self.down = down
            if self.is_open:
                self._call("setDown", down)

    def bar_span(self) -> tuple[float, float]:
        """Left and right ends of the bar on screen."""
        x, _, _, _ = self.panel.frame()
        return x + 20, x + W - 20

    # -------------------------------------------------------------- the window in front

    def _read_screen(self, app) -> None:
        """Read the window in front in the background; what's read goes with each message."""
        read = {"event": threading.Event(), "screen": None}
        self.read = read
        self._call("setScreen", "")
        if app is None:
            read["event"].set()
            return
        threading.Thread(target=self._read_bg, args=(read, app), name="bubble-read", daemon=True).start()

    def _read_bg(self, read: dict, app) -> None:
        t0 = time.monotonic()
        try:
            app, title, text = suggest.read_window(self.cfg, app)
            read["screen"] = {"app": app.name, "title": title or "", "text": text}
            log.info("quick chat: read %s in %d ms (%d chars)", app.name, (time.monotonic() - t0) * 1000, len(text))
        except suggest.NotReadable as e:
            log.info("quick chat: nothing read (%s)", e)
        except Exception:
            log.exception("quick chat: reading the window")
        finally:
            read["event"].set()
        screen = read["screen"]
        if screen is None:
            return
        winui.call_after(self._screen_read, read)
        key = hashlib.sha1("\0".join((screen["app"], screen["title"], screen["text"])).encode()).hexdigest()
        prompts = self.prompt_cache.get(key)
        if prompts is None:
            try:
                prompts = chat.screen_prompts(self.cfg, screen)
            except llm.LLMError as e:
                log.info("quick chat: no questions to offer (%s)", e)
                return
            except Exception:
                log.exception("quick chat: questions to offer")
                return
            self.prompt_cache[key] = prompts
            while len(self.prompt_cache) > PROMPT_CACHE:
                self.prompt_cache.pop(next(iter(self.prompt_cache)))
        winui.call_after(self._prompts_ready, read, prompts)

    def _screen_read(self, read: dict) -> None:
        if read is self.read and self.is_open:
            s = read["screen"]
            label = s["title"].strip() or s["app"]
            self._call("setScreen", label if len(label) <= 40 else label[:38].rstrip() + "…")

    def _prompts_ready(self, read: dict, prompts: list[str]) -> None:
        if read is self.read and self.is_open:
            self._call("setPrompts", prompts)

    # -------------------------------------------------------------- the conversation

    def push_thread(self) -> None:
        if self.thread_id is None:
            self._call("setThread", [], False)
            return
        msgs = chat.messages(self.db, self.thread_id)[-HISTORY:]
        self._call("setThread", [{"id": m["id"], "role": m["role"], "content": m["content"],
                                  "tools": json.loads(m["tools"] or "[]")} for m in msgs],
                   self.thread_id in self.running)

    def _send(self, text: str) -> None:
        if not text:
            return
        if self.thread_id is None:
            self.thread_id = chat.new_thread(self.db)
        tid = self.thread_id
        if tid in self.running:
            return
        cancel = threading.Event()
        self.running[tid] = cancel
        self._call("started", tid, text)
        self.on_working(True)
        llm.prewarm()
        threading.Thread(target=self._answer_bg, args=(tid, text, cancel, self.read), name="bubble-chat",
                         daemon=True).start()

    def _answer_bg(self, tid: int, text: str, cancel: threading.Event, read: dict | None) -> None:
        def on_event(kind, data=None):
            winui.call_after(self._call, "ev", tid, kind, data)
        if read is not None:
            read["event"].wait(SCREEN_WAIT_S)
        try:
            out = chat.send(self.cfg, self.db, tid, text, on_event, cancel,
                            screen=read["screen"] if read is not None else None)
            result = {"ok": True, "text": out["text"], "tools": out["tools"]}
        except llm.Cancelled:
            chat.add_message(self.db, tid, "assistant", "(stopped)")
            result = {"ok": False, "error": "Stopped."}
        except llm.LLMError as e:
            result = {"ok": False, "error": str(e)}
        except Exception as e:
            log.exception("bubble chat reply")
            result = {"ok": False, "error": f"Something went wrong: {e}"}
        winui.call_after(self._finished, tid, result)

    def _finished(self, tid: int, result: dict) -> None:
        self.running.pop(tid, None)
        self._call("finished", tid, result)
        self.on_working(False)

PAGE = r"""<!doctype html><html><head><meta charset="utf-8">
<meta name="color-scheme" content="light dark">
<style>
:root { --fg:rgba(18,18,20,.94); --fill:rgba(250,250,252,.86); --rim:rgba(255,255,255,.85); --muted:rgba(18,18,20,.5);
  --shadow:0 10px 30px rgba(0,0,0,.16), 0 1px 3px rgba(0,0,0,.1); --lift:0 8px 24px rgba(0,0,0,.12);
  --me:linear-gradient(180deg,#d94d18,#b23a0f); --me-fg:#fff; --accent:#d94d18; --accent-hi:#e8622d; }
@media (prefers-color-scheme: dark) { :root { --fg:rgba(255,255,255,.95); --fill:rgba(40,40,44,.84);
  --rim:rgba(255,255,255,.28); --muted:rgba(255,255,255,.5);
  --shadow:0 10px 30px rgba(0,0,0,.35), 0 1px 3px rgba(0,0,0,.3); --lift:0 8px 24px rgba(0,0,0,.3); } }
* { box-sizing:border-box; }
html, body { margin:0; height:100%; background:transparent; overflow:hidden; -webkit-user-select:none;
  font:13px/1.32 "Inter", "Segoe UI Variable Text", "Segoe UI", system-ui, sans-serif;
  -webkit-font-smoothing:antialiased; }
#col { position:absolute; inset:0; display:flex; flex-direction:column; padding:6px 20px 0; }
body:not(.down) #col { flex-direction:column-reverse; padding:0 20px 6px; }
body.shut #col { visibility:hidden; }

#bar { flex:none; height:40px; border-radius:20px; background:#000; color:#fff;
  display:flex; align-items:center; gap:2px; padding:0 6px 0 15px; position:relative; z-index:1;
  box-shadow:inset 0 0 0 .5px rgba(255,255,255,.16), 0 10px 30px rgba(0,0,0,.3), 0 1px 3px rgba(0,0,0,.25); }
#q { flex:1; min-width:0; background:none; border:0; outline:none; color:inherit; font:inherit; font-size:13.5px;
  caret-color:var(--accent); -webkit-user-select:text; text-overflow:ellipsis; }
#q::placeholder { color:rgba(255,255,255,.42); }
.b { width:28px; height:28px; border:0; border-radius:14px; background:none; color:rgba(255,255,255,.55);
  display:grid; place-items:center; padding:0; cursor:default; flex:none;
  transition:background .18s, color .18s, transform .14s; }
.b:hover { background:rgba(255,255,255,.12); color:#fff; }
.b:active { transform:scale(.92); }
.b svg { width:15px; height:15px; fill:none; stroke:currentColor; stroke-width:1.6; stroke-linecap:round; stroke-linejoin:round; }
#go { background:rgba(255,255,255,.14); color:rgba(255,255,255,.45); margin-left:2px; }
#go svg { width:14px; height:14px; stroke-width:2.1; }
#go.on, body.working #go { background:var(--accent); color:#fff; }
#go.on:hover, body.working #go:hover { background:var(--accent-hi); }
#go .stop { display:none; } body.working #go .stop { display:block; } body.working #go .up { display:none; }

#stack { flex:1; min-height:0; overflow-y:auto; overflow-x:hidden; overscroll-behavior:contain; padding:0 4px;
  margin:0 -4px; scrollbar-width:none; }
#stack::-webkit-scrollbar { display:none; }
body.down #stack { -webkit-mask-image:linear-gradient(to bottom, #000 calc(100% - 70px), transparent); }
body:not(.down) #stack { -webkit-mask-image:linear-gradient(to top, #000 calc(100% - 70px), transparent); }
#rows { display:flex; flex-direction:column; gap:6px; padding:8px 0 30px; }
body:not(.down) #rows { min-height:100%; justify-content:flex-end; padding:30px 0 8px; }
.lane { flex:none; display:flex; justify-content:flex-start; }
.lane.me, .lane.chips { justify-content:flex-end; }
.lane.chips { flex-wrap:wrap; gap:6px; }

.bubble { position:relative; max-width:88%; padding:8px 13px 9px; border-radius:19px;
  color:var(--fg); background:var(--fill); box-shadow:inset 0 0 0 .5px var(--rim), inset 0 1px .5px rgba(255,255,255,.5), var(--shadow);
  -webkit-user-select:text; cursor:text; overflow-wrap:anywhere; }
.bubble.me { color:var(--me-fg); background:var(--me);
  box-shadow:var(--shadow); }
body.down .bubble { border-top-left-radius:7px; } body.down .bubble.me { border-top-left-radius:19px; border-top-right-radius:7px; }
body:not(.down) .bubble { border-bottom-left-radius:7px; } body:not(.down) .bubble.me { border-bottom-left-radius:19px; border-bottom-right-radius:7px; }
.bubble.err { color:#d93a2f; }
.bubble p { margin:0; } .bubble p + p, .bubble ul, .bubble ol { margin:6px 0 0; } .bubble ul, .bubble ol { padding-left:18px; }
.bubble code { font:12px ui-monospace, "SF Mono", monospace; background:rgba(127,127,127,.16); border-radius:5px; padding:1px 4px; }
.bubble pre { white-space:pre-wrap; margin:6px 0 0; } .bubble h4 { margin:4px 0 0; font-size:13px; }
.bubble a { color:inherit; text-decoration-color:rgba(127,127,127,.5); }
.bubble .steps { font-size:11px; color:var(--muted); margin-bottom:4px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.copy { position:absolute; right:-8px; top:-8px; width:22px; height:22px; border-radius:11px; border:0; padding:0;
  display:grid; place-items:center; background:rgba(0,0,0,.6); color:#fff; opacity:0; transition:opacity .16s .5s;
  box-shadow:inset 0 0 0 .5px rgba(255,255,255,.18), 0 2px 6px rgba(0,0,0,.25); cursor:default; }
.copy svg { width:12px; height:12px; fill:none; stroke:currentColor; stroke-width:1.6; }
.bubble:hover .copy { opacity:1; transition:opacity .12s; }
.pending { display:inline-flex; align-items:center; gap:8px; height:30px; padding:0 13px; border-radius:15px;
  color:var(--muted); background:var(--fill); box-shadow:inset 0 0 0 .5px var(--rim), var(--shadow);
  font-size:12px; max-width:88%; }
.pending .t { white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.dots { display:inline-flex; gap:3px; flex:none; }
.dots i { width:5px; height:5px; border-radius:50%; background:currentColor; animation:blink 1.1s infinite both; }
.dots i:nth-child(2) { animation-delay:.15s; } .dots i:nth-child(3) { animation-delay:.3s; }
@keyframes blink { 0%, 80%, 100% { opacity:.25; transform:scale(.85); } 40% { opacity:1; transform:none; } }
.chip { height:28px; max-width:100%; padding:0 12px; border:0; border-radius:14px; font:inherit; font-size:12.5px;
  font-weight:500; line-height:28px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; cursor:default;
  color:var(--fg); background:var(--fill); box-shadow:inset 0 0 0 .5px var(--rim), 0 4px 12px rgba(0,0,0,.1); }
.chip:hover { box-shadow:inset 0 0 0 .5px var(--rim), inset 0 0 0 99px rgba(127,127,127,.1), 0 4px 12px rgba(0,0,0,.1); }
.chip:active { box-shadow:inset 0 0 0 .5px var(--rim), inset 0 0 0 99px rgba(127,127,127,.2); }

/* real glass sits under the page here: only the rim and the shadow are drawn */
body.native .bubble:not(.me), body.native .pending, body.native .chip { background:transparent; }
body.native .bubble:not(.me) { border-radius:19px; box-shadow:inset 0 0 0 .5px var(--rim), var(--lift); }
body.native .pending { box-shadow:inset 0 0 0 .5px var(--rim), 0 6px 18px rgba(0,0,0,.12); }
body.native .chip { box-shadow:inset 0 0 0 .5px var(--rim), 0 4px 12px rgba(0,0,0,.08); }
body.native .chip:hover { box-shadow:inset 0 0 0 .5px var(--rim), inset 0 0 0 99px rgba(127,127,127,.12), 0 4px 12px rgba(0,0,0,.08); }
</style></head><body class="down shut">
<div id="col">
  <div id="bar">
    <input id="q" placeholder="Ask Donkey" autocomplete="off" spellcheck="false">
    <button class="b" id="new" title="New chat"><svg viewBox="0 0 16 16"><path d="M8 3v10M3 8h10"/></svg></button>
    <button class="b" id="exp" title="Open in a window"><svg viewBox="0 0 16 16"><path d="M9.5 2.5h4v4M13.5 2.5 9 7M6.5 13.5h-4v-4M2.5 13.5 7 9"/></svg></button>
    <button class="b" id="go" title="Send"><svg viewBox="0 0 16 16"><path class="up" d="M8 13V3.4M3.8 7.4 8 3.2l4.2 4.2"/><rect class="stop" x="4.5" y="4.5" width="7" height="7" rx="1.5" fill="currentColor" stroke="none"/></svg></button>
  </div>
  <div id="stack"><div id="rows"></div></div>
</div>
<script>
const $ = id => document.getElementById(id);
const post = m => window.webkit.messageHandlers.donkey.postMessage(m);
const COPY = '<svg viewBox="0 0 16 16"><path d="M5.5 5.5h7v8h-7zM10.5 5.5v-3h-7v8h2"/></svg>';
const TOOL = { search_memory:'Searched memory', get_snapshots:'Opened screens', get_recent_activity:'Checked recent activity',
  get_working_memory:'Read the last few hours', get_chronicle:'Read the summary', get_daily_summary:'Read the day page',
  search_wiki:'Looked it up', get_wiki_page:'Opened a page', get_sent_messages:'Checked sent messages',
  get_open_loops:'Checked open loops', get_todos:'Checked to-dos', get_upcoming_meetings:'Checked meetings',
  get_time_report:'Checked time spent', create_reminder:'Set a reminder', add_todo:'Added a to-do' };
const toolName = n => TOOL[n] || (n.charAt(0).toUpperCase() + n.slice(1).replace(/_/g, ' '));
function esc(s) { return String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c])); }
function inline(s) {
  s = esc(s).replace(/`([^`]+)`/g, '<code>$1</code>').replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/(^|[^*\w])\*([^*\n]+)\*(?!\w)/g, '$1<em>$2</em>')
    .replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, '<a href="$2">$1</a>')
    .replace(/(^|[\s(])(https?:\/\/[^\s<)]+)/g, '$1<a href="$2">$2</a>');
  return s;
}
function md(text) {
  let html = '', list = null, para = [], code = null;
  const flush = () => { if (para.length) { html += '<p>' + para.map(inline).join('<br>') + '</p>'; para = []; } };
  const close = () => { if (list) { html += `</${list}>`; list = null; } };
  for (const line of text.replace(/\r/g, '').split('\n')) {
    if (code !== null) { if (/^```/.test(line)) { html += '<pre><code>' + esc(code.join('\n')) + '</code></pre>'; code = null; } else code.push(line); continue; }
    if (/^```/.test(line)) { flush(); close(); code = []; continue; }
    let m;
    if ((m = line.match(/^\s*[-*•]\s+(.*)/))) { flush(); if (list !== 'ul') { close(); html += '<ul>'; list = 'ul'; } html += '<li>' + inline(m[1]) + '</li>'; continue; }
    if ((m = line.match(/^\s*\d+[.)]\s+(.*)/))) { flush(); if (list !== 'ol') { close(); html += '<ol>'; list = 'ol'; } html += '<li>' + inline(m[1]) + '</li>'; continue; }
    if ((m = line.match(/^#{1,4}\s+(.*)/))) { flush(); close(); html += '<h4>' + inline(m[1]) + '</h4>'; continue; }
    if (!line.trim()) { flush(); close(); continue; }
    close(); para.push(line);
  }
  if (code !== null) html += '<pre><code>' + esc(code.join('\n')) + '</code></pre>';
  flush(); close(); return html;
}
const parts = t => t.replace(/\|{1,2}$/, '').split('|||').map(s => s.trim()).filter(Boolean);
const steps = tools => [...new Set((tools || []).map(t => toolName(t.name)))].join(' · ');

// Motion with some life in it: springs, where `duration` is one swing and `bounce` how much
// it overshoots. The bubbles move in script, a frame at a time, not as CSS animations: those run on
// the compositor's own clock, and the glass under the bubbles, placed from each frame's positions,
// trailed them by a frame or two and left ghost rims.
function spring(duration, bounce) {
  const w = 2 * Math.PI / duration, z = 1 - bounce, wd = w * Math.sqrt(1 - z * z);
  const at = t => 1 - Math.exp(-z * w * t) * (Math.cos(wd * t) + (z * w / wd) * Math.sin(wd * t));
  let end = 0;
  for (let t = 0; t < 6; t += 1 / 240) { if (Math.abs(1 - at(t)) > .001) end = t; else if (t - end > .25) break; }
  end += 1 / 240;
  return { ease:p => p >= 1 ? 1 : at(p * end), ms:end * 1000, k:w * w, c:2 * z * w };
}
function css(sp) {  // the same spring as a CSS easing, for the bar (no glass under it)
  const n = Math.max(24, Math.round(sp.ms / 1000 * 60)), pts = [];
  for (let i = 0; i <= n; i++) pts.push(+sp.ease(i / n).toFixed(4));
  return { easing:`linear(${pts.join(', ')})`, ms:Math.round(sp.ms) };
}
const MOVE = spring(.5, .12), BAR = css(spring(.42, .32));
const easeIn = p => p * p * p;  // cubic-bezier(.32, 0, .67, 0)
const FADE = 70;  // the far end of the stack fades out over this many points

// The conversation as lanes of bubbles, oldest first; each keeps its element, so a new bubble lands
// alone and the others glide out of its way.
const S = { items:[], live:null, working:false, down:true, n:0, native:false, prompts:[], typed:false, open:false };
const els = new Map();
let motions = [];  // the bar's CSS animations
function anim(el, frames, opts) { const a = el.animate(frames, opts); motions.push(a); a.finished.then(() => { motions = motions.filter(m => m !== a); }, () => {}); return a; }

// Each moving element: y glides back to 0 and g grows to 1 on springs; tw is a timed move on top
// (opening and closing). Drawn as translateY(y + tw.y) scale(tw.s * g), opacity tw.o * min(1, 2g).
const live = new Set();
const mo = el => el._mo || (el._mo = { y:0, vy:0, g:1, vg:0, gAt:0, tw:null });
function shift(el, dy) { const m = mo(el); m.y += dy; live.add(el); }
function grow(el, delay) { const m = mo(el); m.g = 0; m.vg = 0; m.gAt = performance.now() + delay; live.add(el); draw(el, m); }
function tween(el, from, to, ms, ease, delay, hold) {
  const m = mo(el); m.tw = { t0:performance.now() + delay, ms, ease, from, to, hold, v:from }; live.add(el); draw(el, m);
}
function settle(x, v, to, dt) {
  const n = Math.max(1, Math.ceil(dt * 240)), h = dt / n;
  for (let i = 0; i < n; i++) { v += (-MOVE.k * (x - to) - MOVE.c * v) * h; x += v * h; }
  return [x, v];
}
function draw(el, m) {
  const t = m.tw ? m.tw.v : { y:0, s:1, o:1 }, y = m.y + t.y, sc = t.s * m.g, o = t.o * Math.min(1, 2 * m.g);
  el.style.transform = Math.abs(y) < .05 && Math.abs(sc - 1) < 1e-4 ? '' : `translateY(${y.toFixed(2)}px) scale(${sc.toFixed(4)})`;
  el.style.opacity = o > .999 ? '' : o.toFixed(3);
}
let last = 0;
function step(now) {
  const dt = Math.min(Math.max(now - last, 0), 33) / 1000; last = now;
  for (const el of live) {
    const m = mo(el); let busy = false;
    if (m.y || m.vy) {
      [m.y, m.vy] = settle(m.y, m.vy, 0, dt);
      if (Math.abs(m.y) < .05 && Math.abs(m.vy) < 1) m.y = m.vy = 0; else busy = true;
    }
    if (m.g !== 1 || m.vg) {
      if (now >= m.gAt) [m.g, m.vg] = settle(m.g, m.vg, 1, dt);
      if (Math.abs(1 - m.g) < 5e-4 && Math.abs(m.vg) < .01) { m.g = 1; m.vg = 0; } else busy = true;
    }
    const tw = m.tw;
    if (tw) {
      const p = Math.min(1, Math.max(0, (now - tw.t0) / tw.ms)), e = tw.ease(p), v = {};
      for (const k in tw.from) v[k] = tw.from[k] + (tw.to[k] - tw.from[k]) * e;
      tw.v = v;
      if (p < 1) busy = true; else if (!tw.hold) m.tw = null;
    }
    draw(el, m);
    if (!busy) live.delete(el);
  }
}
function itemsFor(m) {
  if (m.role === 'user') return [{ key:'m' + m.id, me:true, text:m.content }];
  const ps = parts(m.content || '');
  return ps.map((p, i) => ({ key:'m' + m.id + '.' + i, text:p, steps:i === 0 ? steps(m.tools) : '' }));
}
function all() {
  const out = S.items.slice();
  const L = S.live;
  if (L) {
    const ps = parts(L.text);
    if (!ps.length) out.push({ key:'pending' + L.n, pending:true, text:L.step || 'Thinking' });
    else ps.forEach((p, i) => out.push({ key:'live' + L.n + '.' + i, text:p, steps:i === 0 ? steps(L.tools) : '' }));
  }
  if (S.prompts.length && !S.working && !S.typed) out.push({ key:'chips' + S.prompts.join('\u0001'), chips:S.prompts });
  return out;
}
function make(it) {
  const lane = document.createElement('div');
  lane.className = 'lane' + (it.me ? ' me' : '') + (it.chips ? ' chips' : '');
  if (!it.chips) {
    const b = document.createElement('div');
    b.className = it.pending ? 'pending' : 'bubble' + (it.me ? ' me' : '') + (it.err ? ' err' : '');
    lane.appendChild(b);
  }
  return lane;
}
function fill(lane, it) {
  const sig = it.chips ? it.chips.join('\u0001') : (it.steps || '') + '\u0000' + it.text;
  if (lane._sig === sig) return;
  lane._sig = sig;
  if (it.chips) { lane.innerHTML = it.chips.map(c => '<button class="chip">' + esc(c) + '</button>').join(''); return; }
  const b = lane.firstElementChild;
  b.innerHTML = it.pending ? '<span class="dots"><i></i><i></i><i></i></span><span class="t">' + esc(it.text) + '</span>'
    : (it.steps ? '<div class="steps">' + esc(it.steps) + '</div>' : '') + (it.me ? '<p>' + esc(it.text).replace(/\n/g, '<br>') + '</p>' : md(it.text))
      + (it.me || it.err ? '' : '<button class="copy" title="Copy">' + COPY + '</button>');
  b._text = it.text;
}
const origin = lane => `${lane.classList.contains('me') || lane.classList.contains('chips') ? 'right' : 'left'} ${S.down ? 'top' : 'bottom'}`;
function land(lane) {  // grows out of its corner
  const targets = lane.classList.contains('chips') ? [...lane.children] : [lane.firstElementChild];
  targets.forEach((el, i) => { el.style.transformOrigin = origin(lane); grow(el, i * 45); });
}
function glide(lane, from) {  // stays where it was drawn, then springs to where the layout now puts it
  const dy = from - lane.getBoundingClientRect().top;
  if (Math.abs(dy) >= .5) shift(lane, dy);
}
const nearFirst = () => { const l = [...$('rows').children]; return S.down ? l : l.reverse(); };
function inView(lane) { const s = $('stack').getBoundingClientRect(), r = lane.getBoundingClientRect(); return r.bottom > s.top && r.top < s.bottom; }
function render(mode) {  // mode 'quiet': no motion; otherwise new lanes land and moved ones glide
  const list = all(), rows = $('rows'), keep = new Set(list.map(x => x.key)), before = new Map();
  if (mode !== 'quiet') for (const [k, el] of els) if (keep.has(k)) before.set(k, el.getBoundingClientRect().top);
  for (const [k, el] of els) if (!keep.has(k)) { el.remove(); els.delete(k); }
  const order = S.down ? list.slice().reverse() : list, fresh = [];
  order.forEach((it, i) => {
    let lane = els.get(it.key);
    if (!lane) { lane = make(it); els.set(it.key, lane); fresh.push(lane); }
    fill(lane, it);
    if (rows.children[i] !== lane) rows.insertBefore(lane, rows.children[i] || null);
  });
  document.body.classList.toggle('working', S.working);
  scrollToNewest();
  if (mode !== 'quiet') {
    for (const [k, top] of before) glide(els.get(k), top);
    fresh.forEach(land);
  }
  kick();
}
function scrollToNewest() { const s = $('stack'); s.scrollTop = S.down ? 0 : s.scrollHeight; }

function rise() {  // opening: the bubbles come out from under the bar, nearest first
  const lanes = nearFirst().filter(inView).slice(0, 10), h = $('stack').getBoundingClientRect().height + 12;
  lanes.forEach((lane, i) => {
    lane.style.transformOrigin = origin(lane);
    tween(lane, { y:S.down ? -h : h, s:.96, o:.4 }, { y:0, s:1, o:1 }, MOVE.ms, MOVE.ease, 90 + i * 28);
  });
  const bar = $('bar');
  bar.style.transformOrigin = S.down ? '50% 0' : '50% 100%';
  anim(bar, [{ transform:'scale(.62, .7)' }, { transform:'none' }], { duration:BAR.ms, easing:BAR.easing });
  anim(bar, [{ opacity:0, filter:'blur(6px)' }, { opacity:1, filter:'blur(0)' }], { duration:260, easing:'ease-out' });
  for (const c of bar.children) anim(c, [{ opacity:0 }, { opacity:1 }], { duration:220, delay:70, fill:'backwards' });
}
let closing = null;
function sink() {  // closing: they sink back under the bar, nearest first, and the bar goes
  const st = $('stack').getBoundingClientRect(), lanes = nearFirst().filter(inView).slice(0, 8);
  lanes.forEach((lane, i) => {
    const r = lane.getBoundingClientRect(), d = S.down ? -(r.bottom - st.top) : st.bottom - r.top;
    lane.style.transformOrigin = origin(lane);
    tween(lane, { y:0, s:1, o:1 }, { y:d, s:.94, o:.4 }, 340, easeIn, i * 32, true);
  });
  const rows = lanes.length ? 340 + (lanes.length - 1) * 32 : 0;
  const bar = anim($('bar'), [{ opacity:1, transform:'none', filter:'blur(0)' }, { opacity:0, transform:'scale(.9)', filter:'blur(4px)' }],
    { duration:160, delay:Math.max(0, rows - 140), easing:'ease-in', fill:'forwards' });
  closing = bar;
  bar.finished.then(() => { if (closing === bar) { document.body.classList.add('shut'); post({ type:'closed' }); } }, () => {});
  kick();
}

// Every frame something moves: where Donkey's bubbles are (for the glass under them) and where
// anything clickable is (only there does the panel take the mouse).
let looping = false, sentGlass = '', sentRects = '';
function kick() { if (!looping) { looping = true; last = performance.now(); requestAnimationFrame(frame); } }
const moving = () => live.size || motions.some(a => a.playState === 'running');
function frame(now) {
  step(now);
  report();  // after this frame's positions are set, so the glass lands with them
  if (moving()) requestAnimationFrame(frame);
  else { looping = false; requestAnimationFrame(report); }
}
function opacityOf(el) { let a = 1; for (let e = el; e && e !== document.body; e = e.parentElement) a *= +getComputedStyle(e).opacity; return a; }
function report() {
  const st = $('stack').getBoundingClientRect(), hits = [], glass = [];
  const r = $('bar').getBoundingClientRect(); hits.push([r.left, r.top, r.right, r.bottom]);
  if (!document.body.classList.contains('shut')) for (const el of $('rows').querySelectorAll('.bubble, .pending, .chip')) {
    const b = el.getBoundingClientRect();
    const top = Math.max(b.top, st.top), bottom = Math.min(b.bottom, st.bottom);
    if (bottom - top < 1 || b.width < 1) continue;
    hits.push([b.left - 10, top - 10, b.right + 10, bottom]);  // the copy button pokes out
    if (!S.native || el.classList.contains('me')) continue;
    const scale = el.offsetWidth ? b.width / el.offsetWidth : 1;
    const radius = parseFloat(getComputedStyle(el).borderTopRightRadius) * scale;
    const mid = (top + bottom) / 2, far = S.down ? (st.bottom - mid) / FADE : (mid - st.top) / FADE;
    const a = opacityOf(el) * Math.max(0, Math.min(1, far));
    glass.push([+b.left.toFixed(1), +top.toFixed(1), +b.width.toFixed(1), +(bottom - top).toFixed(1),
      +Math.min(radius, (bottom - top) / 2).toFixed(1), +a.toFixed(3)]);
  }
  const g = JSON.stringify(glass), h = JSON.stringify(hits);
  if (S.native && g !== sentGlass) { sentGlass = g; post({ type:'glass', items:glass }); }
  if (h !== sentRects) { sentRects = h; post({ type:'rects', rects:hits }); }
}

window.dk = {
  setNative(on) { S.native = on; document.body.classList.toggle('native', on); kick(); },
  open(down) {
    closing = null;
    motions.forEach(a => a.cancel()); motions = []; live.clear();
    for (const el of [$('bar'), ...$('bar').children]) el.getAnimations().forEach(a => a.cancel());  // the last close's fade holds once done
    S.down = down; S.open = true; document.body.classList.toggle('down', down);
    document.body.classList.remove('shut');
    els.forEach(el => el.remove()); els.clear(); render('quiet'); rise(); kick();
    setTimeout(() => $('q').focus(), 0);
  },
  close() { S.open = false; $('q').blur(); sink(); },
  setDown(down) { S.down = down; document.body.classList.toggle('down', down); els.forEach(el => el.remove()); els.clear(); render('quiet'); },
  setScreen(label) {
    $('q').placeholder = label ? 'Ask about ' + label : 'Ask Donkey';
    if (S.prompts.length) { S.prompts = []; render(S.open ? '' : 'quiet'); }
  },
  setPrompts(list) { S.prompts = list || []; render(); },
  setThread(msgs, working) {
    S.items = msgs.flatMap(itemsFor); S.working = working; S.live = working ? { n:++S.n, text:'', tools:[], step:'' } : null;
    els.forEach(el => el.remove()); els.clear(); render('quiet'); updateGo();
  },
  started(tid, text) {
    S.items.push({ key:'u' + (++S.n), me:true, text }); S.live = { n:++S.n, tid, text:'', tools:[], step:'' };
    S.working = true; S.prompts = []; render(); updateGo();
  },
  ev(tid, kind, data) {
    const L = S.live; if (!L) return;
    if (kind === 'token') L.text += data;
    else if (kind === 'reset') L.text = '';
    else if (kind === 'tool_start') { L.tools.push({ name:data.name }); L.step = toolName(data.name) + '…'; }
    else return;
    render();
  },
  finished(tid, result) {
    const L = S.live; S.live = null; S.working = false;
    if (L) {
      const ps = result.ok ? parts(result.text || L.text) : [];
      ps.forEach((p, i) => {  // the streamed bubbles stay as they are, under their final keys
        const key = 'done' + L.n + '.' + i, el = els.get('live' + L.n + '.' + i);
        if (el) { els.delete('live' + L.n + '.' + i); els.set(key, el); }
        S.items.push({ key, text:p, steps:i === 0 ? steps(result.tools || L.tools) : '' });
      });
      if (!result.ok) S.items.push({ key:'err' + L.n, err:true, text:result.error || 'Something went wrong.' });
    }
    render(); updateGo();
  },
};
function updateGo() {
  const typed = !!$('q').value.trim();
  $('go').classList.toggle('on', typed); $('go').title = S.working ? 'Stop' : 'Send';
  if (typed !== S.typed) { S.typed = typed; if (S.prompts.length) render(); }
}
function send(text) {
  if (S.working) { post({ type:'cancel' }); return; }
  text = (text ?? $('q').value).trim(); if (!text) return;
  $('q').value = ''; updateGo(); post({ type:'send', text });
}
$('q').addEventListener('input', updateGo);
$('q').addEventListener('keydown', e => {
  if (e.key === 'Enter' && !e.isComposing) { e.preventDefault(); send(); }
});
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { e.preventDefault(); post({ type:'close' }); }
  else if (e.key === 'n' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); post({ type:'new' }); }
});
$('go').addEventListener('click', () => send());
$('new').addEventListener('click', () => { post({ type:'new' }); $('q').focus(); });
$('exp').addEventListener('click', () => post({ type:'expand' }));
document.addEventListener('click', e => {
  const a = e.target.closest('a'); if (a) { e.preventDefault(); post({ type:'open_url', url:a.href }); return; }
  const chip = e.target.closest('.chip'); if (chip) { send(chip.textContent); return; }
  const c = e.target.closest('.copy');
  if (c) { post({ type:'copy', text:c.parentElement._text || '' }); c.innerHTML = '<svg viewBox="0 0 16 16"><path d="M3.5 8.5l3 3 6-7"/></svg>';
    setTimeout(() => { c.innerHTML = COPY; }, 1200); }
});
document.addEventListener('mousedown', e => { if (!e.target.closest('.bubble') && e.target !== $('q')) setTimeout(() => $('q').focus(), 0); });
$('stack').addEventListener('scroll', report, { passive:true });
new ResizeObserver(() => kick()).observe($('rows'));
window.addEventListener('resize', () => kick());
post({ type:'ready' });
</script></body></html>"""
