"""Donkey as a system tray app: capture, memory, the rewrite key and the creature overlays.

`python -m donkey app` starts it. The main thread runs the Qt event loop; capture, the memory
scheduler, the key watcher and the field watcher run on background threads and hand UI work to
the main thread with winui.call_after. Screen positions from UI Automation are physical pixels;
they're turned into Qt's logical ones on the main thread, just before a window is placed.
"""
import ctypes
import json
import logging
import math
import os
import random
import subprocess
import sys
import threading
import time
from ctypes import wintypes
from pathlib import Path

from PySide6.QtCore import QPoint, QRectF, Qt
from PySide6.QtGui import QAction, QColor, QFont, QIcon, QImage, QPainter, QPixmap
from PySide6.QtSvg import QSvgRenderer
from PySide6.QtWidgets import QFileDialog, QMenu, QSystemTrayIcon

from . import ax, capture, config, edit, instance, keys, llm, notify as notify_mod, onboarding, overlay, suggest, winui
from .bubblechat import BubbleChat
from .db import DB
from .editbar import EditBar
from .field import NOT_FIELDS, TERMINAL_BUNDLES, TEXT_ROLES, ax_range
from .keys import KeyWatcher
from .rewrite import Rewriter, notify
from .suggestcard import SuggestCard

log = logging.getLogger("donkey.app")

UI_STATE_PATH = config.HOME / "ui.json"
STARTUP_LINK = Path(os.environ.get("APPDATA") or Path.home() / "AppData" / "Roaming") / \
    "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup" / "Donkey.lnk"

CREATURE_SIZE = 38                        # drawn size of the donkey
CREATURE_BOX = (52, 54)                   # window: donkey at the bottom, room above for the hop
CREATURE_HIT = 38                         # clickable square at the bottom of the window
FREE_SIZE = 72                            # the pulled-out donkey is bigger than the one by the caret
FREE_BOX = (120, 127)                     # room above it for its hops and flips
FREE_HIT = 72
SINGLE_CLICK_S = 0.28                     # a click on the pulled-out creature waits this long for a second
PERCH_OVERLAP = 4                         # how far its feet dip onto the caret's line
FIELD_POLL_S = 0.3
SNOOZE_S = 30 * 60
ADDRESS_BAR_LABELS = ("address and search", "search or enter", "enter address", "smart search field", "address bar",
                      "sök eller ange")
JETBRAINS = {"idea64.exe", "pycharm64.exe", "webstorm64.exe", "clion64.exe", "goland64.exe", "rider64.exe",
             "phpstorm64.exe", "rubymine64.exe", "datagrip64.exe", "studio64.exe", "fleet.exe"}
KEY_NAMES = keys.KEY_NAMES
DOTS = {"gray": "#8e8e93", "orange": "#ff9f0a", "green": "#30d158", "accent": "#0a84ff"}


def key_name(key: str) -> str:
    try:
        return KEY_NAMES[keys.resolve(key)]
    except ValueError:
        return key


# ------------------------------------------------------------------ small persistent UI prefs

def _ui_state() -> dict:
    try:
        return json.loads(UI_STATE_PATH.read_text())
    except (FileNotFoundError, ValueError):
        return {}


def _save_ui_state(**changes) -> None:
    state = _ui_state() | changes
    UI_STATE_PATH.write_text(json.dumps(state, indent=1))


# ------------------------------------------------------------------ start at sign-in

def login_item_enabled() -> bool:
    return STARTUP_LINK.exists()


def set_login_item(enabled: bool) -> None:
    """A shortcut in the Startup folder: Windows opens it at sign-in (no admin rights needed)."""
    if not enabled:
        STARTUP_LINK.unlink(missing_ok=True)
        return
    import win32com.client
    cmd = config.command("app", "--login", gui=True)
    STARTUP_LINK.parent.mkdir(parents=True, exist_ok=True)
    link = win32com.client.Dispatch("WScript.Shell").CreateShortcut(str(STARTUP_LINK))
    link.TargetPath = cmd[0]
    link.Arguments = subprocess.list2cmdline(cmd[1:])
    link.WorkingDirectory = str(Path(cmd[0]).parent if config.FROZEN else config.PROJECT)
    link.IconLocation = str(cmd[0])
    link.Description = "Donkey"
    link.Save()


# ------------------------------------------------------------------ where the creature sits

def caret_spot(el, frame=None):
    """Where the creature perches, in physical screen pixels: (caret x, line top, line bottom,
    window top).

    It sits just above the blinking caret: clear of the text being typed and of the app's own
    buttons beside the field (emoji, attach, send). Without caret bounds, above the first line."""
    frame = frame or ax.visible_frame(el)
    if not frame:
        return None
    x, y, w, h = frame
    win = ax.element_frame(ax.attr(el, "AXWindow"))
    win_top = win[1] if win else y - 200
    sel = ax_range(ax.attr(el, "AXSelectedTextRange"))
    if sel is not None:
        c = ax.caret_bounds(el, sel[0])
        if c and x - 4 <= c[0] <= x + w + 4 and y - 4 <= c[1] + c[3] / 2 <= y + h + 4:
            return (c[0], c[1], c[1] + c[3], win_top)
    line_h = min(h, 20.0 * _scale_at(x, y))
    top = y + (h - line_h) / 2 if h <= 60 * _scale_at(x, y) else y + 6
    return (x + 12, top, top + line_h, win_top)


def _scale_at(x: float, y: float) -> float:
    """Physical pixels per logical pixel on the monitor at that physical point."""
    import ctypes
    from ctypes import wintypes
    try:
        hmon = ctypes.windll.user32.MonitorFromPoint(wintypes.POINT(int(x), int(y)), 2)
        dx, dy = ctypes.c_uint(), ctypes.c_uint()
        if ctypes.windll.shcore.GetDpiForMonitor(hmon, 0, ctypes.byref(dx), ctypes.byref(dy)) == 0:
            return dx.value / 96.0
    except Exception:
        pass
    return 1.0


def _focused_field_spot(app: ax.FrontApp):
    """Perch spot for the focused text field, or None if the creature shouldn't show here."""
    if app.bundle_id in TERMINAL_BUNDLES or app.bundle_id in JETBRAINS:
        return None
    el = ax.attr(app.element, "AXFocusedUIElement")
    if el is None:
        return None
    role = ax.attr(el, "AXRole")
    if role not in TEXT_ROLES or role in NOT_FIELDS or ax.attr(el, "AXSubrole") == "AXSecureTextField":
        return None
    label = " ".join(filter(None, (ax.as_text(ax.attr(el, n)) for n in ("AXDescription", "AXTitle", "AXPlaceholderValue"))))
    if any(s in label.lower() for s in ADDRESS_BAR_LABELS):
        return None
    frame = ax.visible_frame(el)
    s = _scale_at(frame[0], frame[1]) if frame else 1.0
    if not frame or frame[2] < 60 * s or frame[3] < 12 * s:
        return None
    return caret_spot(el, frame)


class FieldWatcher:
    """Polls the focused field and asks the main thread to move (or hide) the creature.
    While a rewrite runs it stays still, so the creature animates where you clicked it."""

    def __init__(self, ui: "DonkeyApp"):
        self.ui = ui
        self.snoozed_until = 0.0
        self.last = None
        self.last_front = 0  # the last window in front that wasn't Donkey's or the taskbar's

    def _note_front(self, own_pid: int) -> None:
        hwnd = int(ax.user32.GetForegroundWindow() or 0)
        if hwnd and ax._owner_pid(hwnd) != own_pid and ax.class_name(hwnd) not in capture.CHROME_CLASSES:
            self.last_front = hwnd

    def run(self, stop: threading.Event) -> None:
        own_pid = os.getpid()
        while not stop.is_set():
            try:
                self._note_front(own_pid)
            except Exception:
                pass
            if self.ui.busy or self.ui.editing:
                stop.wait(FIELD_POLL_S)
                continue
            spot = None
            try:
                if self.ui.field_enabled and time.time() >= self.snoozed_until:
                    app = ax.front_app()
                    if app is not None and app.pid != own_pid:
                        ax.ensure_accessibility(app)
                        spot = _focused_field_spot(app)
            except Exception:
                log.exception("field watcher")
            key = tuple(round(v) for v in spot) if spot else None
            if key != self.last:
                self.last = key
                winui.call_after(self.ui.place_creature, spot)
            stop.wait(FIELD_POLL_S)


# ------------------------------------------------------------------ tray icons

def _tray_icon(name: str) -> QIcon:
    """Donkey's face in colour, from the creature's own drawing (the Mac's menu bar wants a one-colour
    template; the Windows tray shows colour, on light and dark taskbars alike). "menubar-unread"
    adds an orange dot for new messages; "menubar-paused" is the face greyed out."""
    renderer = QSvgRenderer(str(overlay.ASSETS / "creature.svg"))
    head = renderer.transformForElement("dk-head").mapRect(renderer.boundsOnElement("dk-head"))
    icon = QIcon()
    for side in (16, 20, 24, 32, 40, 48, 64):
        img = QImage(side, side, QImage.Format_ARGB32_Premultiplied)
        img.fill(Qt.transparent)
        p = QPainter(img)
        p.setRenderHint(QPainter.Antialiasing)
        s = side / max(head.width(), head.height())
        p.translate((side - head.width() * s) / 2 - head.x() * s, (side - head.height() * s) / 2 - head.y() * s)
        p.scale(s, s)
        renderer.render(p, "dk-head", head)
        p.resetTransform()
        if name == "menubar-unread":
            d = max(5.0, side * 0.34)
            p.setPen(QColor("white"))
            p.setBrush(QColor("#ff6a1f"))
            p.drawEllipse(QRectF(side - d - 0.5, 0.5, d, d))
        p.end()
        if name == "menubar-paused":  # grey, a little faded, same outline
            grey = img.convertToFormat(QImage.Format_Grayscale8).convertToFormat(QImage.Format_ARGB32_Premultiplied)
            out = QImage(side, side, QImage.Format_ARGB32_Premultiplied)
            out.fill(Qt.transparent)
            q = QPainter(out)
            q.setOpacity(0.55)
            q.drawImage(0, 0, grey)
            q.setOpacity(1.0)
            q.setCompositionMode(QPainter.CompositionMode_DestinationIn)
            q.drawImage(0, 0, img)
            q.end()
            img = out
        icon.addPixmap(QPixmap.fromImage(img))
    return icon


class TrayPull:
    """Press Donkey's tray icon and pull: Donkey comes out under the pointer and is carried until the
    button comes up, as from the Mac's menu bar. Windows tells an app only about clicks on its tray
    icon, never drags, so a low-level mouse hook watches presses on the icon (only while Donkey is in
    it). The press is kept from the taskbar, which would otherwise start rearranging its icons; a
    plain click still opens the menu and a double-click the Donkey window."""
    PULL_PX = 6  # physical pixels the pointer moves, button held, before Donkey comes out

    def __init__(self, ui: "DonkeyApp"):
        self.ui = ui
        self.rect: tuple[int, int, int, int] | None = None  # the icon, physical pixels (main thread keeps it fresh)
        self.armed = False       # Donkey is in the tray, so a press on the icon may pull it out
        self.pressing = self.dragging = False
        self.start = (0, 0)
        self.last_click = 0.0
        self.follow = None
        self._checked_rect, self._checked_at, self._is_ours = None, 0.0, False
        self._proc = keys.HOOKPROC(self._mouse)
        self.events = 0          # every mouse event the hook sees: a hook Windows dropped sees none
        self._seen = (0, None)   # (events, pointer) at the last refresh
        self._quiet = 0
        self.tid = 0
        self.refresh()
        self.timer = winui.every(0.4, self.refresh)
        self._start_hook()

    def _start_hook(self) -> None:
        threading.Thread(target=self._loop, name="tray-pull", daemon=True).start()

    def _check_alive(self) -> None:
        """Windows drops a low-level hook that once answers too slowly, without a word (a busy
        Python process can miss its deadline). If the pointer moves and the hook hears nothing, set
        it again."""
        pt = wintypes.POINT()
        keys.user32.GetCursorPos(ctypes.byref(pt))
        here = (pt.x, pt.y)
        events, last = self._seen
        moved = last is not None and here != last
        self._quiet = self._quiet + 1 if moved and self.events == events else 0
        self._seen = (self.events, here)
        if self._quiet >= 3:
            log.warning("the tray icon's mouse hook went quiet; setting it again")
            self._quiet = 0
            if self.tid:
                keys.user32.PostThreadMessageW(self.tid, keys.WM_QUIT, 0, 0)
            self._start_hook()

    def refresh(self) -> None:
        """Main thread: where the icon is now (it moves when icons are added or the taskbar changes)."""
        self._check_alive()
        self.armed = not self.ui.free.visible
        g = self.ui.tray.geometry()
        if not g.isValid() or g.width() <= 0:
            self.rect = None  # hidden in the overflow area: its clicks go to Qt as usual
            return
        x0, y0 = winui.to_physical(g.x(), g.y())
        x1, y1 = winui.to_physical(g.x() + g.width(), g.y() + g.height())
        rect = (x0, y0, x1, y1)
        now = time.monotonic()
        if rect != self._checked_rect or now - self._checked_at > 5:
            # For an icon behind the ⌃, Windows reports the ⌃'s own spot: take presses there only if
            # what's there really is Donkey's icon, so the ⌃ (and other icons) keep working
            self._checked_rect, self._checked_at = rect, now
            ours = self._names_donkey((x0 + x1) // 2, (y0 + y1) // 2)
            if ours != self._is_ours:
                log.info("tray pull %s (icon at %s)", "ready" if ours else "off: the icon isn't on the taskbar", rect)
            self._is_ours = ours
        self.rect = rect if self._is_ours else None

    @staticmethod
    def _names_donkey(x: int, y: int) -> bool:
        try:
            el = ax.El(ax._uia().ElementFromPoint(wintypes.POINT(x, y)))
        except Exception:
            return False
        for _ in range(4):  # the icon's picture, inside the button that carries its tooltip
            if el is None:
                return False
            name = str(el.prop(ax.P_NAME) or "")
            if name:
                return name.split("\n")[0].strip().startswith(TRAY_TOOLTIP)
            el = el.parent()
        return False

    def _loop(self) -> None:
        self.tid = keys.kernel32.GetCurrentThreadId()
        hook = keys.user32.SetWindowsHookExW(keys.WH_MOUSE_LL, self._proc, keys.kernel32.GetModuleHandleW(None), 0)
        if not hook:
            log.warning("couldn't watch the tray icon for drags (error %d)", ctypes.get_last_error())
            return
        msg = wintypes.MSG()
        while keys.user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
            pass
        keys.user32.UnhookWindowsHookEx(hook)

    def _mouse(self, code, wparam, lparam):
        if code >= 0:
            self.events += 1
            try:
                # Injected clicks count too: in a virtual machine (UTM's vdagent and the like) every
                # real click arrives injected, and Donkey never makes mouse clicks itself
                m = ctypes.cast(lparam, ctypes.POINTER(keys.MSLLHOOKSTRUCT)).contents
                if self._handle(wparam, m.pt.x, m.pt.y):
                    return 1
            except Exception:
                log.exception("tray hook")
        return keys.user32.CallNextHookEx(None, code, wparam, lparam)

    def _handle(self, wparam: int, x: int, y: int) -> bool:
        """Hook thread: True keeps the event from the taskbar."""
        if wparam == WM_LBUTTONDOWN:
            r = self.rect or self._checked_rect
            if r and y >= r[1] - 4 and abs(x - (r[0] + r[2]) / 2) < 200:  # near the icon: say what happened
                log.info("press on the taskbar at (%d, %d): icon %s, pull %s", x, y, r,
                         "ready" if self.rect and self.armed else "off" if not self.armed else "not over Donkey's icon")
            r = self.rect
            if self.armed and r and r[0] <= x < r[2] and r[1] <= y < r[3]:
                self.pressing, self.dragging, self.start = True, False, (x, y)
                return True
            self.pressing = False
            return False
        if not self.pressing:
            return False
        if wparam == WM_MOUSEMOVE:
            if not self.dragging and math.hypot(x - self.start[0], y - self.start[1]) >= self.PULL_PX:
                self.dragging = True
                winui.call_after(self.ui.pull_start)
            return False  # the pointer itself keeps moving
        if wparam == WM_LBUTTONUP:
            self.pressing = False
            winui.call_after(self.ui.pull_end if self.dragging else self.ui.tray_clicked)
            return True
        return False


WM_MOUSEMOVE, WM_LBUTTONDOWN, WM_LBUTTONUP = 0x200, 0x201, 0x202
TRAY_TOOLTIP = "Donkey"  # the tray button's name: how TrayPull tells Donkey's icon from the ⌃


def _promote_tray_icon() -> bool | None:
    """Show Donkey's icon on the taskbar itself rather than behind the ⌃ (Windows 11 hides new tray
    icons there; Donkey is pulled out of its icon, as from the Mac's menu bar, which is always in
    view). Windows keeps the setting per program file (python.exe and pythonw.exe are two), so this
    is done once for each: if you hide it again in Settings, that stays. True if done now, False if
    Explorer hasn't listed the icon yet (try later), None when there's nothing to do."""
    import winreg
    buf = ctypes.create_unicode_buffer(32768)
    ctypes.windll.kernel32.GetModuleFileNameW(None, buf, 32768)
    exe = buf.value.lower()  # the real process image (a venv's pythonw.exe starts the base one)
    done = _ui_state().get("tray_promoted")
    done = done if isinstance(done, list) else []  # (an early build stored True)
    if exe in done:
        return None
    try:
        root = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Control Panel\NotifyIconSettings")
    except OSError:
        return None  # not Windows 11's taskbar: icons there show by default
    found = False
    with root:
        i = 0
        while True:
            try:
                sub = winreg.EnumKey(root, i)
            except OSError:
                break
            i += 1
            try:
                with winreg.OpenKey(root, sub, 0, winreg.KEY_READ | winreg.KEY_SET_VALUE) as k:
                    path = str(winreg.QueryValueEx(k, "ExecutablePath")[0]).lower()
                    try:
                        tip = str(winreg.QueryValueEx(k, "InitialTooltip")[0])
                    except OSError:
                        tip = ""
                    if path == exe and (tip == "Donkey" or os.path.basename(exe) == "donkey.exe"):
                        winreg.SetValueEx(k, "IsPromoted", 0, winreg.REG_DWORD, 1)
                        found = True
            except OSError:
                continue
    if found:
        _save_ui_state(tray_promoted=done + [exe])
        log.info("tray icon shown on the taskbar")
    return found


def _dot(color: str) -> QIcon:
    pix = QPixmap(24, 24)
    pix.fill(Qt.transparent)
    p = QPainter(pix)
    p.setRenderHint(QPainter.Antialiasing)
    p.setPen(Qt.NoPen)
    p.setBrush(QColor(DOTS.get(color, color)))
    p.drawEllipse(7, 7, 10, 10)
    p.end()
    return QIcon(pix)


# ------------------------------------------------------------------ the app

class DonkeyApp:
    """Tray icon + the creature. Created on the main thread."""

    def __init__(self, cfg, db, rewriter: Rewriter, stop: threading.Event):
        self.cfg, self.db, self.rewriter, self.stop = cfg, db, rewriter, stop
        self.busy = False
        self.editing = False
        self.session = None
        self.work_started = 0.0
        self.field_enabled = _ui_state().get("field_creature", True)
        self.icons: dict[str, QIcon] = {}
        self.journalwin = None
        self.tray = QSystemTrayIcon()
        self.tray.setToolTip(TRAY_TOOLTIP)
        self.menu = QMenu()  # filled and placed by _show_menu (not setContextMenu: Qt would put it on the taskbar)
        self.tray.activated.connect(self._tray_activated)
        self.icon_name = ""
        self.refresh_icon()
        self.tray.show()
        # on the taskbar, not behind the ⌃ (Explorer lists a new icon a moment after it appears)
        winui.call_later(2.0, lambda: _promote_tray_icon() is False and winui.call_later(10.0, _promote_tray_icon))

        # One creature: idles above the caret, and animates right there while writing.
        self.creature = overlay.Creature(CREATURE_SIZE, CREATURE_BOX, "field", handler=self._creature_event,
                                         tooltip="Click to write here · right-click to hide",
                                         hit=(CREATURE_HIT, CREATURE_HIT))
        self.bar = EditBar(on_submit=self._edit_submit, on_cancel=self._edit_cancel, on_close=self._edit_closed)
        # The creature you bring out of the tray: sits wherever you drag it; click it to chat,
        # double-click it for ideas on the window in front, including ones Donkey can read but not
        # type into (Remote Desktop).
        self.free = overlay.Creature(FREE_SIZE, FREE_BOX, "free", handler=self._free_event,
                                     tooltip="Click to chat · double-click for ideas on this window · drag to move",
                                     hit=(FREE_HIT, FREE_HIT), draggable=True)
        self.free.on_release = self._free_released
        self.pull = TrayPull(self)  # press the tray icon and pull: Donkey comes out under the pointer
        self.card = SuggestCard(on_again=self._suggest_again, on_close=self._card_closed)
        self.bubbles = BubbleChat(cfg, db, on_expand=lambda tid: self.open_chat(thread_id=tid),
                                  on_working=self._chat_working)
        self.chat_busy = False  # the chat is answering
        self.click_seq = 0  # a single click waits to see whether it's the start of a double-click
        self.suggesting = False
        self.suggest_app = None
        if _ui_state().get("free_out"):
            winui.call_later(0.8, lambda: self._bring_out(fly=False))
        self.watcher = FieldWatcher(self)
        threading.Thread(target=self.watcher.run, args=(stop,), name="field-watcher", daemon=True).start()
        rewriter.on_event = self._rewrite_event_bg
        # The Donkey key outside a text field opens the chat.
        rewriter.on_no_field = lambda: winui.call_after(self.open_chat)
        self.journalwin = None
        self.keys = None  # the KeyWatcher, set by main: the welcome asks how it catches the key
        self.prologue = None
        if step := onboarding.pending(db):  # a fresh copy (or one restarted mid-welcome): the welcome
            winui.call_later(0.1, lambda: self.open_welcome(step))
        elif not llm.has_credentials():  # no model set up: ask which one before anything else
            winui.call_later(1.0, lambda: self.open_settings("first"))
        elif config.FROZEN and not os.environ.get("DONKEY_LOGIN"):
            # opened from the Start menu or a shortcut: show something, not just a tray icon
            # (the sign-in shortcut passes --login and starts quietly)
            winui.call_later(0.6, lambda: self.open_journal())
        # other Donkey processes: a second launch ("show"), a clicked notification (donkey:// link)
        self.server = instance.listen(self._message_from_other)
        self.timer = winui.every(5.0, self.refresh_icon)

    def _message_from_other(self, text: str) -> None:
        if text.startswith("donkey://nudge/"):
            try:
                self.open_chat(nudge_id=int(text.rsplit("/", 1)[1]))
                return
            except ValueError:
                pass
        if text.startswith("donkey://chat"):
            self.open_chat()
        else:
            self.open_journal()

    # -------------------------------------------------------------- placement

    @staticmethod
    def _perch(spot) -> tuple[float, float]:
        """Window origin (top-left) for the creature so its feet rest on top of the caret's line,
        centred over the caret. Near the top of a window it sits below the line instead."""
        caret_x, line_top, line_bottom, win_top = spot
        cx, top = winui.from_physical(caret_x, line_top)
        _, bottom = winui.from_physical(caret_x, line_bottom)
        _, wtop = winui.from_physical(caret_x, win_top)
        bw, bh = CREATURE_BOX
        x = cx - bw / 2 + 3
        y = top - bh + PERCH_OVERLAP
        if y < wtop + 2:
            y = bottom - PERCH_OVERLAP
        return overlay.clamp_to_screen(x, y, bw, bh)

    def place_creature(self, spot) -> None:
        if self.busy:
            return
        if spot is None or not self.field_enabled:
            if self.creature.visible:
                self.creature.hide()
            return
        self.creature.set_state("field")
        self.creature.show_at(*self._perch(spot))

    # -------------------------------------------------------------- rewrite → the same creature animates

    def _rewrite_event_bg(self, kind: str, t) -> None:
        """Rewrite thread: find the caret (UI Automation calls) only if the creature isn't already showing."""
        spot = None
        if kind == "start" and t is not None and not self.creature.visible:
            try:
                spot = caret_spot(t.element)
            except Exception:
                log.exception("caret spot")
        winui.call_after(self._rewrite_event, kind, spot)

    def _rewrite_event(self, kind: str, spot) -> None:
        if self.journalwin is not None and self.journalwin.visible:
            self.journalwin._call("rw", kind)  # the welcome's practice step watches for its first rewrite
        if kind == "start":
            self.busy = True
            self.work_started = time.monotonic()
            if not self.creature.visible and spot:
                self.creature.show_at(*self._perch(spot))  # key tap with no idle creature yet
            self.creature.set_state("working")
        elif kind == "done":
            self.creature.set_state("done")
            winui.call_later(1.1, self._back_to_idle)
        elif kind == "error":
            self.creature.set_state("error")
            winui.call_later(1.8, self._back_to_idle)
        else:  # cancelled
            self._back_to_idle()

    def _back_to_idle(self) -> None:
        self.busy = False
        self.creature.set_state("field")
        self.watcher.last = None  # let the watcher re-place (or hide) it on its next tick
        if not self.field_enabled:
            self.creature.hide()

    def _creature_event(self, kind: str, info) -> None:
        if kind == "hold" or (kind == "click" and info == 2):
            self.open_edit("creature")  # supersedes the rewrite the first click started
        elif kind == "click":
            if self.busy:
                # A click while it's working cancels, but not the second click of a double-click.
                if info == 1 and time.monotonic() - self.work_started > 0.6:
                    self.rewriter.cancel_current()
            elif info == 1:
                self.rewriter.trigger()
        elif kind == "menu":
            overlay.context_menu([("Hide for now", self.snooze_field),
                                  ("Turn off the creature by text fields", self.toggle_field)], info)
        elif kind in ("enter", "exit") and not self.busy:
            self.creature.js(f"setHover({'true' if kind == 'enter' else 'false'})")

    # -------------------------------------------------------------- the creature brought out, and its ideas

    def _tray_point(self) -> tuple[float, float, float, float]:
        """Where Donkey's tray icon is (x, y, w, h); the corner of the taskbar when Windows won't say
        (an icon in the overflow area)."""
        g = self.tray.geometry()
        if g.isValid() and g.width() > 0:
            return g.x(), g.y(), g.width(), g.height()
        cx, cy = winui.cursor()
        sx, sy, sw, sh = winui.work_area(cx, cy)
        return sx + sw - 60, sy + sh, 24, 24

    def _icon_origin(self) -> tuple[float, float]:
        """The creature window's origin that puts the donkey on Donkey's tray icon."""
        x, y, w, h = self._tray_point()
        bw, bh = FREE_BOX
        return x + w / 2 - bw / 2, y + h / 2 - bh + FREE_HIT / 2

    def _bring_out(self, fly: bool = True) -> None:
        """Out of the tray: where it was left, else just above Donkey's icon. Flies up from the icon
        when you ask for it; pops up in place when Donkey starts."""
        bw, bh = FREE_BOX
        saved = _ui_state().get("free_at")
        if saved:
            x, y = overlay.clamp_to_screen(saved[0], saved[1], bw, bh)
        else:
            tx, ty, tw, th = self._tray_point()
            sx, sy, sw, sh = winui.work_area(tx + tw / 2, ty - 10)
            x, y = overlay.clamp_to_screen(tx + tw / 2 - bw / 2, sy + sh - bh - 12, bw, bh)
        self.free.set_state("free")
        self.free.show_at(*(self._icon_origin() if fly else (x, y)))
        self.free.pop_in()
        if fly:
            self.free.fly_to(x, y)
        _save_ui_state(free_out=True)

    def _put_back(self) -> None:
        self.card.close()
        self.bubbles.close()
        self.free.fly_away(*self._icon_origin())
        _save_ui_state(free_out=False)

    def toggle_free(self) -> None:
        if self.free.visible:
            self._put_back()
        else:
            self._bring_out()

    def _free_released(self, x: float, y: float) -> bool:
        """Dropped on the taskbar: back in the tray, the way it came out."""
        bar = winui.taskbar_rect(x, y)
        if bar is None:
            return False
        bx, by, bw, bh = bar
        if not (bx <= x <= bx + bw and by <= y <= by + bh):
            return False
        self._put_back()
        return True

    def _free_event(self, kind: str, info) -> None:
        if kind == "click" and info == 1:
            self.click_seq += 1
            seq = self.click_seq
            winui.call_later(SINGLE_CLICK_S, lambda: seq == self.click_seq and self._toggle_bubbles())
        elif kind == "click" and info == 2:
            self.click_seq += 1  # not a single click after all
            self.bubbles.close()
            if self.card.is_open and not self.suggesting:
                self.card.close()  # double-click again puts the card away
            else:
                self.suggest_here()
        elif kind == "moving":
            if self.card.is_open:  # the card comes along
                self.card.anchor = self._free_anchor()
                self.card._place(animate=False)
            if self.bubbles.is_open:  # and so does the chat
                self.bubbles.follow(self._free_anchor())
        elif kind == "moved":
            _save_ui_state(free_at=list(self.free.origin()))
        elif kind == "menu":
            tricks = [("Surprise me", self.free.trick, ""), None] + \
                     [(label, self.free.trick, name) for name, label in overlay.TRICKS]
            overlay.context_menu([("Do a trick", tricks), None, ("Ideas for this window", self.suggest_here),
                                  ("Put back in the tray", self.toggle_free)], info)
        elif kind in ("enter", "exit") and not self.suggesting:
            self.free.js(f"setHover({'true' if kind == 'enter' else 'false'})")

    def _toggle_bubbles(self) -> None:
        """Open (or close) the chat under the creature. Once the bar is up, Donkey runs off to one end
        of it, picked at random (the other end if that one is off screen), and turns back to face the
        bar, leaving the middle free for what you type."""
        was_open = self.bubbles.is_open
        self.bubbles.toggle(self._free_anchor())
        if was_open or not self.bubbles.is_open:
            return
        left, right = self.bubbles.bar_span()
        bw, bh = FREE_BOX
        x, y = self.free.origin()
        ends = [left + FREE_SIZE * 0.42 - bw / 2, right - FREE_SIZE * 0.42 - bw / 2]
        random.shuffle(ends)
        cx = ends[0]
        for tx in ends:
            cx, _ = overlay.clamp_to_screen(tx, y, bw, bh)
            if abs(cx - tx) < 1:
                break
        centre = x + bw / 2

        def there(d: int) -> None:
            self.bubbles.offset = centre - (self.free.origin()[0] + bw / 2)  # the bar stays put when dragged
            _save_ui_state(free_at=list(self.free.origin()))
            if not self.suggesting:
                self.free.set_state("working" if self.chat_busy else "free")
            winui.call_later(0.35, lambda: self.free.face(-d))  # turns back to look at the bar
        self.free.run_to(cx, y, then=there)

    def _chat_working(self, on: bool) -> None:
        self.chat_busy = on
        if self.free.visible and not self.suggesting:
            self.free.set_state("working" if on else "free")  # Donkey thinks while it answers

    def _free_anchor(self):
        """(centre x, top, bottom) of the creature brought out."""
        bw, bh = FREE_BOX
        x, y = self.free.origin()
        return (x + bw / 2, y, y + bh)

    def suggest_here(self, app=None) -> None:
        if self.suggesting:
            return
        if self.free.visible:
            anchor = self._free_anchor()
            self.free.set_state("working")
        else:
            tx, ty, tw, th = self._tray_point()
            anchor = (tx + tw / 2, ty, ty + th)
        self.suggesting = True
        self.card.open(anchor, getattr(app, "name", None) or "the window")
        if self.watcher.last_front:  # the tray menu put the taskbar in front: use the window before it
            self.card.came_from = self.watcher.last_front
        threading.Thread(target=self._suggest_bg, args=(app,), name="suggest", daemon=True).start()

    def _suggest_bg(self, app) -> None:
        try:
            if app is None:
                app = self._app_behind()
                if app is None or app.pid == os.getpid():
                    raise suggest.NotReadable("Click the window you want ideas on first, then ask again.")
            name, s = suggest.for_window(self.cfg, self.db, app)
            self.suggest_app = app
            winui.call_after(self._suggest_done, name, s, None)
        except suggest.NotReadable as e:
            winui.call_after(self._suggest_done, None, None, str(e))
        except llm.LLMError as e:
            winui.call_after(self._suggest_done, None, None, f"Couldn't think that through ({e}). Try again?")
        except Exception as e:
            log.exception("suggestion failed")
            winui.call_after(self._suggest_done, None, None, f"Something went wrong: {e}")

    def _app_behind(self):
        """The window the card or menu was asked from (the card itself now has the keyboard)."""
        hwnd = self.card.came_from
        if not hwnd:
            return ax.front_app()
        pid = ax._owner_pid(hwnd)
        if ax.class_name(hwnd) == "ApplicationFrameWindow":
            pid = ax._uwp_child_pid(hwnd) or pid
        path = ax.process_path(pid)
        exe = os.path.basename(path).lower() if path else None
        return ax.FrontApp(pid, ax.app_name(path) if path else f"pid {pid}", exe, ax.AppEl(pid, hwnd), path)

    def _suggest_done(self, name, s, error) -> None:
        self.suggesting = False
        if error:
            self.card.error(error)
            if self.free.visible:
                self.free.set_state("error")
                winui.call_later(1.8, lambda: self.free.set_state("free"))
            return
        self.card.show(name, s)
        if self.free.visible:
            self.free.set_state("done")
            winui.call_later(1.1, lambda: self.free.set_state("free"))

    def _suggest_again(self) -> None:
        if self.suggesting:
            return
        app, self.suggesting = self.suggest_app, False
        self.card.close()
        self.suggest_here(app)  # the same window, even though the card had the keyboard

    def _card_closed(self) -> None:
        if self.free.visible and not self.suggesting:
            self.free.set_state("free")

    # -------------------------------------------------------------- the Donkey window

    def open_chat(self, nudge_id: int | None = None, new: bool = False, thread_id: int | None = None) -> None:
        """Chat is a tab of the Donkey window."""
        self.journal_window().open_chat(thread_id=thread_id, nudge_id=nudge_id, new=new)
        self.refresh_icon()

    def open_journal(self, view: str | None = None, day: str | None = None) -> None:
        self.journal_window().open(view, day)

    def journal_window(self):
        if self.journalwin is None:
            from .journal import JournalWindow
            self.journalwin = JournalWindow(self.cfg, self.db, on_capture_change=self.refresh_icon,
                                            on_settings_saved=self._settings_saved,
                                            hooks={"restart": self.restart, "key_kind": self._key_kind,
                                                   "login": login_item_enabled, "set_login": set_login_item})
        return self.journalwin

    def _key_kind(self):
        return getattr(getattr(self.keys, "src", None), "kind", None)

    def restart(self) -> None:
        """Start over in a new process (settings that only take effect at launch). The welcome
        reopens at the step it was on."""
        log.info("restarting")
        env = {**os.environ, **config.command_env(), "DONKEY_RESTART_FROM": str(os.getpid())}
        env.pop("DONKEY_LOGIN", None)
        subprocess.Popen(config.command(*(sys.argv[1:] or ["app"]), gui=True), env=env,
                         creationflags=0x00000008 | 0x00000200)  # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
        self.quit()

    def open_welcome(self, step: str = "hello") -> None:
        """From the start, the full-screen opening comes first and hands over to the window; a
        welcome picked up mid-way goes straight back to its step."""
        if step != "hello" or (self.journalwin is not None and self.journalwin.visible):
            self.open_journal("welcome", step)
            return
        if self.prologue is not None and self.prologue.showing:
            return
        from . import prologue
        win = self.journal_window()  # loads its page while the opening plays
        first = (self.cfg.user_name or "").split()[0] if (self.cfg.user_name or "").split() else ""
        self.prologue = prologue.Prologue(keys.resolve(self.cfg.rewrite_key), first,
                                          on_begin=lambda: win.open("welcome", "hello", rise=True))

    def open_settings(self, reason: str = "") -> None:
        self.open_journal("settings", reason)

    def _settings_saved(self) -> None:
        """Every part of Donkey holds this one Config, so updating it in place switches them all."""
        fresh = config.load()
        self.cfg.__dict__.update(fresh.__dict__)
        llm.use(self.cfg)
        log.info("settings saved: now using %s (%s)", self.cfg.llm_use, self.cfg.chat_model)
        self.refresh_icon()

    # -------------------------------------------------------------- the Donkey key (main thread)

    def key_tap(self) -> None:
        if self.prologue is not None and self.prologue.showing:
            self.prologue.key()
            return
        if self.journalwin is not None and self.journalwin.is_key and self.journalwin.view == "chat":
            self.journalwin.close()  # the key toggles the chat it opened
            return
        if self.bar.is_open:
            # Tapping the key while the bar is open sends what's typed, or closes an empty bar.
            if self.bar.text.strip() and not self.bar.working:
                self._edit_submit(self.bar.text.strip())
            elif not self.bar.working:
                self.bar.close("key_tap")
            return
        self.rewriter.trigger()

    def key_edit(self) -> None:
        """Hold or double-tap: open edit mode."""
        if self.prologue is not None and self.prologue.showing:
            self.prologue.key()
            return
        self.open_edit("key")

    # -------------------------------------------------------------- edit mode

    def open_edit(self, trigger: str) -> None:
        if self.bar.is_open:
            self.bar.come_back()
            return
        if self.busy:
            self.rewriter.cancel_current()  # "superseding the tap's rewrite, opening edit mode"
        threading.Thread(target=self._open_edit_bg, args=(trigger,), name="edit-open", daemon=True).start()

    def _open_edit_bg(self, trigger: str) -> None:
        deadline = time.monotonic() + 1.5
        while self.rewriter._busy.locked() and time.monotonic() < deadline:
            time.sleep(0.03)  # let a superseded rewrite finish cancelling
        try:
            session = edit.open_session(self.rewriter)
        except edit.FieldError as e:
            notify(str(e))
            return
        t = session.target
        anchor = ax.visible_frame(t.element)
        if not anchor:
            spot = caret_spot(t.element)
            anchor = (spot[0] - 20, spot[1], 300.0, spot[2] - spot[1]) if spot else None
        if not anchor:
            notify("Couldn't find where that text field is on screen.")
            return
        log.info("edit mode opened (%s) on %s, scope %s", trigger, t.app.name, session.scope)
        llm.prewarm()
        winui.call_after(self._show_edit, session, anchor)

    def _show_edit(self, session, anchor) -> None:
        self.session = session
        self.editing = True
        self.creature.hide(fade=False)
        self.bar.open(anchor, session.scope, len(session.rounds))

    def _edit_submit(self, text: str) -> None:
        session = self.session
        if session is None or session.running:
            return
        self.bar.set_working("Rewriting…")
        threading.Thread(target=self._edit_round_bg, args=(session, text), name="edit-round", daemon=True).start()

    def _edit_round_bg(self, session, text: str) -> None:
        stepped_aside = threading.Event()

        def hand_back_focus():
            """Main thread: move the bar aside and put the keyboard back in the app being edited."""
            done = threading.Event()

            def run():
                try:
                    self.bar.step_aside()
                finally:
                    done.set()
            winui.call_after(run)
            done.wait(1.0)
            stepped_aside.set()
            time.sleep(0.15)  # let the app take focus back before writing

        try:
            method = session.run_round(text, before_deliver=hand_back_focus)
            status = "Looks good already. Anything else?" if method == "unchanged" else "Done. Anything else?"
            winui.call_after(self._edit_finished, status, None, stepped_aside.is_set())
        except llm.Cancelled:
            winui.call_after(self._edit_finished, "Cancelled.", None, stepped_aside.is_set())
        except (edit.FieldError, edit.DeliveryError, llm.LLMError) as e:
            winui.call_after(self._edit_finished, None, str(e), stepped_aside.is_set())
        except Exception as e:
            log.exception("edit round failed")
            winui.call_after(self._edit_finished, None, f"Something went wrong: {e}", stepped_aside.is_set())

    def _edit_finished(self, status, error, stepped_aside: bool) -> None:
        if not self.bar.is_open:
            return
        if stepped_aside:
            self.bar.come_back()
        rounds = len(self.session.rounds) if self.session else 0
        if error:
            self.bar.set_error(error)
        else:
            self.bar.set_idle(status, rounds)

    def _edit_cancel(self) -> None:
        if self.session is not None:
            self.session.cancel.set()

    def _edit_closed(self, reason: str) -> None:
        log.info("edit mode closed (%s)", reason)
        if self.session is not None:
            self.session.cancel.set()
        self.session = None
        self.editing = False
        self.watcher.last = None  # the creature comes back on the watcher's next tick

    def snooze_field(self) -> None:
        self.watcher.snoozed_until = time.time() + SNOOZE_S
        self.creature.hide()

    def toggle_field(self) -> None:
        self.field_enabled = not self.field_enabled
        _save_ui_state(field_creature=self.field_enabled)
        self.watcher.last = None
        if not self.field_enabled:
            self.creature.hide()

    # -------------------------------------------------------------- tray

    def pull_start(self) -> None:
        """The tray icon was pressed and pulled: Donkey comes out under the pointer, carried."""
        if self.free.visible:
            return
        log.info("pulled out of the tray icon")
        grip = (FREE_BOX[0] / 2, FREE_BOX[1] - FREE_HIT / 2)  # held by the middle of the donkey
        cx, cy = winui.cursor()
        self.free.set_state("free")
        self.free.grab(grip)
        self.free.show_at(cx - grip[0], cy - grip[1])
        self.free.pop_in()
        self.free.lift()
        self.pull.follow = winui.every(1 / 60, self.free.follow_pointer)

    def pull_end(self) -> None:
        if self.pull.follow is not None:
            self.pull.follow.stop()
            self.pull.follow = None
        if not self.free.visible:
            return
        _save_ui_state(free_out=True)
        self.free.drop()  # thrown on with the pointer's speed; dropped on the taskbar, back in the tray
        self.pull.refresh()

    def tray_clicked(self) -> None:
        """A click on the icon that the pull watcher kept from the taskbar: as Qt would report it."""
        now = time.monotonic()
        if now - self.pull.last_click < keys.user32.GetDoubleClickTime() / 1000:
            self.pull.last_click = 0.0
            self.menu.hide()
            self._tray_activated(QSystemTrayIcon.DoubleClick)
        else:
            self.pull.last_click = now
            self._tray_activated(QSystemTrayIcon.Trigger)

    def _tray_activated(self, reason) -> None:
        if reason in (QSystemTrayIcon.Trigger, QSystemTrayIcon.Context):  # left or right click: the menu
            self._show_menu()
        elif reason == QSystemTrayIcon.DoubleClick:
            self.open_journal("home")

    def _show_menu(self) -> None:
        """The menu by the pointer and clear of the taskbar, as Windows' own tray menus open. Put
        at the pointer, Qt ran it down over the taskbar, with Quit right where the next click lands."""
        if self.menu.isVisible():
            self.menu.hide()
            return
        self._fill_menu()
        self.menu.adjustSize()
        w, h = self.menu.width(), self.menu.height()
        cx, cy = winui.cursor()
        sx, sy, sw, sh = winui.work_area(cx, cy)  # the screen without the taskbar
        x = cx if cx + w <= sx + sw else cx - w  # opens toward the middle of the screen
        y = cy - h  # above the pointer: below a top taskbar the clamp moves it down
        x = min(max(x, sx), sx + sw - w)
        y = min(max(y, sy), sy + sh - h)
        self.menu.popup(QPoint(int(x), int(y)))

    def refresh_icon(self) -> None:
        if capture.paused_until():
            name = "menubar-paused"
        elif self.db.query("SELECT 1 FROM nudges WHERE status = 'delivered' LIMIT 1"):
            name = "menubar-unread"
        else:
            name = "menubar"
        if name not in self.icons:
            self.icons[name] = _tray_icon(name)
        if name != self.icon_name:
            self.icon_name = name
            self.tray.setIcon(self.icons[name])
        if self.journalwin is not None and self.journalwin.chat.ready:
            self.journalwin.chat.push_inbox()  # also keeps the Chat tab's unread dot right

    @staticmethod
    def _add(menu: QMenu, title: str, fn=None, enabled: bool = True, checked: bool | None = None,
             icon: QIcon | None = None, bold: bool = False) -> QAction:
        act = QAction(title, menu)
        act.setEnabled(enabled and fn is not None)
        if fn is not None:
            act.triggered.connect(lambda _=False, f=fn: _safe(f))
        if checked is not None:
            act.setCheckable(True)
            act.setChecked(checked)
        if icon is not None:
            act.setIcon(icon)
        if bold:
            f = QFont(act.font())
            f.setBold(True)
            act.setFont(f)
        menu.addAction(act)
        return act

    def _fill_menu(self) -> None:
        """Short on purpose: where you are, the four places in the Donkey window, two things to do
        with the window in front, pause, and the rest under More."""
        menu = self.menu
        menu.clear()
        until = capture.paused_until()
        if not self.cfg.capture_enabled:
            status, dot = "Capture is off in settings", "gray"
        elif until == float("inf"):
            status, dot = "Paused until you resume", "orange"
        elif until:
            status, dot = f"Paused until {time.strftime('%H:%M', time.localtime(until))}", "orange"
        else:
            status, dot = "Remembering your screen", "green"
        key = key_name(self.cfg.rewrite_key)
        self._add(menu, status, lambda: self.open_journal("home"), icon=_dot(dot), bold=True)
        if llm.has_credentials():
            from .settings import in_use
            self._add(menu, f"Tap {key} to write · {in_use(self.cfg)}", enabled=False)
        else:
            self._add(menu, f"Tap {key} to write", enabled=False)
            self._add(menu, "Choose a model to get started…", lambda: self.open_settings(), icon=_dot("orange"))
        menu.addSeparator()

        self._add(menu, "Home", lambda: self.open_journal("home"))
        self._add(menu, "Timeline", lambda: self.open_journal("timeline"))
        self._add(menu, "Memory", lambda: self.open_journal("map"))
        self._add(menu, "Chat", self.open_chat)
        rows = self.db.query("SELECT id, title, status, created_at FROM nudges WHERE status != 'skipped' "
                             "ORDER BY created_at DESC LIMIT 8")
        unread = sum(1 for r in rows if r["status"] == "delivered")
        inbox = menu.addMenu(f"Inbox ({unread} new)" if unread else "Inbox")
        for r in rows:
            when = time.strftime("%a %H:%M", time.localtime(r["created_at"]))
            self._add(inbox, f"{r['title'] or 'Note'}  ·  {when}", lambda nid=r["id"]: self.open_chat(nudge_id=nid),
                      icon=_dot("accent") if r["status"] == "delivered" else None)
        if not rows:
            self._add(inbox, "Nothing yet. Briefs and reminders land here.", enabled=False)
        if unread:
            inbox.addSeparator()
            self._add(inbox, "Mark all as read", self.mark_all_read)
        upcoming = self.db.query("SELECT title, next_fire_at FROM reminders WHERE enabled = 1 "
                                 "ORDER BY next_fire_at LIMIT 1")
        todos = self.db.query("SELECT COUNT(*) AS n FROM todos WHERE done = 0")[0]["n"]
        if upcoming or todos:
            inbox.addSeparator()
        if upcoming:
            nxt = time.strftime("%a %H:%M", time.localtime(upcoming[0]["next_fire_at"]))
            self._add(inbox, f"Next reminder {nxt}: {upcoming[0]['title'][:34]}", enabled=False)
        if todos:
            self._add(inbox, f"{todos} open to-do{'s' if todos != 1 else ''}", lambda: self.open_journal("home"))
        menu.addSeparator()

        self._add(menu, "Ideas for this window", self.suggest_here)
        self._add(menu, "Put Donkey back" if self.free.visible else "Bring Donkey out", self.toggle_free)
        if until:
            self._add(menu, "Resume", self.resume)
        else:
            pause = menu.addMenu("Pause")
            self._add(pause, "For 30 minutes", lambda: self.pause(30))
            self._add(pause, "For 1 hour", lambda: self.pause(60))
            self._add(pause, "Until I resume", lambda: self.pause(None))
        menu.addSeparator()

        more = menu.addMenu("More")
        self._add(more, "New chat", lambda: self.open_chat(new=True))
        self._add(more, "Import chats or notes…", self.import_files)
        self._add(more, "Import a folder of notes…", self.import_folder)
        more.addSeparator()
        self._add(more, "Donkey beside text fields", self.toggle_field, checked=self.field_enabled)
        self._add(more, "Open at sign-in", self.toggle_login, checked=login_item_enabled())
        more.addSeparator()
        self._add(more, "Welcome tour", lambda: self.open_welcome("hello"))
        self._add(more, "Open log", lambda: winui.edit_text_file(config.HOME / "donkey.log"))
        self._add(menu, "Settings…", lambda: self.open_settings())
        self._add(menu, "Quit Donkey", self.quit)

    def pause(self, minutes) -> None:
        capture.pause(minutes)
        self.refresh_icon()

    def resume(self) -> None:
        capture.resume()
        self.refresh_icon()

    def mark_all_read(self) -> None:
        self.db.execute("UPDATE nudges SET status = 'seen', seen_at = ? WHERE status = 'delivered'", (time.time(),))
        self.refresh_icon()

    def import_files(self) -> None:
        paths, _ = QFileDialog.getOpenFileNames(
            None, "Import into Donkey", str(Path.home() / "Downloads"),
            "ChatGPT or Claude exports, Granola's cache (*.zip *.json);;Markdown notes (*.md *.markdown *.txt);;All files (*)")
        if paths:
            threading.Thread(target=self._import_bg, args=(paths,), name="import", daemon=True).start()

    def import_folder(self) -> None:
        path = QFileDialog.getExistingDirectory(None, "A folder of Markdown notes (Obsidian, a Notion export)",
                                                str(Path.home() / "Documents"))
        if path:
            threading.Thread(target=self._import_bg, args=([path],), name="import", daemon=True).start()

    def _import_bg(self, paths: list[str]) -> None:
        from . import imports
        from .rewrite import notify as tell
        lines = []
        for path in paths:
            try:
                lines.append(imports.run(self.db, path, mask=self.cfg.redact))
            except (ValueError, OSError) as e:
                lines.append(str(e))
            except Exception as e:
                log.exception("import %s", path)
                lines.append(f"{Path(path).name}: import failed ({e})")
        tell("\n".join(lines))

    def toggle_login(self) -> None:
        try:
            set_login_item(not login_item_enabled())
        except Exception as e:
            log.exception("sign-in shortcut")
            notify(f"Couldn't change the sign-in shortcut: {e}")

    def quit(self) -> None:
        log.info("quitting", stack_info=True)  # who asked: the menu, a restart, another copy
        self.stop.set()
        self.tray.hide()
        winui.quit()


def _safe(fn) -> None:
    try:
        fn()
    except Exception:
        log.exception("menu action")


# ------------------------------------------------------------------ entry point

def main(no_capture: bool = False, login: bool = False) -> None:
    from . import reminders
    from .capture import Capturer
    from .memory import Scheduler
    from .sends import SendWatcher

    if login:
        os.environ["DONKEY_LOGIN"] = "1"
    config.HOME.mkdir(parents=True, exist_ok=True)
    lock = instance.acquire()
    if lock is None:
        instance.send_to_running("show")
        sys.exit("Donkey is already running (look for its face in the system tray); its window is coming up.")
    _app_id()
    winui.app()  # the Qt application, before any window or call_after
    onboarding.note_launch()
    notify_mod.register()
    cfg = config.load()
    db = DB()
    stop = threading.Event()

    if not no_capture:
        threading.Thread(target=Capturer(cfg, db).run, args=(stop,), name="capture", daemon=True).start()
        threading.Thread(target=Scheduler(cfg, db).run, args=(stop,), name="memory", daemon=True).start()
        threading.Thread(target=SendWatcher(cfg, db).run, args=(stop,), name="sends", daemon=True).start()
    threading.Thread(target=reminders.Ticker(cfg, db).run, args=(stop,), name="reminders", daemon=True).start()
    rewriter = Rewriter(cfg, db)
    ui = {}  # filled once the app object exists; key gestures run on the main thread

    def on_main(name):
        return lambda: winui.call_after(lambda: getattr(ui["app"], name)() if "app" in ui else None)
    watcher = KeyWatcher(cfg.rewrite_key, on_tap=on_main("key_tap"), on_hold=on_main("key_edit"),
                         on_double_tap=on_main("key_edit"), on_cancel=rewriter.cancel_current)
    rewriter.on_busy_change = lambda busy: watcher.armed_cancel.set() if busy else watcher.armed_cancel.clear()
    threading.Thread(target=watcher.run, args=(stop,), name="keys", daemon=True).start()

    donkey = DonkeyApp(cfg, db, rewriter, stop)
    ui["app"] = donkey
    donkey.keys = watcher
    log.info("tray app running; tap %s in any text field to write, hold or double-tap it to edit",
             key_name(cfg.rewrite_key))
    winui.run()
    stop.set()


def _app_id() -> None:
    """Group Donkey's windows under its own name and icon in the taskbar (not Python's)."""
    import ctypes
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(notify_mod.APP_ID)
    except Exception:
        pass
