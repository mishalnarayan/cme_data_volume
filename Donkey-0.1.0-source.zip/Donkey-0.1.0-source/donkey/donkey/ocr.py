"""Reading a window's pixels when its accessibility tree has almost no text.

Some windows are only pictures as far as the screen reader is concerned: a remote desktop
(Citrix, a VM, Remote Desktop), a shared screen in a meeting, many games and canvas apps. For
those, capture takes one picture of that window alone (PrintWindow) and reads it with Windows'
own on-device text recognition (Windows.Media.Ocr; each language needs its Windows language pack).
The image never leaves memory and is never written to disk; only the recognised text goes on,
through the same blocklist and redaction as everything else.
"""
import asyncio
import ctypes
import logging
import re
import threading
import time
from ctypes import wintypes
from dataclasses import dataclass

log = logging.getLogger("donkey.ocr")

MAX_SIDE_PX = 3200   # longer side of the shot; plenty for 11 px text, keeps recognition under a second
CALL_TIMEOUT_S = 5
LANGUAGES = ["en-US"]  # set from capture.ocr_languages
GUTTER_BINS = 200     # a gap with no text this many 200ths of the width wide (or more) splits panes
GUTTER_MIN_BINS = 3
TABLE_ALIGNED = 0.6   # ...unless this share of rows lines up across it: then it is a table
DIVIDER_MIN = 0.25    # a vertical edge (a line, or a change of background) this share of the height tall splits panes
EDGE_DIFF = 8         # a colour step this big (of 255) is an edge
TABLE_TIGHT = 0.6     # ...unless this share of rows lines up tightly across it: a table's frozen column
FILL_DIFF = 6         # colours this close are one fill: a bubble ends where its fill does
NOTE = ("[Read from the window's pixels by text recognition: may contain misreads. Blank lines separate side-by-side "
        "panes. In a chat, lines starting with → are the user's own messages (anything inside their bubble, a picture "
        "they sent included); any other message belongs to the name on the header line above it, never to a name "
        "beside it on the same line. Currency signs such as ₹ are often read as 7]")

try:
    import numpy as np
    from winrt.windows.globalization import Language
    from winrt.windows.graphics.imaging import BitmapAlphaMode, BitmapPixelFormat, SoftwareBitmap
    from winrt.windows.media.ocr import OcrEngine
    from winrt.windows.storage.streams import DataWriter
except ImportError:  # pragma: no cover - the packages are in requirements.txt
    OcrEngine = None


# Cyrillic and Greek letters that look Latin: with only English expected, "Асте" is "Acme".
_LATIN = str.maketrans("АВЕКМНОРСТХаеорсухіјкмнтпΑΒΕΖΗΙΚΜΝΟΡΤΥΧο", "ABEKMHOPCTXaeopcyxijkmhmnABEZHIKMNOPTYXo")

_engines: dict[str, object] = {}
_missing: set[str] = set()


def _engine(language: str):
    """The recogniser for a language tag ("en-US"), or None when Windows has no pack for it."""
    if language in _engines:
        return _engines[language]
    eng = None
    if OcrEngine is not None:
        for tag in dict.fromkeys((language, language.split("-")[0])):
            try:
                eng = OcrEngine.try_create_from_language(Language(tag))
            except Exception:
                eng = None
            if eng is not None:
                break
    if eng is None and language not in _missing:
        _missing.add(language)
        log.warning("no Windows text recognition for %s: add that language in Settings > Time & language "
                    "> Language & region (with its optical character recognition)", language)
    _engines[language] = eng
    return eng


def available() -> bool:
    return OcrEngine is not None and _engine((LANGUAGES or ["en-US"])[0]) is not None


def permitted() -> bool:
    """Windows asks no permission to read a window's pixels."""
    return available()


def request_permission() -> bool:
    return available()


def warm() -> None:
    """Make the recognisers now so the first real read is quick. Capture doesn't wait for it."""
    def run():
        try:
            t0 = time.monotonic()
            for lang in LANGUAGES:
                _engine(lang)
            log.info("text recognition ready in %.1f s", time.monotonic() - t0)
        except Exception:
            log.debug("text recognition warm-up failed", exc_info=True)
    if OcrEngine is not None:
        threading.Thread(target=run, name="ocr-warm", daemon=True).start()


# ------------------------------------------------------------------ window pictures (GDI)

_user32 = ctypes.WinDLL("user32", use_last_error=True)
_gdi32 = ctypes.WinDLL("gdi32", use_last_error=True)
_dwm = ctypes.WinDLL("dwmapi")
WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
_user32.EnumWindows.argtypes = [WNDENUMPROC, wintypes.LPARAM]
_user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
_user32.GetWindowDC.restype = wintypes.HDC
_user32.GetWindowDC.argtypes = [wintypes.HWND]
_user32.ReleaseDC.argtypes = [wintypes.HWND, wintypes.HDC]
_user32.PrintWindow.argtypes = [wintypes.HWND, wintypes.HDC, wintypes.UINT]
_gdi32.CreateCompatibleDC.restype = wintypes.HDC
_gdi32.CreateCompatibleDC.argtypes = [wintypes.HDC]
_gdi32.CreateDIBSection.restype = wintypes.HBITMAP
_gdi32.CreateDIBSection.argtypes = [wintypes.HDC, ctypes.c_void_p, wintypes.UINT, ctypes.POINTER(ctypes.c_void_p),
                                    wintypes.HANDLE, wintypes.DWORD]
_gdi32.SelectObject.restype = wintypes.HGDIOBJ
_gdi32.SelectObject.argtypes = [wintypes.HDC, wintypes.HGDIOBJ]
_gdi32.DeleteObject.argtypes = [wintypes.HGDIOBJ]
_gdi32.DeleteDC.argtypes = [wintypes.HDC]
PW_RENDERFULLCONTENT = 0x2
DWMWA_EXTENDED_FRAME_BOUNDS, DWMWA_CLOAKED = 9, 14


class _BITMAPINFOHEADER(ctypes.Structure):
    _fields_ = [("biSize", wintypes.DWORD), ("biWidth", wintypes.LONG), ("biHeight", wintypes.LONG),
                ("biPlanes", wintypes.WORD), ("biBitCount", wintypes.WORD), ("biCompression", wintypes.DWORD),
                ("biSizeImage", wintypes.DWORD), ("biXPelsPerMeter", wintypes.LONG),
                ("biYPelsPerMeter", wintypes.LONG), ("biClrUsed", wintypes.DWORD), ("biClrImportant", wintypes.DWORD)]


def _pid_of(hwnd) -> int:
    pid = wintypes.DWORD()
    _user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    return int(pid.value)


def _cloaked(hwnd) -> bool:
    v = ctypes.c_int(0)
    _dwm.DwmGetWindowAttribute(wintypes.HWND(hwnd), DWMWA_CLOAKED, ctypes.byref(v), ctypes.sizeof(v))
    return bool(v.value)


def _rect(hwnd) -> tuple[int, int, int, int]:
    """The window's visible bounds (without the invisible resize border), physical pixels."""
    r = wintypes.RECT()
    if _dwm.DwmGetWindowAttribute(wintypes.HWND(hwnd), DWMWA_EXTENDED_FRAME_BOUNDS, ctypes.byref(r),
                                  ctypes.sizeof(r)) != 0:
        _user32.GetWindowRect(wintypes.HWND(hwnd), ctypes.byref(r))
    return r.left, r.top, r.right, r.bottom


def _title(hwnd) -> str:
    from . import ax
    return ax.window_title(int(hwnd))  # the same title capture compares with (Edge's zero-width space dropped)


def _window(pid: int, title: str | None):
    """The on-screen window of `pid` (an hwnd), preferring one with this title, else its largest."""
    mine: list[tuple[int, int]] = []
    fg = _user32.GetForegroundWindow()

    def visit(hwnd, _):
        if not _user32.IsWindowVisible(hwnd) or _user32.IsIconic(hwnd) or _cloaked(hwnd):
            return True
        owner = _pid_of(hwnd)
        if owner != pid and not (hwnd == fg and _uwp_owner(hwnd) == pid):
            return True
        l, t, r, b = _rect(hwnd)
        if r - l >= 80 and b - t >= 60:
            mine.append((hwnd, (r - l) * (b - t)))
        return True
    _user32.EnumWindows(WNDENUMPROC(visit), 0)
    if not mine:
        return None
    titled = [m for m in mine if title and _title(m[0]) == title]
    return max(titled or mine, key=lambda m: m[1])[0]


def _uwp_owner(hwnd) -> int | None:
    from . import ax
    return ax._uwp_child_pid(int(hwnd)) if ax.class_name(int(hwnd)) == "ApplicationFrameWindow" else None


def _grab(hwnd):
    """The window's pixels as an H x W x 4 (BGRA) array, painted by the window itself, so windows
    on top of it don't get in; None when it can't be had."""
    l, t, r, b = _rect(hwnd)
    wr = wintypes.RECT()
    _user32.GetWindowRect(wintypes.HWND(hwnd), ctypes.byref(wr))
    full_w, full_h = wr.right - wr.left, wr.bottom - wr.top
    if full_w <= 0 or full_h <= 0:
        return None
    wdc = _user32.GetWindowDC(hwnd)
    mdc = _gdi32.CreateCompatibleDC(wdc)
    bmi = _BITMAPINFOHEADER(ctypes.sizeof(_BITMAPINFOHEADER), full_w, -full_h, 1, 32, 0, 0, 0, 0, 0, 0)
    bits = ctypes.c_void_p()
    bmp = _gdi32.CreateDIBSection(mdc, ctypes.byref(bmi), 0, ctypes.byref(bits), None, 0)
    try:
        if not bmp:
            return None
        old = _gdi32.SelectObject(mdc, bmp)
        ok = _user32.PrintWindow(hwnd, mdc, PW_RENDERFULLCONTENT)
        _gdi32.SelectObject(mdc, old)
        if not ok:
            return None
        buf = (ctypes.c_ubyte * (full_w * full_h * 4)).from_address(bits.value)
        a = np.frombuffer(buf, dtype=np.uint8).reshape(full_h, full_w, 4).copy()
    finally:
        if bmp:
            _gdi32.DeleteObject(bmp)
        _gdi32.DeleteDC(mdc)
        _user32.ReleaseDC(hwnd, wdc)
    x0, y0 = max(0, l - wr.left), max(0, t - wr.top)  # crop the invisible resize border
    a = a[y0:y0 + (b - t), x0:x0 + (r - l)]
    return a if a.size else None


def _scaled(a, scale: float):
    """Resize a BGRA array (smoothly) by `scale`."""
    if abs(scale - 1.0) < 0.01:
        return a
    from PySide6.QtCore import Qt
    from PySide6.QtGui import QImage
    h, w = a.shape[:2]
    a = np.ascontiguousarray(a)
    img = QImage(a.data, w, h, w * 4, QImage.Format_RGB32)
    img = img.scaled(max(1, int(w * scale)), max(1, int(h * scale)), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
    img = img.convertToFormat(QImage.Format_RGB32)
    out = np.frombuffer(img.constBits(), dtype=np.uint8, count=img.sizeInBytes())
    return out.reshape(img.height(), img.bytesPerLine() // 4, 4)[:, :img.width()].copy()


def load_image(path):
    """A PNG or JPEG file as the BGRA array the recogniser and layout take (tools and tests)."""
    from PySide6.QtGui import QImage
    img = QImage(str(path)).convertToFormat(QImage.Format_RGB32)
    if img.isNull():
        return None
    a = np.frombuffer(img.constBits(), dtype=np.uint8, count=img.sizeInBytes())
    return a.reshape(img.height(), img.bytesPerLine() // 4, 4)[:, :img.width()].copy()


def save_image(a, path) -> None:
    from PySide6.QtGui import QImage
    a = np.ascontiguousarray(a)
    h, w = a.shape[:2]
    QImage(a.data, w, h, w * 4, QImage.Format_RGB32).save(str(path))


def _shot(win):
    """A picture of the window sized for text recognition: small text is scaled up (Windows'
    recogniser misses text under about 10 px tall), big windows down to MAX_SIDE_PX."""
    a = _grab(win) if win else None
    if a is None:
        return None
    h, w = a.shape[:2]
    limit = min(MAX_SIDE_PX, int(getattr(OcrEngine, "max_image_dimension", 10000) or 10000))
    scale = min(2.0, limit / max(w, h))
    if scale > 1.0:
        dpr = _dpi_scale(win)  # no upscaling where the screen is already at 200%
        scale = min(scale, max(1.0, 2.0 / dpr))
    return _scaled(a, scale)


def _dpi_scale(hwnd) -> float:
    try:
        return _user32.GetDpiForWindow(wintypes.HWND(hwnd)) / 96.0 or 1.0
    except Exception:
        return 1.0

THUMB_W, THUMB_H = 128, 80  # the change check's picture of the window: a two-letter reply spans several cells
THUMB_CELL_DIFF = 12        # a cell this much lighter or darker (of 255) changed
THUMB_MIN_CELLS = 5         # this many changed cells is a change; fewer is a blinking caret, a ticking digit or noise
BLANK_SPREAD = 2.0         # cells this alike (standard deviation) are a blank, black or locked screen


def thumbnail(pid: int, title: str | None) -> bytes | None:
    """A small grey picture of the window: enough to tell whether it changed since the last text
    recognition without running it again. None when it can't be taken."""
    if OcrEngine is None:
        return None
    win = _window(pid, title)
    a = _grab(win) if win else None
    if a is None:
        return None
    grey = a[:, :, 2] * 0.299 + a[:, :, 1] * 0.587 + a[:, :, 0] * 0.114
    h, w = grey.shape
    rows = np.linspace(0, h, THUMB_H + 1).astype(int)
    cols = np.linspace(0, w, THUMB_W + 1).astype(int)
    rows, cols = np.minimum(rows[:-1], h - 1), np.minimum(cols[:-1], w - 1)
    cells = np.add.reduceat(np.add.reduceat(grey, rows, axis=0), cols, axis=1)
    counts = np.outer(np.diff(np.r_[rows, h]), np.diff(np.r_[cols, w])).clip(min=1)
    return (cells / counts).clip(0, 255).astype(np.uint8).tobytes()

def changed(a: bytes, b: bytes) -> bool:
    return len(a) != len(b) or sum(abs(x - y) > THUMB_CELL_DIFF for x, y in zip(a, b)) >= THUMB_MIN_CELLS


def changed_cells(a: bytes, b: bytes) -> set[int]:
    """Thumbnail cells (row * THUMB_W + col) that differ between two pictures of one window."""
    return {i for i, (x, y) in enumerate(zip(a, b)) if abs(x - y) > THUMB_CELL_DIFF}


def words_in(boxes: list["Box"], cells: set[int]) -> set[str]:
    """Words of the boxes that touch any of these thumbnail cells."""
    out: set[str] = set()
    for b in boxes:
        r0, r1 = int(b.top * THUMB_H), min(THUMB_H - 1, int((b.top + b.height) * THUMB_H))
        c0, c1 = int(b.left * THUMB_W), min(THUMB_W - 1, int(b.right * THUMB_W))
        if any(r * THUMB_W + c in cells for r in range(r0, r1 + 1) for c in range(c0, c1 + 1)):
            out |= words(b.text)
    return out


def blank(thumb: bytes) -> bool:
    """One flat colour: a remote desktop gone black or to its lock screen, a screen saver."""
    mean = sum(thumb) / len(thumb)
    return (sum((x - mean) ** 2 for x in thumb) / len(thumb)) ** 0.5 < BLANK_SPREAD


@dataclass
class Box:
    top: float    # 0 = top of the window, 1 = bottom
    left: float
    right: float
    height: float
    text: str
    own: bool = False  # sits in the user's own chat bubble, as the pixels show


def _recognize(image, language: str) -> list[Box]:
    eng = _engine(language)
    if eng is None or image is None:
        return []
    h, w = image.shape[:2]
    writer = DataWriter()
    writer.write_bytes(np.ascontiguousarray(image).tobytes())
    bmp = SoftwareBitmap.create_copy_from_buffer(writer.detach_buffer(), BitmapPixelFormat.BGRA8, w, h,
                                                 BitmapAlphaMode.IGNORE)

    async def run():
        return await eng.recognize_async(bmp)
    try:
        result = asyncio.run(run())
    except Exception as e:
        log.debug("text recognition failed: %s", e)
        return []
    out = []
    for line in result.lines or []:
        rects = [wd.bounding_rect for wd in line.words or []]
        text = " ".join((line.text or "").split())
        if not rects or not text:
            continue
        x0 = min(r.x for r in rects)
        y0 = min(r.y for r in rects)
        x1 = max(r.x + r.width for r in rects)
        y1 = max(r.y + r.height for r in rects)
        out.append(Box(y0 / h, x0 / w, x1 / w, (y1 - y0) / h, text))
    return out

def _overlap(a: Box, b: Box) -> bool:
    return a.left < b.right and b.left < a.right and a.top < b.top + b.height and b.top < a.top + a.height


_LATIN_SCRIPT = re.compile(r"^[\x00-\u024f\u2000-\u206f]*$")  # Latin letters and punctuation only
_CURRENCY = re.compile(r"([₹€£¥₩])\s?(\d[\d,.]*)")


def _merge(primary: list[Box], extra: list[Box]) -> list[Box]:
    """Lines in another script from an extra pass replace what the first pass made of them, and a
    currency sign the extra pass saw fixes the amount the first pass misread ("738,000" for "₹38,000")."""
    out = list(primary)
    for e in extra:
        hits = [p for p in out if _overlap(p, e)]
        if not _LATIN_SCRIPT.match(_CURRENCY.sub("", e.text)):
            out = [p for p in out if p not in hits] + [e]
            continue
        for amount in _CURRENCY.finditer(e.text):
            sign, digits = amount.group(1), amount.group(2).rstrip(",.")
            if len(digits) < 3:
                continue
            # The misread sign survives as one stray character glued to the same digits (the extra
            # pass may have cut the amount short, so its digits need only start the number).
            misread = re.compile(rf"(?<![\w,.₹€£¥₩])[^\s₹€£¥₩](?={re.escape(digits)})")
            for p in hits:
                p.text = misread.sub(sign, p.text, count=1)
    return out


def recognize(image) -> list[Box]:
    """Text lines in a picture (BGRA array), in no particular order: a pass in the first configured language,
    then one per further language (another script, or currency signs, the first pass can't read)."""
    boxes = _recognize(image, LANGUAGES[0])
    for language in LANGUAGES[1:]:
        boxes = _merge(boxes, _recognize(image, language))
    for b in boxes:
        b.text = b.text.translate(_LATIN) if _mostly_latin(b.text) else b.text
    return boxes


def _mostly_latin(text: str) -> bool:
    letters = [c for c in text if c.isalpha()]
    return sum(c < "\u0250" for c in letters) > len(letters) / 2


def _rows(boxes: list[Box]) -> list[list[Box]]:
    """Boxes grouped into visual rows, top to bottom, each row left to right."""
    rows: list[list[Box]] = []
    for b in sorted(boxes, key=lambda b: b.top + b.height / 2):
        row = rows[-1] if rows else None
        # Same row when the vertical centres are within half a line of each other.
        if row and abs((b.top + b.height / 2) - (row[-1].top + row[-1].height / 2)) < min(b.height, row[-1].height) / 2:
            row.append(b)
        else:
            rows.append([b])
    return [sorted(r, key=lambda b: b.left) for r in rows]


def _aligned(a: list[Box], b: list[Box]) -> float:
    """Share of the shorter side's rows that have a box at the same height on the other side."""
    if not a or not b:
        return 0.0
    small, big = (a, b) if len(a) <= len(b) else (b, a)
    hit = sum(any(abs((x.top + x.height / 2) - (y.top + y.height / 2)) < min(x.height, y.height) / 2 for y in big)
              for x in small)
    return hit / len(small)


def _spread(xs: list[float]) -> float:
    xs = sorted(xs)
    return xs[len(xs) * 8 // 10] - xs[len(xs) * 2 // 10]


def _right_aligned(pane: list[Box]) -> bool:
    """Lines flush right with ragged left edges: the other side of a chat, not a pane of its own."""
    return len(pane) >= 2 and _spread([b.left for b in pane]) > 0.02 and \
        _spread([b.right for b in pane]) < 0.3 * _spread([b.left for b in pane])


def _panes(boxes: list[Box]) -> list[list[Box]]:
    """Split side-by-side panes (a sidebar, a message list, a reading pane) at the empty vertical
    gutters between them. A gap whose two sides line up row by row is a table's columns, not panes."""
    narrow = [b for b in boxes if b.right - b.left < 0.5] or boxes
    lo, hi = min(b.left for b in boxes), max(b.right for b in boxes)
    if hi - lo <= 0:
        return [boxes]
    covered = [0] * GUTTER_BINS
    for b in narrow:
        for i in range(int((b.left - lo) / (hi - lo) * GUTTER_BINS), min(GUTTER_BINS, int((b.right - lo) / (hi - lo) * GUTTER_BINS) + 1)):
            covered[i] += 1
    cuts, run = [], 0
    for i, c in enumerate(covered):
        run = run + 1 if c == 0 else 0
        if run == GUTTER_MIN_BINS:
            cuts.append(lo + (i + 0.5) / GUTTER_BINS * (hi - lo))
    panes: list[list[Box]] = []
    for edge_lo, edge_hi in zip([lo - 1, *cuts], [*cuts, hi + 1]):
        pane = [b for b in boxes if edge_lo <= (b.left + b.right) / 2 < edge_hi]
        if not pane:
            continue
        if panes and (_aligned(panes[-1], pane) >= TABLE_ALIGNED or _right_aligned(pane)):
            panes[-1].extend(pane)
        else:
            panes.append(pane)
    return panes


def _pane_text(pane: list[Box], seen: bool = False) -> str:
    """One line per visual row. `seen`: the picture showed whose bubbles are whose, so → follows
    that; without it, lines flush right in a chat-like pane are taken for the user's."""
    rows = _rows(pane)
    # The pane's edges where most of its text sits (a stray clock or search box shouldn't move them).
    lefts, rights = sorted(b.left for b in pane), sorted(b.right for b in pane)
    lo, hi = lefts[len(lefts) // 10], rights[min(len(rights) - 1, len(rights) * 85 // 100)]
    width = max(hi - lo, 1e-6)
    right = [len(r) == 1 and r[0].left > lo + 0.3 * width and r[0].right > hi - 0.04 * width for r in rows]
    starts_left = sum(r[0].left < lo + 0.1 * width for r in rows)
    # A pane with lines on both sides is chat-like: mark the right-hand ones (usually your own messages).
    if seen:
        return "\n".join(("→ " if all(b.own for b in r) else "") + "   ".join(b.text for b in r) for r in rows)
    mark = len(rows) >= 4 and sum(right) >= 2 and starts_left >= 2
    return "\n".join(("→ " if mark and r else "") + "   ".join(b.text for b in row) for row, r in zip(rows, right))


def layout(boxes: list[Box], image=None) -> str:
    """Boxes as reading-order text: pane by pane, left to right; within a pane one line per visual
    row. Right-aligned lines in a chat-like pane start with →. With the window's picture, panes
    come from the dividers drawn between them and the user's messages from their bubbles."""
    if not boxes:
        return ""
    px = _pixels(image) if image is not None else None
    groups = [boxes]
    if px is not None:
        dividers = _dividers(px)
        parts = [_tighten(g, x0, x1, dividers) for g, x0, x1 in _cut(boxes, dividers)]
        for g, x0, x1 in parts:
            _mark_own(g, px, x0, x1)
        groups = [g for g, _, _ in parts]
    # A chat the pixels found the user's bubbles in is one pane, top to bottom: its two sides and
    # the times centred between them are not columns.
    return "\n\n".join(_pane_text(p, px is not None) for g in groups for p in ([g] if any(b.own for b in g) else _panes(g)))


# ------------------------------------------------------------------ pixels

def _pixels(image):
    """The picture as a height x width x RGB array, or None."""
    try:
        return image[:, :, 2::-1].astype(np.int16)
    except Exception:
        log.debug("pixels unavailable", exc_info=True)
        return None

@dataclass
class Divider:
    x: float
    top: float
    bottom: float


def _dividers(px) -> list[Divider]:
    """Vertical edges at least DIVIDER_MIN of the height tall: the lines and background changes
    apps draw between panes. Text never makes one (a glyph's edge is a line high), a card or a
    picture only its own height."""
    import numpy as np
    h, w = px.shape[:2]
    edge = np.abs(np.diff(px, axis=1)).max(axis=2) > EDGE_DIFF
    need = int(DIVIDER_MIN * h)
    found: list[Divider] = []
    for x in np.nonzero(edge.sum(axis=0) >= need)[0]:
        ys = np.nonzero(edge[:, x])[0]
        breaks = np.nonzero(np.diff(ys) > 4)[0]  # a dotted or anti-aliased line still counts
        for y0, y1 in zip(np.r_[ys[0], ys[breaks + 1]], np.r_[ys[breaks], ys[-1]]):
            if y1 - y0 >= need:
                found.append(Divider((x + 1) / w, y0 / h, y1 / h))
    merged: list[Divider] = []
    for d in sorted(found, key=lambda d: d.x):  # a line's two sides are one divider
        m = merged[-1] if merged else None
        if m and d.x - m.x < 6 / w and d.top < m.bottom and m.top < d.bottom:
            m.top, m.bottom = min(m.top, d.top), max(m.bottom, d.bottom)
        else:
            merged.append(d)
    return merged


def _tight(a: list[Box], b: list[Box]) -> float:
    """Share of the shorter side's lines with a line at the very same height on the other side."""
    if not a or not b:
        return 0.0
    small, big = (a, b) if len(a) <= len(b) else (b, a)
    return sum(any(abs((x.top + x.height / 2) - (y.top + y.height / 2)) < min(x.height, y.height) * 0.2 for y in big)
               for x in small) / len(small)


def _cut(boxes: list[Box], dividers: list[Divider], x0: float = 0.0, x1: float = 1.0) -> list[tuple]:
    """(boxes, left edge, right edge) of each part: the boxes split around the longest divider into
    above, left, right and below, each split again by the dividers left; the edges are the
    dividers around the part (or the window's). A divider rows line up across is a table's, and
    doesn't split."""
    for d in sorted(dividers, key=lambda d: d.top - d.bottom):
        mid = lambda b: b.top + b.height / 2
        beside = [b for b in boxes if d.top <= mid(b) <= d.bottom]
        left = [b for b in beside if (b.left + b.right) / 2 < d.x]
        right = [b for b in beside if (b.left + b.right) / 2 >= d.x]
        if not left or not right or _tight(left, right) >= TABLE_TIGHT:
            continue
        rest = [x for x in dividers if x is not d]
        above = [b for b in boxes if mid(b) < d.top]
        below = [b for b in boxes if mid(b) > d.bottom]
        parts = ((above, x0, x1), (left, x0, d.x), (right, d.x, x1), (below, x0, x1))
        return [g for part, a, b in parts if part for g in _cut(part, rest, a, b)]
    return [(boxes, x0, x1)]


def _tighten(group: list[Box], x0: float, x1: float, dividers: list[Divider]) -> tuple:
    """The part's edges pulled in to the nearest dividers running alongside most of its text, even
    ones that split nothing (empty space between a popup and the page behind it)."""
    top, bottom = min(b.top for b in group), max(b.top + b.height for b in group)
    lo, hi = min(b.left for b in group), max(b.right for b in group)
    alongside = [d for d in dividers if min(d.bottom, bottom) - max(d.top, top) >= 0.5 * (bottom - top)]
    x0 = max([x0] + [d.x for d in alongside if x0 < d.x <= lo])
    x1 = min([x1] + [d.x for d in alongside if hi <= d.x < x1])
    return group, x0, x1


def _spans(group: list[Box], px) -> list[tuple]:
    """(box, left px, right px, fill) of the block of colour each box's text sits in: its bubble, a
    card, or the pane's background, followed out from beside the text."""
    import numpy as np
    h, w = px.shape[:2]
    spans = []
    for b in group:
        # This much other colour in a row is the bubble's edge, not a letter or an icon (a read tick) on the way.
        gap = max(4, int(0.006 * w), int(1.2 * b.height * h))
        y = int((b.top + b.height / 2) * h)
        x0, x1 = int(b.left * w), min(w - 1, int(b.right * w))
        if not 0 <= y < h or x1 <= x0 or x0 < 3:
            continue
        fill = px[y, x0 - 3]  # the bubble's side padding, level with the text
        other = (np.abs(px[y] - fill).max(axis=1) > FILL_DIFF).astype(np.int8)
        runs = np.convolve(other, np.ones(gap, dtype=np.int8), "valid") == gap  # runs[i]: other colour from i on
        left = np.nonzero(runs[:max(0, x0 - gap)])[0]
        right = np.nonzero(runs[x1:])[0]
        spans.append((b, left[-1] + gap if len(left) else 0, x1 + right[0] if len(right) else w, tuple(fill // 4)))
    return spans


def _bubbles(spans: list[tuple]) -> list[tuple[int, int]]:
    """(left, right) of each bubble: lines with one left edge stacked right on top of each other are one."""
    out: list[tuple[int, int]] = []
    last = None
    for sp in sorted(spans, key=lambda sp: sp[0].top):
        b = sp[0]
        if last and abs(sp[1] - last[1]) <= 3 and b.top - last[0].top <= 2.2 * max(b.height, last[0].height):
            out[-1] = (out[-1][0], max(out[-1][1], sp[2]))
        else:
            out.append((sp[1], sp[2]))
        last = sp
    return out


def _mark_own(group: list[Box], px, x0: float = 0.0, x1: float = 1.0) -> None:
    """Mark the boxes in the user's own chat bubbles: bubbles whose right edges line up at the
    pane's right while the other side's line up at its left, as in nearly every chat app (a
    gradient fill, as in Messenger, is fine). Text inside such a bubble (a picture the user sent)
    is theirs too. Nothing is marked in a pane without at least two times in it."""
    import numpy as np
    h, w = px.shape[:2]
    spans = _spans(group, px)
    if not spans:
        return
    lo, hi = int(x0 * w), min(w, int(x1 * w))  # the pane's edges: the dividers around it, as drawn
    top = min(h - 1, max(0, int(min(b.top for b in group) * h)))
    rows = slice(top, max(top + 1, min(h, int(max(b.top + b.height for b in group) * h))))
    bg = np.median(px[rows, min(w - 1, lo + 3)], axis=0) // 4  # the pane's own background, at its left edge
    # A bubble is a fill other than the pane's that ends before the pane does, on both sides.
    bubbles = [s for s in spans if s[1] > lo + 3 and s[2] < hi - 3  # background runs right up to the divider
               and np.abs(np.array(s[3]) - bg).max() > FILL_DIFF // 4]
    if not bubbles:
        return
    # The other side's bubbles start at one left edge near the pane's left; the user's start further in
    # and end at one right edge. A bubble starting at the other side's edge (a long message of theirs,
    # a banner across the chat) or in their colour is not the user's.
    near = [s for s in bubbles if s[1] - lo < 0.3 * (hi - lo)]
    first = min(s[1] for s in near) if near else None
    theirs = [np.array(s[3]) for s in near if s[1] - first <= 0.006 * w]
    inset = [s for s in bubbles if s[1] - lo > 0.15 * (hi - lo) and s[2] > lo + 0.6 * (hi - lo)
             and (first is None or s[1] >= first + 0.02 * w)
             and not any(np.abs(np.array(s[3]) - t).max() <= 1 for t in theirs)]  # fills are in steps of 4
    if not inset:
        return
    edge = max(s[2] for s in inset)
    own = [s for s in inset if edge - s[2] <= 0.006 * w]
    mine, other = _bubbles(own), _bubbles([sp for sp in near if sp[1] - first <= 0.006 * w] if near else [])
    # Messages vary in length: the user's left edges are ragged, the other side's right edges are.
    # A list's or a calendar's items share their edges; a lone coloured block with no other side
    # (a button) proves nothing.
    ragged = lambda xs: max(xs) - min(xs) >= 0.02 * w
    if (len(mine) >= 3 or len(mine) >= 2 and not theirs) and not ragged([bb[0] for bb in mine]):
        return
    if len(other) >= 3 and not ragged([bb[1] for bb in other]):
        return
    if len(mine) == 1 and not other:
        return
    if not any(_TIME.search(b.text) for b in group):
        return  # a chat shows when things were said
    rects = []
    tall = 0.5 * (rows.stop - rows.start) / h  # a "bubble" taller than this is a background, not a message
    for b, l, r, fill in own:
        b.own = True
        x = r - 3  # the bubble's right padding: follow its fill up and down to the bubble's top and bottom
        col = np.abs(px[:, x] - px[int(b.top * h) - 1, x]).max(axis=1) <= FILL_DIFF
        y = int((b.top + b.height / 2) * h)
        up, down = np.nonzero(~col[:y])[0], np.nonzero(~col[y:])[0]
        top, bottom = (up[-1] + 1 if len(up) else 0) / h, (y + down[0] if len(down) else h) / h
        if bottom - top < tall:
            rects.append((l / w, r / w, top, bottom))
    for b in group:
        cx, cy = (b.left + b.right) / 2, b.top + b.height / 2
        if any(l <= cx <= r and t <= cy <= btm for l, r, t, btm in rects):
            b.own = True


_TIME = re.compile(r"\b\d{1,2}:\d{2}\b")


def read_window(pid: int, title: str | None) -> str | None:
    """Recognised text of the window, or None (no recogniser, no window, nothing legible)."""
    boxes, image = read_boxes(pid, title)
    return layout(boxes, image) or None


def read_boxes(pid: int, title: str | None) -> tuple[list[Box], object]:
    """The window's recognised text boxes and its picture (for `layout`); ([], None) without
    a recogniser or a window."""
    if not available():
        return [], None
    t0 = time.monotonic()
    win = _window(pid, title)
    image = _shot(win) if win is not None else None
    if image is None:
        return [], None
    t1 = time.monotonic()
    boxes = recognize(image)
    log.debug("ocr: %dx%d px, shot %d ms, recognition %d ms, %d boxes", image.shape[1], image.shape[0],
              (t1 - t0) * 1000, (time.monotonic() - t1) * 1000, len(boxes))
    return boxes, image

_WORD = re.compile(r"\w{3,}")


def words(text: str) -> set[str]:
    return {w.lower() for w in _WORD.findall(text or "")}
