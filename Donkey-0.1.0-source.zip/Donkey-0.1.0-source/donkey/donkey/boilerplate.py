"""Page chrome, learned per surface: text fragments that repeat across most visits to a site or app
(menus, sidebars, footers, "Skip to main content"), stripped before screens go to the model.

A surface is a site (domain) or, without one, an app. A context is one page or window in one
hour, so a page left open for an hour counts once, not once per capture: otherwise a long read
would look like chrome. A fragment is chrome when it shows up in at least CHROME_SHARE of a
surface's contexts, and only once the surface has MIN_CONTEXTS of them.

The original text is kept in `snapshots.content` (and in full-text search); the stripped text
goes to `snapshots.body`, which summaries and wiki evidence read.
"""
import logging
import re
import time
from collections import Counter

from .db import DB

log = logging.getLogger("donkey.boilerplate")

MIN_CONTEXTS = 5
CHROME_SHARE = 0.6
WINDOW_CONTEXTS = 200        # learn from the most recent contexts per surface
REFIT_GROWTH = 1.25          # refit when a surface has 25% more contexts than at the last fit
REFIT_AGE_S = 6 * 3600
MAX_KEY_CHARS = 160

# Fragment boundaries: line breaks, runs of spaces, and the seam where browser text glues two
# elements together with nothing between them ("…main contentAccessibility help").
_SPLIT = re.compile(r"\n+|[ \t\u00a0]{2,}|\ufffc+|(?<=[a-z0-9.!?:)\]])(?=[A-Z][a-z]{2,})")
_DIGITS = re.compile(r"\d+")


def _pieces(text: str) -> list[tuple[str, str]]:
    """(separator before it, fragment), so stripped text can be rebuilt with its own spacing."""
    out, last, sep = [], 0, ""
    for m in _SPLIT.finditer(text or ""):
        out.append((sep, text[last:m.start()]))
        sep, last = m.group(0), m.end()
    out.append((sep, (text or "")[last:]))
    return [(s, f) for s, f in out if f.strip()]


def fragments(text: str) -> list[str]:
    return [f.strip() for _, f in _pieces(text)]


def key(fragment: str) -> str:
    """Numbers and case don't matter: "(81) WhatsApp" and "(79) WhatsApp" are the same chrome."""
    return " ".join(_DIGITS.sub("#", fragment.lower()).split())[:MAX_KEY_CHARS]


def surface_of(domain: str | None, app: str) -> str:
    return domain or f"app:{app.lower()}"


def _contexts(db: DB, surface: str) -> list[set[str]]:
    if surface.startswith("app:"):
        where, arg = "domain IS NULL AND lower(app) = ?", surface[4:]
    else:
        where, arg = "domain = ?", surface
    rows = db.query(f"SELECT COALESCE(url, window_title) AS page, captured_at, content FROM snapshots "
                    f"WHERE {where} ORDER BY captured_at DESC LIMIT 2000", (arg,))
    ctx: dict[tuple[str, str], set[str]] = {}
    for r in rows:
        k = (r["page"] or "", time.strftime("%Y-%m-%dT%H", time.localtime(r["captured_at"])))
        if k not in ctx and len(ctx) >= WINDOW_CONTEXTS:
            continue
        ctx.setdefault(k, set()).update(key(f) for f in fragments(r["content"]))
    return list(ctx.values())


def fit(db: DB, surface: str) -> int:
    """Learn this surface's chrome. Returns the number of chrome fragments (0 if not enough data)."""
    contexts = _contexts(db, surface)
    db.execute("DELETE FROM boilerplate WHERE surface = ?", (surface,))
    if len(contexts) < MIN_CONTEXTS:
        db.execute("INSERT OR REPLACE INTO boilerplate_fit (surface, screens, fitted_at) VALUES (?, ?, ?)",
                   (surface, len(contexts), time.time()))
        return 0
    df = Counter(k for c in contexts for k in c)
    chrome = [(k, n / len(contexts)) for k, n in df.items() if k and n / len(contexts) >= CHROME_SHARE]
    for k, share in chrome:
        db.execute("INSERT INTO boilerplate (surface, key, df) VALUES (?, ?, ?)", (surface, k, share))
    db.execute("INSERT OR REPLACE INTO boilerplate_fit (surface, screens, fitted_at) VALUES (?, ?, ?)",
               (surface, len(contexts), time.time()))
    return len(chrome)


def chrome_keys(db: DB, surface: str) -> set[str]:
    return {r["key"] for r in db.query("SELECT key FROM boilerplate WHERE surface = ?", (surface,))}


def strip(text: str, chrome: set[str]) -> str:
    if not chrome:
        return text
    out, dropped = [], False
    for sep, frag in _pieces(text):
        if key(frag.strip()) in chrome:
            dropped = True
            continue
        sep = " " if "\ufffc" in sep else sep
        out.append(("\n" if dropped and out else sep if out else "") + frag)
        dropped = False
    return "".join(out)


def drop_seen(text: str, seen: set[str]) -> str:
    """Drop fragments already in `seen` (case and spacing ignored, numbers kept, so a changed price
    or time still counts as new) and add this text's fragments to it. For summarizing an hour:
    a page re-read every 20 s repeats almost everything it said the first time."""
    out, dropped = [], False
    for sep, frag in _pieces(text):
        k = " ".join(frag.lower().split())[:MAX_KEY_CHARS]
        if k in seen:
            dropped = True
            continue
        seen.add(k)
        sep = " " if "\ufffc" in sep else sep
        out.append(("\n" if dropped and out else sep if out else "") + frag)
        dropped = False
    return "".join(out)


def refresh(db: DB) -> dict:
    """Refit surfaces that grew or aged, then (re)compute `body` for their screens."""
    fitted = {r["surface"]: r for r in db.query("SELECT surface, screens, fitted_at FROM boilerplate_fit")}
    surfaces = {surface_of(r["domain"], r["app"]) for r in
                db.query("SELECT DISTINCT domain, app FROM snapshots WHERE captured_at > ?", (time.time() - 7 * 86400,))}
    done = {"refit": 0, "bodies": 0}
    for s in surfaces:
        f = fitted.get(s)
        n_now = len(_contexts(db, s)) if f else None
        if f is None or n_now >= max(MIN_CONTEXTS, f["screens"] * REFIT_GROWTH) or time.time() - f["fitted_at"] > REFIT_AGE_S:
            fit(db, s)
            done["refit"] += 1
            done["bodies"] += _rebody(db, s, only_missing=False)
        else:
            done["bodies"] += _rebody(db, s, only_missing=True)
    if done["refit"]:
        log.info("boilerplate: refit %d surfaces, %d screens re-stripped", done["refit"], done["bodies"])
    return done


def _rebody(db: DB, surface: str, only_missing: bool) -> int:
    chrome = chrome_keys(db, surface)
    if surface.startswith("app:"):
        where, arg = "domain IS NULL AND lower(app) = ?", surface[4:]
    else:
        where, arg = "domain = ?", surface
    if not chrome:  # nothing learned: readers fall back to `content`
        if not only_missing:
            db.execute(f"UPDATE snapshots SET body = NULL WHERE {where}", (arg,))
        return 0
    if only_missing:
        where += " AND body IS NULL"
    rows = db.query(f"SELECT id, content FROM snapshots WHERE {where}", (arg,))
    for r in rows:
        db.execute("UPDATE snapshots SET body = ? WHERE id = ?", (strip(r["content"], chrome), r["id"]))
    return len(rows)
