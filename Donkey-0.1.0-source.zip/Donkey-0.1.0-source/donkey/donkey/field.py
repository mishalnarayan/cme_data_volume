"""Read the focused text field and decide which part of it a rewrite replaces.

UI Automation offsets (as ax.py reports them) count UTF-16 code units; Python strings count code
points. Everything in `Target` is in Python indices except `slice_utf16`, which is what goes back
to ax.
"""
import logging
import re
import time
from dataclasses import dataclass, field

from . import ax

_log = logging.getLogger("donkey.field")

TEXT_ROLES = {"AXTextArea", "AXTextField", "AXComboBox", "AXSearchField"}
# Focusable things that are never text fields (a page, a link, a list…), even if selectable.
NOT_FIELDS = {"AXWebArea", "AXStaticText", "AXButton", "AXLink", "AXImage", "AXMenuItem", "AXMenuButton",
              "AXPopUpButton", "AXCheckBox", "AXRadioButton", "AXRow", "AXCell", "AXList", "AXTable",
              "AXOutline", "AXTabGroup", "AXToolbar", "AXWindow", "AXApplication"}
# Terminals expose the whole scrollback as the field's value; write at the prompt instead.
TERMINAL_BUNDLES = {"windowsterminal.exe", "cmd.exe", "powershell.exe", "pwsh.exe", "conhost.exe",
                    "openconsole.exe", "wezterm-gui.exe", "alacritty.exe", "hyper.exe", "warp.exe",
                    "mintty.exe", "kitty.exe", "tabby.exe", "putty.exe", "ghostty.exe"}
PARAGRAPH_SCOPE_CHARS = 4000  # longer fields without a selection: rewrite only the caret's paragraph
_G_LINE = re.compile(r"(?m)^/g[ \t]+\S")
# Where an email reply's quoted thread, a forward, or a signature starts: below it is read-only.
_QUOTE_START = re.compile(
    r"(?m)^(?:On [^\n]{3,200}(?:\n[^\n]{0,120})?wrote:[ \t]*$"
    r"|-{2,} ?Original Message ?-{2,}"
    r"|-{5,} ?Forwarded message ?-{5,}"
    r"|From: [^\n]+\n(?:Sent|Date): "
    r"|-- $)")


def quote_start(v: str) -> int | None:
    """Index where the quoted thread (or signature) begins, when there is user text above it."""
    m = _QUOTE_START.search(v)
    return m.start() if m and v[:m.start()].strip() else None


class FieldError(Exception):
    """Shown to the user as-is."""


class NoField(FieldError):
    """The key was tapped with no text field focused (the app opens the chat instead)."""


def u16_to_py(s: str, units: int) -> int:
    i = n = 0
    while i < len(s) and n < units:
        n += 2 if ord(s[i]) > 0xFFFF else 1
        i += 1
    return i


def py_to_u16(s: str, i: int) -> int:
    return len(s[:i].encode("utf-16-le")) // 2


def ax_range(value) -> tuple[int, int] | None:
    """(location, length) from ax's AXSelectedTextRange."""
    if not value:
        return None
    try:
        return int(value[0]), int(value[1])
    except (TypeError, ValueError, IndexError):
        return None


@dataclass
class Target:
    app: ax.FrontApp
    element: object = field(repr=False)
    role: str | None = None
    subrole: str | None = None
    label: str | None = None
    window_title: str = ""
    url: str | None = None
    domain: str | None = None
    value: str = ""
    caret: int = 0
    kind: str = "draft"            # selection | draft | paragraph | empty | g
    slice_start: int = 0           # Python indices into value
    slice_end: int = 0
    readable: bool = True          # False: contents unknown, so insert at the cursor
    probe: object = field(default=None, repr=False)

    @property
    def slice_text(self) -> str:
        return self.value[self.slice_start:self.slice_end]

    @property
    def before(self) -> str:
        return self.value[:self.slice_start]

    @property
    def after(self) -> str:
        return self.value[self.slice_end:]

    @property
    def slice_utf16(self) -> tuple[int, int]:
        start = py_to_u16(self.value, self.slice_start)
        return start, py_to_u16(self.value, self.slice_end) - start

    @property
    def single_line(self) -> bool:
        return self.role in ("AXTextField", "AXSearchField", "AXComboBox")

    @property
    def surface_key(self) -> str:
        return f"{self.app.name}|{self.domain or ''}|{self.role or ''}".lower()


def clean_value(el, value: str | None) -> str:
    """The field's text, with a placeholder ("Type a message") reported as the value treated as empty."""
    value = (value or "").replace("\r\n", "\n")
    placeholder = ax.as_text(ax.attr(el, "AXPlaceholderValue"))
    if placeholder and value.strip() == placeholder.strip():
        return ""
    return value


def _label(el) -> str | None:
    for name in ("AXDescription", "AXTitle", "AXPlaceholderValue", "AXHelp"):
        text = ax.as_text(ax.attr(el, name))
        if text and text.strip():
            return text.strip()
    title_el = ax.attr(el, "AXTitleUIElement")
    return ax.as_text(ax.attr(title_el, "AXValue")) if title_el is not None else None


def read_target(app: ax.FrontApp | None = None) -> Target:
    """Read the focused field of `app` (default: the frontmost app)."""
    app = app or ax.front_app()
    if app is None:
        raise NoField("No app has focus.")
    just_enabled = ax.ensure_accessibility(app)
    el = ax.attr(app.element, "AXFocusedUIElement")
    if just_enabled and (el is None or ax.attr(el, "AXRole") not in TEXT_ROLES):
        time.sleep(0.6)  # Chromium/Electron build their accessibility tree after the first request
        el = ax.attr(app.element, "AXFocusedUIElement")
    if el is None:
        _log.info("no field: %s (%s) reports no focused element", app.name, app.bundle_id)
        raise NoField("Click into a text field first.")
    role = ax.as_text(ax.attr(el, "AXRole"))
    subrole = ax.as_text(ax.attr(el, "AXSubrole"))
    if subrole == "AXSecureTextField":
        raise FieldError("That's a password field. Donkey won't touch it.")
    value = ax.as_text(ax.attr(el, "AXValue"))
    settable = ax.value_settable(el)
    if app.bundle_id in TERMINAL_BUNDLES and role == "AXStaticText" and ax.attr(el, "AXSelectedTextRange") is not None:
        role = "AXTextArea"  # Windows Terminal and conhost call their text area "text"; the Mac's call it a text area
    # Anything that takes typing counts, even if the app won't tell us what's in it.
    editable = role not in NOT_FIELDS and (
        role in TEXT_ROLES or settable
        or ax.attr(el, "AXSelectedTextRange") is not None
        or ax.attr(el, "AXInsertionPointLineNumber") is not None)
    if not editable:
        _log.info("no field: %s (%s) focus is %s, settable=%s", app.name, app.bundle_id, ax.describe(el), settable)
        raise NoField("Click into a text field first.")
    readable = value is not None and app.bundle_id not in TERMINAL_BUNDLES
    if not readable:
        value = ""  # unknown contents: write new text and insert it at the cursor
    value = (value or "").replace("\r\n", "\n")
    placeholder = ax.as_text(ax.attr(el, "AXPlaceholderValue"))
    if placeholder and value.strip() == placeholder.strip():
        value = ""  # some composers report their placeholder ("Type a message") as the value

    p = ax.probe(app)
    web = ax.find_web_area(p.window, el) if app.is_browser else None
    url = ax.url_string(ax.attr(web, "AXURL")) if web is not None else None
    t = Target(app=app, element=el, role=role, subrole=subrole, label=_label(el), window_title=p.title,
               url=url, domain=ax.domain_of(url), value=value, readable=readable, probe=p)
    if not readable:
        t.kind = "empty"
        return t

    sel = ax_range(ax.attr(el, "AXSelectedTextRange"))
    sel_start = u16_to_py(value, sel[0]) if sel else len(value)
    sel_end = u16_to_py(value, sel[0] + sel[1]) if sel else len(value)
    t.caret = sel_start
    _choose_slice(t, sel_start, sel_end)
    return t


def _choose_slice(t: Target, sel_start: int, sel_end: int) -> None:
    v = t.value
    if sel_end > sel_start and v[sel_start:sel_end].strip():
        t.kind, t.slice_start, t.slice_end = "selection", sel_start, sel_end
        return
    if not v.strip():
        t.kind, t.slice_start, t.slice_end = "empty", 0, len(v)
        return
    g = list(_G_LINE.finditer(v))
    if g:
        start = g[-1].start()
        end = v.find("\n\n", start)
        t.kind, t.slice_start, t.slice_end = "g", start, len(v) if end < 0 else end
        return
    q = quote_start(v)
    if q is not None:
        t.kind, t.slice_start, t.slice_end = "above_quote", 0, q
        return
    if len(v) > PARAGRAPH_SCOPE_CHARS:
        start = v.rfind("\n\n", 0, t.caret)
        end = v.find("\n\n", t.caret)
        start = 0 if start < 0 else start + 2
        end = len(v) if end < 0 else end
        if v[start:end].strip():
            t.kind, t.slice_start, t.slice_end = "paragraph", start, end
            return
    t.kind, t.slice_start, t.slice_end = "draft", 0, len(v)
