"""Recipient dossier: what memory knows about the person a message is going to, for rewrites.

The recipient is whoever the composer names (sends.surface_of). It is matched to a wiki page
by exact title or alias only: a wrong person is worse than none. The dossier carries that
page's summary and best claims, plus the user's last messages sent to this recipient (how
they write to this person). Nothing here is fetched when the surface is private or blocked.
"""
import json
import re

from .db import DB

MAX_CLAIMS = 8
MAX_SENDS = 6
_PAREN = re.compile(r"\s*\((?:you|online|typing…?|typing\.\.\.)\)\s*$", re.I)


def _norm(s: str) -> str:
    return " ".join(_PAREN.sub("", s or "").lower().split())


def find_page(db: DB, recipient: str | None):
    """The wiki page whose title or alias is exactly this recipient's name."""
    key = _norm(recipient)
    if len(key) < 2 or not re.search(r"[a-z]", key):
        return None  # empty, or a bare phone number: nothing to match on
    best = None
    for p in db.query("SELECT slug, page_type, title, aliases, summary, body_claims, mention_count FROM wiki_pages "
                      "WHERE page_type IN ('person', 'org', 'project') ORDER BY mention_count DESC"):
        names = [p["title"]]
        try:
            names += json.loads(p["aliases"] or "[]")
        except ValueError:
            pass
        if any(_norm(n) == key for n in names if n):
            if p["page_type"] == "person":
                return p
            best = best or p
    return best


def _claims(page) -> list[str]:
    try:
        claims = json.loads(page["body_claims"] or "[]")
    except ValueError:
        return []
    keep = [c for c in claims if isinstance(c, dict) and c.get("worth") != "noise" and c.get("text")]
    keep.sort(key=lambda c: c.get("worth") != "core")  # core first, stable otherwise
    return [c["text"] for c in keep[:MAX_CLAIMS]]


def past_sends(db: DB, recipient: str | None, limit: int = MAX_SENDS) -> list[str]:
    if not recipient:
        return []
    rows = db.query("SELECT text FROM sends WHERE kind = 'sent' AND surface = ? ORDER BY ts DESC LIMIT ?",
                    (recipient, limit))
    return [r["text"] for r in reversed(rows) if r["text"] and r["text"] != "[redacted code]"]


def dossier(db: DB, recipient: str | None) -> str | None:
    """A short block for the prompt, or None when memory has nothing on this recipient."""
    page = find_page(db, recipient)
    sent = past_sends(db, recipient)
    if not page and not sent:
        return None
    lines = []
    if page:
        lines.append(f"Memory page: {page['title']} ({page['page_type']})")
        if page["summary"]:
            lines.append(f"Summary: {page['summary']}")
        lines += [f"- {c}" for c in _claims(page)]
    if sent:
        lines.append("Recent messages the user sent to them (for tone, language and length only):")
        lines += [f"> {' '.join(s.split())[:300]}" for s in sent]
    return "\n".join(lines)
