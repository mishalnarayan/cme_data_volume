"""Capture loop: a cheap probe every tick, a read of the front window when it changed, saved
once it holds still.

Gates, in order: pause → away (locked / screensaver) → idle (unless the front app is playing a
video: then time is credited but nothing is read) → self / system chrome →
blocked app → private window → nothing new to look at. A read is due when the probe changes
(another window, field or text length) and every couple of seconds besides, because a chat
gaining a message or a list scrolling leaves the probe as it was (reads cost a few ms). After
the read: blocked URL/domain/path, near-empty frames, redaction; then a read that differs from
the last one saved waits a tick to hold still (a scroll, typing) and goes to a merging upsert.
Windows read from pixels are only read again when a small picture of them changed.
"""
import ctypes
import json
import logging
import os
import threading
import time
from collections import Counter
from ctypes import wintypes

from . import ax, config, ocr, textmerge, web
from .config import HOME, Config
from .db import DB
from .filters import OWN_LOG, blocked_reason, is_private_window, load_rules, redact, redact_url
from .timeproj import time_title

log = logging.getLogger("donkey.capture")

PAUSE_PATH = HOME / "pause.json"
AWAY_BUNDLES = {"lockapp.exe", "logonui.exe", "scrnsave.scr"}
CHROME_BUNDLES = {  # system UI that is never content
    "searchhost.exe", "searchapp.exe", "searchui.exe", "startmenuexperiencehost.exe",
    "shellexperiencehost.exe", "textinputhost.exe", "shellhost.exe", "widgets.exe",
    "applicationframehost.exe", "taskmgr.exe", "snippingtool.exe", "screenclippinghost.exe",
}
CHROME_CLASSES = {"Shell_TrayWnd", "Shell_SecondaryTrayWnd", "Progman", "WorkerW", "NotifyIconOverflowWindow",
                  "TopLevelWindowForOverflowXamlIsland", "XamlExplorerHostIslandWindow", "Windows.UI.Core.CoreWindow"}
MIN_CONTENT_CHARS = 20
OCR_MIN_GAP_S = 3       # at most one text recognition this often, however fast windows change
WALK_BUDGET = 0.025     # share of time re-reading may take: a slow window is re-read less often
SETTLE_MAX_S = 5        # a window that never holds still (a ticking clock on the page) is saved this often
OCR_MIN_NEW_WORDS = 20  # pixels must add this many words the screen reader didn't give
OCR_SAME_VIEW = 0.5     # word overlap below this with the last read is a new view: a new row
OCR_VIEW_MIN_WORDS = 8  # fewer words where the picture changed is text added to empty space, not a new view
ACTIVE_INPUT_S = 5  # input this recent means the user is at the machine right now
READ_GRACE_S = 180  # reading without touching anything this long after the last input still counts
METER_EVERY_S = 600


# ------------------------------------------------------------------ session state

class _LASTINPUTINFO(ctypes.Structure):
    _fields_ = [("cbSize", wintypes.UINT), ("dwTime", wintypes.DWORD)]


_user32 = ctypes.WinDLL("user32", use_last_error=True)
_kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
_kernel32.GetTickCount64.restype = ctypes.c_uint64
_user32.OpenInputDesktop.restype = wintypes.HANDLE
_user32.GetUserObjectInformationW.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD,
                                              ctypes.POINTER(wintypes.DWORD)]
_user32.CloseDesktop.argtypes = [wintypes.HANDLE]


def idle_seconds() -> float:
    """Seconds since the last keyboard or mouse input anywhere in this session."""
    info = _LASTINPUTINFO(ctypes.sizeof(_LASTINPUTINFO), 0)
    if not _user32.GetLastInputInfo(ctypes.byref(info)):
        return 0.0
    now = _kernel32.GetTickCount64() & 0xFFFFFFFF  # dwTime is a 32-bit tick count
    return ((now - info.dwTime) & 0xFFFFFFFF) / 1000.0


_video_cache: tuple[float, list[tuple[int, str]]] = (0.0, [])


def video_owners(max_age_s: float = 10) -> list[tuple[int, str]]:
    """(pid, exe name) of apps playing sound right now: a video playing keeps an active audio
    session. Cached; asks Windows at most every 10 s."""
    global _video_cache
    at, owners = _video_cache
    if time.monotonic() - at < max_age_s:
        return owners
    owners = []
    try:
        import comtypes
        try:
            comtypes.CoInitializeEx(comtypes.COINIT_MULTITHREADED)
        except OSError:
            pass
        from pycaw.pycaw import AudioUtilities
        for s in AudioUtilities.GetAllSessions():
            try:
                if s.State == 1 and s.ProcessId:  # AudioSessionStateActive
                    owners.append((int(s.ProcessId), (s.Process.name() if s.Process else "").lower()))
            except Exception:
                continue
    except Exception:
        log.debug("couldn't list audio sessions", exc_info=True)
    _video_cache = (time.monotonic(), owners)
    return owners


def playing_video(app) -> bool:
    """Whether the front app is playing a video (its own process or another process of the same app:
    browsers play sound from a helper process)."""
    for pid, name in video_owners():
        if pid == app.pid or (name and name == (app.bundle_id or "")):
            return True
    return False


def screen_locked() -> bool:
    """The lock screen, the sign-in screen or a UAC prompt has the input desktop, or a screensaver runs."""
    desk = _user32.OpenInputDesktop(0, False, 0x0001)  # DESKTOP_READOBJECTS
    if not desk:
        return True  # the secure desktop: locked, or a UAC prompt
    try:
        buf = ctypes.create_unicode_buffer(64)
        need = wintypes.DWORD()
        if _user32.GetUserObjectInformationW(desk, 2, buf, ctypes.sizeof(buf), ctypes.byref(need)):  # UOI_NAME
            if buf.value.lower() != "default":
                return True
    finally:
        _user32.CloseDesktop(desk)
    running = wintypes.BOOL()
    if _user32.SystemParametersInfoW(0x0072, 0, ctypes.byref(running), 0) and running.value:  # SPI_GETSCREENSAVERRUNNING
        return True
    return False

def pause(minutes: float | None) -> None:
    """Pause capture for `minutes`, or until resume() when None."""
    HOME.mkdir(parents=True, exist_ok=True)
    until = time.time() + minutes * 60 if minutes else None
    PAUSE_PATH.write_text(json.dumps({"until": until}))


def resume() -> None:
    PAUSE_PATH.unlink(missing_ok=True)


def paused_until() -> float | None:
    """Epoch the pause ends, float('inf') for until-resume, None when not paused."""
    try:
        until = json.loads(PAUSE_PATH.read_text()).get("until")
    except (FileNotFoundError, ValueError):
        return None
    if until is None:
        return float("inf")
    if until <= time.time():
        resume()
        return None
    return until


# ------------------------------------------------------------------ the loop

class Meter:
    """Counts outcomes and timings; logs a summary every 10 minutes. ocr_ms: one text recognition;
    pic_wait_ms: a window's picture first changing to its text being read; save_lag_ms: a read first
    differing from what was saved to it being saved (time held back to let it settle)."""

    def __init__(self):
        self.outcomes: Counter = Counter()
        self.walk_ms: list[int] = []
        self.thumb_ms: list[int] = []
        self.ocr_ms: list[int] = []
        self.pic_wait_ms: list[int] = []
        self.save_lag_ms: list[int] = []
        self.since = time.monotonic()

    def maybe_report(self) -> None:
        if time.monotonic() - self.since < METER_EVERY_S:
            return
        ms = sorted(self.walk_ms)
        p50 = ms[len(ms) // 2] if ms else 0
        p95 = ms[int(len(ms) * 0.95)] if ms else 0
        summary = " ".join(f"{k}={v}" for k, v in self.outcomes.most_common())
        thumbs = sorted(self.thumb_ms)
        extra = "".join(f" {name} p50={v[len(v) // 2]} p95={v[int(len(v) * 0.95)]} n={len(v)}"
                        for name, v in (("ocr_ms", sorted(self.ocr_ms)), ("pic_wait_ms", sorted(self.pic_wait_ms)),
                                        ("save_lag_ms", sorted(self.save_lag_ms))) if v)
        log.info("meter: %s walk_ms p50=%d p95=%d%s%s", summary, p50, p95,
                 f" thumb_ms p50={thumbs[len(thumbs) // 2]} n={len(thumbs)}" if thumbs else "", extra)
        self.__init__()


class Capturer:
    def __init__(self, cfg: Config, db: DB):
        self.cfg = cfg
        self.db = db
        self.rules = load_rules(cfg.blocked_apps, cfg.blocked_domains)
        self.rules_mtime = self._config_mtime()
        self.rules_checked_at = time.monotonic()
        self.meter = Meter()
        self.last_key = None
        self.last_walk_at = 0.0
        self.last_tick_at = None
        self.surface: tuple[str, str | None, str | None] | None = None  # (app, domain, title) being credited
        self.surface_key = None
        self.pending: list[tuple[float, str, str | None, str | None, float]] = []  # uncommitted time credits
        self.last_ocr_at = 0.0
        self.last_ocr_words: set[str] = set()
        self.recheck_s = cfg.recheck_every_s
        self.saved_digest, self.saved_at = None, 0.0  # the last read written, and when
        self.read_digest = None                       # the last read, saved or not
        self.changed_at = None                        # first read since the last save that differed from it
        self.held: dict | None = None                 # reads not saved yet (still moving), merged: a scroll's middle counts
        self.unsettled = False                        # last read was still changing: look again next tick
        self.last_thumb: bytes | None = None          # pixel windows: the picture at the last tick...
        self.ocr_view = self.ocr_thumb = self.ocr_text = None  # ...and at the last text recognition
        self.ocr_boxes: list = []
        self.new_view: bool | None = None             # the last recognition saw a different screen under the same title
        self.laid_for, self.laid_convo = None, None   # the page text last laid out from its picture, and the result
        self.moving_since = None                      # pixels changing every look since then
        self.pic_changed_at = None                    # picture first changed since the last recognition
        self.pixels_at = 0.0                          # last look at the picture
        if cfg.ocr and ocr.permitted():
            ocr.LANGUAGES = cfg.ocr_languages
            ocr.warm()

    def run(self, stop: threading.Event) -> None:
        log.info("capture loop started (probe every %.1fs, re-read every %.1fs, unchanged saved every %ss)",
                 self.cfg.probe_interval_s, self.cfg.recheck_every_s, self.cfg.walk_every_s)
        while not stop.is_set():
            started = time.monotonic()
            try:
                outcome = self.tick()
            except Exception:
                log.exception("capture tick failed")
                outcome = "error"
            self.meter.outcomes[outcome] += 1
            self.meter.maybe_report()
            stop.wait(max(0.0, self.cfg.probe_interval_s - (time.monotonic() - started)))
        try:
            self._save_held()
        except Exception:
            log.exception("saving the last read failed")
        self._trim_and_flush(time.time() - idle_seconds())
        log.info("capture loop stopped")

    @staticmethod
    def _config_mtime() -> float:
        try:
            return config.CONFIG_PATH.stat().st_mtime
        except OSError:
            return 0.0

    def _reload_rules(self) -> None:
        """Pick up ignore rules added to config.json (by hand or `donkey ignore add`) without a restart."""
        if time.monotonic() - self.rules_checked_at < 5:
            return
        self.rules_checked_at = time.monotonic()
        mtime = self._config_mtime()
        if mtime == self.rules_mtime:
            return
        self.rules_mtime = mtime
        try:
            fresh = config.load()
        except Exception:
            log.exception("config.json unreadable; keeping the current ignore rules")
            return
        self.cfg.blocked_apps, self.cfg.blocked_domains = fresh.blocked_apps, fresh.blocked_domains
        self.rules = load_rules(fresh.blocked_apps, fresh.blocked_domains)
        log.info("ignore rules reloaded from config.json")

    def tick(self) -> str:
        now = time.time()
        # Gaps longer than a few ticks (sleep, a stalled UI Automation call) are not foreground time.
        elapsed = min(now - self.last_tick_at, self.cfg.probe_interval_s * 3) if self.last_tick_at else 0.0
        self.last_tick_at = now

        if paused_until():
            return self._away("paused", now)
        if screen_locked():
            return self._away("away_skip", now)
        idle = idle_seconds()
        watching = False
        if idle > self.cfg.idle_after_s:
            front = ax.front_app()
            watching = front is not None and front.pid != os.getpid() and playing_video(front)
            if not watching:
                return self._away("idle_skip", now, last_input_at=now - idle)
            if self.surface is not None:
                # Watching, not away: the time counts, but the screen isn't read again (nothing to learn
                # from a video page re-read every 20 s).
                self._credit(*self.surface, elapsed, now, 0.0)
                return "watching"
            # Not read yet (just started, or back from away): one normal read below learns the page.

        app = ax.front_app()
        if app is None:
            return "no_app"
        if app.bundle_id in AWAY_BUNDLES:
            return self._away("away_skip", now)
        if app.pid == os.getpid() or app.bundle_id in CHROME_BUNDLES or (
                isinstance(app.element, ax.AppEl) and ax.class_name(app.element.hwnd) in CHROME_CLASSES):
            return "self_skip"
        ax.ensure_accessibility(app)
        p = ax.probe(app)

        # Time credit goes to the surface we last read for this window (domain known only after a read).
        if self.surface_key != (app.pid, p.title):
            self.surface, self.surface_key = (app.name, None, None), (app.pid, p.title)
        self._credit(*self.surface, elapsed, now, idle)

        if not self.cfg.capture_enabled:
            return "disabled"
        self._reload_rules()
        reason = blocked_reason(self.rules, app.name, None, p.title)
        if reason:
            return "blocked"
        if is_private_window(p.title):
            return "private_skip"
        if p.key == self.last_key and not self.unsettled and now - self.last_walk_at < self.recheck_s:
            return "probe_skip"

        read_from = time.monotonic()
        frame = ax.read_frame(app, p, max_chars=self.cfg.max_chars)
        if p.key != self.last_key:
            self.read_digest = None
        self.last_key, self.last_walk_at, self.unsettled = p.key, now, False
        self.recheck_s = max(self.cfg.recheck_every_s, frame.walk_ms / 1000 / WALK_BUDGET)
        self.meter.walk_ms.append(frame.walk_ms)
        if frame.exhausted:
            log.debug("walk budget exhausted: %s (%d nodes, %d ms)", app.name, frame.nodes, frame.walk_ms)

        reason = blocked_reason(self.rules, frame.app, frame.url, frame.window_title)
        if reason:
            log.debug("blocked %s (%s)", frame.app, reason)
            self.surface = (frame.app, None, None)
            return "blocked"
        t = time_title(frame.window_title)
        self.surface = (frame.app, frame.domain, redact(t) if self.cfg.redact else t)
        content, title, url = frame.content, frame.window_title, frame.url
        coalesce, outcome = self.cfg.coalesce_window_s, "walk"
        if self.cfg.ocr and len(content.strip()) < self.cfg.ocr_below_chars:
            pixels, state = self._pixels(frame, now)
            if state in ("moving", "blank"):
                return state
            if pixels:
                content, outcome = f"{content.strip()}\n\n{ocr.NOTE}\n{pixels}".strip(), "ocr" if state == "read" else "walk"
            if pixels and state == "read":
                # A remote desktop keeps one title all day: a different screen under it gets its own
                # row instead of being folded into the last one.
                seen = ocr.words(pixels)
                if self.new_view if self.new_view is not None else \
                        len(seen & self.last_ocr_words) < OCR_SAME_VIEW * max(1, len(seen)):
                    coalesce = 0
                self.last_ocr_words = seen
        content = OWN_LOG.sub("", content)
        if len(content.strip()) < MIN_CONTENT_CHARS:
            return "empty"

        extra = frame.domain == "web.whatsapp.com"  # its transcript is a second walk
        try:  # who said what, where the app tells us (the page text alone doesn't)
            convo = web.labelled_conversation(p.window, frame.domain)
            extra = extra or convo is not None
            if convo is None and ocr.NOTE not in content and ocr.permitted() and web.looks_like_conversation(content):
                seen = hash((frame.app, frame.window_title, frame.url, content))
                if seen != self.laid_for:  # a second walk and a window shot only when the page's text changed
                    extra = True
                    root = ax.find_web_area(p.window, p.focused) if frame.domain else p.window
                    self.laid_convo = web.layout_conversation(p.window, root or p.window, frame.pid, frame.window_title)
                    self.laid_for = seen
                convo = self.laid_convo
        except Exception:
            log.debug("conversation labelling failed", exc_info=True)
            convo = None
        if convo:
            content = f"{content}\n\n{convo}"
        if extra:  # re-read at the slower pace this read's extra work allows
            self.recheck_s = max(self.recheck_s, (time.monotonic() - read_from) / WALK_BUDGET)
        if self.cfg.redact:
            content, title = redact(content), redact(title)
            url = redact_url(url) if url else url
        snap = {"app": frame.app, "bundle_id": frame.bundle_id, "window_title": title, "url": url,
                "domain": frame.domain, "content": content, "focused_role": frame.focused_role, "captured_at": now}
        view = (frame.app, title, url)
        if self.held and self.held["view"] != view:
            self._save_held()  # moved on before it held still: what was seen is still saved
        digest = hash((view, content))
        recent = now - self.saved_at < self.cfg.walk_every_s
        if digest == self.saved_digest and recent:
            self.read_digest = digest
            return "same"
        self.changed_at = self.changed_at or now
        if digest != self.read_digest and coalesce and now - self.changed_at < SETTLE_MAX_S:
            # Changed since the last look: saved once it holds still, so a scroll or a burst of
            # typing is one write where it stopped. The reads on the way are kept, merged.
            self.read_digest, self.unsettled = digest, True
            if self.held:
                merged = textmerge.merge(self.held["snap"]["content"], content, self.cfg.max_chars)
                snap["content"] = content if merged is None else merged
            self.held = {"view": view, "snap": snap, "coalesce": coalesce}
            return "settling"
        if self.held:
            merged = textmerge.merge(self.held["snap"]["content"], content, self.cfg.max_chars)
            snap["content"] = content if merged is None else merged
        self.held = None
        self.saved_digest, self.read_digest = digest, digest
        self._save(snap, coalesce)
        return outcome

    def _save(self, snap: dict, coalesce: float) -> None:
        if self.changed_at:
            self.meter.save_lag_ms.append(int((snap["captured_at"] - self.changed_at) * 1000))
        self.saved_at, self.changed_at = snap["captured_at"], None
        snap_id = self.db.upsert_snapshot(snap, coalesce, self.cfg.max_chars)
        log.debug("snapshot %d: %s | %s | %d chars", snap_id, snap["app"], snap["window_title"][:60], len(snap["content"]))

    def _save_held(self) -> None:
        held, self.held = self.held, None
        if held:
            self.saved_digest = None
            self._save(held["snap"], held["coalesce"])

    def _pixels(self, frame, now: float) -> tuple[str | None, str]:
        """Text from the window's pixels, and how it was had: "read" (recognised now), "reuse" (the
        picture hasn't changed since the last recognition), "moving" (still changing: look again
        next tick), "blank" (one flat colour: nothing to read) or "none"."""
        if not ocr.permitted():
            return None, "none"
        t0 = time.monotonic()
        try:
            thumb = ocr.thumbnail(frame.pid, frame.window_title)
        except Exception:
            log.debug("thumbnail failed", exc_info=True)
            thumb = None
        self.meter.thumb_ms.append(int((time.monotonic() - t0) * 1000))
        if thumb is None:  # no picture to compare: recognise at the old, slower pace
            if now - self.last_ocr_at < 10:
                return None, "none"
            self.new_view, self.ocr_view = None, None  # boxes without a picture: nothing to compare next time
            return self._ocr(frame), "read"
        prev, self.last_thumb = self.last_thumb, thumb
        if now - self.pixels_at > 3 * self.cfg.probe_interval_s:
            self.pic_changed_at = None  # not watching in between (another app, away): no wait to count
        self.pixels_at = now
        if ocr.blank(thumb):
            return None, "blank"
        view = (frame.pid, frame.window_title)
        if self.ocr_view == view and self.ocr_thumb is not None and not ocr.changed(thumb, self.ocr_thumb):
            return self.ocr_text, "reuse"
        moving = prev is not None and ocr.changed(thumb, prev)
        self.moving_since = (self.moving_since or now) if moving else None
        if moving or prev is None or self.ocr_view != view:
            self.pic_changed_at = self.pic_changed_at or now
        # A picture that never holds still (a video, a spinner) is still read every few seconds.
        if (moving and now - self.moving_since < SETTLE_MAX_S) or now - self.last_ocr_at < OCR_MIN_GAP_S:
            self.unsettled = True
            return None, "moving"
        self.moving_since = None
        old_boxes = self.ocr_boxes if self.ocr_view == view else []
        self.meter.pic_wait_ms.append(int((now - (self.pic_changed_at or now)) * 1000))
        self.pic_changed_at = None
        text = self._ocr(frame)
        self.new_view = self._new_view(old_boxes, self.ocr_thumb if old_boxes else None, thumb)
        self.ocr_view, self.ocr_thumb, self.ocr_text = view, thumb, text
        return text, "read"

    def _new_view(self, old_boxes: list, old_thumb: bytes | None, thumb: bytes) -> bool | None:
        """Another chat or document under the same title: where the picture changed, the words are
        not the ones that were there. Fixed parts (a contact list, a toolbar) don't count, and a
        scroll keeps most of its words. None when there is no earlier recognition to compare."""
        if old_thumb is None or not self.ocr_boxes:
            return None
        cells = ocr.changed_cells(old_thumb, thumb)
        before, after = ocr.words_in(old_boxes, cells), ocr.words_in(self.ocr_boxes, cells)
        if len(before) < OCR_VIEW_MIN_WORDS or not after:
            return False  # text added to empty space, or cleared: the same view
        return len(before & after) < OCR_SAME_VIEW * min(len(before), len(after))

    def _ocr(self, frame) -> str | None:
        """Text read from the window's pixels when it adds real words to what the screen reader gave."""
        self.last_ocr_at = time.time()
        t0 = time.monotonic()
        try:
            self.ocr_boxes, image = ocr.read_boxes(frame.pid, frame.window_title)
            text = ocr.layout(self.ocr_boxes, image)
            self.meter.ocr_ms.append(int((time.monotonic() - t0) * 1000))
        except Exception:
            log.debug("screen reading failed", exc_info=True)
            self.ocr_boxes = []
            return None
        if not text or len(ocr.words(text) - ocr.words(frame.content)) < OCR_MIN_NEW_WORDS:
            return None
        return text[: self.cfg.max_chars]

    # -------------------------------------------------------------- time credit

    def _away(self, outcome: str, now: float, last_input_at: float | None = None) -> str:
        """Leaving the machine: forget the probe, and drop time credited after the last input."""
        self.last_key = None
        self.surface_key = None
        self.unsettled, self.last_thumb = False, None
        self._save_held()
        self._trim_and_flush(last_input_at if last_input_at is not None else now)
        return outcome

    def _credit(self, app: str, domain: str | None, title: str | None, seconds: float, now: float, idle: float) -> None:
        if seconds > 0:
            self.pending.append((now, app, domain, title, seconds))
        if idle < ACTIVE_INPUT_S:
            self._flush()

    def _trim_and_flush(self, last_input_at: float) -> None:
        """Walk-away tail trim: credits more than READ_GRACE_S after the last keyboard/mouse input never happened."""
        self.pending = [c for c in self.pending if c[0] <= last_input_at + READ_GRACE_S]
        self._flush()

    def _flush(self) -> None:
        if not self.pending:
            return
        groups: dict[tuple, list] = {}
        for at, app, domain, title, secs in self.pending:
            key = (time.strftime("%Y-%m-%dT%H", time.localtime(at)), app, domain, title)
            g = groups.setdefault(key, [at, 0.0])
            g[1] += secs
        for (_, app, domain, title), (at, secs) in groups.items():
            self.db.credit_time(app, domain, secs, at, title)
        self.pending.clear()
