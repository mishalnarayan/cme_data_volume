"""Memory scheduler: runs the chronicle, wiki, embedding and digest jobs in order.

Each pass is idempotent (jobs are keyed by period and skipped once done), so it can run on a
timer, at startup, or by hand with `donkey memory`.
"""
import datetime as dt
import logging
import threading
import time

from . import attention, boilerplate, chronicle, claims, config, daypage, embed, facts, forget, learn, lessons, llm, loops, nudges, profile, tidy, timeproj, wiki
from .config import Config
from .db import DB

log = logging.getLogger("donkey.memory")

INTERVAL_S = 300
HOURS_PER_PASS = 6      # spread a 24-hour backfill over a few passes
BACKOFF_S = 1800        # after an API failure
MAX_TRIES = 3           # botched replies for one job before it's left alone (see _job)

_busy = threading.Lock()  # one pass at a time: the timer's or the user's Update
on_busy = None            # called with True/False as a pass starts and ends (the journal greys its Update button)


def _hold(blocking: bool) -> bool:
    if not _busy.acquire(blocking=blocking):
        return False
    if on_busy:
        on_busy(True)
    return True


def _release() -> None:
    _busy.release()
    if on_busy:
        on_busy(False)


_failures: dict[str, int] = {}  # job key -> botched replies in a row, while the app runs


def _botched(e: llm.LLMError) -> bool:
    """A reply cut off, malformed or declined: a problem with this job's input, not an outage."""
    return any(s in str(e) for s in ("cut off", "too long", "structured output", "declined"))


def _gave_up(key: str) -> bool:
    return _failures.get(key, 0) >= MAX_TRIES


def _job(key: str, fn, *args) -> bool:
    """Run one job; True when it ran. A botched reply skips only this job, so the rest of the pass
    still runs, and after MAX_TRIES in a row the key is left alone until the app restarts (keys of
    jobs without their own period carry the hour, so those are tried again next hour). An outage
    (no key, no credits, no connection, rate limit) still raises: the whole pass backs off."""
    if _gave_up(key):
        return False
    try:
        fn(*args)
    except llm.LLMError as e:
        if not _botched(e):
            raise
        _failures[key] = _failures.get(key, 0) + 1
        log.warning("%s failed (%d/%d), going on with the rest: %s", key, _failures[key], MAX_TRIES, e)
        return False
    _failures.pop(key, None)
    return True


def run_pass(cfg: Config, db: DB, hours_limit: int = HOURS_PER_PASS) -> dict:
    """One pass over all pending work. Returns counts per job."""
    done = {"hours": 0, "days": 0, "weeks": 0, "wiki": 0, "embedded": 0, "digest": 0}
    now = time.time()
    today = dt.date.today()
    try:  # history matching an ignore rule added since the last pass (config read fresh: rules change while running)
        done.update({f"forgot_{k}": v for k, v in forget.apply_new_rules(config.load(), db).items()})
    except Exception:
        log.exception("forgetting ignored history failed")
    try:
        boilerplate.refresh(db)  # strip learned page chrome before screens go to the model
    except Exception:
        log.exception("boilerplate refresh failed")
    try:
        done["paired"] = learn.pair_sends(db)
        done["survival"] = learn.check_survival(db)
        learn.count_outcomes(db)
    except Exception:
        log.exception("send pairing failed")
    if llm.has_credentials():
        hour = chronicle.hour_key(now)
        for key in [k for k in chronicle.pending_hours(db, now) if not _gave_up(f"hour {k}")][:hours_limit]:
            done["hours"] += _job(f"hour {key}", chronicle.process_hour, cfg, db, key)
        try:
            done["claims"] = claims.run_pass(cfg, db)
        except llm.LLMError as e:
            log.warning("claims ledger failed: %s", e)
        for day in chronicle.pending_days(db, today):
            done["days"] += _job(f"day {day}", chronicle.process_day, cfg, db, day)
        for week in chronicle.pending_weeks(db, today):
            done["weeks"] += _job(f"week {week}", chronicle.process_week, cfg, db, week)
        for month in chronicle.pending_months(db, today):
            done["months"] = done.get("months", 0) + _job(f"month {month}", chronicle.process_month, cfg, db, month)
        for year in chronicle.pending_years(db, today):
            done["years"] = done.get("years", 0) + _job(f"year {year}", chronicle.process_year, cfg, db, year)
        for day in daypage.pending(db, today):
            done["day_pages"] = done.get("day_pages", 0) + _job(f"day page {day}", daypage.get, cfg, db, day)
        try:
            done["retries"] = lessons.learn_from_retries(cfg, db)
            done["rules"] = learn.mine_rules(cfg, db)
            done["rules_off"] = learn.resolve_conflicts(cfg, db)
        except llm.LLMError as e:
            log.warning("style rule mining failed: %s", e)
        try:
            done["time_rules"] = timeproj.propose_rules(cfg, db)
            done["projects_curated"] = sum(timeproj.curate(cfg, db).values())
        except llm.LLMError as e:
            log.warning("time rules failed: %s", e)
        try:
            done["facts"] = facts.distill(cfg, db)
        except llm.LLMError as e:
            log.warning("chat facts failed: %s", e)
        try:
            done["observed"] = learn.observe_style(cfg, db)
            done["consolidated"] = learn.consolidate(cfg, db)
            learn.resolve_conflicts(cfg, db)  # merged rules are checked in their new scopes
        except llm.LLMError as e:
            log.warning("observed style failed: %s", e)
        try:
            done["profile"] = int(profile.refresh(cfg, db) is not None)
        except llm.LLMError as e:
            log.warning("profile refresh failed: %s", e)
        try:
            done["tidied"] = tidy.run(cfg, db)["pages"]
        except llm.LLMError as e:
            log.warning("wiki tidy failed: %s", e)
        done["wiki"] = wiki.regenerate_dirty(cfg, db)
        wiki.prune_stale(db)
        wiki.refresh_salience(db)
        def digest():
            done["digest"] = int(chronicle.refresh_digest(cfg, db))
        _job(f"digest {hour}", digest)
        # Mail and to-dos are memory, kept whether or not nudges (the messages) are on.
        attention.process_queue(cfg, db)  # its own per-screen tries
        if loops.needs_run(db):
            _job(f"to-dos {hour}", loops.run_tracker, cfg, db)
        _job(f"nudges {hour}", nudges.run_pass, cfg, db)
    else:
        log.info("no Anthropic API key: skipping summaries and wiki (embeddings still run)")
    try:
        done["embedded"] = embed.sync(db)
    except Exception:
        log.exception("embedding sync failed")
    return done


def update_now(cfg: Config, db: DB) -> dict | None:
    """The user's Update: everything a timed pass does, now, including the hour still running and the
    one that just ended (each written up again once it has settled). None when a pass is already running."""
    if not _hold(False):
        return None
    try:
        if llm.has_credentials():
            now = time.time()
            for key in chronicle.pending_hours(db, now + chronicle.SETTLE_S)[-1:] + [chronicle.hour_key(now)]:
                _job(f"hour {key} so far", chronicle.process_hour, cfg, db, key)
        return run_pass(cfg, db)
    finally:
        _release()


class Scheduler:
    def __init__(self, cfg: Config, db: DB):
        self.cfg, self.db = cfg, db

    def run(self, stop: threading.Event) -> None:
        log.info("memory scheduler started (every %d s)", INTERVAL_S)
        embed.prewarm(self.db)  # model ready before the first pass, search, or map open
        stop.wait(60)  # let capture settle first
        while not stop.is_set():
            wait = INTERVAL_S
            _hold(True)
            try:
                done = run_pass(self.cfg, self.db)
                if any(done.values()):
                    log.info("memory pass: %s", " ".join(f"{k}={v}" for k, v in done.items() if v))
                if done["hours"] == HOURS_PER_PASS:
                    wait = 30  # more backfill waiting
            except llm.LLMError as e:
                log.warning("memory pass stopped: %s; retrying in %d min", e, BACKOFF_S // 60)
                wait = BACKOFF_S
            except Exception:
                log.exception("memory pass failed")
            finally:
                _release()
            stop.wait(wait)


def redact_backfill(db: DB) -> int:
    """Re-mask everything already stored with the current redaction rules (e.g. new one-time-code rules)."""
    from .filters import redact
    targets = [("snapshots", "id", ["content", "window_title"]), ("flags", "id", ["text"]),
               ("open_loops", "id", ["summary", "evidence", "close_evidence"]), ("todos", "id", ["text"]),
               ("wiki_mentions", "id", ["note"]), ("chronicle", "id", ["summary"]), ("nudges", "id", ["title", "body"])]
    changed = 0
    for table, key, cols in targets:
        for row in db.query(f"SELECT {key}, {', '.join(cols)} FROM {table}"):
            new = {c: redact(row[c]) for c in cols if isinstance(row[c], str)}
            diff = {c: v for c, v in new.items() if v != row[c]}
            if diff:
                db.execute(f"UPDATE {table} SET {', '.join(f'{c} = ?' for c in diff)} WHERE {key} = ?",
                           (*diff.values(), row[key]))
                changed += 1
    digest = chronicle.DIGEST_PATH
    if digest.exists():
        from .filters import redact as r
        digest.write_text(r(digest.read_text()))
    log.info("redact backfill: %d rows re-masked", changed)
    return changed


def rebuild_graph(cfg: Config, db: DB, hours: int = 24) -> dict:
    """Re-extract the knowledge graph from the screens already captured (last `hours`), with the
    current extraction and claim rules. Snapshots are kept; only derived pages and summaries are redone.
    Mentions older than the window stay (they can't be re-summarized), but their pages are rewritten."""
    if not llm.has_credentials():
        raise RuntimeError("rebuilding the graph needs LLM credentials; nothing was changed")
    hours = min(hours, chronicle.BACKFILL_HOURS)  # pending_hours never looks further back
    masked = redact_backfill(db)
    cutoff = time.strftime("%Y-%m-%dT%H", time.localtime(time.time() - hours * 3600))
    db.execute("DELETE FROM embeddings WHERE kind = 'wiki'")
    db.execute("DELETE FROM wiki_mentions WHERE hour_key >= ?", (cutoff,))
    db.execute("DELETE FROM wiki_pages WHERE pinned = 0 AND slug NOT IN (SELECT slug FROM wiki_mentions)")
    db.execute("""UPDATE wiki_pages SET body = '', body_claims = '[]', links = '[]', related_links = '[]', is_dirty = 1, regen_failures = 0,
                  mention_count = (SELECT COUNT(*) FROM wiki_mentions m WHERE m.slug = wiki_pages.slug)
                  WHERE pinned = 0""")
    db.execute("DELETE FROM flags WHERE hour_key >= ?", (cutoff,))
    db.execute("DELETE FROM chronicle WHERE period = 'hour' AND period_key >= ?", (cutoff,))
    db.execute("DELETE FROM chronicle WHERE period IN ('day', 'week', 'month', 'year') AND created_at >= ?",
               (time.time() - hours * 3600,))
    log.info("knowledge graph cleared; re-extracting the last %d hours", hours)
    done = run_pass(cfg, db, hours_limit=hours)
    while wiki.regenerate_dirty(cfg, db):
        pass  # every dirty page, not just one pass's worth
    embed.sync(db)
    chronicle.refresh_digest(cfg, db, force=True)
    done["masked_rows"] = masked
    return done
