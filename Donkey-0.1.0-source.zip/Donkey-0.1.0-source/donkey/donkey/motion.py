"""Movement with some life in it: windows fade in and out, and the creature you drag keeps its
momentum when you let go, then settles with a little overshoot. Main thread only.

Works on any window with the winui.Panel frame API: origin(), move_to(x, y), frame(),
set_frame(x, y, w, h), alpha(), set_alpha(a). Coordinates are top-left, logical pixels.
"""
import math
import time

from PySide6.QtCore import Qt, QTimer

FRAME_MS = 8              # ~120 Hz
VELOCITY_WINDOW_S = 0.08  # the pointer's speed over its last moves, not the whole drag
PROJECT_S = 0.1           # how far a throw carries: its speed times this
MAX_SPEED = 4000.0        # pixels per second; a flick beyond this is a twitch, not a throw


class Velocity:
    """The pointer's speed from its recent positions, in pixels per second."""

    def __init__(self):
        self.samples: list[tuple[float, float, float]] = []

    def add(self, x: float, y: float) -> None:
        now = time.monotonic()
        self.samples.append((now, x, y))
        self.samples = [s for s in self.samples if now - s[0] <= VELOCITY_WINDOW_S]

    def get(self) -> tuple[float, float]:
        if len(self.samples) < 2 or time.monotonic() - self.samples[-1][0] > VELOCITY_WINDOW_S:
            return 0.0, 0.0  # held still before letting go: no throw
        (t0, x0, y0), (t1, x1, y1) = self.samples[0], self.samples[-1]
        dt = max(t1 - t0, 1e-3)
        vx, vy = (x1 - x0) / dt, (y1 - y0) / dt
        speed = math.hypot(vx, vy)
        if speed > MAX_SPEED:
            vx, vy = vx * MAX_SPEED / speed, vy * MAX_SPEED / speed
        return vx, vy

    def clear(self) -> None:
        self.samples = []


def project(x: float, y: float, vx: float, vy: float) -> tuple[float, float]:
    """Where a throw from (x, y) at this speed comes to rest."""
    return x + vx * PROJECT_S, y + vy * PROJECT_S


def _timer(step) -> QTimer:
    t = QTimer()
    t.setTimerType(Qt.PreciseTimer)
    t.setInterval(FRAME_MS)
    t.timeout.connect(step)
    return t


class Spring:
    """Moves a window's origin to a point, starting at a given speed: a damped spring, so a throw
    carries on and a short move overshoots a touch before resting. `on_step(x, y, vx, vy)` runs every
    frame; `on_done()` once it rests. A new `to` takes over from wherever the window is, at its speed."""

    def __init__(self, window, on_step=None, on_done=None):
        self.window = window
        self.on_step, self.on_done = on_step, on_done
        self.timer = _timer(self._step)
        self.pos = self.vel = self.target = (0.0, 0.0)
        self.k = self.c = 0.0
        self.last = 0.0

    @property
    def running(self) -> bool:
        return self.timer.isActive()

    def to(self, x: float, y: float, vx: float = 0.0, vy: float = 0.0, response: float = 0.42,
           damping: float = 0.78, on_done=None) -> None:
        """`response`: seconds for one swing; `damping`: 1 never overshoots, lower bounces more."""
        self.pos = self.window.origin()
        if not self.running:
            self.vel = (vx, vy)
        self.target = (x, y)
        self.k = (2 * math.pi / response) ** 2
        self.c = 4 * math.pi * damping / response
        if on_done is not None:
            self.on_done = on_done
        self.last = time.monotonic()
        if not self.running:
            self.timer.start()

    def stop(self) -> None:
        self.timer.stop()
        self.vel = (0.0, 0.0)

    def _step(self) -> None:
        now = time.monotonic()
        dt, self.last = min(now - self.last, 1 / 30), now
        (x, y), (vx, vy), (tx, ty) = self.pos, self.vel, self.target
        steps = max(1, int(dt / (1 / 240)))  # small steps keep a stiff spring stable
        h = dt / steps
        for _ in range(steps):
            vx += (-self.k * (x - tx) - self.c * vx) * h
            vy += (-self.k * (y - ty) - self.c * vy) * h
            x, y = x + vx * h, y + vy * h
        self.pos, self.vel = (x, y), (vx, vy)
        resting = math.hypot(x - tx, y - ty) < 0.4 and math.hypot(vx, vy) < 8
        if resting:
            x, y = tx, ty
        self.window.move_to(x, y)
        if self.on_step:
            self.on_step(x, y, 0.0 if resting else vx, 0.0 if resting else vy)
        if resting:
            self.stop()
            done, self.on_done = self.on_done, None
            if done:
                done()


class Tween:
    """Eases a window's opacity and/or frame to new values over `duration`, then calls `then`.
    A new run takes over from where the last one got to."""

    def __init__(self, window):
        self.window = window
        self.timer = _timer(self._step)
        self.then = None
        self.ease = "out"

    def run(self, alpha: float | None = None, frame=None, duration: float = 0.18, then=None, ease: str = "out") -> None:
        """`frame` is (x, y, w, h). `ease`: "out" starts quick and stops gently; "inout" also builds
        up speed, like a run."""
        self.stop()
        self.ease = ease
        self.a0, self.a1 = self.window.alpha(), alpha
        self.f0 = self.window.frame()
        self.f1 = None if frame is None else tuple(float(v) for v in frame)
        self.t0, self.duration, self.then = time.monotonic(), max(duration, 1e-3), then
        self.timer.start()
        self._step()

    def stop(self) -> None:
        self.timer.stop()

    def _step(self) -> None:
        t = min(1.0, (time.monotonic() - self.t0) / self.duration)
        e = (1 - math.cos(math.pi * t)) / 2 if self.ease == "inout" else 1 - (1 - t) ** 3
        if self.a1 is not None:
            self.window.set_alpha(self.a0 + (self.a1 - self.a0) * e)
        if self.f1 is not None:
            x, y, w, h = (a + (b - a) * e for a, b in zip(self.f0, self.f1))
            self.window.set_frame(x, y, w, h)
        if t >= 1:
            self.stop()
            then, self.then = self.then, None
            if then:
                then()
