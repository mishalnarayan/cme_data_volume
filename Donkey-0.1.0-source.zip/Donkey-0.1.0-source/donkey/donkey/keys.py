"""The Donkey key: a bare modifier, tapped on its own.

A bare modifier can't be a normal global hotkey. Key state comes from low-level keyboard and mouse
hooks on their own thread (they see every press, and pass each one straight on); if the hooks
can't be set, key state is polled. Either way a 16 ms loop does the timing. A press counts as a
tap only if it is released within HOLD_S and nothing else was pressed meanwhile, so Ctrl+C with
the Donkey key as Ctrl never triggers a rewrite.

Two Windows quirks: AltGr (right Alt on many keyboards) also sends a fake left Ctrl; and tapping
Alt or the Windows key alone makes the app react (a menu, Start, or in Chrome the focus jumping to
the ⋮ button, out of the field Donkey is about to read). So when the Donkey key is one of those, the
hook holds its press back from apps: a tap never reaches them. If another key or a click comes
while it's held (a shortcut, an AltGr character), the hook hands the press on first, then that key,
so shortcuts work as usual.
"""
import ctypes
import logging
import threading
import time
from ctypes import wintypes

log = logging.getLogger("donkey.keys")

POLL_S = 0.016
HOLD_S = 0.45
DOUBLE_TAP_S = 0.4  # a second tap within this of the first is a double-tap
VK_ESC, VK_BACK = 0x1B, 0x08

VK_LSHIFT, VK_RSHIFT, VK_LCONTROL, VK_RCONTROL, VK_LMENU, VK_RMENU, VK_LWIN, VK_RWIN = (
    0xA0, 0xA1, 0xA2, 0xA3, 0xA4, 0xA5, 0x5B, 0x5C)
GENERIC = {0x10: (VK_LSHIFT, VK_RSHIFT), 0x11: (VK_LCONTROL, VK_RCONTROL), 0x12: (VK_LMENU, VK_RMENU)}
MODIFIER_VKS = {VK_LSHIFT, VK_RSHIFT, VK_LCONTROL, VK_RCONTROL, VK_LMENU, VK_RMENU, VK_LWIN, VK_RWIN}

# name -> (virtual key, the same modifier on the other side)
MODIFIER_KEYS = {
    "right_alt": (VK_RMENU, VK_LMENU),
    "left_alt": (VK_LMENU, VK_RMENU),
    "right_control": (VK_RCONTROL, VK_LCONTROL),
    "left_control": (VK_LCONTROL, VK_RCONTROL),
    "right_shift": (VK_RSHIFT, VK_LSHIFT),
    "left_shift": (VK_LSHIFT, VK_RSHIFT),
    "right_windows": (VK_RWIN, VK_LWIN),
    "left_windows": (VK_LWIN, VK_RWIN),
}
KEY_NAMES = {"right_alt": "Right Alt", "left_alt": "Left Alt", "right_control": "Right Ctrl",
             "left_control": "Left Ctrl", "right_shift": "Right Shift", "left_shift": "Left Shift",
             "right_windows": "Right Windows key", "left_windows": "Left Windows key"}
# Names carried over from a Mac config.json
ALIASES = {"right_option": "right_alt", "left_option": "left_alt", "right_command": "right_windows",
           "left_command": "left_windows", "fn": "right_alt"}
MASKED = {VK_LMENU, VK_RMENU, VK_LWIN, VK_RWIN}  # held back from apps when tapped alone

user32 = ctypes.WinDLL("user32", use_last_error=True)
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

WH_KEYBOARD_LL, WH_MOUSE_LL = 13, 14
WM_KEYDOWN, WM_KEYUP, WM_SYSKEYDOWN, WM_SYSKEYUP = 0x100, 0x101, 0x104, 0x105
WM_LBUTTONDOWN, WM_RBUTTONDOWN, WM_MBUTTONDOWN, WM_XBUTTONDOWN = 0x201, 0x204, 0x207, 0x20B
WM_QUIT = 0x12
LLKHF_EXTENDED = 0x01
LLKHF_INJECTED = 0x10
LLMHF_INJECTED = 0x01
KEYEVENTF_EXTENDEDKEY = 0x1
KEYEVENTF_KEYUP = 0x2
SWALLOW_MAX_S = 15  # a held-back press with no key-up this long: the hook missed it, stop holding

LRESULT = ctypes.c_ssize_t
HOOKPROC = ctypes.WINFUNCTYPE(LRESULT, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM)
user32.SetWindowsHookExW.argtypes = [ctypes.c_int, HOOKPROC, wintypes.HINSTANCE, wintypes.DWORD]
user32.SetWindowsHookExW.restype = wintypes.HHOOK
user32.CallNextHookEx.argtypes = [wintypes.HHOOK, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM]
user32.CallNextHookEx.restype = LRESULT
user32.UnhookWindowsHookEx.argtypes = [wintypes.HHOOK]
user32.GetMessageW.argtypes = [ctypes.POINTER(wintypes.MSG), wintypes.HWND, wintypes.UINT, wintypes.UINT]
user32.PostThreadMessageW.argtypes = [wintypes.DWORD, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
user32.GetAsyncKeyState.argtypes = [ctypes.c_int]
user32.GetAsyncKeyState.restype = ctypes.c_short
kernel32.GetModuleHandleW.restype = wintypes.HMODULE


class KBDLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [("vkCode", wintypes.DWORD), ("scanCode", wintypes.DWORD), ("flags", wintypes.DWORD),
                ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.c_size_t)]


class MSLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [("pt", wintypes.POINT), ("mouseData", wintypes.DWORD), ("flags", wintypes.DWORD),
                ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.c_size_t)]


def resolve(name: str) -> str:
    name = (name or "").strip().lower()
    if name in MODIFIER_KEYS:
        return name
    if name in ALIASES:
        if name == "fn":
            log.warning("there's no Fn key event on Windows; using right Alt as the Donkey key")
        return ALIASES[name]
    raise ValueError(f"unknown key {name!r}; choose one of: {', '.join(MODIFIER_KEYS)}")


def key_down(vk: int) -> bool:
    return bool(user32.GetAsyncKeyState(vk) & 0x8000)


EXTENDED_VKS = {0xA3, 0xA5, 0x5B, 0x5C}  # right Ctrl, right Alt, both Win keys


def _send_key(vk: int, up: bool, scan: int | None = None, extended: bool | None = None) -> None:
    if scan is None:
        scan = user32.MapVirtualKeyW(vk, 0) & 0xFF
    if extended is None:
        extended = vk in EXTENDED_VKS
    user32.keybd_event(vk, scan & 0xFF, (KEYEVENTF_KEYUP if up else 0) | (KEYEVENTF_EXTENDEDKEY if extended else 0), 0)


def release_key(vk: int) -> None:
    """Tell Windows a key is up. For a key it wrongly thinks is still held (a key-up lost on the way
    in, which happens in virtual machines): left so, it turns every keystroke into a shortcut."""
    _send_key(vk, up=True)


class _Polled:
    """Key state read by polling (when the hooks can't be set)."""
    kind = "polling"

    def key_down(self, vk: int) -> bool:
        return key_down(vk)

    def modifiers(self) -> set[int]:
        return {vk for vk in MODIFIER_VKS if key_down(vk)}

    def inputs(self) -> int:
        return 0

    def cancel_presses(self) -> int | None:
        return None  # polled from key state instead

    def masks(self, vk: int) -> None:
        pass


class _Hooked:
    """Key state kept from low-level hooks on their own message-loop thread. Every event is passed
    on unchanged, except a lone press of the Donkey key when it's Alt or Win (see the top)."""
    kind = "keyboard hook"

    def __init__(self):
        self.down: set[int] = set()
        self.events = 0      # real (not injected) key events seen: a hook Windows dropped sees none
        self.released: set[int] = set()  # modifiers whose last real event was a key-up
        self._inputs = 0
        self._cancels = 0
        self.mask_vk: int | None = None
        self.swallowing = False  # the Donkey key is down and apps haven't been told
        self.swallowed_at = 0.0
        self.tid = 0
        self.hooks: list = []
        self._procs = (HOOKPROC(self._key), HOOKPROC(self._mouse))

    def start(self) -> bool:
        ready = threading.Event()
        threading.Thread(target=self._loop, args=(ready,), name="key-hook", daemon=True).start()
        ready.wait(2.0)
        return bool(self.hooks)

    def stop(self) -> None:
        if self.tid:
            user32.PostThreadMessageW(self.tid, WM_QUIT, 0, 0)

    def _loop(self, ready: threading.Event) -> None:
        self.tid = kernel32.GetCurrentThreadId()
        mod = kernel32.GetModuleHandleW(None)
        kb = user32.SetWindowsHookExW(WH_KEYBOARD_LL, self._procs[0], mod, 0)
        ms = user32.SetWindowsHookExW(WH_MOUSE_LL, self._procs[1], mod, 0)
        self.hooks = [h for h in (kb, ms) if h]
        ready.set()
        if not kb:
            log.warning("couldn't set the keyboard hook (error %d)", ctypes.get_last_error())
            return
        msg = wintypes.MSG()
        while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
            pass
        for h in self.hooks:
            user32.UnhookWindowsHookEx(h)
        self.hooks = []

    def _key(self, code, wparam, lparam):
        if code >= 0:
            try:
                k = ctypes.cast(lparam, ctypes.POINTER(KBDLLHOOKSTRUCT)).contents
                if not k.flags & LLKHF_INJECTED and self._handle(k, wparam):
                    return 1  # held back from apps
            except Exception:
                log.exception("key hook")
        return user32.CallNextHookEx(None, code, wparam, lparam)

    def _handle(self, k, wparam) -> bool:
        """Track one real key event; True to keep it from apps."""
        vk = k.vkCode
        self.events += 1
        is_down = wparam in (WM_KEYDOWN, WM_SYSKEYDOWN)
        if vk == VK_LCONTROL and k.scanCode & 0x200:
            # AltGr's fake left Ctrl goes with right Alt: held back with it (handing right Alt on
            # makes Windows send a fresh one)
            return self.mask_vk == VK_RMENU and (self.swallowing or is_down)
        if is_down:
            if vk == self.mask_vk:
                if vk not in self.down:
                    self.swallowing, self.swallowed_at = True, time.monotonic()
                self.down.add(vk)
                self.released.discard(vk)
                return self.swallowing  # its auto-repeat too, until it's handed on
            if self.swallowing:
                # A shortcut with the Donkey key: hand its press on first, then this key, in order
                self.swallowing = False
                _send_key(self.mask_vk, up=False)
                self._count_down(vk)
                _send_key(vk, up=False, scan=k.scanCode, extended=bool(k.flags & LLKHF_EXTENDED))
                return True
            self._count_down(vk)
            return False
        if wparam in (WM_KEYUP, WM_SYSKEYUP):
            self.down.discard(vk)
            self.released.add(vk)
            for generic, sides in GENERIC.items():
                if vk == generic:
                    self.down.difference_update(sides)
            if vk == self.mask_vk and self.swallowing:
                self.swallowing = False
                return True  # a lone tap or hold: apps never saw it go down, so not up either
        return False

    def _count_down(self, vk: int) -> None:
        if vk in MODIFIER_VKS:
            self.down.add(vk)
            self.released.discard(vk)
        else:
            self._inputs += 1
            if vk in (VK_ESC, VK_BACK):
                self._cancels += 1

    def _mouse(self, code, wparam, lparam):
        if code >= 0 and wparam in (WM_LBUTTONDOWN, WM_RBUTTONDOWN, WM_MBUTTONDOWN, WM_XBUTTONDOWN):
            try:
                # Injected clicks count too: in a virtual machine (UTM's vdagent and the like) every
                # real click arrives injected, and Donkey never makes mouse clicks itself
                self._inputs += 1
                if self.swallowing:  # Alt+click and the like: the app needs to know it's down
                    self.swallowing = False
                    _send_key(self.mask_vk, up=False)
            except Exception:
                pass
        return user32.CallNextHookEx(None, code, wparam, lparam)

    def give_up_swallow(self) -> None:
        """A held-back press whose key-up never came (the hook missed it): stop holding it."""
        if self.swallowing:
            self.swallowing = False
            if self.mask_vk is not None:
                self.down.discard(self.mask_vk)

    def key_down(self, vk: int) -> bool:
        return vk in self.down

    def modifiers(self) -> set[int]:
        return set(self.down)

    def inputs(self) -> int:
        return self._inputs

    def cancel_presses(self) -> int | None:
        return self._cancels

    def masks(self, vk: int) -> None:
        self.mask_vk = vk if vk in MASKED else None

    def resync(self) -> None:
        """Drop keys the hook thinks are down but Windows says are up (a missed key-up)."""
        for vk in list(self.down):
            if self.swallowing and vk == self.mask_vk:
                continue  # held back, so Windows' key state never saw it go down
            if not key_down(vk):
                self.down.discard(vk)


def key_source():
    hooked = _Hooked()
    if hooked.start():
        return hooked
    log.warning("couldn't hook the keyboard, so the Donkey key is read by polling")
    return _Polled()


class KeyWatcher:
    """Calls on_tap / on_hold for the Donkey key, and on_cancel when Esc or Backspace goes down
    while `armed_cancel` is set (i.e. a rewrite is running)."""

    def __init__(self, key_name: str, on_tap, on_hold=None, on_cancel=None, on_double_tap=None):
        self.key_name = resolve(key_name)
        self.code, self.twin = MODIFIER_KEYS[self.key_name]
        self.on_tap, self.on_hold, self.on_cancel = on_tap, on_hold, on_cancel
        self.on_double_tap = on_double_tap
        self.last_tap_at = 0.0
        self.armed_cancel = threading.Event()
        self.src = None

    def run(self, stop: threading.Event) -> None:
        src = self.src = key_source()
        src.masks(self.code)
        log.info("key watcher running (%s, %s)", src.kind, self.key_name)
        was_down = False
        pressed_at = 0.0
        inputs_at_press = 0
        chorded = held = False
        cancel_was_down = False
        cancels_seen = src.cancel_presses()
        missed = 0
        stuck_since = 0.0
        real_was_down, events_at_real_down = False, 0
        rehooked_at = 0.0
        while not stop.is_set():
            now = time.monotonic()
            down = src.key_down(self.code)
            if isinstance(src, _Hooked):
                # Only the hook says when the key goes down: Windows' own key state can stay "down"
                # after a lost key-up (common in virtual machines), and trusting it would invent
                # presses. That state is used only to clear a key-up the hook missed, and to notice
                # a hook Windows dropped.
                real = key_down(self.code)
                if src.swallowing:
                    # held back from apps, so Windows' key state never saw it go down
                    if now - src.swallowed_at > SWALLOW_MAX_S:
                        log.warning("%s held back with no key-up for %d s; letting go", self.key_name, SWALLOW_MAX_S)
                        src.give_up_swallow()
                        down = False
                    missed = 0
                elif down and not real:
                    missed += 1
                    if missed >= 3:  # not just the moment between the hook and the key state
                        src.resync()
                        down = False
                else:
                    missed = 0
                if real and not down and self.code in src.released:
                    # The hook saw the key go up, yet Windows still holds it: release it there
                    stuck_since = stuck_since or now
                    if now - stuck_since > 0.4:
                        log.warning("Windows still held %s after it was let go; releasing it", self.key_name)
                        release_key(self.code)
                        stuck_since = 0.0
                        events_at_real_down = -1  # that key-up was ours, not one the hook missed
                else:
                    stuck_since = 0.0
                if real and not real_was_down:
                    events_at_real_down = src.events
                elif real_was_down and not real and src.events == events_at_real_down \
                        and now - rehooked_at > 10 and not stop.is_set():
                    # A whole press the hook never heard: Windows drops a hook that once answered
                    # too slowly, without a word. Hook again.
                    log.warning("the keyboard hook went quiet; setting it again")
                    rehooked_at = now
                    src.stop()
                    src = self.src = key_source()
                    src.masks(self.code)
                    cancels_seen = src.cancel_presses()
                    down, missed = False, 0
                real_was_down = real
            if down and not was_down:
                pressed_at, inputs_at_press = now, src.inputs()
                chorded, held = self._other_modifiers_down(), False
            elif down:
                if not chorded and (self._other_modifiers_down() or src.inputs() != inputs_at_press):
                    chorded = True
                if not chorded and not held and now - pressed_at >= HOLD_S:
                    held = True
                    if self.on_hold:
                        self._fire(self.on_hold)
            elif was_down:
                if not chorded and not held and src.inputs() == inputs_at_press:
                    # The first tap fires at once (no waiting); a quick second tap supersedes it.
                    if self.on_double_tap and now - self.last_tap_at < DOUBLE_TAP_S:
                        self.last_tap_at = 0.0
                        self._fire(self.on_double_tap)
                    else:
                        self.last_tap_at = now
                        self._fire(self.on_tap)
            was_down = down

            cancels = src.cancel_presses()
            if self.armed_cancel.is_set() and self.on_cancel:
                if cancels is None:
                    cancel_down = key_down(VK_ESC) or key_down(VK_BACK)
                    if cancel_down and not cancel_was_down:
                        self._fire(self.on_cancel)
                    cancel_was_down = cancel_down
                elif cancels != cancels_seen:
                    self._fire(self.on_cancel)
            else:
                cancel_was_down = False
            cancels_seen = cancels
            stop.wait(POLL_S)

    def _other_modifiers_down(self) -> bool:
        return bool(self.src.modifiers() - {self.code})

    @staticmethod
    def _fire(fn) -> None:
        try:
            fn()
        except Exception:
            log.exception("key handler failed")
