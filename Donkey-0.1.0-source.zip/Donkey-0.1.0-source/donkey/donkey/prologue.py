"""The opening a new copy plays before the welcome: the whole screen goes soft and dark, a greeting,
the logo and name, what Donkey does, then "press the Donkey key to begin". Beginning hands over to the Donkey
window, which rises into place while the dark lifts. Main thread only."""
import base64
import json
import logging

from PySide6.QtGui import QGuiApplication

from . import motion, overlay, winui

log = logging.getLogger(__name__)

PAGE = overlay.ASSETS / "prologue.html"
NAMES = {"alt": "Alt", "control": "Ctrl", "shift": "Shift", "windows": "Windows key"}
# Windows can't blur the screen behind a window, so the page itself dims it
DIM_CSS = ("<style>html{background:rgba(14,12,10,0);transition:background-color 1.6s ease}"
           "html.dim{background:rgba(14,12,10,.9)}</style>")


def key_caption(key: str) -> tuple[str, str]:
    """"right_alt" → ("", "right Alt"), "left_control" → ("", "Ctrl")."""
    side, _, name = key.rpartition("_")
    label = NAMES.get(name, name.title())
    return "", (f"right {label}" if side == "right" else label)


def _logo() -> str | None:
    """The app icon as a data URL (the page is loaded from a string, so it can't fetch files)."""
    try:
        return "data:image/png;base64," + base64.b64encode((overlay.ASSETS / "icon.png").read_bytes()).decode()
    except OSError:
        return None


class Prologue:
    """Shows itself on creation; `on_begin` runs once, as the dark starts to lift."""

    def __init__(self, key: str, first_name: str, on_begin):
        self.on_begin, self.begun = on_begin, False
        g = QGuiApplication.primaryScreen().geometry()  # the whole screen, taskbar included
        win = winui.Panel(g.width(), g.height(), focusable=True)
        win.on_message("donkey", self._on_message)
        glyph, name = key_caption(key)
        data = json.dumps({"first_name": first_name, "glyph": glyph, "key_name": name, "logo": _logo()},
                          ensure_ascii=False)
        html = PAGE.read_text().replace("/*DATA*/null", data.replace("</", "<\\/"))
        html = html.replace("</head>", DIM_CSS + "</head>", 1)
        win.load(html)
        win.js("requestAnimationFrame(() => document.documentElement.classList.add('dim'))")
        win.set_frame(g.x(), g.y(), g.width(), g.height())
        win.present(activate=True)
        self.win = win
        self.fader = motion.Tween(win)

    @property
    def showing(self) -> bool:
        return not self.begun

    def key(self) -> None:
        """The Donkey key, as the app's key watcher saw it (the page doesn't hear a lone modifier)."""
        self.win.js("dk.begin()")

    def _on_message(self, msg: dict) -> None:
        if msg.get("type") == "begin":
            self._begin()

    def _begin(self) -> None:
        if self.begun:
            return
        self.begun = True
        winui.call_later(0.35, self._handover)

    def _handover(self) -> None:
        try:
            self.on_begin()
        except Exception:
            log.exception("prologue hand-over")
        self.win.set_hit([])  # clicks go through while it fades
        self.fader.run(alpha=0.0, duration=1.1, then=self.win.dismiss)