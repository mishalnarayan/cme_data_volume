"""The edit-mode command bar: a panel over the field where you type what to change.

A floating, borderless window with a web page in it. On Windows a window has to be in front to
take typing, so the bar takes the keyboard while it's open and gives it straight back to the app
you're editing (whose field keeps its caret) whenever the text is written in, and when it closes.
All methods run on the main thread.
"""
import json
import logging

from . import overlay, winui

log = logging.getLogger("donkey.editbar")

MIN_W, MAX_W = 420, 600
START_H = 86
GAP = 8  # between the field and the bar
HEAD_H = 26  # the strip above the text box (the scope line) drags the bar


class EditBar:
    """Callbacks: on_submit(text), on_cancel(), on_close(reason)."""

    def __init__(self, on_submit, on_cancel, on_close):
        self.on_submit, self.on_cancel, self.on_close = on_submit, on_cancel, on_close
        self.is_open = False
        self.working = False
        self.delivering = False
        self.text = ""
        self.width = MIN_W
        self.height = START_H
        self.anchor = None  # (x, field top, field bottom), logical pixels
        self.below = True
        self.pinned = False  # dragged by hand: stays put until it next opens
        self.target_hwnd = 0  # the window being edited, which gets the keyboard back

        panel = winui.Panel(MIN_W, START_H, focusable=True)
        panel.on_message("donkey", self._on_message)
        panel.load(_html())
        panel.add_drag_strip(HEAD_H, on_moved=self._dragged)
        panel.on_deactivate = self._on_resign_key
        self.panel = panel

    # -------------------------------------------------------------- page bridge

    def js(self, code: str) -> None:
        self.panel.js(code)

    def _on_message(self, msg: dict) -> None:
        kind = msg.get("type")
        if kind == "submit":
            text = str(msg.get("text") or "").strip()
            if text and not self.working:
                self.on_submit(text)
        elif kind == "input":
            self.text = str(msg.get("text") or "")
        elif kind == "cancel":
            self.on_cancel()
        elif kind == "close":
            self.close(str(msg.get("reason") or "esc"))
        elif kind == "height":
            self._resize(float(msg.get("h") or START_H))

    def _dragged(self) -> None:
        self.pinned = True

    def _on_resign_key(self) -> None:
        # Clicking back into your app with nothing typed closes the bar.
        if self.is_open and not self.working and not self.delivering and not self.text.strip():
            self.close("blur")

    # -------------------------------------------------------------- placement

    def open(self, field_rect_px, scope: str, rounds: int = 0) -> None:
        """Show under (or above) the field given in physical screen pixels, and take the keyboard."""
        x, y, w, h = winui.rect_from_physical(*field_rect_px)
        self.width = max(MIN_W, min(MAX_W, w))
        self.anchor = (x, y, y + h)
        _, sy, _, sh = winui.work_area(x + w / 2, y + h / 2)
        self.below = (y + h) + GAP + self.height < sy + sh - 40
        self.text = ""
        self.working = False
        self.pinned = False
        fg = winui.foreground()
        if fg and fg != self.panel.hwnd:
            self.target_hwnd = fg
        self._place()
        self.js(f"openBar({json.dumps(scope)}, {int(rounds)})")
        self.panel.set_alpha(1.0)
        self.panel.present(activate=True)
        self.is_open = True

    def _place(self) -> None:
        if self.pinned:  # keep the top edge where it was put
            x, y, _, _ = self.panel.frame()
        else:
            x, top, bottom = self.anchor
            y = bottom + GAP if self.below else top - GAP - self.height
        x, y = overlay.clamp_to_screen(x, y, self.width, self.height)
        self.panel.set_frame(x, y, self.width, self.height)

    def _resize(self, h: float) -> None:
        h = max(60.0, min(320.0, h))
        if abs(h - self.height) < 1 or not self.anchor:
            return
        self.height = h
        self._place()

    # -------------------------------------------------------------- states

    def set_working(self, status: str = "Working on it…") -> None:
        self.working = True
        self.js(f"setWorking({json.dumps(status)})")

    def set_idle(self, status: str, rounds: int) -> None:
        self.working = False
        self.js(f"setIdle({json.dumps(status)}, {int(rounds)})")

    def set_error(self, message: str) -> None:
        self.working = False
        self.js(f"setError({json.dumps(message)})")

    def step_aside(self) -> None:
        """Give the keyboard back to the field so the result can be written; the bar returns after."""
        self.delivering = True
        self.panel.dismiss()
        if self.target_hwnd:
            winui.activate(self.target_hwnd)

    def come_back(self) -> None:
        self.delivering = False
        if self.is_open:
            self.panel.present(activate=True)
            self.js("focusInput()")

    def close(self, reason: str = "esc") -> None:
        if not self.is_open:
            return
        self.is_open = False
        self.working = False
        self.delivering = False
        had_keyboard = self.panel.isActiveWindow()
        self.panel.dismiss()
        if had_keyboard and self.target_hwnd and reason != "blur":
            winui.activate(self.target_hwnd)  # back to typing where you were
        self.js("resetBar()")
        self.on_close(reason)

def _html() -> str:
    svg = (overlay.ASSETS / "creature.svg").read_text()
    return f"""<!doctype html><html><head><meta charset="utf-8"><style>
:root {{ --ink:#24211e; --muted:rgba(36,33,30,.55); --accent:#8a6e52; --field:rgba(255,255,255,.55); --err:#d64545; }}
@media (prefers-color-scheme: dark) {{ :root {{ --ink:#f3efe9; --muted:rgba(243,239,233,.6); --field:rgba(255,255,255,.08); --err:#ff8a8a; }} }}
html, body {{ margin:0; background:transparent; color:var(--ink); overflow:hidden;
  font:14px/1.4 "Inter", "Segoe UI Variable Text", "Segoe UI", system-ui, sans-serif; -webkit-user-select:none; }}
.bar {{ display:flex; gap:10px; padding:12px 14px 10px 10px; align-items:flex-start; }}
#critter {{ width:36px; height:34px; flex:none; margin-top:2px; }}
#critter svg {{ width:100%; height:100%; overflow:visible; }}
{overlay.DONKEY_CSS}
.main {{ flex:1; min-width:0; }}
.top {{ display:flex; justify-content:space-between; font-size:11.5px; color:var(--muted); margin-bottom:5px; }}
.scope {{ font-weight:600; letter-spacing:.01em; }}
textarea {{ width:100%; box-sizing:border-box; resize:none; border:0; outline:none; background:var(--field);
  color:var(--ink); border-radius:10px; padding:8px 10px; font:inherit; font-size:15px; line-height:1.35;
  min-height:38px; max-height:180px; -webkit-user-select:text; }}
textarea::placeholder {{ color:var(--muted); }}
textarea:disabled {{ opacity:.6; }}
.status {{ font-size:12px; color:var(--muted); margin-top:6px; min-height:16px; }}
.status.err {{ color:var(--err); }}
kbd {{ font:inherit; font-size:11px; padding:0 4px; border-radius:4px; background:var(--field); }}
@keyframes bob {{ 0%,100% {{ transform:translateY(0) }} 50% {{ transform:translateY(-2px) }} }}
@keyframes swayL {{ 0%,100% {{ transform:rotate(0) }} 50% {{ transform:rotate(-8deg) }} }}
@keyframes swayR {{ 0%,100% {{ transform:rotate(0) }} 50% {{ transform:rotate(8deg) }} }}
@keyframes blink {{ 0%,93%,100% {{ transform:scaleY(1) }} 95% {{ transform:scaleY(.1) }} }}
{winui.GLASS_CSS}
</style></head><body>
<div class="bar"><div id="critter">{svg}</div><div class="main">
  <div class="top"><span class="scope" id="scope">This draft</span><span id="rounds"></span></div>
  <textarea id="ta" rows="1" placeholder="Tell Donkey what to change…" spellcheck="true"></textarea>
  <div class="status" id="status"><kbd>Enter</kbd> apply · <kbd>Shift+Enter</kbd> new line · <kbd>Esc</kbd> close</div>
</div></div>
<script>
const ta = document.getElementById('ta'), statusEl = document.getElementById('status');
const HINT = statusEl.innerHTML;
const post = m => window.webkit.messageHandlers.donkey.postMessage(m);
let working = false, idleTimer = null;
function report() {{ post({{type:'height', h: document.body.scrollHeight}}); }}
function grow() {{ ta.style.height = 'auto'; ta.style.height = Math.min(ta.scrollHeight, 180) + 'px'; report(); }}
function armIdle() {{ clearTimeout(idleTimer); idleTimer = setTimeout(() => {{ if (!working && !ta.value.trim()) post({{type:'close', reason:'timeout'}}); }}, 30000); }}
function focusInput() {{ setTimeout(() => {{ ta.focus(); }}, 60); }}
function setRounds(n) {{ document.getElementById('rounds').textContent = n ? `${{n}} change${{n > 1 ? 's' : ''}} so far` : ''; }}
function openBar(scope, rounds) {{ document.body.className = ''; document.getElementById('scope').textContent = scope;
  setRounds(rounds); ta.value = ''; ta.disabled = false; statusEl.className = 'status'; statusEl.innerHTML = HINT;
  grow(); focusInput(); armIdle(); }}
function resetBar() {{ working = false; ta.value = ''; ta.disabled = false; clearTimeout(idleTimer); }}
function setWorking(msg) {{ working = true; document.body.className = 'working'; ta.disabled = true;
  statusEl.className = 'status'; statusEl.textContent = msg + '  Esc to cancel.'; }}
function setIdle(msg, rounds) {{ working = false; document.body.className = 'done'; setRounds(rounds);
  ta.disabled = false; ta.value = ''; grow(); statusEl.className = 'status'; statusEl.textContent = msg;
  setTimeout(() => {{ if (!working) document.body.className = ''; }}, 1200); focusInput(); armIdle(); }}
function setError(msg) {{ working = false; document.body.className = 'error'; ta.disabled = false;
  statusEl.className = 'status err'; statusEl.textContent = msg; focusInput(); armIdle(); }}
ta.addEventListener('input', () => {{ grow(); post({{type:'input', text: ta.value}}); armIdle(); }});
ta.addEventListener('keydown', ev => {{
  if (ev.key === 'Escape') {{ ev.preventDefault(); post(working ? {{type:'cancel'}} : {{type:'close', reason:'esc'}}); }}
  else if (ev.key === 'Enter' && !ev.shiftKey && !ev.isComposing) {{ ev.preventDefault();
    if (working) return;
    if (ta.value.trim()) post({{type:'submit', text: ta.value}}); else post({{type:'close', reason:'empty_enter'}}); }}
}});
window.addEventListener('load', report);
</script></body></html>"""
