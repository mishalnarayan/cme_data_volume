"""OpenAI-compatible chat-completions client (OpenRouter, Groq, Together, local servers…).

Standard library only. Connections are kept alive in a small pool and can be opened ahead of
time (`prewarm`), so a rewrite doesn't pay for a TLS handshake. `complete` streams (so Esc can
cancel mid-generation); `parse` asks for JSON matching a Pydantic schema, validates it, and
retries once with the error.
"""
import http.client
import json
import logging
import queue
import re
import ssl
import threading
import time
from urllib.parse import urlsplit

from pydantic import ValidationError

from .config import is_local

log = logging.getLogger("donkey.llm")


class ProviderError(Exception):
    pass


class CancelledStream(Exception):
    pass


# ------------------------------------------------------------------ connection pool

_POOL: "queue.LifoQueue[tuple[float, http.client.HTTPSConnection]]" = queue.LifoQueue(maxsize=4)
_IDLE_MAX_S = 50  # providers close idle keep-alive connections after roughly a minute
_ssl = ssl.create_default_context()


def _new_conn(cfg) -> http.client.HTTPConnection:
    u = urlsplit(cfg.llm_endpoint)
    if u.scheme == "http":
        return http.client.HTTPConnection(u.hostname, u.port or 80, timeout=cfg.llm_timeout)
    return http.client.HTTPSConnection(u.hostname, u.port or 443, timeout=cfg.llm_timeout, context=_ssl)


def _get_conn(cfg):
    while True:
        try:
            idle_since, conn = _POOL.get_nowait()
        except queue.Empty:
            return _new_conn(cfg)
        u = urlsplit(cfg.llm_endpoint)
        same_host = (conn.host, conn.port) == (u.hostname, u.port or conn.default_port)
        if same_host and time.monotonic() - idle_since < _IDLE_MAX_S:
            conn.timeout = cfg.llm_timeout
            return conn
        conn.close()


def _put_conn(conn) -> None:
    try:
        _POOL.put_nowait((time.monotonic(), conn))
    except queue.Full:
        conn.close()


def drop_pool() -> None:
    while True:
        try:
            _POOL.get_nowait()[1].close()
        except queue.Empty:
            return


def prewarm(cfg) -> None:
    """Open a connection (DNS + TCP + TLS) now so the next request skips it. Safe to call often."""
    if not cfg.llm_endpoint or not _POOL.empty():
        return
    try:
        conn = _new_conn(cfg)
        conn.connect()
        _put_conn(conn)
    except OSError:
        pass


# ------------------------------------------------------------------ requests

def _headers(cfg) -> dict:
    headers = {"Content-Type": "application/json", "X-Title": "Donkey", "HTTP-Referer": "https://github.com/donkey-app"}
    if cfg.llm_api_key:
        headers["Authorization"] = f"Bearer {cfg.llm_api_key}"
    headers.update(cfg.llm_headers)
    return headers


def _merge(into: dict, more: dict) -> None:
    """Nested dicts are merged, so {"provider": {...}} in two places adds up."""
    for k, v in more.items():
        if isinstance(v, dict) and isinstance(into.get(k), dict):
            into[k] = {**into[k]}
            _merge(into[k], v)
        else:
            into[k] = v


def _body(cfg, model: str, system: str, user: str, effort: str, max_tokens: int | None, messages=None,
          fast: bool = False, **extra) -> dict:
    body = {"model": model,
            "messages": [{"role": "system", "content": system},
                         *(messages if messages is not None else [{"role": "user", "content": user}])],
            "max_tokens": min(max_tokens or cfg.llm_max_tokens, cfg.llm_max_tokens)}
    if cfg.llm_temperature is not None:
        body["temperature"] = cfg.llm_temperature
    reasoning = (cfg.llm_reasoning_effort or "").lower()
    if reasoning in ("none", "off", "false") and model in _MUST_REASON:
        body["reasoning"] = {"effort": "low"}
    elif reasoning in ("none", "off", "false"):
        body["reasoning"] = {"enabled": False}  # biggest latency win: no thinking tokens before the answer
    elif reasoning:
        body["reasoning"] = {"effort": effort if reasoning == "auto" else reasoning}
    _merge(body, cfg.llm_extra)
    _merge(body, cfg.llm_fast_extra if fast else cfg.llm_background_extra)  # someone waiting, or not
    body.update(extra)
    return body


def _error(status: int, raw: bytes) -> ProviderError:
    detail = raw.decode(errors="replace")[:400]
    try:
        detail = json.loads(detail).get("error", {}).get("message", detail)
    except (ValueError, AttributeError):
        pass
    if status == 401:
        return ProviderError(f"The API key was rejected (401): {detail}")
    if status == 402:
        return ProviderError(f"Out of credits (402): {detail}")
    if status == 429:
        return ProviderError("Rate limited. Try again in a moment.")
    return ProviderError(f"API error {status}: {detail}")


# Models that refuse a request with thinking turned off ("Reasoning is mandatory"): they get the
# lightest thinking instead, found out on the first refusal.
_MUST_REASON: set[str] = set()
# Models that refuse max_tokens (OpenAI's reasoning models want max_completion_tokens) or any
# temperature but their own, also found out on the first refusal.
_COMPLETION_TOKENS: set[str] = set()
_NO_TEMPERATURE: set[str] = set()


def _adapt(body: dict) -> dict:
    """The request as this model accepts it, given what it refused before."""
    model = body.get("model")
    if model in _MUST_REASON and body.get("reasoning") == {"enabled": False}:
        body = {**body, "reasoning": {"effort": "low"}}
    if model in _COMPLETION_TOKENS and "max_tokens" in body:
        body = {k: v for k, v in body.items() if k != "max_tokens"} | {"max_completion_tokens": body["max_tokens"]}
    if model in _NO_TEMPERATURE:
        body = {k: v for k, v in body.items() if k != "temperature"}
    return body


def _learn(body: dict, error: str) -> bool:
    """Note what a 400 says this model won't take; True when there is something new to retry without."""
    text, model = error.lower(), body.get("model")
    if "400" not in text:
        return False
    for seen, sign, applies in ((_MUST_REASON, "reasoning", body.get("reasoning") == {"enabled": False}),
                                (_COMPLETION_TOKENS, "max_completion_tokens", "max_tokens" in body),
                                (_NO_TEMPERATURE, "temperature", "temperature" in body)):
        if applies and sign in text and model not in seen:
            seen.add(model)
            log.info("%s refused a parameter; retrying without it (%s)", model, text[:100])
            return True
    return False


def _send(cfg, body: dict):
    """POST and return (conn, response) with a 200 status. Retries once on a stale pooled connection,
    and once per parameter a model turns out to refuse (thinking off, max_tokens, temperature)."""
    for _ in range(3):
        try:
            return _send_once(cfg, _adapt(body))
        except ProviderError as e:
            if not _learn(body, str(e)):
                raise
    return _send_once(cfg, _adapt(body))


def _send_once(cfg, body: dict):
    if not cfg.llm_endpoint:
        raise ProviderError("No endpoint set for the provider in use in config.json.")
    if not cfg.llm_api_key and not is_local(cfg.llm_endpoint):
        raise ProviderError("No api_key (or api_key_env) for the provider in use in config.json.")
    path = urlsplit(cfg.llm_endpoint).path or "/"
    payload = json.dumps(body).encode()
    for attempt in range(2):
        conn = _get_conn(cfg)
        try:
            conn.request("POST", path, body=payload, headers=_headers(cfg))
            resp = conn.getresponse()
        except (http.client.RemoteDisconnected, http.client.CannotSendRequest, ConnectionError, BrokenPipeError):
            conn.close()
            if attempt == 0:
                continue  # the pooled connection had gone stale; try a fresh one
            raise ProviderError(f"Couldn't reach {cfg.llm_endpoint}.")
        except (TimeoutError, OSError) as e:
            conn.close()
            raise ProviderError(f"Couldn't reach {cfg.llm_endpoint}: {e}")
        if resp.status != 200:
            raw = resp.read()
            _put_conn(conn) if not resp.will_close else conn.close()
            raise _error(resp.status, raw)
        return conn, resp
    raise ProviderError(f"Couldn't reach {cfg.llm_endpoint}.")


def _served(fast: bool, model: str, provider: str | None, t0: float) -> None:
    """Which host answered (OpenRouter names it on every reply; other endpoints don't)."""
    if provider:
        log.info("llm %s: %s via %s in %d ms", "fast" if fast else "background", model, provider,
                 (time.monotonic() - t0) * 1000)


def complete(cfg, model: str, effort: str, system: str, user: str, cancel: threading.Event | None = None,
             max_tokens: int | None = None, on_first_token=None, fast: bool = False) -> str:
    t0 = time.monotonic()
    conn, resp = _send(cfg, _body(cfg, model, system, user, effort, max_tokens, fast=fast, stream=True))
    parts: list[str] = []
    finish = provider = None
    clean = False
    try:
        while True:
            if cancel is not None and cancel.is_set():
                raise CancelledStream()
            raw = resp.readline()
            if not raw:
                clean = True
                break
            line = raw.decode(errors="replace").strip()
            if not line.startswith("data:"):
                continue  # blank keep-alives and ": OPENROUTER PROCESSING" comments
            data = line[5:].strip()
            if data == "[DONE]":
                resp.read()  # drain so the connection can be reused
                clean = True
                break
            try:
                chunk = json.loads(data)
            except ValueError:
                continue
            if "error" in chunk:
                raise ProviderError(f"Provider error: {chunk['error'].get('message', chunk['error'])}")
            provider = chunk.get("provider") or provider
            for choice in chunk.get("choices", []):
                text = (choice.get("delta") or {}).get("content")
                if text:
                    if not parts and on_first_token:
                        on_first_token()
                    parts.append(text)
                finish = choice.get("finish_reason") or finish
    finally:
        if clean and not resp.will_close:
            _put_conn(conn)
        else:
            conn.close()
    _served(fast, model, provider, t0)
    if finish == "length":
        raise ProviderError("The result was too long and got cut off.")
    if finish == "content_filter":
        raise ProviderError("The model declined this request.")
    return "".join(parts)


def chat(cfg, model: str, effort: str, system: str, messages: list[dict], tools: list[dict],
         cancel: threading.Event | None = None, on_text=None, max_tokens: int | None = None,
         tool_choice: str | None = None) -> dict:
    """One streamed turn of a tool-using conversation (OpenAI chat format). `messages` excludes the
    system prompt. Returns {"text", "tool_calls": [{"id", "name", "arguments" (JSON text)}], "usage"}."""
    extra = {"stream": True, "stream_options": {"include_usage": True}}
    if tools:
        extra["tools"] = tools
        if tool_choice:
            extra["tool_choice"] = tool_choice
    t0 = time.monotonic()
    conn, resp = _send(cfg, _body(cfg, model, system, "", effort, max_tokens, messages=messages, fast=True, **extra))  # chat is always waited on
    parts: list[str] = []
    calls: dict[int, dict] = {}
    usage, finish, provider, clean = {}, None, None, False
    try:
        while True:
            if cancel is not None and cancel.is_set():
                raise CancelledStream()
            raw = resp.readline()
            if not raw:
                clean = True
                break
            line = raw.decode(errors="replace").strip()
            if not line.startswith("data:"):
                continue
            data = line[5:].strip()
            if data == "[DONE]":
                resp.read()
                clean = True
                break
            try:
                chunk = json.loads(data)
            except ValueError:
                continue
            if "error" in chunk:
                raise ProviderError(f"Provider error: {chunk['error'].get('message', chunk['error'])}")
            usage = chunk.get("usage") or usage
            provider = chunk.get("provider") or provider
            for choice in chunk.get("choices", []):
                delta = choice.get("delta") or {}
                if text := delta.get("content"):
                    parts.append(text)
                    if on_text:
                        on_text(text)
                for tc in delta.get("tool_calls") or []:
                    c = calls.setdefault(tc.get("index", len(calls)), {"id": "", "name": "", "arguments": ""})
                    c["id"] = tc.get("id") or c["id"]
                    fn = tc.get("function") or {}
                    c["name"] += fn.get("name") or ""
                    c["arguments"] += fn.get("arguments") or ""
                finish = choice.get("finish_reason") or finish
    finally:
        if clean and not resp.will_close:
            _put_conn(conn)
        else:
            conn.close()
    _served(True, model, provider, t0)
    if finish == "length" and not calls:
        raise ProviderError("The reply was too long and got cut off.")
    tool_calls = [c | {"id": c["id"] or f"call_{i}"} for i, c in sorted(calls.items()) if c["name"]]
    return {"text": "".join(parts), "tool_calls": tool_calls, "usage": usage}


def _extract_json(text: str) -> str:
    text = text.strip()
    fence = re.search(r"```(?:json)?\s*(.*?)```", text, re.S)
    if fence:
        text = fence.group(1).strip()
    start, end = text.find("{"), text.rfind("}")
    return text[start:end + 1] if start >= 0 and end > start else text


def _salvage(text: str, schema):
    """From an answer cut off mid-way, the complete items of a schema whose one field is a list
    (e.g. {"claims": [...]}), or None. Items that fail validation on their own are dropped."""
    fields = list(schema.model_fields.items())
    if len(fields) != 1:
        return None
    name, field = fields[0]
    m = re.search(rf'"{re.escape(name)}"\s*:\s*\[', text)
    if not m:
        return None
    decoder, items, pos = json.JSONDecoder(), [], m.end()
    while True:
        while pos < len(text) and text[pos] in " \t\r\n,":
            pos += 1
        try:
            item, pos = decoder.raw_decode(text, pos)
        except ValueError:
            break  # the cut-off item
        items.append(item)
    kept = []
    for item in items:
        try:
            kept.append(schema.model_validate({name: [item]}).model_dump()[name][0])
        except ValidationError:
            continue
    return schema.model_validate({name: kept}) if kept else None


def _post_json(cfg, body: dict) -> dict:
    conn, resp = _send(cfg, body)
    try:
        payload = json.loads(resp.read().decode())
    finally:
        _put_conn(conn) if not resp.will_close else conn.close()
    if "error" in payload:
        raise ProviderError(f"Provider error: {payload['error'].get('message', payload['error'])}")
    return payload


def parse(cfg, model: str, effort: str, system: str, user: str, schema, max_tokens: int | None = None,
          fast: bool = False):
    json_schema = schema.model_json_schema()
    system = (f"{system}\n\nRespond with only one JSON object (no prose, no code fences) that matches this "
              f"JSON Schema:\n{json.dumps(json_schema)}")
    response_format = {"type": "json_schema",
                       "json_schema": {"name": schema.__name__, "schema": json_schema, "strict": False}}
    prompt_user = user
    last_error = None
    for attempt in range(2):
        t0 = time.monotonic()
        body = _body(cfg, model, system, prompt_user, effort, max_tokens, fast=fast)
        if response_format:
            body["response_format"] = response_format
        try:
            payload = _post_json(cfg, body)
        except ProviderError as e:
            msg = str(e).lower()
            if response_format and ("response_format" in msg or "json_schema" in msg or "structured" in msg):
                response_format = None  # this provider/model doesn't do structured output; rely on the prompt
                body.pop("response_format", None)
                payload = _post_json(cfg, body)
            else:
                raise
        _served(fast, model, payload.get("provider"), t0)
        choice = (payload.get("choices") or [{}])[0]
        text = (choice.get("message") or {}).get("content") or ""
        if choice.get("finish_reason") == "length":
            # Usually a loop (one list repeated until the limit), not a long answer. Ask once more,
            # then keep the complete items that came before the cut.
            if attempt == 0:
                prompt_user = (f"{user}\n\nYour previous answer ran past the length limit. Keep every list short "
                               f"and name each item once.")
                continue
            if (salvaged := _salvage(text, schema)) is not None:
                return salvaged
            raise ProviderError("incomplete structured output (cut off)")
        try:
            return schema.model_validate_json(_extract_json(text))
        except (ValidationError, ValueError) as e:
            last_error = e
            prompt_user = (f"{user}\n\nYour previous answer was not valid JSON for the schema "
                           f"({str(e)[:300]}). Answer again with only the JSON object.")
    raise ProviderError(f"invalid structured output: {str(last_error)[:200]}")
