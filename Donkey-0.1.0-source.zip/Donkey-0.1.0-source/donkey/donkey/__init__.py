"""Donkey: a local, open re-implementation of a screen-memory + writing assistant for Windows."""
