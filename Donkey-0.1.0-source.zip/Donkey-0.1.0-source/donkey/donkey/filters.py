"""What never gets stored: blocked apps/sites, private windows, and secrets inside captured text."""
import re
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

BLOCKLIST_PATH = Path(__file__).with_name("blocklist.txt")


# ---------------------------------------------------------------- blocklist

@dataclass
class Rules:
    domains: set[str] = field(default_factory=set)
    apps: set[str] = field(default_factory=set)
    urls: list[str] = field(default_factory=list)
    paths: set[str] = field(default_factory=set)
    titles: list[str] = field(default_factory=list)

    def add(self, line: str) -> None:
        line = line.strip()
        if not line or line.startswith("#"):
            return
        kind, sep, value = line.partition(":")
        value = value.strip().lower()
        if sep and kind in ("app", "url", "path", "title") and value:
            {"app": self.apps.add, "path": self.paths.add,
             "url": self.urls.append, "title": self.titles.append}[kind](value)
        else:
            self.domains.add(line.lower().removeprefix("www."))


def load_rules(extra_apps=(), extra_domains=()) -> Rules:
    """Built-in list (plain domain covers subdomains; `app:`, `url:`, `path:`, `title:`) plus the user's."""
    rules = Rules()
    for line in BLOCKLIST_PATH.read_text().splitlines():
        rules.add(line)
    for app in extra_apps:
        rules.apps.add(app.lower())
    for d in extra_domains:
        rules.add(d)
    return rules


def _domain_blocked(rules: Rules, host: str) -> bool:
    host = host.lower().removeprefix("www.")
    if host.startswith(("jobs.", "careers.")):
        return False
    parts = host.split(".")
    return any(".".join(parts[i:]) in rules.domains for i in range(len(parts) - 1))


def blocked_reason(rules: Rules, app: str, url: str | None, title: str) -> str | None:
    if app.lower() in rules.apps:
        return f"app:{app}"
    t = title.lower()
    for needle in rules.titles:
        if needle in t:
            return f"title:{needle}"
    if not url:
        return None
    u = url.lower()
    for needle in rules.urls:
        if needle in u:
            return f"url:{needle}"
    parsed = urlparse(u)
    if parsed.hostname and _domain_blocked(rules, parsed.hostname):
        return f"domain:{parsed.hostname}"
    for piece in parsed.path.split("/"):
        if piece and piece.rsplit(".", 1)[0] in rules.paths:
            return f"path:{piece}"
    return None


# ---------------------------------------------------------- private windows

# Donkey's own log open in a terminal: its lines name people and pages it already knows about, and
# reading them back would feed its own output into memory as if it were the user's.
OWN_LOG = re.compile(r"^\d\d:\d\d:\d\d (?:DEBUG|INFO|WARNING|ERROR|CRITICAL) donkey[.\w]*: .*\n?", re.M)

# Chromium: a private or guest window is titled "<page> - <brand> (<mode>)" in every
# language; a normal window ends with the brand (or a profile name without parentheses).
_CHROMIUM_BRANDS = ("Google Chrome", "Brave", "Comet", "Chromium", "Microsoft Edge", "Vivaldi")
_CHROMIUM_PRIVATE = re.compile(r" - (?:%s) \([^()]+\)$" % "|".join(map(re.escape, _CHROMIUM_BRANDS)))
# Safari ("<page>, Private Browsing") and Firefox ("<page> — Private Browsing") suffixes, per language.
_PRIVATE_SUFFIXES = tuple(s.lower() for s in (
    ", Private Browsing", "— Private Browsing", "- Private Browsing",
    "— Mozilla Firefox Private Browsing",  # Firefox's title on Windows
    ", Privates Surfen", "— Privater Modus", ", navigation privée", "— Navigation privée",
    ", navegación privada", "— Navegación privada", ", navigazione privata", "— Navigazione anonima",
    ", navegação privada", "— Navegação privativa", ", privé-venster", "— Privénavigatie",
    ", privat surfning", "— Privat surfning", ", Privat nettlesing", ", yksityinen selaus",
    "— Yksityinen selaus", ", przeglądanie prywatne", "— Tryb prywatny", ", Penelusuran Pribadi",
    ", Pelayaran Peribadi", ", zasebno brskanje", ", privat browser",
))


def is_private_window(title: str) -> bool:
    if _CHROMIUM_PRIVATE.search(title):
        return True
    t = title.rstrip().lower()
    return t.endswith(_PRIVATE_SUFFIXES)


# ------------------------------------------------------------------ redaction

_SECRET_TOKENS = re.compile(
    r"\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}(?:\.[A-Za-z0-9_-]+)?"   # JWT
    r"|\b(?:AKIA|ASIA|ABIA|ACCA)[0-9A-Z]{16}\b"                            # AWS
    r"|\bgh[pousr]_[A-Za-z0-9]{16,}|\bgithub_pat_[A-Za-z0-9_]{20,}"        # GitHub
    r"|\bsk-(?:ant-|proj-)?[A-Za-z0-9_-]{16,}"                             # Anthropic / OpenAI
    r"|\bxox[baprse]-[A-Za-z0-9-]{10,}"                                    # Slack
    r"|\bAIza[0-9A-Za-z_-]{20,}|\bya29\.[A-Za-z0-9_-]{20,}"                # Google
    r"|\b[sr]k_(?:live|test)_[A-Za-z0-9]{16,}|\bwhsec_[A-Za-z0-9]{16,}"    # Stripe
    r"|\bglpat-[A-Za-z0-9_-]{16,}|\bnpm_[A-Za-z0-9]{30,}|\bpypi-[A-Za-z0-9_-]{30,}"
    r"|\bhf_[A-Za-z0-9]{30,}|\bdop_v1_[a-f0-9]{40,}|\bshp(?:at|ss|ca|pa)_[a-f0-9]{32}"
    r"|\bSG\.[A-Za-z0-9_-]{16,}\.[A-Za-z0-9_-]{16,}"                       # SendGrid
)
_PEM = re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----.*?(?:-----END [A-Z ]*PRIVATE KEY-----|\Z)", re.S)
_ASSIGNMENT = re.compile(
    r"""(?i)(\b(?:api[_-]?key|apikey|access[_-]?token|refresh[_-]?token|secret[_-]?key|client[_-]?secret"""
    r"""|private[_-]?key|auth[_-]?token|auth[_-]?key|password|passwd|pwd|secret|token)\b["']?[ \t]*[:=][ \t]*["']?)"""
    r"""([^\s"'`\[\]{}()<>,;]{8,})"""
)
_BEARER = re.compile(r"(?i)\b((?:authorization[ \t]*:[ \t]*)?(?:bearer|basic)[ \t]+)([A-Za-z0-9._~+/=-]{20,})")
_URL_CREDS = re.compile(r"\b([a-zA-Z][a-zA-Z0-9+.-]*://[^\s:/@]*:)[^\s@/\[]+@")
_URL = re.compile(r"\bhttps?://[^\s<>\"']+")
_SSN = re.compile(r"\b\d{3}-\d{2}-\d{4}\b")
# One-time codes: "OTP 5759", "verification code: 123456", "123456 is your login code".
_OTP_AFTER = re.compile(
    r"(?i)\b(otp|one[- ]time (?:password|code|pin)|verification code|security code|login code|sign[- ]in code|"
    r"confirmation code|auth(?:entication)? code|passcode|2fa code)\b([^\n\d]{0,30}?)(\d{4,8})\b")
_OTP_BEFORE = re.compile(
    r"(?i)\b\d{4,8}\b(?=[^\n\d]{0,12}\b(?:is|as)\s+(?:your|the)\b[^\n]{0,30}\b(?:otp|code|password|pin)\b)")
_IBAN = re.compile(r"\b[A-Z]{2}\d{2}(?:[ ]?[A-Z0-9]){11,30}\b")
_CVV = re.compile(r"(?i)\b(cvv2?|cvc2?)\b([^0-9\n]{0,8})\d{3,4}\b")
_CARD = re.compile(r"\b\d(?:[ -]?\d){12,18}\b")
_SENSITIVE_QUERY_KEY = re.compile(
    r"(?i)^(?:access[_-]?token|refresh[_-]?token|id[_-]?token|token|api[_-]?key|apikey|x[_-]api[_-]key|key"
    r"|client[_-]?secret|secret|password|passwd|pwd|auth|authorization|sig|signature|jwt|session[_-]?id"
    r"|session|sid|code)$"
)


def _luhn_ok(digits: str) -> bool:
    total = 0
    for i, ch in enumerate(reversed(digits)):
        d = int(ch)
        if i % 2:
            d = d * 2 - 9 if d > 4 else d * 2
        total += d
    return total % 10 == 0


def _iban_ok(raw: str) -> bool:
    s = raw.replace(" ", "")
    if not 15 <= len(s) <= 34:
        return False
    rearranged = s[4:] + s[:4]
    try:
        return int("".join(str(int(c, 36)) for c in rearranged)) % 97 == 1
    except ValueError:
        return False


def redact_url(url: str) -> str:
    """Strip credentials and sensitive query parameters from a URL."""
    try:
        p = urlparse(url)
    except ValueError:
        p = None
    if p and p.query:
        pairs = parse_qsl(p.query, keep_blank_values=True)
        if any(_SENSITIVE_QUERY_KEY.match(k) for k, _ in pairs):
            kept = [(k, "[redacted]" if _SENSITIVE_QUERY_KEY.match(k) else v) for k, v in pairs]
            url = urlunparse(p._replace(query=urlencode(kept, safe="[]")))
    # Last: "[redacted]" in the host part would make urlparse reject the URL.
    return _URL_CREDS.sub(r"\1[redacted]@", url)


def redact(text: str) -> str:
    if not text:
        return text
    text = _PEM.sub("[redacted secret]", text)
    text = _SECRET_TOKENS.sub("[redacted secret]", text)
    text = _BEARER.sub(r"\1[redacted]", text)
    text = _URL.sub(lambda m: redact_url(m.group(0)), text)  # before assignments, which would eat the query
    text = _URL_CREDS.sub(r"\1[redacted]@", text)
    text = _ASSIGNMENT.sub(r"\1[redacted]", text)
    text = _SSN.sub("[redacted ssn]", text)
    text = _OTP_AFTER.sub(r"\1\2[redacted code]", text)
    text = _OTP_BEFORE.sub("[redacted code]", text)
    text = _IBAN.sub(lambda m: "[redacted iban]" if _iban_ok(m.group(0)) else m.group(0), text)
    text = _CVV.sub(r"\1\2[redacted]", text)

    def card(m):
        digits = re.sub(r"\D", "", m.group(0))
        return "[redacted card]" if 13 <= len(digits) <= 19 and _luhn_ok(digits) else m.group(0)

    return _CARD.sub(card, text)
