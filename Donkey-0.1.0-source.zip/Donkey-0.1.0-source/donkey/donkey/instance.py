"""One Donkey at a time, and how other processes talk to it.

A named mutex marks the running copy. It also listens on a local socket: a second copy started
while one runs sends "show" there (the running one brings its window up) and quits; a clicked
notification's donkey:// link arrives the same way through `donkey open`. A restart starts the
new process with DONKEY_RESTART_FROM set, and the new one waits for the old to finish first.
"""
import ctypes
import logging
import os
from ctypes import wintypes

log = logging.getLogger("donkey.instance")

_kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
_kernel32.CreateMutexW.restype = wintypes.HANDLE
_kernel32.CreateMutexW.argtypes = [ctypes.c_void_p, wintypes.BOOL, wintypes.LPCWSTR]
_kernel32.OpenProcess.restype = wintypes.HANDLE
_kernel32.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
ERROR_ALREADY_EXISTS = 183
SYNCHRONIZE = 0x00100000


def _suffix() -> str:
    from . import config
    # one Donkey per Windows user, and a test copy with its own data folder beside it
    tag = os.environ.get("USERNAME", "user")
    if "DONKEY_HOME" in os.environ:  # the same in every process (hash() isn't: it's salted per process)
        import zlib
        tag += "-" + format(zlib.crc32(str(config.HOME).lower().encode("utf-8")), "08x")
    return tag


def mutex_name() -> str:
    return f"Local\\DonkeyApp-{_suffix()}"


def server_name() -> str:
    return f"DonkeyApp-{_suffix()}"


def wait_for_previous(timeout_s: float = 15.0) -> None:
    """After a restart: let the old process exit before taking over."""
    pid = os.environ.pop("DONKEY_RESTART_FROM", "")
    if not pid.isdigit():
        return
    h = _kernel32.OpenProcess(SYNCHRONIZE, False, int(pid))
    if h:
        _kernel32.WaitForSingleObject(h, int(timeout_s * 1000))
        _kernel32.CloseHandle(h)


def acquire():
    """The mutex handle if this is the only Donkey (keep it for the life of the process), else None."""
    wait_for_previous()
    h = _kernel32.CreateMutexW(None, True, mutex_name())
    if not h:
        return None
    if ctypes.get_last_error() == ERROR_ALREADY_EXISTS:
        _kernel32.CloseHandle(h)
        return None
    return h


def send_to_running(message: str, timeout_ms: int = 1500) -> bool:
    """Hand a message ("show", a donkey:// link) to the running Donkey. False if none answered."""
    from PySide6.QtNetwork import QLocalSocket
    sock = QLocalSocket()
    sock.connectToServer(server_name())
    if not sock.waitForConnected(timeout_ms):
        return False
    sock.write((message.strip() + "\n").encode("utf-8"))
    sock.flush()
    sock.waitForBytesWritten(timeout_ms)
    sock.disconnectFromServer()
    return True


def listen(on_message):
    """Serve messages from other Donkey processes; `on_message(text)` runs on the main thread."""
    from PySide6.QtNetwork import QLocalServer
    QLocalServer.removeServer(server_name())  # a stale one left by a crash
    server = QLocalServer()
    server.setSocketOptions(QLocalServer.UserAccessOption)

    def accept():
        while server.hasPendingConnections():
            sock = server.nextPendingConnection()
            buf = bytearray()

            def read(s=sock, b=buf):
                b.extend(bytes(s.readAll()))
                while b"\n" in b:
                    line, _, rest = bytes(b).partition(b"\n")
                    b[:] = rest
                    try:
                        on_message(line.decode("utf-8", "replace").strip())
                    except Exception:
                        log.exception("message from another Donkey")
            sock.readyRead.connect(read)
            sock.disconnected.connect(sock.deleteLater)
    server.newConnection.connect(accept)
    if not server.listen(server_name()):
        log.warning("couldn't listen for other Donkey processes: %s", server.errorString())
    return server
