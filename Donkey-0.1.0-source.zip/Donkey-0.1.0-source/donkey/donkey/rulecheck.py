"""Writing rules that can be checked in code.

A stated or learned rule can carry checks, parsed from its text ("No emoji on WhatsApp" ->
no_emoji) or given by rule mining:
  no_emoji, no_newlines, no_greeting, no_signoff, max_sentences:N, ban_phrase:<text>
After a rewrite, fix() applies the ones that can't change the meaning (dropping emoji, joining
lines, a greeting or sign-off on its own line), and broken() names the rest, which get one re-ask.
Nothing the user typed themselves counts: a rule never removes the user's own emoji or greeting.
"""
import json
import re

_NUMS = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5}
_NEG = r"(?:no|never (?:use|add|include|put|write)|don'?t (?:use|add|include|put|write)|do not (?:use|add|include|put|write)" \
       r"|avoid|skip|without|drop|leave out|remove|stop (?:using|adding))"
_PARSE = [
    ("no_emoji", re.compile(rf"(?i)\b{_NEG}\s+(?:any\s+|the\s+)?(?:\w+\s+)?emoji")),
    ("no_newlines", re.compile(rf"(?i)\b{_NEG}\s+(?:any\s+|the\s+)?(?:line ?breaks?|new ?lines?|blank lines|paragraph breaks)"
                               r"|\b(?:single|one)[- ]line (?:messages?|replies?|only)\b|\bon one line\b")),
    ("no_greeting", re.compile(rf"(?i)\b{_NEG}\s+(?:any\s+|the\s+|a\s+)?(?:greetings?|salutations?|hi/hello)\b"
                               r"|\b(?:don'?t|do not|never|stop)\s+(?:start|open|begin)(?:ing)?\s+(?:\w+\s+){0,2}with\s+"
                               r"[\"'“‘]?(?:hi|hey|hello)\b")),
    ("no_signoff", re.compile(rf"(?i)\b{_NEG}\s+(?:any\s+|the\s+|a\s+)?(?:sign-?offs?|closings?|closing lines?|signatures?)\b")),
]
_MAX_SENT = re.compile(r"(?i)\b(?:at most|max(?:imum)?(?: of)?|no more than|up to|keep (?:it|them|messages|replies) (?:to|under))\s+"
                       r"(\d|one|two|three|four|five)\s+sentences?\b")
_BAN = re.compile(r"(?i)\b(?:never|don'?t|do not|stop|avoid)\s+(?:say(?:ing)?|us(?:e|ing)|writ(?:e|ing)|start(?:ing)? with|"
                  r"open(?:ing)? with|end(?:ing)? with)\s+[\"'“‘]([^\"'”’]{2,60})[\"'”’]")
SPEC = re.compile(r"no_emoji|no_newlines|no_greeting|no_signoff|max_sentences:[1-9]|ban_phrase:.{2,60}")


_KEEP = re.compile(r"(?i)\b(?:don'?t|do not|never)\s+(?:skip|drop|remove|leave out|avoid|forget)\b")


def parse(rule: str) -> list[str]:
    """The checks a rule's own words imply ([] when it can't be checked in code)."""
    rule = _KEEP.sub("keep", rule)  # "don't skip the greeting" asks for one
    out = [name for name, rx in _PARSE if rx.search(rule)]
    if m := _MAX_SENT.search(rule):
        n = m.group(1).lower()
        out.append(f"max_sentences:{_NUMS.get(n) or int(n)}")
    out += [f"ban_phrase:{m.group(1).strip()}" for m in _BAN.finditer(rule)]
    return out


def valid(checks: list[str]) -> list[str]:
    return [c.strip() for c in checks if SPEC.fullmatch(c.strip())]


def dumps(checks: list[str]) -> str | None:
    checks = list(dict.fromkeys(valid(checks)))
    return json.dumps(checks) if checks else None


def loads(text: str | None) -> list[str]:
    try:
        return valid(json.loads(text)) if text else []
    except (ValueError, TypeError):
        return []


# ------------------------------------------------------------------ detection

_EMOJI = re.compile("[\U0001F000-\U0001FAFF☀-➿⬀-⯿️‍\U0001F1E6-\U0001F1FF]")
# A greeting word, up to three words of name, then punctuation or a line end: "Hi Sara," "Hey!" "Dear Mr. Rao,"
_GREETING = re.compile(r"(?i)^\s*(?:hi+|hey+|hello+|hiya|yo|dear|good (?:morning|afternoon|evening)|namaste|namaskar)\b"
                       r"(?:\s+(?:mr|ms|mrs|dr)\.)?(?:(?:\s+[^\s,!.?\n]+){0,3}[ \t]*(?:[,!.]+|(?=\n))|(?:\s+[^\s,!.?\n]+)?\s*$)")
_SIGNOFF = re.compile(r"(?i)^\s*(?:thanks|thank you|thx|regards|best|best regards|kind regards|warm regards|cheers|"
                      r"sincerely|yours(?: truly| sincerely)?|take care|love)[,!.]*\s*$")
_SENT = re.compile(r"[^.!?\n]+[.!?]*")


def _greeting(text: str) -> bool:
    return bool(_GREETING.match(text))


def _signoff(text: str) -> bool:
    lines = [ln for ln in text.strip().splitlines() if ln.strip()]
    # "Thanks," alone, or "Thanks,\nName" / "Best,\nName" as the last two lines
    return len(lines) > 1 and (bool(_SIGNOFF.match(lines[-1])) or
                               (len(lines) > 2 and bool(_SIGNOFF.match(lines[-2])) and len(lines[-1].split()) <= 3))


def sentences(text: str) -> int:
    return len([s for s in _SENT.findall(text) if re.search(r"\w", s)])


def _breaks(check: str, text: str) -> bool:
    name, _, arg = check.partition(":")
    if name == "no_emoji":
        return bool(_EMOJI.search(text))
    if name == "no_newlines":
        return "\n" in text.strip()
    if name == "no_greeting":
        return _greeting(text)
    if name == "no_signoff":
        return _signoff(text)
    if name == "max_sentences":
        return sentences(text) > int(arg)
    if name == "ban_phrase":
        return bool(re.search(rf"(?i)(?<!\w){re.escape(arg)}(?!\w)", text))
    return False


def broken(out: str, draft: str, checks: list[str]) -> list[str]:
    """Checks the output breaks that the user's own text didn't already break."""
    return [c for c in checks if _breaks(c, out) and not _breaks(c, draft or "")]


# ------------------------------------------------------------------ safe fixes

def fix(out: str, draft: str, checks: list[str]) -> str:
    """Apply the checks whose fix can't change what the message says."""
    for c in broken(out, draft, checks):
        if c == "no_emoji":
            out = re.sub(r"[ \t]*" + _EMOJI.pattern + r"+", "", out)
            out = re.sub(r"[ \t]+([.,!?])", r"\1", out).strip()
        elif c == "no_newlines":
            out = re.sub(r"\s*\n+\s*", " ", out.strip())
        elif c == "no_greeting":
            lines = out.strip().split("\n", 1)
            m = _GREETING.match(lines[0])
            if m and m.end() == len(lines[0].rstrip()) and len(lines) > 1 and lines[1].strip():
                out = lines[1].strip()                       # "Hi Sara," on its own line
            elif m and "\n" not in out[:m.end()] and out[m.end():].strip():
                rest = out[m.end():].lstrip(" ,!")        # "Hey, " or "Hey Rohit, " before the message
                out = rest[:1].upper() + rest[1:] if out.strip()[:1].isupper() else rest
        elif c == "no_signoff":
            lines = out.rstrip().split("\n")
            while lines and not lines[-1].strip():
                lines.pop()
            if len(lines) > 2 and _SIGNOFF.match(lines[-2]) and len(lines[-1].split()) <= 3:
                lines = lines[:-2]
            elif len(lines) > 1 and _SIGNOFF.match(lines[-1]):
                lines = lines[:-1]
            if "\n".join(lines).strip():
                out = "\n".join(lines).rstrip()
    return out
