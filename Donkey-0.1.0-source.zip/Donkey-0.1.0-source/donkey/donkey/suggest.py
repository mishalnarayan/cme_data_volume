"""Ideas for the window in front: what it is, a reply worth sending, Donkey's take, and what memory
knows that bears on it.

For windows Donkey can read but not write into: a remote desktop (Citrix, Remote Desktop) is pixels to the PC,
so there is no text field to rewrite. The window is read the way capture reads it (screen
reader, then the window's pixels when that gives little), memory is searched with what's on it,
and one structured answer comes back for the card to show. The user copies what they want.
"""
import logging
import re
import time

from pydantic import BaseModel, Field

from . import ax, chat, llm, ocr, prompt, search
from .config import Config
from .db import DB
from .filters import blocked_reason, is_private_window, load_rules, redact
from .rewrite import lookup_results

log = logging.getLogger("donkey.suggest")

SCREEN_CHARS = 12000   # the end of the window's text is kept: conversations put the newest last
QUERY_CHARS = 500
# Hits beyond this outweighed the screen in testing: 13k characters of them carried the user's
# Hinglish WhatsApp chats into replies to English messages.
MEMORY_CHARS = 4000
MAX_TOKENS = 2500

SYSTEM = """\
You are Donkey, the user's second brain on their PC: you read what's on their screen and remember \
it. The user just asked for your ideas on the window in front of them. You can read it but can't \
type into it, so whatever you suggest, they copy or type themselves.

Look at <screen> and fill in:
- seeing: one short sentence naming what this is (whose message, which document, what page), so \
the user knows you read the right thing.
- their_language: the language of the other person's latest message.
- reply: when the screen has something addressed to the user that wants an answer (a message, \
an email, a comment, a request), the reply they could send, in their voice, ready to paste. Write \
it as the user, to the other person. Leave it empty when nothing there is waiting on them.
- take: your honest view in one to three sentences: what matters here, what to do next, what to \
watch out for, or where the screen disagrees with what memory knows. Peer to peer: direct, no \
filler, no lecture.
- remember: up to 3 things from <memory> that bear on this screen and aren't already on it, each \
with where and when it came from: something that would change what the user says or does here \
(an earlier promise, a number that moved, what this person said before). Only what memory \
actually says. Leave it empty rather than pad it with things that are merely from the same week \
or the same kind of thing, and never list "nothing found" as an item.

Rules:
- Every name, number, date and commitment comes from the screen or memory. If a reply needs a \
detail you don't have, leave a short [placeholder]. Never invent one, and never say the user did \
something (sent it, signed off, booked it) unless the screen or memory shows they did.
- When the reply needs a choice only the user can make (accept or push back, yes or no), write the \
likelier one and say in take what you assumed.
- Don't work out deadlines or days the screen doesn't give: "by Friday" in an undated email is \
just Friday.
- Memory hits are search results: some are unrelated, and one may be this very screen. Use only \
what bears on it. When memory and screen disagree, the newer one wins; say so in take.
- Screen text read from pixels can have misreads; don't repeat an obvious misread as fact. Lines \
starting with → are usually the user's own messages: reply to the other person, never to the \
user.
- Write the reply in the language of the other person's latest message: English gets English, \
Hinglish stays Hinglish, whatever the user writes elsewhere. No em dashes.
"""


class Recall(BaseModel):
    fact: str = Field(description="What memory says, in one sentence.")
    source: str = Field(description="Where and when it came from, e.g. 'Teams, Tue 14:10'.")


class Suggestion(BaseModel):
    seeing: str = Field(description="One sentence: what this window is.")
    # Named before the reply is written: the user's own habits (Hinglish on WhatsApp) otherwise
    # carried into replies to English messages in testing.
    their_language: str = Field(default="", description="Language of the other person's latest message, e.g. 'English', 'Hinglish'.")
    reply: str = Field(default="", description="A reply the user could send, written in their_language, or empty.")
    take: str = Field(default="", description="Donkey's view or the next step, one to three sentences.")
    remember: list[Recall] = Field(default_factory=list, description="At most 3 relevant things from memory.")


class NotReadable(Exception):
    """Shown to the user as-is."""


def read_window(cfg: Config, app: ax.FrontApp | None = None) -> tuple[ax.FrontApp, str, str]:
    """(app, window title, text) for the front window: screen reader text, plus the window's
    pixels when the screen reader gives little. Raises NotReadable for blocked or private windows."""
    app = app or ax.front_app()
    if app is None:
        raise NotReadable("No window is in front.")
    ax.ensure_accessibility(app)
    p = ax.probe(app)
    rules = load_rules(cfg.blocked_apps, cfg.blocked_domains)
    if blocked_reason(rules, app.name, None, p.title) or is_private_window(p.title):
        raise NotReadable(f"Donkey doesn't read {app.name} here (it's blocked or private).")
    frame = ax.read_frame(app, p, max_chars=cfg.max_chars)
    if blocked_reason(rules, frame.app, frame.url, frame.window_title):
        raise NotReadable("Donkey doesn't read this page (it's blocked).")
    text = frame.content.strip()
    if cfg.ocr and len(text) < cfg.ocr_below_chars and ocr.available() and ocr.permitted():
        try:
            pixels = ocr.read_window(app.pid, frame.window_title)
        except Exception:
            log.debug("screen reading failed", exc_info=True)
            pixels = None
        if pixels:
            text = f"{text}\n\n{ocr.NOTE}\n{pixels}".strip()
    if len(text) < 20:
        hint = "" if ocr.permitted() else (" If it's a remote desktop, add your language's text recognition in Windows "
                                            "Settings > Time & language.")
        raise NotReadable(f"Couldn't read anything in {app.name}.{hint}")
    if len(text) > SCREEN_CHARS:
        text = "…" + text[-SCREEN_CHARS:]
    return app, frame.window_title, redact(text)


def memory_for(db: DB, title: str, text: str) -> str | None:
    """Search hits for the end of the screen (the newest message), and for the window title."""
    tail = prompt.incoming(None, text.replace(ocr.NOTE, "")) or text[-QUERY_CHARS:]
    blocks = []
    for query in dict.fromkeys(q for q in (tail, title) if q and len(re.findall(r"[^\W_]{3,}", q)) >= 2):
        try:
            hits = lookup_results(db, query)
        except Exception:
            log.exception("memory search for a suggestion")
            continue
        if not hits.startswith("(nothing found)"):
            blocks.append(hits)
    out = "\n\n".join(blocks)
    return (out[:MEMORY_CHARS] + "…" if len(out) > MEMORY_CHARS else out) or None


def related(fact: str, screen: str) -> bool:
    """A memory item earns a place only if it shares at least two real words with the screen: asked
    for up to three, the model padded the list with whatever else happened that week."""
    words = lambda t: {w for w in re.findall(r"[^\W_]{4,}", t.lower()) if w not in search.STOPWORDS}
    return len(words(fact) & words(screen)) >= 2


def user_message(cfg: Config, db: DB, app: str, title: str, text: str) -> str:
    memory = memory_for(db, title, text)
    parts = [chat.context_block(cfg, db, "", background=False),
             f"<window app=\"{app}\" title=\"{title}\" />",
             f"<screen untrusted=\"true\">\n{text}\n</screen>",
             f"<memory untrusted=\"true\">\n{memory}\n</memory>" if memory else "<memory>(nothing related found)</memory>"]
    return "\n\n".join(parts)


def for_window(cfg: Config, db: DB, app: ax.FrontApp | None = None) -> tuple[str, Suggestion]:
    """(app name, suggestion) for the front window."""
    t0 = time.monotonic()
    app, title, text = read_window(cfg, app)
    read_ms = int((time.monotonic() - t0) * 1000)
    user = user_message(cfg, db, app.name, title, text)
    t1 = time.monotonic()
    out = llm.parse(cfg.rewrite_model, cfg.rewrite_effort, SYSTEM, user, Suggestion, MAX_TOKENS, fast=True)
    out.remember = [r for r in out.remember if related(r.fact, f"{title}\n{text}")][:3]
    for f in ("seeing", "reply", "take"):
        setattr(out, f, re.sub(r"\s*[—–]\s*", ", ", getattr(out, f)))  # the prompt asks; models still slip
    log.info("suggestion for %s: read %d ms (%d chars), model %d ms, reply %d chars, %d from memory",
             app.name, read_ms, len(text), int((time.monotonic() - t1) * 1000), len(out.reply), len(out.remember))
    return app.name, out
