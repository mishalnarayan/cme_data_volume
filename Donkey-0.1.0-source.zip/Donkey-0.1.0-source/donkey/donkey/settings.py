"""Settings (a view in the Donkey window, journal.py): which model Donkey talks to (OpenRouter,
OpenAI, Claude, LM Studio or any OpenAI-compatible server), its key, and your name. Saving writes
config.json and switches over without a restart. It opens by itself at launch when no model is set up."""
import copy
import json
import logging
import time
import urllib.error
import urllib.request

from . import config

log = logging.getLogger("donkey")

# One entry per choice in the window. The key is the providers block it writes in config.json.
PRESETS = {
    "openrouter": {
        "label": "OpenRouter", "kind": "openai", "key": True,
        "endpoint": "https://openrouter.ai/api/v1/chat/completions",
        "key_url": "https://openrouter.ai/keys",
        "blurb": "Hundreds of models from every lab with one key. Pay as you go.",
        "suggest": "deepseek/deepseek-v4.1-flash", "reasoning_effort": "none",
        "extra": {"provider": {"quantizations": ["int8", "fp8", "fp16", "bf16", "fp32", "unknown"]}},
        "fast_extra": {"provider": {"sort": "latency"}},
        "background_extra": {"provider": {"sort": "price"}},
    },
    "openai": {
        "label": "OpenAI", "kind": "openai", "key": True,
        "endpoint": "https://api.openai.com/v1/chat/completions",
        "key_url": "https://platform.openai.com/api-keys",
        "blurb": "GPT models with an OpenAI API key.",
        "suggest": "", "reasoning_effort": "",
    },
    "anthropic": {
        "label": "Claude", "kind": "anthropic", "key": True,
        "endpoint": "https://api.anthropic.com",
        "key_url": "https://console.anthropic.com/settings/keys",
        "blurb": "Anthropic's Claude models with a Claude API key.",
        "suggest": "claude-haiku-5-5",
    },
    "lmstudio": {
        "label": "LM Studio", "kind": "openai", "key": False,
        "endpoint": "http://localhost:1234/v1/chat/completions",
        "key_url": "https://lmstudio.ai",
        "blurb": "A model running on this PC. Nothing leaves it.",
        "suggest": "", "reasoning_effort": "", "timeout": 600,
    },
    "custom": {
        "label": "Other", "kind": "openai", "key": None,
        "endpoint": "http://localhost:11434/v1/chat/completions",
        "blurb": "Any OpenAI-compatible server: Ollama, Groq, Together, vLLM, a work proxy…",
        "suggest": "", "reasoning_effort": "",
    },
}


def in_use(cfg) -> str:
    """"deepseek-v4.1-flash · OpenRouter": the model doing the work, for the menu."""
    label = PRESETS.get(cfg.llm_use, {}).get("label") or cfg.llm_use or "Claude"
    return f"{cfg.chat_model.split('/')[-1]} · {label}"


def _mask(key: str) -> str:
    return f"{key[:6]}…{key[-4:]}" if len(key) > 14 else ("•" * len(key) if key else "")


def state() -> dict:
    """What the window shows: each choice as saved, the one in use, and the name."""
    raw = config.read_raw()
    blocks = raw.get("providers", {})
    use = str(raw.get("llm", {}).get("use", ""))
    out = {}
    for name, p in PRESETS.items():
        b = blocks.get(name, {})
        key = str(b.get("api_key", ""))
        if name == "anthropic" and not key:
            from .llm import KEY_PATH
            import os
            key = os.environ.get("ANTHROPIC_API_KEY", "") or (KEY_PATH.read_text().strip() if KEY_PATH.exists() else "")
        out[name] = {
            "label": p["label"], "blurb": p["blurb"], "needs_key": p["key"], "key_url": p.get("key_url", ""),
            "endpoint": str(b.get("endpoint") or p["endpoint"]),
            "model": str(b.get("model") or p.get("suggest", "")),
            "key_hint": _mask(key), "has_key": bool(key), "saved": name in blocks,
        }
    return {"use": use if use in PRESETS else "custom" if use else "openrouter", "providers": out,
            "name": str(raw.get("identity", {}).get("name", "")), "account_name": config.account_name(),
            "config_path": str(config.CONFIG_PATH), "data_path": str(config.HOME)}


def _stored_key(name: str) -> str:
    return str(config.read_raw().get("providers", {}).get(name, {}).get("api_key", ""))


def _models_url(endpoint: str) -> str:
    base = endpoint.rstrip("/")
    for tail in ("/chat/completions", "/completions"):
        if base.endswith(tail):
            base = base[: -len(tail)]
    return base + "/models"


def _get_json(url: str, headers: dict, timeout: float = 15) -> dict:
    req = urllib.request.Request(url, headers={"User-Agent": "Donkey", **headers})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read())


def models(name: str, endpoint: str, key: str) -> dict:
    """The models a provider offers, for the picker: {models: [{id, label, note}]} or {error}."""
    p = PRESETS.get(name, PRESETS["custom"])
    key = key or _stored_key(name)
    try:
        if p["kind"] == "anthropic":
            if not key:
                from .llm import KEY_PATH
                import os
                key = os.environ.get("ANTHROPIC_API_KEY", "") or (KEY_PATH.read_text().strip() if KEY_PATH.exists() else "")
            if not key:
                return {"error": "Paste your Claude key first."}
            data = _get_json("https://api.anthropic.com/v1/models?limit=100",
                             {"x-api-key": key, "anthropic-version": "2023-06-01"})
            return {"models": [{"id": m["id"], "label": m.get("display_name") or m["id"], "note": ""}
                               for m in data.get("data", [])]}
        headers = {"Authorization": f"Bearer {key}"} if key else {}
        data = _get_json(_models_url(endpoint), headers)
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):
            return {"error": "The key was rejected. Check it and try again."}
        return {"error": f"The server answered {e.code}."}
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        if name == "lmstudio":
            return {"error": "LM Studio isn't answering. Open it, load a model, and turn on the server "
                             "(Developer tab > Start server)."}
        return {"error": f"Couldn't reach {endpoint}: {getattr(e, 'reason', e)}"}
    except ValueError:
        return {"error": "That address didn't answer like an OpenAI-compatible server."}
    rows = []
    for m in data.get("data", data if isinstance(data, list) else []):
        if not isinstance(m, dict) or not m.get("id"):
            continue
        note = []
        if ctx := m.get("context_length"):
            note.append(f"{int(ctx) // 1000}k context")
        price = m.get("pricing") or {}
        try:
            inp, outp = float(price.get("prompt", 0)) * 1e6, float(price.get("completion", 0)) * 1e6
            if price:
                note.append("free" if inp == outp == 0 else f"${inp:.2f} / ${outp:.2f} per M tokens")
        except (TypeError, ValueError):
            pass
        if "embed" in m["id"].lower():
            continue  # embedding models can't chat
        if name == "openai" and not any(s in m["id"] for s in ("gpt", "o1", "o3", "o4", "o5")):
            continue  # embeddings, whisper, dall-e, tts…
        rows.append({"id": m["id"], "label": m.get("name") or m["id"], "note": " · ".join(note)})
    if name == "lmstudio":
        return _lmstudio_loaded(endpoint, rows)
    return {"models": rows}


def _lmstudio_loaded(endpoint: str, rows: list) -> dict:
    """LM Studio answers any model id with whatever it has loaded, so the picker says which ones are
    loaded (its own /api/v0/models knows) and puts them first."""
    base = _models_url(endpoint).rsplit("/v1/", 1)[0]
    try:
        loaded = {m["id"] for m in _get_json(base + "/api/v0/models", {}, timeout=5).get("data", [])
                  if m.get("state") == "loaded"}
    except Exception:
        return {"models": rows}
    for r in rows:
        if r["id"] in loaded:
            r["note"] = " · ".join(x for x in ("loaded", r["note"]) if x)
    rows.sort(key=lambda r: r["id"] not in loaded)
    return {"models": rows, "loaded": [r["id"] for r in rows if r["id"] in loaded]}


def _candidate(name: str, endpoint: str, key: str, model: str) -> tuple[dict, dict]:
    """The config.json layout with this choice in use, and the block it writes."""
    p = PRESETS.get(name, PRESETS["custom"])
    raw = copy.deepcopy(config.read_raw())
    old = raw.get("providers", {}).get(name, {})
    models = [model] + [m for m in old.get("models", []) if m != model][:5]
    block = {"kind": p["kind"], "model": model, "models": models}
    if p["kind"] == "openai":
        block["endpoint"] = endpoint.strip() or p["endpoint"]
    for k in ("reasoning_effort", "extra", "fast_extra", "background_extra", "timeout"):
        if k in p and k not in old:
            block[k] = p[k]
    if key:
        block["api_key"] = key.strip()
    raw.setdefault("llm", {})["use"] = name
    raw.setdefault("providers", {})[name] = {**old, **block}
    return raw, block


def test(name: str, endpoint: str, key: str, model: str) -> dict:
    """One tiny request with these settings: {ok, ms, reply} or {ok: False, error}."""
    if not model:
        return {"ok": False, "error": "Pick a model first."}
    if name == "lmstudio":
        have = models(name, endpoint, key)
        ids = [m["id"] for m in have.get("models", [])]
        if ids and model not in ids:
            loaded = have.get("loaded") or []
            hint = f" The loaded one is {loaded[0]}." if loaded else " Load one in LM Studio first."
            return {"ok": False, "error": f"LM Studio doesn't have {model}.{hint}"}
    raw, _ = _candidate(name, endpoint, key, model)
    cfg = config.from_raw(raw)
    t0 = time.monotonic()
    try:
        if cfg.llm_provider == "anthropic":
            import anthropic
            from .llm import KEY_PATH
            k = cfg.llm_api_key or (KEY_PATH.read_text().strip() if KEY_PATH.exists() else None)
            client = anthropic.Anthropic(api_key=k, timeout=30.0) if k else anthropic.Anthropic(timeout=30.0)
            msg = client.messages.create(model=model, max_tokens=20,
                                         messages=[{"role": "user", "content": "Say hello in three words."}])
            reply = "".join(b.text for b in msg.content if getattr(b, "type", "") == "text")
        else:
            from . import openai_compat
            reply = openai_compat.complete(cfg, model, "low", "Answer in at most five words.",
                                           "Say hello in three words.", max_tokens=400)
    except Exception as e:  # shown in the window as-is
        msg = getattr(e, "message", None) or str(e) or type(e).__name__
        if "cut off" in msg:  # a thinking model spent the tiny test budget reasoning: it answered, so it works
            return {"ok": True, "ms": int((time.monotonic() - t0) * 1000), "reply": "(still thinking when the test stopped)"}
        if "authentication" in msg.lower() or "401" in msg:
            msg = "The key was rejected. Check it and try again."
        return {"ok": False, "error": msg[:300]}
    return {"ok": True, "ms": int((time.monotonic() - t0) * 1000), "reply": reply.strip()[:120]}


def save_name(user_name: str) -> None:
    raw = config.read_raw()
    raw.setdefault("identity", {})["name"] = user_name.strip()
    config._write(raw)


def save(name: str, endpoint: str, key: str, model: str, user_name: str | None) -> None:
    _, block = _candidate(name, endpoint, key, model)
    config.save_model(name, block, user_name)
