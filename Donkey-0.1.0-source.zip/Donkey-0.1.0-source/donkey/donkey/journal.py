"""The Donkey window: Home, Timeline, the memory map and Chat (your day at a glance, every day
written up, what Donkey knows, and asking it), plus Settings and the first-run welcome.

One window (a Qt web view, same bridge pattern as the chat window). The page asks for data with
{type: "get", what, args, rid} and gets dk.reply(rid, data) back; everything is read from the
database here, so the page holds no state worth keeping. Ribbons are drawn from the screens'
own seen-from/seen-until times, so they are minute-accurate, unlike the hourly time ledger.
"""
import base64
import datetime as dt
import json
import logging
import re
import shutil
import sqlite3
import tempfile
import threading
import time
from pathlib import Path

from . import capture, chatwindow, daypage, memory, onboarding, timeproj
from .config import Config
from .db import DB

log = logging.getLogger("donkey.journal")

GAP_S = 90          # two sightings of one app this close are one stretch on the ribbon
FOCUS_GAP_S = 180   # a break shorter than this doesn't end a focus stretch
MIN_SEG_S = 20


# ------------------------------------------------------------------ small helpers

def _day_bounds(day: str) -> tuple[float, float]:
    d = dt.datetime.fromisoformat(day)
    return d.timestamp(), (d + dt.timedelta(days=1)).timestamp()


def _today() -> str:
    return dt.date.today().isoformat()


def _first_sentence(text: str, limit: int = 220) -> str:
    text = re.sub(r"[*_`#>]", "", text or "").strip()
    text = re.sub(r"^\s*-\s*", "", text)
    m = re.match(r"(.+?[.!?])(\s|$)", text, re.S)
    s = (m.group(1) if m else text.split("\n")[0]).strip()
    return s if len(s) <= limit else s[:limit - 1].rstrip() + "…"


def _page_opening(body: str) -> str:
    """The opening sentence of a day page (the line after its # heading)."""
    for line in (body or "").splitlines()[1:]:
        if line.strip() and not line.startswith("#"):
            return line.strip()
    return ""


# ------------------------------------------------------------------ ribbon

def ribbon(db: DB, day: str) -> list[dict]:
    """The day's stretches of foreground use: [{s, e, app, domain, title}], merged when one app
    continues across sightings."""
    start, end = _day_bounds(day)
    rows = db.query("SELECT app, domain, window_title, captured_at, last_seen_at, duration_s FROM snapshots "
                    "WHERE last_seen_at >= ? AND captured_at < ? AND app NOT LIKE 'pid %' ORDER BY captured_at", (start, end))
    segs: list[dict] = []
    for r in rows:
        s = max(r["captured_at"], start)
        e = min(max(r["last_seen_at"], r["captured_at"] + min(r["duration_s"] or 0, 60), s + MIN_SEG_S), end)
        key = (r["app"], r["domain"] or "")
        if segs and (segs[-1]["app"], segs[-1]["domain"]) == key and s - segs[-1]["e"] <= GAP_S:
            segs[-1]["e"] = max(segs[-1]["e"], e)
            if r["window_title"]:
                segs[-1]["title"] = r["window_title"]
            continue
        if segs and s < segs[-1]["e"]:  # overlap with a different app: the newer one has the screen
            segs[-1]["e"] = s
            if segs[-1]["e"] - segs[-1]["s"] < 1:
                segs.pop()
        segs.append({"s": s, "e": e, "app": r["app"], "domain": r["domain"] or "", "title": r["window_title"] or ""})
    return [x for x in segs if x["e"] - x["s"] >= 1]


def focus_stats(segs: list[dict]) -> dict:
    """Longest stretch without a break, and how often the app in front changed."""
    best = (0.0, 0.0, 0.0)
    run_s = run_e = None
    switches = 0
    for i, x in enumerate(segs):
        if i and x["app"] != segs[i - 1]["app"]:
            switches += 1
        if run_e is not None and x["s"] - run_e <= FOCUS_GAP_S:
            run_e = max(run_e, x["e"])
        else:
            run_s, run_e = x["s"], x["e"]
        if run_e - run_s > best[0]:
            best = (run_e - run_s, run_s, run_e)
    return {"longest": best[0], "longest_from": best[1], "longest_to": best[2], "switches": switches}


# ------------------------------------------------------------------ icons

_icons: dict[str, str | None] = {}
_favicons: dict[str, str | None] | None = None
_icon_lock = threading.Lock()


def _exe_path(exe: str | None) -> str | None:
    """Where an app's .exe is: seen running this session, else Windows' App Paths, else the PATH."""
    if not exe:
        return None
    from . import ax
    if p := ax.known_path(exe):
        return p
    import winreg
    for root in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
        try:
            with winreg.OpenKey(root, rf"Software\Microsoft\Windows\CurrentVersion\App Paths\{exe}") as k:
                p = str(winreg.QueryValueEx(k, "")[0]).strip('"')
                if Path(p).exists():
                    return p
        except OSError:
            continue
    return shutil.which(exe)


def app_icon(db: DB, app: str) -> str | None:
    """The app's own icon (from its .exe) as a small PNG data URL (cached). Main thread."""
    with _icon_lock:
        if app in _icons:
            return _icons[app]
    url = None
    try:
        from PySide6.QtCore import QBuffer, QByteArray, QFileInfo, QIODevice
        from PySide6.QtWidgets import QFileIconProvider
        row = db.query("SELECT bundle_id FROM snapshots WHERE app = ? AND bundle_id IS NOT NULL AND bundle_id != '' "
                       "ORDER BY captured_at DESC LIMIT 1", (app,))
        path = _exe_path(row[0]["bundle_id"]) if row else None
        if path:
            pix = QFileIconProvider().icon(QFileInfo(path)).pixmap(64, 64)
            if not pix.isNull():
                data = QByteArray()
                buf = QBuffer(data)
                buf.open(QIODevice.WriteOnly)
                pix.save(buf, "PNG")
                url = "data:image/png;base64," + base64.b64encode(bytes(data)).decode()
    except Exception:
        log.debug("icon for %s", app, exc_info=True)
    with _icon_lock:
        _icons[app] = url
    return url


def _favicon_dbs() -> list[Path]:
    """Chrome's and Edge's favicon caches (default profiles), Chrome first."""
    import os
    local = Path(os.environ.get("LOCALAPPDATA") or Path.home() / "AppData" / "Local")
    return [p for p in (local / "Google/Chrome/User Data/Default/Favicons",
                        local / "Microsoft/Edge/User Data/Default/Favicons",
                        local / "BraveSoftware/Brave-Browser/User Data/Default/Favicons") if p.exists()]


def _load_favicons() -> dict[str, str | None]:
    """Site icons from the browsers' own favicon caches (a copy, since the browser keeps it open):
    host -> data URL."""
    out: dict[str, str | None] = {}
    for src in reversed(_favicon_dbs()):  # the first browser's icons win
        try:
            with tempfile.TemporaryDirectory() as tmp:
                dst = Path(tmp) / "f.db"
                shutil.copy(src, dst)
                con = sqlite3.connect(dst)
                rows = con.execute("""SELECT m.page_url, b.image_data, b.width FROM icon_mapping m
                                      JOIN favicon_bitmaps b ON b.icon_id = m.icon_id
                                      WHERE b.width BETWEEN 16 AND 96 ORDER BY b.width""").fetchall()
                con.close()
            for page, data, _w in rows:  # ordered by width, so the largest wins
                host = re.sub(r"^www\.", "", (re.match(r"https?://([^/:]+)", page or "") or [None, ""])[1])
                if host and data:
                    out[host] = "data:image/png;base64," + base64.b64encode(data).decode()
        except Exception:
            log.debug("favicons from %s", src, exc_info=True)
    return out

def site_icon(domain: str) -> str | None:
    global _favicons
    with _icon_lock:
        if _favicons is None:
            _favicons = _load_favicons()
        d = re.sub(r"^www\.", "", domain)
        if d in _favicons:
            return _favicons[d]
        for host, url in _favicons.items():  # m.youtube.com for youtube.com and the like
            if host.endswith("." + d) or d.endswith("." + host):
                return url
    return None


def icons(db: DB, apps: list[str], sites: list[str]) -> dict:
    return {"apps": {a: app_icon(db, a) for a in apps}, "sites": {s: site_icon(s) for s in sites}}


# ------------------------------------------------------------------ aggregates

def _active_by_day(db: DB, days: int) -> dict[str, float]:
    since = (dt.date.today() - dt.timedelta(days=days)).isoformat()
    return {r["d"]: r["s"] for r in db.query(
        "SELECT substr(hour_key, 1, 10) AS d, SUM(seconds) AS s FROM time_ledger WHERE hour_key >= ? GROUP BY d",
        (since,))}


def top_used(db: DB, since: str, until: str | None = None, n: int = 8) -> dict:
    until = until or "9999"
    apps = db.query("SELECT app AS name, SUM(seconds) AS s FROM time_ledger WHERE hour_key >= ? AND hour_key < ? "
                    "AND app NOT LIKE 'pid %' GROUP BY app ORDER BY s DESC LIMIT ?", (since, until, n))
    sites = db.query("SELECT domain AS name, SUM(seconds) AS s FROM time_ledger WHERE hour_key >= ? AND hour_key < ? "
                     "AND domain != '' GROUP BY domain ORDER BY s DESC LIMIT ?", (since, until, n))
    rep = timeproj.report(db, since, None if until == "9999" else until)
    # Apps and sites together: time in a browser counts for the site it was on, so the browser itself
    # only keeps the time it had no page in front.
    mixed = db.query("SELECT CASE WHEN domain != '' THEN domain ELSE app END AS name, domain != '' AS site, "
                     "SUM(seconds) AS s FROM time_ledger WHERE hour_key >= ? AND hour_key < ? AND app NOT LIKE 'pid %' "
                     "GROUP BY name ORDER BY s DESC LIMIT ?", (since, until, n))
    ranked = lambda d: [{"name": k, "s": v} for k, v in sorted(d.items(), key=lambda kv: -kv[1])][:n]
    return {"all": [dict(r) for r in mixed], "apps": [dict(r) for r in apps], "sites": [dict(r) for r in sites],
            "projects": ranked(rep["projects"]), "categories": ranked(rep["categories"])}


def heat(db: DB, days: int = 7) -> list[dict]:
    """Minutes per hour for the last `days` days, oldest first."""
    today = dt.date.today()
    out = []
    for i in range(days - 1, -1, -1):
        d = (today - dt.timedelta(days=i)).isoformat()
        hours = [0.0] * 24
        for r in db.query("SELECT substr(hour_key, 12, 2) AS h, SUM(seconds) AS s FROM time_ledger "
                          "WHERE hour_key LIKE ? GROUP BY h", (d + "T%",)):
            hours[int(r["h"])] = round(r["s"] / 60, 1)
        out.append({"day": d, "hours": hours})
    return out


def _counts(db: DB, start: float, end: float) -> dict:
    one = lambda sql: db.query(sql, (start, end))[0]["n"]
    return {"rewrites": one("SELECT COUNT(*) AS n FROM rewrites WHERE ts >= ? AND ts < ? AND error IS NULL"),
            "sent": one("SELECT COUNT(*) AS n FROM sends WHERE ts >= ? AND ts < ? AND kind = 'sent'"),
            "chats": one("SELECT COUNT(*) AS n FROM chat_messages WHERE created_at >= ? AND created_at < ? AND role = 'user'"),
            "screens": one("SELECT COUNT(*) AS n FROM snapshots WHERE captured_at >= ? AND captured_at < ?")}


def changes(db: DB, hours: float = 72, limit: int = 6) -> list[dict]:
    """Claims whose value changed recently: what someone said before, and now."""
    since = time.time() - hours * 3600
    rows = db.query("""SELECT c.id, c.subject, c.topic, c.value, c.said_by, c.source, c.said_at, c.kind,
                              o.value AS old_value, o.said_by AS old_by, o.said_at AS old_at
                       FROM claims c JOIN claims o ON o.id = c.replaces
                       WHERE c.said_at >= ? AND c.current = 1 ORDER BY c.said_at DESC""", (since,))
    out, seen = [], set()
    for r in rows:
        if r["value"].strip().lower() == (r["old_value"] or "").strip().lower():
            continue
        if r["said_by"] == "the user":  # their own drafts and plans: they know
            continue
        key = (r["subject"].lower(), r["topic"].lower())
        if key in seen:
            continue
        seen.add(key)
        out.append(dict(r))
        if len(out) >= limit:
            break
    return out


def plate(db: DB) -> dict:
    now = time.time()
    loops = db.query("SELECT id, kind, summary, person, due_at FROM open_loops WHERE status = 'open' AND "
                     "(todo_id IS NULL OR todo_id NOT IN (SELECT id FROM todos WHERE done = 0)) "  # already a to-do
                     "ORDER BY (due_at IS NULL), due_at, updated_at DESC LIMIT 12")
    todos = db.query("SELECT id, text, source, created_at FROM todos WHERE done = 0 ORDER BY created_at DESC LIMIT 12")
    # why Donkey ticked it, shown under the to-do (nothing when the user ticked it)
    done_today = db.query("SELECT t.id, t.text, t.done_at, NULLIF(l.close_evidence, 'marked done by the user') AS why "
                          "FROM todos t LEFT JOIN open_loops l ON l.id = t.loop_id "
                          "WHERE t.done = 1 AND t.done_at >= ? ORDER BY t.done_at DESC", (_day_bounds(_today())[0],))
    meetings = db.query("SELECT title, starts_at, location FROM attention_items WHERE kind = 'meeting' AND status = 'active' "
                        "AND starts_at >= ? AND starts_at < ? ORDER BY starts_at LIMIT 5", (now - 1800, now + 3 * 86400))
    rems = []
    try:
        from . import reminders
        for r in reminders.listing(db):
            nxt = reminders.next_fire(dict(r), dt.datetime.now())
            if nxt:
                rems.append({"id": r["id"], "title": r["title"], "at": nxt.timestamp(), "repeat": r["repeat"]})
        rems.sort(key=lambda r: r["at"])
    except Exception:
        log.debug("reminders", exc_info=True)
    return {"loops": [dict(r) for r in loops], "todos": [dict(r) for r in todos],
            "done_today": [dict(r) for r in done_today], "meetings": [dict(r) for r in meetings], "reminders": rems[:5]}


def _now_doing(db: DB) -> dict | None:
    r = db.query("SELECT app, domain, window_title, captured_at, last_seen_at FROM snapshots "
                 "ORDER BY last_seen_at DESC LIMIT 1")
    return dict(r[0]) if r else None


# ------------------------------------------------------------------ pages

def home(cfg: Config, db: DB) -> dict:
    today = _today()
    start, end = _day_bounds(today)
    segs = ribbon(db, today)
    by_day = _active_by_day(db, 8)
    prior = [s for d, s in by_day.items() if d != today]
    week_ago = (dt.date.today() - dt.timedelta(days=6)).isoformat()
    month_ago = (dt.date.today() - dt.timedelta(days=29)).isoformat()
    paused = capture.paused_until()
    return {
        "name": (cfg.user_name or "").split()[0] if cfg.user_name else "",
        "now": time.time(),
        "today": today,
        "paused": None if paused is None else (-1 if paused == float("inf") else paused),
        "doing": _now_doing(db),
        "ribbon": segs,
        "hours_summarized": [r["k"][11:13] for r in db.query(
            "SELECT period_key AS k FROM chronicle WHERE period = 'hour' AND period_key LIKE ?", (today + "T%",))],
        "active": by_day.get(today, 0.0),
        "avg": sum(prior) / len(prior) if prior else None,
        "focus": focus_stats(segs),
        "counts": _counts(db, start, end),
        "top": {"today": top_used(db, today + "T00"), "week": top_used(db, week_ago + "T00"),
                "month": top_used(db, month_ago + "T00")},
        "heat": heat(db, 7),
        "plate": plate(db),
        "changes": changes(db),
        "days": days(db, limit=6),
        "progress": onboarding.progress(db),
        "key_label": key_label(cfg.rewrite_key),
    }


def key_label(key: str) -> str:
    """"right_alt" → "Right Alt", for the page (Mac names in an old config count as their Windows twins)."""
    from .keys import KEY_NAMES, resolve
    try:
        return KEY_NAMES[resolve(key)]
    except (ValueError, KeyError):
        return key.replace("_", " ").title()


def _key(key: str) -> str:
    from .keys import resolve
    try:
        return resolve(key)
    except ValueError:
        return key


def days(db: DB, limit: int = 400, query: str = "") -> list[dict]:
    """Every day with activity, newest first: active time, a 24-hour density, its opening line."""
    rows = db.query("SELECT substr(hour_key, 1, 10) AS d, substr(hour_key, 12, 2) AS h, SUM(seconds) AS s "
                    "FROM time_ledger GROUP BY d, h")
    per: dict[str, list[float]] = {}
    for r in rows:
        per.setdefault(r["d"], [0.0] * 24)[int(r["h"])] = r["s"] / 60
    for r in db.query("SELECT DISTINCT substr(period_key, 1, 10) AS d FROM chronicle WHERE period = 'hour'"):
        per.setdefault(r["d"], [0.0] * 24)
    match = None
    if query.strip():
        q = " ".join(f'"{w}"' for w in re.findall(r"\w+", query)) or '""'
        match = {}
        for r in db.query("SELECT c.period, c.period_key, snippet(chronicle_fts, 0, '[', ']', '…', 12) AS snip "
                          "FROM chronicle_fts JOIN chronicle c ON c.id = chronicle_fts.rowid "
                          "WHERE chronicle_fts MATCH ? AND c.period IN ('hour', 'day') ORDER BY rank LIMIT 200", (q,)):
            match.setdefault(r["period_key"][:10], r["snip"])
    pages = {r["day"]: r["body"] for r in db.query("SELECT day, body FROM day_pages")}
    day_sums = {r["k"]: r["summary"] for r in db.query("SELECT period_key AS k, summary FROM chronicle WHERE period = 'day'")}
    weeks = {r["k"]: r["summary"] for r in db.query("SELECT period_key AS k, summary FROM chronicle WHERE period = 'week'")}
    out = []
    for d in sorted(per, reverse=True):
        if match is not None and d not in match:
            continue
        top = db.query("SELECT app, domain, SUM(seconds) AS s FROM time_ledger WHERE hour_key LIKE ? "
                       "AND app NOT LIKE 'pid %' GROUP BY app ORDER BY s DESC LIMIT 6", (d + "T%",))
        opening = _page_opening(pages.get(d, "")) or _first_sentence(day_sums.get(d, ""))
        if not opening:
            first = db.query("SELECT summary FROM chronicle WHERE period = 'hour' AND period_key LIKE ? "
                             "ORDER BY length(summary) DESC LIMIT 1", (d + "T%",))
            opening = _first_sentence(first[0]["summary"]) if first else ""
        wk = dt.date.fromisoformat(d).isocalendar()
        out.append({"day": d, "active": sum(per[d]) * 60, "hours": [round(m, 1) for m in per[d]],
                    "opening": opening, "has_page": d in pages, "apps": [r["app"] for r in top],
                    "week": f"{wk[0]}-W{wk[1]:02d}", "snippet": (match or {}).get(d, "")})
        if len(out) >= limit:
            break
    return out


def weeks(db: DB) -> dict:
    return {r["k"]: r["summary"] for r in db.query("SELECT period_key AS k, summary FROM chronicle WHERE period = 'week'")}


def day(cfg: Config, db: DB, d: str) -> dict:
    start, end = _day_bounds(d)
    segs = ribbon(db, d)
    hours = db.query("SELECT period_key, summary FROM chronicle WHERE period = 'hour' AND period_key LIKE ? "
                     "ORDER BY period_key", (d + "T%",))
    mins = daypage._minutes(db, d)
    page = db.query("SELECT body, built_from FROM day_pages WHERE day = ?", (d,))
    newest = db.query("SELECT MAX(created_at) AS t FROM chronicle WHERE period = 'hour' AND period_key LIKE ?",
                      (d + "T%",))[0]["t"]
    claims = db.query("SELECT subject, topic, value, said_by, kind, replaces FROM claims WHERE hour_key LIKE ? "
                      "AND current = 1 ORDER BY said_at LIMIT 30", (d + "T%",))
    people = db.query("""SELECT p.slug, p.title, p.page_type, COUNT(*) AS n FROM wiki_mentions m
                         JOIN wiki_pages p ON p.slug = m.slug WHERE m.hour_key LIKE ?
                         GROUP BY p.slug ORDER BY n DESC LIMIT 16""", (d + "T%",))
    day_sum = db.query("SELECT summary FROM chronicle WHERE period = 'day' AND period_key = ?", (d,))
    ordered = [x["day"] for x in days(db)]  # newest first
    i = ordered.index(d) if d in ordered else -1
    return {
        "day": d, "today": d == _today(), "ribbon": segs, "focus": focus_stats(segs),
        "active": sum(m for m, _ in mins.values()) * 60,
        "hours": [{"h": r["period_key"][11:13], "summary": r["summary"],
                   "mins": round(mins.get(r["period_key"][11:13], (0, []))[0]),
                   "where": mins.get(r["period_key"][11:13], (0, []))[1]} for r in hours],
        "page": page[0]["body"] if page else None,
        "stale": bool(page and newest and page[0]["built_from"] < newest),
        "summary": day_sum[0]["summary"] if day_sum else None,
        "can_build": bool(hours),
        "claims": list({(r["subject"], r["topic"]): dict(r) for r in claims}.values()),  # latest per topic
        "people": [dict(r) for r in people],
        "counts": _counts(db, start, end),
        "top": top_used(db, d + "T00", (dt.date.fromisoformat(d) + dt.timedelta(days=1)).isoformat() + "T00", 6),
        "newer": ordered[i - 1] if i > 0 else None,
        "older": ordered[i + 1] if 0 <= i < len(ordered) - 1 else None,
    }


def build_page(cfg: Config, db: DB, d: str) -> str | None:
    """Write (or rewrite) the day's summary page now: the "Summarize this day" button."""
    db.execute("DELETE FROM day_pages WHERE day = ?", (d,))
    return daypage.get(cfg, db, d, build=True)


def complete_todo(db: DB, todo_id: int, done: bool) -> None:
    if done:
        from . import loops
        loops.complete_todo(db, todo_id)
    else:
        db.execute("UPDATE todos SET done = 0, done_at = NULL WHERE id = ?", (todo_id,))


def close_loop(db: DB, loop_id: int) -> None:
    from . import loops
    loops.close_loop(db, loop_id, "done", "closed from Home")


def add_todo(db: DB, text: str) -> int:
    from . import loops
    return loops.add_todo(db, text.strip(), source="user")


def day_context(db: DB, d: str, limit: int = 9000) -> str:
    """What a question about one day is answered from: its page, or its hour summaries."""
    head = f"(The question is about {dt.date.fromisoformat(d):%A, %#d %B %Y}. What Donkey recorded that day:)"
    page = db.query("SELECT body FROM day_pages WHERE day = ?", (d,))
    hours = db.query("SELECT period_key, summary FROM chronicle WHERE period = 'hour' AND period_key LIKE ? "
                     "ORDER BY period_key", (d + "T%",))
    parts = [page[0]["body"]] if page else []
    parts += [f"## {r['period_key'][11:13]}:00\n{r['summary']}" for r in hours]
    body = "\n\n".join(parts) or "(nothing recorded that day)"
    return head + "\n" + (body if len(body) <= limit else body[:limit] + "\n…")


def day_thread(db: DB, d: str, create: bool = False) -> int | None:
    """The chat thread for questions asked from a day in the Timeline (one per day)."""
    from . import chat
    key = f"day_thread:{d}"
    row = db.query("SELECT value FROM job_state WHERE key = ?", (key,))
    if row and db.query("SELECT 1 FROM chat_threads WHERE id = ?", (int(row[0]["value"]),)):
        return int(row[0]["value"])
    if not create:
        return None
    tid = chat.new_thread(db, f"About {dt.date.fromisoformat(d):%A, %#d %b}")
    db.execute("INSERT OR REPLACE INTO job_state (key, value, updated_at) VALUES (?, ?, ?)", (key, str(tid), time.time()))
    return tid


def day_messages(db: DB, d: str) -> list[dict]:
    from . import chat
    tid = day_thread(db, d)
    if tid is None:
        return []
    return [{"role": m["role"], "content": re.sub(r"^\[About [^\]]+\]\s*", "", m["content"])}
            for m in chat.messages(db, tid)]


def snapshot(cfg: Config, db: DB) -> str:
    """A static copy of the page with today's data built in (for testing in a browser)."""
    data = {"home": home(cfg, db), "days": days(db), "weeks": weeks(db)}
    data["dayData"] = {d["day"]: day(cfg, db, d["day"]) for d in data["days"][:10]}
    apps = sorted({x["app"] for d in data["dayData"].values() for x in d["ribbon"]}
                  | {a["name"] for p in data["home"]["top"].values() for a in p["apps"]}
                  | {a for d in data["days"] for a in d["apps"]})
    sites = sorted({s["name"] for p in data["home"]["top"].values() for s in p["sites"]})
    data["icons"] = icons(db, apps, sites)
    from . import memory_map
    data["map"] = memory_map.build(db)
    from . import settings
    data["settings"] = settings.state()
    from . import llm, overlay
    data["perms"] = onboarding.permissions(cfg)
    data["welcome"] = {"key": _key(cfg.rewrite_key), "key_label": key_label(cfg.rewrite_key), **data["perms"],
                       "settings": data["settings"], "has_model": llm.has_credentials(), "login": False,
                       "first_name": data["home"]["name"]}
    data["creature"] = overlay._html(60, "free")
    return json.dumps(data, default=str)


# ------------------------------------------------------------------ the window

TEMPLATE_PATH = Path(__file__).parent / "assets" / "journal.html"


def page_html(data: str | None = None) -> str:
    logo = "data:image/svg+xml;base64," + base64.b64encode((TEMPLATE_PATH.parent / "creature.svg").read_bytes()).decode()
    lexend = "data:font/woff2;base64," + base64.b64encode((TEMPLATE_PATH.parent / "fonts" / "lexend-200_300-latin.woff2").read_bytes()).decode()
    return TEMPLATE_PATH.read_text().replace("/*LOGO*/", logo).replace("/*LEXEND*/", lexend).replace("/*DATA*/null", (data or "null").replace("</", "<\\/"))


LIGHT_BG, DARK_BG = "#f7f4ef", "#1a1816"  # the page's --bg, so the window never flashes white
GEOMETRY_PATH = None


def _geometry_path():
    from . import config
    return config.HOME / "window.json"


class JournalWindow:
    """Home and Timeline in a normal window (not floating). Reads run on the main thread (all
    under ~20 ms); writing a day up and day questions run on threads and report back."""

    def __init__(self, cfg: Config, db: DB, on_capture_change=None, on_settings_saved=None,
                 hooks: dict | None = None):
        from PySide6.QtGui import QColor, QIcon

        from . import overlay, winui

        self.cfg, self.db = cfg, db
        self.on_capture_change = on_capture_change or (lambda: None)
        self.on_settings_saved = on_settings_saved or (lambda: None)
        # from the app, for the welcome: restart(), key_kind(), login() / set_login(on)
        self.hooks = hooks or {}
        self.ready, self.visible, self.pending = False, False, []
        self.view = "home"
        memory.on_busy = lambda on: self._later("updating", on)
        self.chat = chatwindow.ChatPane(cfg, db, call=lambda fn, *a: self._call("chat", fn, list(a)),
                                        on_unread=lambda n: self._call("chatUnread", n))
        self.asking: dict[str, threading.Event] = {}

        win = winui.Panel(1180, 820, focusable=True, on_top=False, tool=False, frameless=False,
                          translucent=False, title="Donkey")
        win.setMinimumSize(720, 520)
        win.setWindowIcon(QIcon(str(overlay.ASSETS / "icon.png")))
        win.web.page().setBackgroundColor(QColor(DARK_BG if winui.apps_are_dark() else LIGHT_BG))
        win.on_message("donkey", self._on_message)
        win.on_close_request = self._closing
        self._restore_geometry(win)
        win.load(page_html())
        self.win = win

    def _restore_geometry(self, win) -> None:
        from . import winui
        try:
            x, y, w, h = json.loads(_geometry_path().read_text())["frame"]
            sx, sy, sw, sh = winui.work_area(x + w / 2, y + h / 2)
            if sx <= x + w / 2 <= sx + sw and sy <= y + h / 2 <= sy + sh:
                win.set_frame(x, y, min(w, sw), min(h, sh))
                return
        except (OSError, ValueError, KeyError, TypeError):
            pass
        self._center(win)

    @staticmethod
    def _center(win) -> None:
        from . import winui
        x, y, w, h = win.frame()
        cx, cy = winui.cursor()
        sx, sy, sw, sh = winui.work_area(cx, cy)
        w, h = min(w, sw - 40), min(h, sh - 40)
        win.set_frame(sx + (sw - w) / 2, sy + (sh - h) / 2, w, h)

    def _closing(self) -> bool:
        self.visible = False
        try:
            g = self.win.normalGeometry()
            _geometry_path().write_text(json.dumps({"frame": [g.x(), g.y(), g.width(), g.height()]}))
        except OSError:
            pass
        return True

    # -------------------------------------------------------------- showing

    def open(self, view: str | None = None, day: str | None = None, rise: bool = False) -> None:
        if rise and not self.visible:
            self._rise()
        else:
            if self.win.isMinimized():
                self.win.showNormal()
            self.win.present(activate=True)
        self.visible = True
        if view:
            self._call("show", view, day)
        else:
            self.js("dk.refresh()")

    def _rise(self) -> None:
        """Come in centred, fading up from a little below (the size stays put, so the page inside
        doesn't lay itself out again mid-move)."""
        from . import motion
        self._center(self.win)
        x, y, w, h = self.win.frame()
        self.win.set_alpha(0.0)
        self.win.set_frame(x, y + 22, w, h)
        self.win.present(activate=True)
        self._riser = motion.Tween(self.win)
        self._riser.run(alpha=1.0, frame=(x, y, w, h), duration=0.9)

    @property
    def is_key(self) -> bool:
        return self.visible and bool(self.win.isActiveWindow())

    def open_chat(self, thread_id: int | None = None, nudge_id: int | None = None, new: bool = False) -> None:
        self.chat.show(thread_id=thread_id, nudge_id=nudge_id, new=new)
        self.open("chat")

    def close(self) -> None:
        self.win.close()

    def js(self, code: str) -> None:
        if not self.ready:
            self.pending.append(code)
            return
        self.win.js(code)

    def _call(self, fn: str, *args) -> None:
        self.js(f"dk.{fn}({', '.join(json.dumps(a, ensure_ascii=False, default=str) for a in args)})")

    def _later(self, fn: str, *args) -> None:
        from . import winui
        winui.call_after(self._call, fn, *args)
    # -------------------------------------------------------------- page bridge

    def _get(self, what: str, args: dict):
        if what == "home":
            return home(self.cfg, self.db)
        if what == "days":
            return days(self.db, query=str(args.get("q") or ""))
        if what == "weeks":
            return weeks(self.db)
        if what == "day":
            d = str(args.get("day") or "")
            if not re.fullmatch(r"\d{4}-\d\d-\d\d", d):
                return None
            out = day(self.cfg, self.db, d)
            out["chat"] = day_messages(self.db, d)
            out["asking"] = d in self.asking
            return out
        if what == "map":
            from . import memory_map
            return memory_map.build(self.db)
        if what == "settings":
            from . import settings
            return settings.state()
        if what == "welcome":
            from . import llm, settings
            h = home(self.cfg, self.db)
            return {"key": _key(self.cfg.rewrite_key), "key_label": key_label(self.cfg.rewrite_key),
                    **self._perms(), "settings": settings.state(), "has_model": llm.has_credentials(),
                    "login": bool(self.hooks.get("login", lambda: False)()), "first_name": h["name"]}
        if what == "perms":
            return self._perms()
        if what == "creature":
            from . import overlay
            return overlay._html(60, "free")
        if what == "chat_page":
            return chatwindow._html()
        if what == "icons":
            return icons(self.db, [str(a) for a in args.get("apps") or []][:80],
                         [str(s) for s in args.get("sites") or []][:80])
        return None

    def _perms(self) -> dict:
        return onboarding.permissions(self.cfg, self.hooks.get("key_kind", lambda: None)())

    def front(self) -> None:
        """Back in front (after a trip to Windows Settings)."""
        self.win.present(activate=True)

    def _on_message(self, msg: dict) -> None:
        if msg.get("src") == "chat":
            self.chat.on_message(msg)
            return
        kind = msg.get("type")
        if kind == "view":
            self.view = str(msg.get("view") or "")
        elif kind == "ready":
            self.ready = True
            for code in self.pending:
                self.win.js(code)
            self.pending.clear()
            self._call("updating", memory._busy.locked())  # a pass may already be running
        elif kind == "controls":
            pass  # the window has its own title bar on Windows
        elif kind == "get":
            try:
                data = self._get(str(msg.get("what")), dict(msg.get("args") or {}))
            except Exception:
                log.exception("journal %s", msg.get("what"))
                data = None
            self._call("reply", msg.get("rid"), data)
        elif kind == "pause":
            capture.pause(None) if msg.get("on") else capture.resume()
            self.on_capture_change()
        elif kind == "todo":
            complete_todo(self.db, int(msg["id"]), bool(msg.get("done")))
        elif kind == "loop_done":
            close_loop(self.db, int(msg["id"]))
        elif kind == "add_todo" and str(msg.get("text") or "").strip():
            add_todo(self.db, str(msg["text"]))
        elif kind == "update":
            threading.Thread(target=self._update_bg, name="update", daemon=True).start()
        elif kind == "build":
            d = str(msg.get("day") or "")
            threading.Thread(target=self._build_bg, args=(d,), name="daypage", daemon=True).start()
        elif kind == "ask":
            self._ask(str(msg.get("day") or ""), str(msg.get("text") or "").strip())
        elif kind == "stop_ask":
            if (ev := self.asking.get(str(msg.get("day") or ""))) is not None:
                ev.set()
        elif kind == "open_chat":
            d = str(msg.get("day") or "")
            self.open_chat(thread_id=day_thread(self.db, d))
        elif kind == "save_name":
            from . import settings
            settings.save_name(str(msg.get("user_name") or ""))
            self.on_settings_saved()
        elif kind in ("models", "test", "save"):
            threading.Thread(target=self._settings_bg, args=(kind, msg), name="settings", daemon=True).start()
        elif kind == "welcome_step":
            onboarding.mark(str(msg.get("step") or "") or None)
        elif kind == "welcome_done":
            onboarding.mark(done=True)
        elif kind == "perm_request":
            onboarding.request(str(msg.get("which") or ""))
        elif kind == "perm_reset":
            if onboarding.reset(str(msg.get("which") or "")) and "restart" in self.hooks:
                self.hooks["restart"]()  # listed again by the new process when it asks
        elif kind == "perm_reveal":
            onboarding.reveal_holder()
        elif kind == "front":
            self.front()
        elif kind == "restart" and "restart" in self.hooks:
            self.hooks["restart"]()
        elif kind == "login_item" and "set_login" in self.hooks:
            self.hooks["set_login"](bool(msg.get("on")))
        elif kind == "reveal":
            from . import config as config_mod, winui
            what = str(msg.get("what"))
            if what == "config":
                winui.edit_text_file(config_mod.CONFIG_PATH)
            elif what == "log":
                winui.edit_text_file(config_mod.HOME / "donkey.log")
            elif what == "data":
                winui.open_path(config_mod.HOME)
        elif kind == "open_url" and str(msg.get("url") or "").startswith(("https://", "http://")):
            from . import winui
            winui.open_url(str(msg["url"]))
        elif kind == "copy":
            from .deliver import set_clipboard_text
            set_clipboard_text(str(msg.get("text") or ""))

    def _settings_bg(self, kind: str, msg: dict) -> None:
        """Model lists, tries and saves touch the network or the config file: off the main thread."""
        from . import settings, winui
        a = {k: str(msg.get(k) or "").strip() for k in ("name", "endpoint", "key", "model", "user_name")}
        try:
            if kind == "models":
                out = settings.models(a["name"], a["endpoint"], a["key"])
            elif kind == "test":
                out = settings.test(a["name"], a["endpoint"], a["key"], a["model"])
            else:
                # the welcome's model step has no name field: leave the name alone
                settings.save(a["name"], a["endpoint"], a["key"], a["model"],
                              a["user_name"] if "user_name" in msg else None)
                winui.call_after(self.on_settings_saved)
                out = {"ok": True, "state": settings.state()}
        except Exception as e:
            log.exception("settings %s", kind)
            out = {"ok": False, "error": str(e)}
        self._later("reply", msg.get("rid"), out)

    def _update_bg(self) -> None:
        from . import llm
        try:
            done = memory.update_now(self.cfg, self.db)
            self._later("updated", True, None if done is not None else "An update is already running.")
        except llm.LLMError as e:
            self._later("updated", False, str(e))
        except Exception as e:
            log.exception("update")
            self._later("updated", False, f"Something went wrong: {e}")

    def _build_bg(self, d: str) -> None:
        from . import llm
        try:
            ok = build_page(self.cfg, self.db, d) is not None
            self._later("built", d, ok, None if ok else "Nothing to write up for this day yet.")
        except llm.LLMError as e:
            self._later("built", d, False, str(e))
        except Exception as e:
            log.exception("day page")
            self._later("built", d, False, f"Something went wrong: {e}")

    def _ask(self, d: str, text: str) -> None:
        if not text or not re.fullmatch(r"\d{4}-\d\d-\d\d", d) or d in self.asking:
            return
        cancel = threading.Event()
        self.asking[d] = cancel
        threading.Thread(target=self._ask_bg, args=(d, text, cancel), name="daychat", daemon=True).start()

    def _ask_bg(self, d: str, text: str, cancel: threading.Event) -> None:
        from . import chat, llm
        label = f"{dt.date.fromisoformat(d):%A %#d %B}"
        try:
            tid = day_thread(self.db, d, create=True)
            llm.prewarm()
            out = chat.send(self.cfg, self.db, tid, f"[About {label}] {text}",
                            lambda k, data=None: self._later("askEv", d, k, data), cancel,
                            context=day_context(self.db, d))
            self._later("askEv", d, "done", {"text": out["text"]})
        except llm.Cancelled:
            self._later("askEv", d, "error", {"text": "Stopped."})
        except llm.LLMError as e:
            self._later("askEv", d, "error", {"text": str(e)})
        except Exception as e:
            log.exception("day question")
            self._later("askEv", d, "error", {"text": f"Something went wrong: {e}"})
        finally:
            self.asking.pop(d, None)
