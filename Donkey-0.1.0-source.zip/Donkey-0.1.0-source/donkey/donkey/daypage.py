"""The daily summary page: one readable page per day.

Opening sentence, work sessions with how long each was, focus, done, unfinished and three next
steps. The model groups the day's hours into sessions; the durations come from tracked foreground
time in code, never from the model. Built from the hour summaries, so it is cached until a newer
hour summary exists for that day. Finished days are built by the memory pass; today on demand.
"""
import datetime as dt
import logging
import time

from pydantic import BaseModel, Field

from . import chronicle, llm, loops
from .config import Config
from .db import DB

log = logging.getLogger("donkey.daypage")

SYSTEM = """\
Write the daily summary page for one day of a person's computer activity, speaking to them as \
"you". You get the hourly summaries, the minutes they were actually active in each hour with \
the apps and sites used, signals noticed that day, and their open loops and to-dos.

- opening: one sentence on what the day was mostly about.
- sessions: the work sessions in order. A session is a run of consecutive hours spent on one \
thread of work. Give each a short name, its first and last hour exactly as listed (sessions \
never share an hour), and one line on what happened. Leave out idle hours and pure \
entertainment unless that was the day.
- focus: one or two sentences on where attention went and what broke it up.
- done: things finished, sent or produced, one concrete line each. Nothing that was only read.
- unfinished: things started, promised or waiting on someone that are still open.
- next_steps: exactly three, each an outcome to reach ("Rahul has the revised quote"), not a \
chore ("open the file"), drawn from the unfinished items and open loops.

Only use what is given; when the material is thin, say less. Under 300 words in total."""


class Session(BaseModel):
    name: str
    first_hour: str = Field(description="HH, as listed in the input")
    last_hour: str = Field(description="HH, as listed in the input")
    what: str


class DayPage(BaseModel):
    opening: str
    sessions: list[Session]
    focus: str
    done: list[str]
    unfinished: list[str]
    next_steps: list[str]


def _minutes(db: DB, day: str) -> dict[str, tuple[float, list[str]]]:
    """Per hour ("HH"): active minutes and the surfaces with the most time."""
    out: dict[str, tuple[float, list[str]]] = {}
    for r in db.query("SELECT hour_key, app, domain, seconds FROM time_ledger WHERE hour_key LIKE ? "
                      "ORDER BY hour_key, seconds DESC", (day + "T%",)):
        h = r["hour_key"][11:13]
        mins, where = out.get(h, (0.0, []))
        if r["seconds"] >= 120 and len(where) < 4:
            where = where + [r["domain"] or r["app"]]
        out[h] = (mins + r["seconds"] / 60, where)
    return out


def _fmt_minutes(m: float) -> str:
    m = round(m)
    return f"{m // 60} h {m % 60:02d} min" if m >= 60 else f"{m} min"


def material(db: DB, day: str) -> tuple[str, list[str], dict]:
    hours = db.query("SELECT period_key, summary FROM chronicle WHERE period = 'hour' AND period_key LIKE ? "
                     "ORDER BY period_key", (day + "T%",))
    mins = _minutes(db, day)
    keys = [h["period_key"][11:13] for h in hours]
    parts = ["Hours (HH: active minutes, main apps/sites, then the summary):"]
    for h in hours:
        hh = h["period_key"][11:13]
        m, where = mins.get(hh, (0.0, []))
        parts.append(f"## {hh}: {m:.0f} min active{' in ' + ', '.join(where) if where else ''}\n{h['summary']}")
    flags = db.query("SELECT kind, text FROM flags WHERE hour_key LIKE ? ORDER BY hour_key", (day + "T%",))
    parts.append("Signals that day:\n" + ("\n".join(f"- {f['kind']}: {f['text']}" for f in flags) or "(none)"))
    open_ = loops.open_loops(db)[:15]
    parts.append("Open loops now:\n" + ("\n".join(f"- [{r['kind']}] {r['summary']}" for r in open_) or "(none)"))
    todos = db.query("SELECT text FROM todos WHERE done = 0 ORDER BY created_at DESC LIMIT 10")
    parts.append("Open to-dos:\n" + ("\n".join(f"- {t['text']}" for t in todos) or "(none)"))
    return "\n\n".join(parts), keys, mins


def render(day: str, page: DayPage, keys: list[str], mins: dict) -> str:
    d = dt.date.fromisoformat(day)
    lines = [f"# {d:%A}, {d.day} {d:%B %Y}", "", page.opening.strip(), ""]
    taken: set[str] = set()
    sessions = []
    for s in page.sessions:
        if s.first_hour not in keys or s.last_hour not in keys:
            continue  # an hour that isn't in the material: the model made it up
        span = [k for k in keys if s.first_hour <= k <= s.last_hour and k not in taken]
        if not span:
            continue
        taken |= set(span)
        active = sum(mins.get(k, (0.0, []))[0] for k in span)
        sessions.append(f"- {span[0]}:00–{int(span[-1]) + 1:02d}:00 · {_fmt_minutes(active)} active · "
                        f"**{s.name.strip()}**: {s.what.strip()}")
    if sessions:
        lines += ["## Work sessions", *sessions, ""]
    lines += ["## Focus", page.focus.strip(), ""]
    for title, items in (("Done", page.done), ("Unfinished", page.unfinished)):
        if items:
            lines += [f"## {title}", *(f"- {i.strip()}" for i in items), ""]
    if page.next_steps:
        lines += ["## Next steps", *(f"{n}. {s.strip()}" for n, s in enumerate(page.next_steps[:3], 1)), ""]
    return "\n".join(lines).rstrip() + "\n"


def get(cfg: Config, db: DB, day: str, build: bool = True) -> str | None:
    """The page for a day, rebuilt when a newer hour summary exists. None when nothing is summarized."""
    newest = db.query("SELECT MAX(created_at) AS t FROM chronicle WHERE period = 'hour' AND period_key LIKE ?",
                      (day + "T%",))[0]["t"]
    row = db.query("SELECT body, built_from FROM day_pages WHERE day = ?", (day,))
    if newest is None:
        return row[0]["body"] if row else None
    if row and row[0]["built_from"] >= newest or not build or not llm.has_credentials():
        return row[0]["body"] if row else None
    text, keys, mins = material(db, day)
    user = f"Day: {day} ({dt.date.fromisoformat(day):%A})\n\n{text}"
    page: DayPage = llm.parse(cfg.memory_model, "low", SYSTEM, user, DayPage, max_tokens=2000)
    body = render(day, page, keys, mins)
    db.execute("INSERT OR REPLACE INTO day_pages (day, body, built_from, created_at) VALUES (?, ?, ?, ?)",
               (day, body, newest, time.time()))
    log.info("daily summary page for %s built", day)
    return body


def pending(db: DB, today: dt.date) -> list[str]:
    """Finished days in the backfill window that have hour summaries but no current page."""
    since = (today - dt.timedelta(days=chronicle.BACKFILL_DAYS)).isoformat()
    rows = db.query("""SELECT substr(c.period_key, 1, 10) AS day, MAX(c.created_at) AS t FROM chronicle c
                       WHERE c.period = 'hour' AND c.period_key >= ? GROUP BY day""", (since,))
    built = {r["day"]: r["built_from"] for r in db.query("SELECT day, built_from FROM day_pages")}
    return [r["day"] for r in rows if r["day"] < today.isoformat() and built.get(r["day"], 0) < r["t"]]
