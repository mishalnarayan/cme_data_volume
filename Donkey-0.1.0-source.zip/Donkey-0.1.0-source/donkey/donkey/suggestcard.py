"""The ideas card: what Donkey makes of the window in front, shown beside the creature you pulled out.

A rounded panel like the edit bar, floating over everything. It takes the keyboard while it's up
(for Esc and editing the reply) and gives it back to the window you were in when it closes. It
shows what Donkey read, a reply you can edit and copy (into a remote desktop, the copy reaches the
remote clipboard), Donkey's take, and what memory knows. All methods run on the main thread.
"""
import json
import logging

from . import motion, overlay, winui

log = logging.getLogger("donkey.suggestcard")

W, START_H, MAX_H = 400, 120, 640
GAP = 6
HEAD_H = 42  # the header row, where the card is dragged from
CLOSE_W = 40  # the × at its right end stays clickable


def copy(text: str) -> None:
    from .deliver import set_clipboard_text
    set_clipboard_text(text)


class SuggestCard:
    """Callbacks: on_again() asks for another suggestion; on_close() when the card goes away."""

    def __init__(self, on_again, on_close):
        self.on_again, self.on_close = on_again, on_close
        self.is_open = False
        self.shown = 0  # each opening, so a fade-out that finishes late doesn't hide the next one
        self.height = START_H
        self.anchor = None  # (centre x, top, bottom) of the creature: the card hangs below, or sits above
        self.pinned = False  # dragged somewhere by hand: stays there instead of following the creature
        self.came_from = 0  # the window that had the keyboard before the card took it
        panel = winui.Panel(W, START_H, focusable=True)
        panel.on_message("donkey", self._on_message)
        panel.load(_html())
        panel.add_drag_strip(HEAD_H, CLOSE_W, on_moved=self._dragged)
        self.panel = panel
        self.fader, self.mover = motion.Tween(panel), motion.Tween(panel)

    def js(self, code: str) -> None:
        self.panel.js(code)

    def _on_message(self, msg: dict) -> None:
        kind = msg.get("type")
        if kind == "copy":
            copy(str(msg.get("text") or ""))
        elif kind == "again":
            self.on_again()
        elif kind == "close":
            self.close()
        elif kind == "height":
            self._resize(float(msg.get("h") or START_H))

    def _dragged(self) -> None:
        self.pinned = True
        self.mover.stop()

    # -------------------------------------------------------------- placement

    def open(self, anchor: tuple[float, float, float], app: str) -> None:
        """Show 'reading' by the anchor (centre x, top, bottom) and take the keyboard (for Esc)."""
        self.anchor = anchor
        if not self.panel.isVisible():
            self.pinned = False  # a fresh card comes back to the creature; "Try again" stays put
            fg = winui.foreground()
            if fg and fg != self.panel.hwnd:
                self.came_from = fg
        self.shown += 1
        self._place(animate=False)
        self.js(f"setReading({json.dumps(app)})")
        if not self.panel.isVisible():
            self.panel.set_alpha(0.0)
        self.panel.present(activate=True)
        self.fader.run(alpha=1.0, duration=0.16)
        self.is_open = True

    def _place(self, animate: bool = True) -> None:
        """Hang under the anchor (or sit above it near the bottom of the screen). Growing for new
        content glides; following the creature as it's dragged doesn't. Once dragged by hand, the
        card keeps its top edge where it was put and grows downward from there."""
        if self.pinned:
            fx, fy, _, _ = self.panel.frame()
            x, y = overlay.clamp_to_screen(fx, fy, W, self.height)
        else:
            cx, top, bottom = self.anchor
            _, sy, _, sh = winui.work_area(cx, bottom)
            y = bottom + GAP
            if y + self.height > sy + sh - 40:
                y = top - GAP - self.height
            x, y = overlay.clamp_to_screen(cx - W / 2, y, W, self.height)
        rect = (round(x), round(y), W, self.height)
        if animate and self.panel.isVisible():
            self.mover.run(frame=rect, duration=0.2)
        else:
            self.mover.stop()  # a move while growing: jump to the end
            self.panel.set_frame(*rect)

    def _resize(self, h: float) -> None:
        cx = self.anchor[0] if self.anchor else 0
        _, _, _, sh = winui.work_area(cx, self.anchor[1] if self.anchor else 0)
        room = sh - 80 if sh else MAX_H
        h = max(80.0, min(float(MAX_H), room, h))  # taller content scrolls inside the card
        if abs(h - self.height) < 1 or not self.anchor:
            return
        self.height = h
        self._place()

    # -------------------------------------------------------------- content

    def show(self, app: str, s) -> None:
        data = {"app": app, "seeing": s.seeing, "reply": s.reply, "take": s.take,
                "remember": [{"fact": r.fact, "source": r.source} for r in s.remember]}
        self.js(f"setIdeas({json.dumps(data)})")

    def error(self, message: str) -> None:
        self.js(f"setError({json.dumps(message)})")

    def close(self) -> None:
        if not self.is_open:
            return
        self.is_open = False
        shown = self.shown
        if self.panel.isActiveWindow() and self.came_from:
            winui.activate(self.came_from)  # the keyboard goes back where it was
        self.fader.run(alpha=0.0, duration=0.14, then=lambda: self.panel.dismiss() if shown == self.shown else None)
        self.on_close()

def _html() -> str:
    svg = (overlay.ASSETS / "creature.svg").read_text()
    return f"""<!doctype html><html><head><meta charset="utf-8"><style>
:root {{ --ink:#24211e; --muted:rgba(36,33,30,.58); --accent:#8a6e52; --field:rgba(255,255,255,.55); --err:#d64545; --line:rgba(36,33,30,.12); }}
@media (prefers-color-scheme: dark) {{ :root {{ --ink:#f3efe9; --muted:rgba(243,239,233,.62); --field:rgba(255,255,255,.08); --err:#ff8a8a; --line:rgba(255,255,255,.12); }} }}
html, body {{ margin:0; height:100%; background:transparent; color:var(--ink); overflow:hidden;
  font:13.5px/1.42 "Inter", "Segoe UI Variable Text", "Segoe UI", system-ui, sans-serif; -webkit-user-select:none; }}
.card {{ height:100%; display:flex; flex-direction:column; }}
.head {{ display:flex; align-items:center; gap:8px; padding:10px 14px 4px 12px; flex:none; cursor:default; }}
/* Content taller than the card scrolls under the header, fading out at the edge that has more. */
.body {{ flex:1 1 auto; min-height:0; overflow-y:auto; overscroll-behavior:contain; padding:0 14px 14px 12px; }}
.body.more-below {{ -webkit-mask-image:linear-gradient(to bottom, #000 calc(100% - 28px), transparent); }}
.body.more-above {{ -webkit-mask-image:linear-gradient(to top, #000 calc(100% - 20px), transparent); }}
.body.more-above.more-below {{ -webkit-mask-image:linear-gradient(to bottom, transparent, #000 20px, #000 calc(100% - 28px), transparent); }}
.body::-webkit-scrollbar {{ width:9px; }}
.body::-webkit-scrollbar-thumb {{ background:var(--line); border-radius:9px; border:2px solid transparent; background-clip:padding-box; }}
#critter {{ width:30px; height:28px; flex:none; }}
#critter svg {{ width:100%; height:100%; overflow:visible; }}
{overlay.DONKEY_CSS}
.title {{ flex:1; min-width:0; font-weight:600; font-size:13px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }}
.x {{ border:0; background:none; color:var(--muted); font-size:17px; cursor:pointer; padding:0 2px; line-height:1; }}
.seeing {{ color:var(--muted); font-size:12.5px; margin:6px 0 2px; }}
.label {{ font-size:11px; font-weight:600; letter-spacing:.04em; text-transform:uppercase; color:var(--muted); margin:10px 0 4px; }}
textarea {{ width:100%; box-sizing:border-box; resize:none; border:0; outline:none; background:var(--field);
  color:var(--ink); border-radius:10px; padding:8px 10px; font:inherit; font-size:14px; line-height:1.38;
  -webkit-user-select:text; max-height:200px; }}
.row {{ display:flex; gap:6px; justify-content:flex-end; margin-top:6px; align-items:center; }}
.row .note {{ flex:1; font-size:11.5px; color:var(--muted); }}
button.b {{ border:0; border-radius:8px; padding:4px 11px; font:inherit; font-size:12.5px; cursor:pointer;
  background:var(--field); color:var(--ink); }}
button.b.primary {{ background:var(--accent); color:#fff; }}
.take {{ -webkit-user-select:text; }}
ul {{ margin:0; padding-left:16px; }} li {{ margin:2px 0; -webkit-user-select:text; }}
.src {{ color:var(--muted); font-size:11.5px; }}
.status {{ color:var(--muted); font-size:12.5px; margin-top:6px; }}
.status.err {{ color:var(--err); }}
.hide {{ display:none; }}
@keyframes bob {{ 0%,100% {{ transform:translateY(0) }} 50% {{ transform:translateY(-2px) }} }}
@keyframes swayL {{ 0%,100% {{ transform:rotate(0) }} 50% {{ transform:rotate(-8deg) }} }}
@keyframes swayR {{ 0%,100% {{ transform:rotate(0) }} 50% {{ transform:rotate(8deg) }} }}
@keyframes blink {{ 0%,93%,100% {{ transform:scaleY(1) }} 95% {{ transform:scaleY(.1) }} }}
{winui.GLASS_CSS}
</style></head><body>
<div class="card">
  <div class="head"><div id="critter">{svg}</div><div class="title" id="title">Ideas</div>
    <button class="x" id="x" title="Close (Esc)">×</button></div>
  <div class="body" id="body">
  <div class="status" id="status"></div>
  <div id="ideas" class="hide">
    <div class="seeing" id="seeing"></div>
    <div id="replyBox"><div class="label">You could reply</div>
      <textarea id="reply" rows="2" spellcheck="true"></textarea>
      <div class="row"><span class="note" id="copied"></span><button class="b primary" id="copy">Copy</button></div></div>
    <div id="takeBox"><div class="label">My take</div><div class="take" id="take"></div></div>
    <div id="memBox"><div class="label">From memory</div><ul id="mem"></ul></div>
    <div class="row"><button class="b" id="again">Try again</button></div>
  </div>
  </div>
</div>
<script>
const $ = id => document.getElementById(id);
const post = m => window.webkit.messageHandlers.donkey.postMessage(m);
const scroller = $('body');
function edges() {{ const s = scroller;
  s.classList.toggle('more-above', s.scrollTop > 1);
  s.classList.toggle('more-below', s.scrollTop + s.clientHeight < s.scrollHeight - 1); }}
function report() {{ post({{type:'height', h: document.querySelector('.head').offsetHeight + scroller.scrollHeight}}); edges(); }}
scroller.addEventListener('scroll', edges, {{passive:true}});
window.addEventListener('resize', edges);
function grow() {{ const t = $('reply'); t.style.height = 'auto'; t.style.height = Math.min(t.scrollHeight, 200) + 'px'; }}
function setReading(app) {{ scroller.scrollTop = 0; document.body.className = 'working'; $('title').textContent = 'Reading ' + app + '…';
  $('ideas').classList.add('hide'); $('status').className = 'status'; $('status').textContent = 'Looking at the window and what I remember.'; report(); }}
function setIdeas(d) {{ scroller.scrollTop = 0; document.body.className = 'done'; setTimeout(() => {{ document.body.className = ''; }}, 1100);
  $('title').textContent = 'Ideas for ' + d.app; $('status').textContent = ''; $('seeing').textContent = d.seeing || '';
  $('replyBox').classList.toggle('hide', !d.reply); $('reply').value = d.reply || ''; $('copied').textContent = '';
  $('takeBox').classList.toggle('hide', !d.take); $('take').textContent = d.take || '';
  const mem = $('mem'); mem.innerHTML = '';
  for (const r of d.remember || []) {{ const li = document.createElement('li'); li.textContent = r.fact + ' ';
    const s = document.createElement('span'); s.className = 'src'; s.textContent = r.source; li.appendChild(s); mem.appendChild(li); }}
  $('memBox').classList.toggle('hide', !(d.remember || []).length);
  $('ideas').classList.remove('hide'); grow(); report(); }}
function setError(msg) {{ document.body.className = 'error'; $('title').textContent = 'Ideas';
  $('ideas').classList.add('hide'); $('status').className = 'status err'; $('status').textContent = msg; report(); }}
$('x').onclick = () => post({{type:'close'}});
$('again').onclick = () => post({{type:'again'}});
$('copy').onclick = () => {{ post({{type:'copy', text: $('reply').value}}); $('copied').textContent = 'Copied. Paste it where you reply.'; }};
$('reply').addEventListener('input', () => {{ grow(); report(); }});
document.addEventListener('keydown', ev => {{ if (ev.key === 'Escape') {{ ev.preventDefault(); post({{type:'close'}}); }} }});
window.addEventListener('load', report);
</script></body></html>"""
