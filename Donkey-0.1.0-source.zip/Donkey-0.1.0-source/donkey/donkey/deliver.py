"""Write a rewrite back into the field: UI Automation write, then paste, then leave it on the clipboard.

Guards run first: same app still in front, same conversation (recipient, page, window), field
unchanged since it was read. Where the field lets its text be selected, the slice is selected and
the text pasted (Ctrl+V): the app handles that like typing, so formatting around it stays and Ctrl+Z
undoes it (the Mac replaced just the selection through AX, which keeps both too). A whole new value
through the Value pattern, which wipes formatting and often undo, goes only into plain-text boxes:
first where nothing can be selected, else when the paste didn't take. A surface where a value write
reports success but changes nothing is remembered and skipped next time.
"""
import ctypes
import json
import logging
import re
import time
from ctypes import wintypes
from urllib.parse import urlparse

import win32clipboard
import win32con

from . import ax, web
from .config import HOME
from .field import Target, _label, clean_value

log = logging.getLogger("donkey.deliver")

LEARNED_PATH = HOME / "delivery.json"
# Sites whose editors (React/Lexical/Draft.js composers) need real paste events; go straight to paste.
# Paste never presses Enter, so chat apps don't send anything.
PASTE_ONLY_DOMAINS = {"linkedin.com", "outlook.office.com", "outlook.live.com", "outlook.office365.com",
                      "web.whatsapp.com", "web.telegram.org", "app.slack.com", "discord.com", "messenger.com",
                      "x.com", "instagram.com", "teams.microsoft.com", "teams.live.com"}
VK_CONTROL, VK_V, VK_A = 0x11, 0x56, 0x41
PASTE_WAIT_S = 1.5  # web composers can take about a second to show a paste in their value


class DeliveryError(Exception):
    """The text could not be placed; it is on the clipboard. Shown to the user as-is."""


def _norm(s: str | None) -> str:
    return (s or "").replace("\r\n", "\n").replace("\r", "\n").replace("\u00a0", " ")


def _learned() -> dict:
    try:
        return json.loads(LEARNED_PATH.read_text(encoding="utf-8"))
    except (FileNotFoundError, ValueError):
        return {"ax_noop": []}


def _learn_noop(surface_key: str) -> None:
    data = _learned()
    if surface_key not in data["ax_noop"]:
        data["ax_noop"].append(surface_key)
        LEARNED_PATH.write_text(json.dumps(data, indent=1), encoding="utf-8")
        log.info("learned: value write is a no-op on %s; will paste there", surface_key)


def _wait_for_value(el, accept, timeout_s: float = 0.6) -> str | None:
    """Poll the field until `accept(value)` or timeout; returns the last value read."""
    deadline = time.monotonic() + timeout_s
    value = None
    while True:
        if isinstance(el, ax.El):
            el._memo.clear()  # read it fresh
        value = _norm(ax.as_text(ax.attr(el, "AXValue")))
        if accept(value) or time.monotonic() > deadline:
            return value
        time.sleep(0.02)


def _select_slice(t: Target) -> bool:
    loc, length = t.slice_utf16
    return ax.set_attr(t.element, "AXSelectedTextRange", (loc, length))


def _is_web(t: Target) -> bool:
    return isinstance(t.element, ax.El) and str(t.element.prop(ax.P_FRAMEWORK, "") or "").lower() in ax.WEB_FRAMEWORKS


def _ax_write(t: Target, text: str) -> str | None:
    """Replace the whole value through the Value pattern; verify by reading it back. Plain-text
    boxes only: in a rich editor it would wipe the formatting, and page scripts wouldn't see it."""
    if _is_web(t) or not ax.plain_text_field(t.element) or not ax.value_settable(t.element):
        return None
    expected = _norm(t.before + text + t.after)
    if not ax.set_value(t.element, expected):
        return None
    value = _wait_for_value(t.element, lambda v: v == expected, 0.3)
    if value == expected:
        caret = ax._u16(t.before + text)
        ax.select_range(t.element, caret, 0)  # caret after the new text, as if it was typed
        return "ax_silent"
    if value == _norm(t.value):
        _learn_noop(t.surface_key)
        return None
    # The field changed but not into what we expected (editors normalise whitespace, etc.).
    # Claim delivery rather than pasting a second copy on top.
    log.info("value write landed with an unrecognised result on %s", t.surface_key)
    return "ax_unverified"


def _open_clipboard(tries: int = 20) -> bool:
    for _ in range(tries):  # another app may have it open for a moment
        try:
            win32clipboard.OpenClipboard(None)
            return True
        except Exception:
            time.sleep(0.02)
    return False


# GDI handles can't be copied as bytes; Windows makes them again from the DIB / text formats
_SKIP_FORMATS = {win32con.CF_BITMAP, win32con.CF_METAFILEPICT, win32con.CF_PALETTE, win32con.CF_ENHMETAFILE,
                 win32con.CF_OWNERDISPLAY, win32con.CF_DSPBITMAP, win32con.CF_DSPMETAFILEPICT,
                 win32con.CF_DSPENHMETAFILE, win32con.CF_TEXT, win32con.CF_OEMTEXT, win32con.CF_LOCALE}
_PRIVATE = None


def _private_formats():
    """Formats that keep our temporary text out of clipboard history and cloud clipboard."""
    global _PRIVATE
    if _PRIVATE is None:
        _PRIVATE = [win32clipboard.RegisterClipboardFormat(n) for n in (
            "ExcludeClipboardContentFromMonitorProcessing", "CanIncludeInClipboardHistory",
            "CanUploadToCloudClipboard")]
    return _PRIVATE


def set_clipboard_text(text: str, private: bool = False) -> int:
    """Put text on the clipboard; returns its sequence number (0 if the clipboard was busy)."""
    if not _open_clipboard():
        return 0
    try:
        win32clipboard.EmptyClipboard()
        win32clipboard.SetClipboardData(win32con.CF_UNICODETEXT, text)
        if private:
            # Markers only (what they hold doesn't matter, but pywin32 can't store zero bytes), and
            # a nicety: if Windows refuses them the paste still goes ahead
            for fmt in _private_formats():
                try:
                    win32clipboard.SetClipboardData(fmt, (0).to_bytes(4, "little"))
                except Exception:
                    log.debug("clipboard marker %d refused", fmt)
    finally:
        win32clipboard.CloseClipboard()
    return win32clipboard.GetClipboardSequenceNumber()


def get_clipboard_text() -> str | None:
    if not _open_clipboard():
        return None
    try:
        if win32clipboard.IsClipboardFormatAvailable(win32con.CF_UNICODETEXT):
            return win32clipboard.GetClipboardData(win32con.CF_UNICODETEXT)
        return None
    except Exception:
        return None
    finally:
        win32clipboard.CloseClipboard()


# OLE's own bookkeeping: meaningless (or misleading) once the app that copied isn't the owner
_OLE_FORMATS = {"ole private data", "embed source", "link source", "object descriptor",
                "link source descriptor", "objectlink", "ownerlink", "native"}
SAVE_BUDGET_S = 2.0           # apps render big copies on request (Excel): stop saving after this long
SAVE_MAX_BYTES = 64 * 2 ** 20  # and past this much

_k32 = ctypes.WinDLL("kernel32", use_last_error=True)
_k32.GlobalSize.argtypes = [wintypes.HGLOBAL]
_k32.GlobalSize.restype = ctypes.c_size_t
_k32.GlobalLock.argtypes = [wintypes.HGLOBAL]
_k32.GlobalLock.restype = ctypes.c_void_p
_k32.GlobalUnlock.argtypes = [wintypes.HGLOBAL]
_k32.GlobalAlloc.argtypes = [wintypes.UINT, ctypes.c_size_t]
_k32.GlobalAlloc.restype = wintypes.HGLOBAL
_k32.GlobalFree.argtypes = [wintypes.HGLOBAL]
_u32 = ctypes.WinDLL("user32", use_last_error=True)
_u32.GetClipboardData.argtypes = [wintypes.UINT]
_u32.GetClipboardData.restype = wintypes.HANDLE
_u32.SetClipboardData.argtypes = [wintypes.UINT, wintypes.HANDLE]
_u32.SetClipboardData.restype = wintypes.HANDLE
_u32.EnumClipboardFormats.argtypes = [wintypes.UINT]
_u32.EnumClipboardFormats.restype = wintypes.UINT
GMEM_MOVEABLE = 0x0002


def _format_name(fmt: int) -> str:
    try:
        return win32clipboard.GetClipboardFormatName(fmt)
    except Exception:
        return ""  # a standard format


def _read_raw(fmt: int) -> bytes | None:
    """A format's bytes exactly as stored (clipboard open)."""
    h = _u32.GetClipboardData(fmt)
    if not h:
        return None
    size = _k32.GlobalSize(h)
    p = _k32.GlobalLock(h)
    if not p:
        return None
    try:
        return ctypes.string_at(p, size)
    finally:
        _k32.GlobalUnlock(h)


def _write_raw(fmt: int, data: bytes) -> bool:
    """Put bytes on the clipboard as a format (clipboard open and emptied)."""
    h = _k32.GlobalAlloc(GMEM_MOVEABLE, max(1, len(data)))  # an empty marker still needs a block
    if not h:
        return False
    p = _k32.GlobalLock(h)
    if not p:
        _k32.GlobalFree(h)
        return False
    ctypes.memmove(p, data, len(data))
    _k32.GlobalUnlock(h)
    if not _u32.SetClipboardData(fmt, h):
        _k32.GlobalFree(h)  # still ours only when Windows didn't take it
        return False
    return True


class Clipboard:
    """Save the clipboard's formats byte for byte, and put them back: text, rich text, HTML,
    pictures, copied files (Explorer's file list and its cut-or-copy flag) and apps' own formats
    alike. Only what can't be copied as bytes is left out: GDI handles (Windows rebuilds those
    from the bytes formats), text Windows derives itself, and OLE's own bookkeeping."""

    def __init__(self):
        self.saved: list[tuple[int, bytes]] = []
        self.our_change = None
        if not _open_clipboard():
            return
        try:
            deadline, total = time.monotonic() + SAVE_BUDGET_S, 0
            fmt = _u32.EnumClipboardFormats(0)
            while fmt:
                if fmt not in _SKIP_FORMATS and _format_name(fmt).lower() not in _OLE_FORMATS:
                    if time.monotonic() > deadline or total > SAVE_MAX_BYTES:
                        log.info("clipboard too big to keep whole; %s and later formats won't come back",
                                 _format_name(fmt) or fmt)
                        break
                    try:
                        data = _read_raw(fmt)
                    except Exception:
                        data = None
                    if data is not None:
                        self.saved.append((fmt, data))
                        total += len(data)
                fmt = _u32.EnumClipboardFormats(fmt)
        finally:
            win32clipboard.CloseClipboard()

    def put(self, text: str) -> None:
        self.our_change = set_clipboard_text(text, private=True)

    def restore(self) -> None:
        if win32clipboard.GetClipboardSequenceNumber() != self.our_change:
            return  # someone copied something since; leave it
        if not _open_clipboard():
            return
        try:
            win32clipboard.EmptyClipboard()
            for fmt, data in self.saved:
                try:
                    _write_raw(fmt, data)
                except Exception:
                    pass
            # what comes back was already in clipboard history once: don't add it again
            had = {f for f, _ in self.saved}
            for fmt in _private_formats()[1:]:  # CanIncludeInClipboardHistory, CanUploadToCloudClipboard
                if fmt not in had:
                    _write_raw(fmt, (0).to_bytes(4, "little"))
        finally:
            win32clipboard.CloseClipboard()


class _KEYBDINPUT(ctypes.Structure):
    _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD), ("dwFlags", wintypes.DWORD),
                ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.c_size_t)]


class _INPUT(ctypes.Structure):
    class _U(ctypes.Union):
        _fields_ = [("ki", _KEYBDINPUT), ("pad", ctypes.c_byte * 32)]
    _anonymous_ = ("u",)
    _fields_ = [("type", wintypes.DWORD), ("u", _U)]


_user32 = ctypes.WinDLL("user32", use_last_error=True)
_user32.SendInput.argtypes = [wintypes.UINT, ctypes.POINTER(_INPUT), ctypes.c_int]
_MODIFIERS_UP = (0x10, 0x11, 0x12, 0x5B, 0x5C)  # Shift, Ctrl, Alt, Win: up first, so only Ctrl counts


def _chord(vk: int) -> None:
    """Ctrl + key, as real key presses."""
    seq = [(m, True) for m in _MODIFIERS_UP if _user32.GetAsyncKeyState(m) & 0x8000]
    seq += [(VK_CONTROL, False), (vk, False), (vk, True), (VK_CONTROL, True)]
    arr = (_INPUT * len(seq))()
    for i, (key, up) in enumerate(seq):
        arr[i].type = 1  # INPUT_KEYBOARD
        arr[i].ki = _KEYBDINPUT(key, 0, 0x2 if up else 0, 0, 0)
    _user32.SendInput(len(seq), arr, ctypes.sizeof(_INPUT))
    time.sleep(0.03)


def _paste(t: Target, text: str, cancelled) -> str | None:
    """Paste over the slice. In a field we can read, the paste counts only once the field shows it
    changed; if not, focus the field and paste once more, else None (the caller leaves the text on
    the clipboard and says so)."""
    clip = Clipboard()
    clip.put(text)
    try:
        before = _norm(t.value)
        nothing_to_change = before in (_norm(t.before + text + t.after), _norm(text))
        for attempt in (1, 2):
            selected = _select_slice(t) if t.readable else False
            if not t.readable:
                pass  # paste at the cursor, wherever it is
            elif not selected:
                if t.kind == "selection":
                    pass  # the user's own highlight is still in place
                elif t.kind in ("draft", "empty"):
                    _chord(VK_A)  # whole field
                else:
                    return None  # can't select a paragraph without UI Automation; don't paste in the wrong place
            front = ax.front_app()
            if cancelled() or front is None or front.pid != t.app.pid:
                return None
            _chord(VK_V)
            method = "paste" if selected or t.kind == "selection" else "select_all_paste"
            if not t.readable or nothing_to_change:
                time.sleep(0.25)  # let the target app finish reading the clipboard
                return method
            if _wait_for_value(t.element, lambda v: v != before, PASTE_WAIT_S) != before:
                time.sleep(0.25)
                return method
            log.info("paste left the field unchanged on %s (attempt %d)", t.surface_key, attempt)
            ax.set_attr(t.element, "AXFocused", True)
        return None
    finally:
        clip.restore()


_advapi32 = ctypes.WinDLL("advapi32", use_last_error=True)
_kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
_kernel32.OpenProcess.restype = wintypes.HANDLE
_advapi32.OpenProcessToken.argtypes = [wintypes.HANDLE, wintypes.DWORD, ctypes.POINTER(wintypes.HANDLE)]
_advapi32.GetTokenInformation.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD,
                                          ctypes.POINTER(wintypes.DWORD)]


def _elevated(pid: int | None = None) -> bool | None:
    """Whether a process (default: this one) runs as administrator; None if Windows won't say."""
    h = _kernel32.GetCurrentProcess() if pid is None else _kernel32.OpenProcess(0x1000, False, pid)
    if not h:
        return None
    token = wintypes.HANDLE()
    try:
        if not _advapi32.OpenProcessToken(h, 0x0008, ctypes.byref(token)):  # TOKEN_QUERY
            return None
        try:
            val, size = wintypes.DWORD(), wintypes.DWORD()
            if not _advapi32.GetTokenInformation(token, 20, ctypes.byref(val), 4, ctypes.byref(size)):
                return None  # TokenElevation
            return bool(val.value)
        finally:
            _kernel32.CloseHandle(token)
    finally:
        if pid is not None:
            _kernel32.CloseHandle(h)


def secure_input(pid: int | None = None) -> bool:
    """The app in front runs as administrator and Donkey doesn't: Windows drops keystrokes and
    UI Automation writes from Donkey into it, so paste can't work."""
    if _elevated() is True:
        return False
    if pid is None:
        front = ax.front_app()
        pid = front.pid if front else None
    if pid is None:
        return False
    e = _elevated(pid)
    return e is None or e  # can't even read its token: it's elevated

_TITLE_NOISE = re.compile(r"\(\d+\)|High memory usage - [\d.]+ [KMG]B -|^[*•●!\s]+")


def _title_key(title: str | None) -> str:
    """A window title without what changes on its own: unread counts, Chrome's memory warning."""
    return " ".join(_TITLE_NOISE.sub(" ", title or "").split()).lower()


def _page_key(url: str | None) -> str | None:
    u = urlparse(url or "")
    return f"{u.netloc}{u.path}".lower() if u.netloc else None


def conversation_moved(t: Target, app: ax.FrontApp) -> str | None:
    """Why the focused field is no longer where the text was read (another chat, tab or window),
    or None. Compares what the field was labelled with ("Type a message to Anna"), the page in a
    browser, and the window title elsewhere."""
    el = ax.attr(app.element, "AXFocusedUIElement")
    if el is None:
        return "the text field lost focus"
    then, now = web.recipient_from_label(t.label), web.recipient_from_label(_label(el))
    if then and now and then != now:
        return f"the chat changed from {then} to {now}"
    p = ax.probe(app)
    if app.is_browser:
        area = ax.find_web_area(p.window, el)
        url = ax.url_string(ax.attr(area, "AXURL")) if area is not None else None
        if _page_key(url) and _page_key(t.url) and _page_key(url) != _page_key(t.url):
            return "the page changed"
    elif _title_key(p.title) != _title_key(t.window_title):
        return "the window changed"
    return None


def deliver(t: Target, text: str, cancelled=lambda: False) -> str:
    """Place `text` over the target slice. Returns the method used; raises DeliveryError, and on
    any failure the text is left on the clipboard: a written reply is never lost."""
    step = ["start"]
    try:
        return _deliver(t, text, cancelled, step)
    except DeliveryError:
        raise
    except Exception as e:
        log.exception("delivery failed in %s (%s) at step %s, field %s", t.app.name, t.app.bundle_id, step[0],
                      t.role)
        try:
            _leave_on_clipboard(text)
        except Exception:
            log.exception("couldn't leave the result on the clipboard either")
            raise DeliveryError("Couldn't write into this field, or put the result on the clipboard.") from e
        raise DeliveryError("Couldn't write into this field. The result is on your clipboard, ready to paste.") from e


def _deliver(t: Target, text: str, cancelled, step: list) -> str:
    front = ax.front_app()
    if front is None or front.pid != t.app.pid:
        _leave_on_clipboard(text)
        raise DeliveryError("You switched apps before the rewrite finished. The result is on your clipboard.")
    if moved := conversation_moved(t, front):
        log.info("delivery refused: %s", moved)
        _leave_on_clipboard(text)
        raise DeliveryError(f"Not written: {moved} while Donkey worked. The result is on your clipboard.")
    if not t.readable:
        # Contents unknown: never select anything, just paste at the cursor.
        if secure_input(t.app.pid):
            _leave_on_clipboard(text)
            raise DeliveryError("This app runs as administrator, so Windows won't let Donkey paste into it. "
                                "The result is on your clipboard.")
        step[0] = "paste at cursor"
        method = _paste(t, text, cancelled)
        if method:
            return "paste_at_cursor"
        _leave_on_clipboard(text)
        raise DeliveryError("Couldn't paste into this field. The result is on your clipboard, ready to paste.")
    step[0] = "re-read field"
    current = _norm(clean_value(t.element, ax.as_text(ax.attr(t.element, "AXValue"))))
    if current != _norm(t.value):
        _leave_on_clipboard(text)
        raise DeliveryError("You kept typing while the rewrite ran, so Donkey left your draft alone. "
                            "The result is on your clipboard.")

    skip_ax = t.surface_key in _learned()["ax_noop"] or (t.domain or "").removeprefix("www.") in PASTE_ONLY_DOMAINS
    selectable = ax.can_select(t.element)
    if not skip_ax and not selectable:
        # nothing to select a slice with: a whole new value is the only precise write
        step[0] = "direct write"
        method = _ax_write(t, text)
        if method:
            return method
    if secure_input(t.app.pid):
        _leave_on_clipboard(text)
        raise DeliveryError("This app runs as administrator, so Windows won't let Donkey write into it. "
                            "The result is on your clipboard.")
    step[0] = "paste"
    method = _paste(t, text, cancelled)
    if method:
        return method
    front = ax.front_app()
    if not skip_ax and selectable and not cancelled() and front is not None and front.pid == t.app.pid:
        # the paste didn't take: a plain-text box can still take the whole new value (a late
        # paste can't double up, since the write sets the entire value)
        step[0] = "direct write after paste"
        method = _ax_write(t, text)
        if method:
            return method
    _leave_on_clipboard(text)
    raise DeliveryError("Couldn't write into this field. The result is on your clipboard, ready to paste.")


def _leave_on_clipboard(text: str) -> None:
    set_clipboard_text(text)
