"""Search across all memory layers, fused with reciprocal rank fusion.

Sources: keyword (FTS5 BM25) over snapshots, chronicle, wiki and imported documents; vectors over chronicle,
wiki and imported documents; and a personalised PageRank walk over wiki pages, their links, and the screens behind them.
"""
import json
import logging
import re
import datetime as dt
import time
from collections import defaultdict
from dataclasses import dataclass, field

from .db import DB
from .filters import blocked_reason, load_rules

log = logging.getLogger("donkey.search")

RRF_K = 10             # small K: a strong top hit in one source beats weak hits spread over several
PER_SOURCE = 20
PPR_DAMPING = 0.85
PPR_ITERS = 15
PPR_SEEDS = 5


@dataclass
class Hit:
    kind: str          # snapshot | chronicle | wiki | document
    ref_id: int
    title: str
    snippet: str
    when: float | None
    score: float = 0.0
    sources: list[str] = field(default_factory=list)


# Question words and glue: in an OR query they match nearly every row and swamp the real terms.
STOPWORDS = set("a an and are as at be by did do does for from how i in is it me my of on or so that the this "
                "to was what when where which who why with about".split())


def fts_query(text: str) -> str | None:
    """Free text → an FTS5 OR query of quoted terms, so user input can't be a syntax error."""
    words = [t for t in re.findall(r"\w+", text.lower()) if len(t) > 1]
    terms = [t for t in words if t not in STOPWORDS] or words
    return " OR ".join(f'"{t}"' for t in dict.fromkeys(terms)) or None


def _keyword(db: DB, q: str) -> dict[str, list[Hit]]:
    out = {}
    out["snapshot"] = [Hit("snapshot", r["id"], f"{r['app']} | {r['window_title']}", r["excerpt"], r["last_seen_at"])
                       for r in db.query(
        """SELECT s.id, s.app, s.window_title, s.last_seen_at,
                  snippet(snapshots_fts, 0, '[', ']', ' … ', 24) AS excerpt
           FROM snapshots_fts JOIN snapshots s ON s.id = snapshots_fts.rowid
           WHERE snapshots_fts MATCH ? ORDER BY bm25(snapshots_fts) LIMIT ?""", (q, PER_SOURCE))]
    out["chronicle"] = [Hit("chronicle", r["id"], f"{r['period']} {r['period_key']}", r["excerpt"], r["created_at"])
                        for r in db.query(
        """SELECT c.id, c.period, c.period_key, c.created_at,
                  snippet(chronicle_fts, 0, '[', ']', ' … ', 32) AS excerpt
           FROM chronicle_fts JOIN chronicle c ON c.id = chronicle_fts.rowid
           WHERE chronicle_fts MATCH ? ORDER BY bm25(chronicle_fts) LIMIT ?""", (q, PER_SOURCE))]
    out["wiki"] = [Hit("wiki", r["id"], f"{r['title']} ({r['page_type']})", r["summary"], r["last_seen"])
                   for r in db.query(
        """SELECT w.id, w.title, w.page_type, w.summary, w.last_seen
           FROM wiki_fts JOIN wiki_pages w ON w.id = wiki_fts.rowid
           WHERE wiki_fts MATCH ? ORDER BY bm25(wiki_fts, 10.0, 5.0, 2.0, 1.0) LIMIT ?""", (q, PER_SOURCE))]
    out["document"] = [Hit("document", r["id"], f"{r['source']} | {r['title']}", r["excerpt"], r["ts"])
                       for r in db.query(
        """SELECT p.id, d.source, d.title, COALESCE(p.ts, d.created_at) AS ts,
                  snippet(document_fts, 0, '[', ']', ' … ', 24) AS excerpt
           FROM document_fts JOIN document_parts p ON p.id = document_fts.rowid JOIN documents d ON d.id = p.doc_id
           WHERE document_fts MATCH ? ORDER BY bm25(document_fts) LIMIT ?""", (q, PER_SOURCE))]
    return out


# ------------------------------------------------------------------ time phrases

_MONTHS = {m: i for i, m in enumerate(["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}
_DAYS = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
_PARTS = {"morning": (6, 12), "afternoon": (12, 17), "evening": (17, 21), "night": (19, 24), "tonight": (19, 24),
          "lunch": (12, 14), "noon": (11, 14)}
_CLOCK = re.compile(r"\b(?:at|around|about|near|by)?\s*(\d{1,2})(?::(\d{2}))?\s*(am|pm)\b")
_DATE = re.compile(r"\b(\d{1,2})(?:st|nd|rd|th)?\s+(?:of\s+)?([a-z]{3})[a-z]*\b|\b([a-z]{3})[a-z]*\s+(\d{1,2})(?:st|nd|rd|th)?\b")
_ISO = re.compile(r"\b(\d{4})-(\d{2})-(\d{2})\b")


def time_window(text: str, now: dt.datetime | None = None) -> tuple[dt.datetime, dt.datetime, dt.datetime | None] | None:
    """(start, end, focus) for time phrases in a question, or None. A time without a date means
    its most recent occurrence; "last night" is the evening before today."""
    now = now or dt.datetime.now()
    t = text.lower()
    day = None
    if m := _ISO.search(t):
        day = dt.date(int(m[1]), int(m[2]), int(m[3]))
    elif "yesterday" in t or "last night" in t:
        day = now.date() - dt.timedelta(days=1)
    elif "today" in t or "this morning" in t or "tonight" in t:
        day = now.date()
    else:
        for m in _DATE.finditer(t):
            d, mon = (m[1], m[2]) if m[1] else (m[4], m[3])
            if mon in _MONTHS and 1 <= int(d) <= 31:
                cand = dt.date(now.year, _MONTHS[mon], int(d))
                day = cand if cand <= now.date() else cand.replace(year=now.year - 1)
                break
        for i, name in enumerate(_DAYS):
            if day is None and re.search(rf"\b(?:last|on)?\s*{name}\b", t):
                back = (now.weekday() - i) % 7 or 7
                day = now.date() - dt.timedelta(days=back)
    hours = None
    if m := _CLOCK.search(t):
        h = int(m[1]) % 12 + (12 if m[3] == "pm" else 0)
        hours = (max(0, h - 1), min(24, h + 2))
        focus_h = h
    else:
        focus_h = None
        for word, rng in _PARTS.items():
            if re.search(rf"\b{word}\b", t):
                hours = rng
                break
    if day is None and hours is None:
        return None
    if day is None:  # a time of day alone: the most recent one that has already started
        day = now.date() if now.hour >= hours[0] else now.date() - dt.timedelta(days=1)
    start = dt.datetime.combine(day, dt.time(hours[0] if hours else 0))
    end = dt.datetime.combine(day, dt.time(0)) + dt.timedelta(hours=hours[1] if hours else 24)
    focus = dt.datetime.combine(day, dt.time(focus_h)) if focus_h is not None else None
    return start, end, focus


_MONTH_NAMES = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october",
                "november", "december"]
_MONTH_WORD = re.compile(r"\b(?:(in|during|of|for|since)\s+)?(%s)\b(?:\s+(\d{4}))?" % "|".join(_MONTH_NAMES))


def period_window(text: str, now: dt.datetime | None = None) -> tuple[str, str, dt.date, dt.date] | None:
    """(period, key, first day, last day) for a question about a whole week, month or year, or None.
    "this week", "last month", "in October", "October 2025", "this year", "in 2025"."""
    now = now or dt.datetime.now()
    t, today = text.lower(), now.date()
    if m := re.search(r"\b(this|last|past|previous)\s+(week|month|year)\b", t):
        back = m[1] != "this"
        if m[2] == "week":
            first = today - dt.timedelta(days=today.weekday() + (7 if back else 0))
            y, w, _ = first.isocalendar()
            return "week", f"{y}-W{w:02d}", first, first + dt.timedelta(days=6)
        if m[2] == "month":
            first = today.replace(day=1)
            if back:
                first = (first - dt.timedelta(days=1)).replace(day=1)
            return "month", first.isoformat()[:7], first, (first + dt.timedelta(days=32)).replace(day=1) - dt.timedelta(days=1)
        year = today.year - back
        return "year", str(year), dt.date(year, 1, 1), dt.date(year, 12, 31)
    for m in _MONTH_WORD.finditer(t):
        if m[2] == "may" and not (m[1] or m[3]):
            continue  # "may" the verb
        month = _MONTH_NAMES.index(m[2]) + 1
        year = int(m[3]) if m[3] else today.year if month <= today.month else today.year - 1
        first = dt.date(year, month, 1)
        return "month", first.isoformat()[:7], first, (first + dt.timedelta(days=32)).replace(day=1) - dt.timedelta(days=1)
    if m := re.search(r"\b(?:in|during|of)\s+(20\d\d)\b", t):
        year = int(m[1])
        return "year", str(year), dt.date(year, 1, 1), dt.date(year, 12, 31)
    return None


def _period_hits(db: DB, text: str) -> list[Hit]:
    """The summary of the week, month or year a question names; while it is still in progress (or
    not rolled up), the nearest summaries below it, latest first."""
    w = period_window(text)
    if not w:
        return []
    period, key, first, last = w
    rows = db.query("SELECT id FROM chronicle WHERE period = ? AND period_key = ?", (period, key))
    if rows:
        return [h for h in (_load(db, "chronicle", r["id"]) for r in rows) if h]
    below = {"week": ("day",), "month": ("week", "day"), "year": ("month", "week", "day")}[period]
    lo, hi = first.isoformat(), last.isoformat()
    for p in below:
        parts = [r for r in db.query("SELECT id, period_key FROM chronicle WHERE period = ? ORDER BY period_key DESC", (p,))
                 if _period_start(p, r["period_key"]) and lo <= _period_start(p, r["period_key"]) <= hi]
        if parts:
            rows = parts
            break
    return [h for h in (_load(db, "chronicle", r["id"]) for r in rows[:8]) if h]


_GENERIC = set("""what which did do does doing done have has had been be was were i i've me my mine on in at of for
during since about the a an this last past previous week month year summary summarize summarise recap overview
work worked working spend spent time how up to all everything happened happen show tell give so far""".split())


def _only_period(text: str) -> bool:
    """True when nothing but the period and generic words is asked ("what did I do in October")."""
    words = re.findall(r"[a-z']+|\d{4}", text.lower())
    return all(w in _GENERIC or w in _MONTH_NAMES or w.isdigit() for w in words)


def _period_start(period: str, key: str) -> str | None:
    if period == "day":
        return key
    if period == "month":
        return key + "-01"
    if period == "week":
        try:
            return dt.date.fromisocalendar(int(key[:4]), int(key[6:]), 1).isoformat()
        except ValueError:
            return None
    return None


def _time_hits(db: DB, text: str) -> list[Hit]:
    """Summaries of the hours (and day) a question points at, closest to the named time first."""
    w = time_window(text)
    if not w:
        return []
    start, end, focus = w
    keys = []
    h = start
    while h < end:
        keys.append(h.strftime("%Y-%m-%dT%H"))
        h += dt.timedelta(hours=1)
    marks = ",".join("?" * len(keys))
    rows = db.query(f"SELECT id, period_key FROM chronicle WHERE period = 'hour' AND period_key IN ({marks})", keys)
    mid = focus or start + (end - start) / 2
    rows = sorted(rows, key=lambda r: abs(dt.datetime.strptime(r["period_key"], "%Y-%m-%dT%H") + dt.timedelta(minutes=30) - mid))
    hits = [h for h in (_load(db, "chronicle", r["id"]) for r in rows) if h]
    day = db.query("SELECT id FROM chronicle WHERE period = 'day' AND period_key = ?", (start.strftime("%Y-%m-%d"),))
    if day and (hit := _load(db, "chronicle", day[0]["id"])):
        hits.append(hit)
    return hits


def _load(db: DB, kind: str, ref_id: int) -> Hit | None:
    if kind == "chronicle":
        r = db.query("SELECT id, period, period_key, summary, created_at FROM chronicle WHERE id = ?", (ref_id,))
        return Hit("chronicle", ref_id, f"{r[0]['period']} {r[0]['period_key']}", r[0]["summary"][:300],
                   r[0]["created_at"]) if r else None
    if kind == "document":
        r = db.query("""SELECT p.id, p.text, COALESCE(p.ts, d.created_at) AS ts, d.source, d.title FROM document_parts p
                        JOIN documents d ON d.id = p.doc_id WHERE p.id = ?""", (ref_id,))
        return Hit("document", ref_id, f"{r[0]['source']} | {r[0]['title']}", r[0]["text"][:300], r[0]["ts"]) if r else None
    if kind == "snapshot":
        r = db.query("SELECT id, app, window_title, url, content, last_seen_at FROM snapshots WHERE id = ?", (ref_id,))
        if not r or blocked_reason(_rules(), r[0]["app"], r[0]["url"], r[0]["window_title"]):
            return None
        return Hit("snapshot", ref_id, f"{r[0]['app']} | {r[0]['window_title']}", r[0]["content"][:300],
                   r[0]["last_seen_at"])
    r = db.query("SELECT id, title, page_type, summary, last_seen FROM wiki_pages WHERE id = ?", (ref_id,))
    return Hit("wiki", ref_id, f"{r[0]['title']} ({r[0]['page_type']})", r[0]["summary"], r[0]["last_seen"]) if r else None


_RULES = None


def _rules():
    global _RULES
    if _RULES is None:
        _RULES = load_rules()
    return _RULES


def _graph(db: DB) -> dict[str, set[str]]:
    """Undirected graph: page:<id> ↔ page:<id> (links) and page:<id> ↔ snap:<id> (screens behind its
    claims and mentions)."""
    adj: dict[str, set[str]] = defaultdict(set)

    def edge(a: str, b: str) -> None:
        if a != b:
            adj[a].add(b)
            adj[b].add(a)

    pages = db.query("SELECT id, slug, links, body_claims FROM wiki_pages")
    ids = {p["slug"]: p["id"] for p in pages}
    for p in pages:
        node = f"page:{p['id']}"
        for slug in json.loads(p["links"]):
            if slug in ids:
                edge(node, f"page:{ids[slug]}")
        for c in json.loads(p["body_claims"] or "[]"):
            for sid in c.get("screens", []):
                edge(node, f"snap:{sid}")
    for m in db.query("SELECT w.id, m.snapshot_ids FROM wiki_mentions m JOIN wiki_pages w ON w.slug = m.slug"):
        for sid in json.loads(m["snapshot_ids"]):
            edge(f"page:{m['id']}", f"snap:{sid}")
    return adj


def ppr(adj: dict[str, set[str]], seeds: dict[str, float]) -> dict[str, float]:
    """Personalised PageRank (damping 0.85, 15 iterations). Mass that
    reaches a node with no edges goes back to the seeds instead of vanishing."""
    total = sum(seeds.values())
    if not total:
        return {}
    restart = {n: w / total for n, w in seeds.items()}
    rank = dict(restart)
    for _ in range(PPR_ITERS):
        nxt: dict[str, float] = defaultdict(float)
        lost = 0.0
        for node, score in rank.items():
            out = adj.get(node)
            if out:
                share = PPR_DAMPING * score / len(out)
                for n in out:
                    nxt[n] += share
            else:
                lost += PPR_DAMPING * score
        for n, w in restart.items():
            nxt[n] += (1 - PPR_DAMPING + lost) * w
        rank = nxt
    return rank


def _graph_hits(db: DB, ranked: dict[str, list[Hit]]) -> list[Hit]:
    """Walk from the best wiki hits (and, more lightly, the best matching screens) to what they connect to."""
    wiki_seeds = [h.ref_id for h in ranked.get("bm25_wiki", [])[:PPR_SEEDS]]
    wiki_seeds += [h.ref_id for h in ranked.get("vector", []) if h.kind == "wiki"][:PPR_SEEDS]
    seeds: dict[str, float] = {}
    for rank, page_id in enumerate(dict.fromkeys(wiki_seeds)):
        seeds[f"page:{page_id}"] = 1 / (rank + 1)
    for rank, h in enumerate(ranked.get("bm25_snapshot", [])[:PPR_SEEDS]):
        seeds.setdefault(f"snap:{h.ref_id}", 0.5 / (rank + 1))
    if not seeds:
        return []
    scores = ppr(_graph(db), seeds)
    out = []
    for node, score in sorted(scores.items(), key=lambda kv: -kv[1]):
        if node in seeds or score <= 0:
            continue
        kind, ref = node.split(":")
        if (h := _load(db, "wiki" if kind == "page" else "snapshot", int(ref))):
            out.append(h)
        if len(out) >= PER_SOURCE:
            break
    return out


def search(db: DB, text: str, limit: int = 10, use_vectors: bool = True) -> list[Hit]:
    ranked: dict[str, list[Hit]] = {}
    q = fts_query(text)
    if q:
        for kind, hits in _keyword(db, q).items():
            ranked[f"bm25_{kind}"] = hits
    if use_vectors:  # a failure raises: no quiet keyword-only results (--keyword asks for those)
        from . import embed
        ranked["vector"] = [h for h in (_load(db, k, i) for k, i, _ in embed.nearest(db, text, PER_SOURCE)) if h]
    time_weight = 1.0
    if timed := _time_hits(db, text):
        ranked["time"] = timed
        start, end, _ = time_window(text)
        # A narrow window ("around 3pm") is the answer; a whole day only scopes the question.
        time_weight = 2.0 if end - start <= dt.timedelta(hours=6) else 0.7
    elif periods := _period_hits(db, text):
        ranked["time"] = periods
        # "what did I do this month" is answered by the month's summary; "Rahul's mail last month"
        # only uses the month to scope.
        time_weight = 3.0 if _only_period(text) else 0.7
    try:
        ranked["ppr"] = _graph_hits(db, ranked)
    except Exception:
        log.exception("graph walk unavailable")

    fused: dict[tuple[str, int], Hit] = {}
    for source, hits in ranked.items():
        weight = 0.5 if source == "ppr" else time_weight if source == "time" else 1.0
        for rank, h in enumerate(hits):
            key = (h.kind, h.ref_id)
            hit = fused.setdefault(key, h)
            hit.score += weight / (RRF_K + rank + 1)
            if source not in hit.sources:
                hit.sources.append(source)
    return sorted(fused.values(), key=lambda h: -h.score)[:limit]


def format_hits(hits: list[Hit]) -> str:
    lines = []
    for h in hits:
        when = time.strftime("%Y-%m-%d %H:%M", time.localtime(h.when)) if h.when else ""
        lines.append(f"[{h.kind} {h.ref_id}] {h.title}  {when}  ({', '.join(h.sources)})")
        lines.append("    " + " ".join(h.snippet.split())[:300])
    return "\n".join(lines)
