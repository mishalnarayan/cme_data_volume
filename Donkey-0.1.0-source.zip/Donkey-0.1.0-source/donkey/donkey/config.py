"""Settings, from config.json next to the README (created with defaults on first run).

Everything Donkey writes (the database with its vectors, logs, profile, the memory map, evals and
the downloaded embedding models) lives in data/ beside it, so the whole project is one folder.
DONKEY_HOME moves data/ (the scenario test uses its own); config.json then sits inside it.
The installed Donkey.exe can't write inside its install folder, so there both live in
%APPDATA%\Donkey.

VENDOR is what Donkey ships with instead of fetching or finding on the PC: the embedding model
and llama-server, carried in the install folder. Running from source it's usually absent, and
Donkey downloads the model and uses a llama-server.exe on the PATH (winget install llama.cpp)."""
import json
import os
import shutil
import sys
from dataclasses import dataclass, field
from pathlib import Path

FROZEN = bool(getattr(sys, "frozen", False))   # running as the installed Donkey.exe
PROJECT = Path(__file__).resolve().parent.parent
VENDOR = Path(__file__).resolve().parent / "vendor"
if "DONKEY_HOME" in os.environ:
    HOME = Path(os.environ["DONKEY_HOME"])
    CONFIG_PATH = HOME / "config.json"
elif FROZEN:
    HOME = Path(os.environ.get("APPDATA") or Path.home() / "AppData" / "Roaming") / "Donkey"
    CONFIG_PATH = HOME / "config.json"
else:
    HOME = PROJECT / "data"
    CONFIG_PATH = PROJECT / "config.json"
if FROZEN and "SSL_CERT_FILE" not in os.environ:   # the bundled Python doesn't read the Windows certificate store
    try:
        import certifi
        os.environ["SSL_CERT_FILE"] = certifi.where()
    except ImportError:
        pass


def _python(gui: bool) -> str:
    exe = Path(sys.executable)
    if exe.name.lower() in ("python.exe", "pythonw.exe"):
        want = exe.with_name("pythonw.exe" if gui else "python.exe")
        if want.exists():
            return str(want)
    return str(exe)


def command(*args: str, gui: bool = False) -> list[str]:
    """How to start Donkey again with these arguments (restarts, login item, MCP clients, the
    donkey:// link handler). `gui`: no console window (Donkey.exe / pythonw.exe); otherwise the
    console one (donkey-cli.exe / python.exe), which MCP clients need for its standard input/output.
    From source it runs donkey\__main__.py by path, so no working folder or PYTHONPATH is needed."""
    if FROZEN:
        exe = Path(sys.executable).with_name("Donkey.exe" if gui else "donkey-cli.exe")
        return [str(exe if exe.exists() else sys.executable), *args]
    return [_python(gui), "-X", "utf8", str(PROJECT / "donkey" / "__main__.py"), *args]


command_line = command


def shell_command(*args: str, gui: bool = False) -> str:
    """command() as one command line for the registry or a shortcut. Arguments are used as given
    (so "%1" placeholders keep their quotes)."""
    import subprocess
    return " ".join([subprocess.list2cmdline(command(gui=gui)), *args])


def command_env() -> dict:
    """The environment that command() needs (only a moved data folder)."""
    env = {}
    if "DONKEY_HOME" in os.environ:
        env["DONKEY_HOME"] = str(HOME)
    return env
DB_PATH = HOME / "donkey.db"
# Downloaded models (EmbeddingGemma, the small fallback model) go in data/models too.
os.environ.setdefault("HF_HUB_CACHE", str(HOME / "models"))


def _migrate_old_home() -> None:
    """Data used to live in ~/.donkey (and before that ~/.minnow): move it into data/ on first run."""
    if "DONKEY_HOME" in os.environ or HOME.exists():
        return
    for old in (Path.home() / ".donkey", Path.home() / ".minnow"):
        if old.is_dir():
            shutil.move(str(old), str(HOME))
            break
    else:
        return
    for old_name, new_name in (("minnow.db", "donkey.db"), ("minnow.db-wal", "donkey.db-wal"),
                               ("minnow.db-shm", "donkey.db-shm"), ("minnow.log", "donkey.log")):
        if (HOME / old_name).exists():
            (HOME / old_name).rename(HOME / new_name)


_migrate_old_home()

# The config file as first written. "_about" keys are notes for whoever reads the file; Donkey
# ignores every key that starts with "_". Restart Donkey after editing.
DEFAULTS = {
    "_about": "Donkey settings. Restart Donkey after editing. Keys starting with _ are notes.",
    "llm": {
        "_about": "use = which block in providers Donkey talks to. One model does everything "
                  "(rewrites, background memory jobs, chat) unless a block sets rewrite_model, "
                  "memory_model or chat_model. models = what the chat's hidden picker offers "
                  "(Alt-click the donkey, or type /model).",
        "use": "openrouter",
        "temperature": 0.1,
        "max_tokens": 8000,
        "timeout": 180,
    },
    "providers": {
        "openrouter": {
            "_about": "kind openai = any OpenAI-compatible chat-completions endpoint. "
                      "reasoning_effort none = no thinking (fastest). extra is merged into every request; "
                      "fast_extra into the ones someone waits on (chat, writing), background_extra into memory jobs.",
            "kind": "openai",
            "endpoint": "https://openrouter.ai/api/v1/chat/completions",
            "api_key": "",
            "model": "deepseek/deepseek-v4.1-flash",
            "models": ["deepseek/deepseek-v4.1-flash"],
            "reasoning_effort": "none",
            "extra": {"provider": {"quantizations": ["int8", "fp8", "fp16", "bf16", "fp32", "unknown"]}},
            "fast_extra": {"provider": {"sort": "latency"}},
            "background_extra": {"provider": {"sort": "price"}},
        },
        "lmstudio": {
            "_about": "LM Studio's local server (Developer tab > Start server). No key; nothing leaves "
                      "this PC. model = the id LM Studio shows for the loaded model.",
            "kind": "openai",
            "endpoint": "http://localhost:1234/v1/chat/completions",
            "model": "qwen/qwen3-8b",
            "models": ["qwen/qwen3-8b"],
            "reasoning_effort": "",
            "timeout": 600,
        },
        "anthropic": {
            "_about": "Claude. Key from api_key here, ANTHROPIC_API_KEY, or data/anthropic-key.",
            "kind": "anthropic",
            "model": "claude-haiku-5-5",
            "models": ["claude-haiku-5-5"],
        },
    },
    "identity": {
        "_about": "Your name, so memory never files you as a separate person. Leave it empty to use this Windows account's full name.",
        "name": "",
    },
    "embeddings": {
        "_about": "gemma = EmbeddingGemma 2 on this PC via llama.cpp (winget install llama.cpp; 310 MB "
                  "download once into data/models). openai = any OpenAI-compatible /embeddings endpoint (model, endpoint, api_key).",
        "provider": "gemma",
    },
    "rewrite": {
        "_about": "key = the key you tap to rewrite the focused text field: right_alt, left_alt, "
                  "right_control, left_control, right_shift, left_shift, right_windows or left_windows. "
                  "effort = low, medium or high (Claude only).",
        "key": "right_alt",
        "effort": "low",
        "no_em_dashes": True,
        "sounds": True,
    },
    "nudges": {
        "_about": "morning_brief / evening_wrap: a time like 08:45, or empty for off. meeting_briefs = "
                  "a prep note ~15 min before meetings. changes = tell you when something you relied on changed.",
        "enabled": True,
        "morning_brief": "08:45",
        "evening_wrap": "",
        "meeting_briefs": True,
        "followups": True,
        "max_followups_per_day": 3,
        "changes": True,
        "max_changes_per_day": 3,
        "quiet_hours": "21:00-08:00",
    },
    "capture": {
        "_about": "ocr reads the pixels of windows the screen reader can't (remote desktops, Phone "
                  "Link) when it gets fewer than ocr_below_chars; ocr_languages[0] is the main pass, "
                  "each needs its Windows language pack; hi-IN also reads Devanagari and the rupee sign. blocked_domains = your additions; "
                  "built-ins live in donkey/filters.py.",
        "enabled": True,
        "probe_interval_s": 1.0,
        "recheck_every_s": 2.0,
        "walk_every_s": 20,
        "coalesce_window_s": 300,
        "idle_after_s": 120,
        "max_chars": 60000,
        "redact": True,
        "ocr": True,
        "ocr_below_chars": 200,
        "ocr_languages": ["en-US"],
        "blocked_apps": ["1Password", "Bitwarden", "Credential Manager", "KeePass", "KeePassXC", "LastPass", "Dashlane"],
        "blocked_domains": [],
    },
}


@dataclass
class Config:
    rewrite_key: str = "right_alt"
    rewrite_model: str = "claude-opus-5-5"
    rewrite_effort: str = "low"
    no_em_dashes: bool = True
    sounds: bool = True
    memory_model: str = "claude-haiku-5-5"
    chat_model: str = ""             # empty = the rewrite model
    chat_models: list[str] = field(default_factory=list)  # what the chat's hidden picker offers
    llm_use: str = ""                # the [providers.*] block in use ("" = an old flat [llm] section)
    nudges_enabled: bool = True
    morning_brief: str = "08:45"
    evening_wrap: str = ""
    meeting_briefs: bool = True
    followups: bool = True
    max_followups_per_day: int = 3
    changes: bool = True
    max_changes_per_day: int = 3
    quiet_hours: str = "21:00-08:00"
    capture_enabled: bool = True
    probe_interval_s: float = 1.0
    recheck_every_s: float = 2.0
    walk_every_s: float = 20
    coalesce_window_s: float = 300
    idle_after_s: float = 120
    max_chars: int = 60000
    redact: bool = True
    ocr: bool = True
    ocr_below_chars: int = 200
    ocr_languages: list[str] = field(default_factory=lambda: ["en-US"])
    blocked_apps: list[str] = field(default_factory=list)
    blocked_domains: list[str] = field(default_factory=list)
    user_name: str = ""
    embeddings: dict = field(default_factory=dict)
    llm_provider: str = "anthropic"
    llm_endpoint: str = ""
    llm_api_key: str = ""
    llm_temperature: float | None = None
    llm_max_tokens: int = 8000
    llm_timeout: float = 180
    llm_reasoning_effort: str = ""
    llm_extra: dict = field(default_factory=dict)
    llm_fast_extra: dict = field(default_factory=dict)        # + on requests someone waits on (chat, writing)
    llm_background_extra: dict = field(default_factory=dict)  # + on memory jobs
    llm_headers: dict = field(default_factory=dict)


_GENERIC_LOGINS = {"user", "admin", "administrator", "owner", "guest", "default", "pc", "home", "test",
                   "windows", "microsoft", "me", "dev", "work", "office", "student", "family", "local"}


def _display_name() -> str:
    """The account's display name: a Microsoft or work account's name (GetUserNameExW)."""
    import ctypes
    try:
        secur32 = ctypes.WinDLL("secur32")
        size = ctypes.c_ulong(0)
        secur32.GetUserNameExW(3, None, ctypes.byref(size))  # NameDisplay
        if not size.value:
            return ""
        buf = ctypes.create_unicode_buffer(size.value + 1)
        return buf.value.strip() if secur32.GetUserNameExW(3, buf, ctypes.byref(size)) else ""
    except OSError:
        return ""


def _local_full_name(login: str) -> str:
    """The "Full name" on a local account (lusrmgr / `net user`), often empty."""
    import ctypes
    from ctypes import wintypes
    try:
        netapi = ctypes.WinDLL("netapi32")
        buf = ctypes.c_void_p()
        if netapi.NetUserGetInfo(None, login, 10, ctypes.byref(buf)) != 0 or not buf.value:
            return ""
        try:  # USER_INFO_10: name, comment, usr_comment, full_name
            return ctypes.cast(buf, ctypes.POINTER(wintypes.LPWSTR * 4)).contents[3] or ""
        finally:
            netapi.NetApiBufferFree(buf)
    except OSError:
        return ""


def account_name() -> str:
    """The user's name as this PC knows it, e.g. "Anna Berg": the account's full name, else the
    login name when it reads like a name. A Mac account always has a full name; a Windows local
    account often has only its login name, which Windows setup asks for as "Who's going to use this PC?"."""
    login = os.environ.get("USERNAME", "").strip()
    for name in (_display_name(), _local_full_name(login)):
        name = name.strip()
        # with no full name set, Windows gives back the login name (or DOMAIN\login)
        if name and name.lower() not in ("unknown", login.lower()) and "\\" not in name:
            return name
    if login.isalpha() and len(login) >= 2 and login.lower() not in _GENERIC_LOGINS:
        return login[0].upper() + login[1:]
    return ""


def _without_notes(d):
    if isinstance(d, dict):
        return {k: _without_notes(v) for k, v in d.items() if not k.startswith("_")}
    return d


def _merge(base: dict, over: dict) -> dict:
    out = dict(base)
    for k, v in over.items():
        out[k] = _merge(out[k], v) if isinstance(v, dict) and isinstance(out.get(k), dict) else v
    return out


def _write(raw: dict) -> None:
    # it holds API keys: it lives in the user's own profile, which other accounts can't read
    CONFIG_PATH.write_text(json.dumps(raw, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def _from_toml(path: Path) -> dict:
    """An old config.toml turned into the JSON layout (flat [llm] sections become a provider block)."""
    import tomllib
    old = tomllib.loads(path.read_text())
    llm = old.get("llm", {})
    if llm and "use" not in llm:
        kind = str(llm.pop("provider", "anthropic")).lower()
        name = "anthropic" if kind == "anthropic" else "openrouter" if "openrouter.ai" in str(llm.get("endpoint", "")) else "custom"
        common = {k: llm.pop(k) for k in ("temperature", "max_tokens", "timeout") if k in llm}
        old.setdefault("providers", {})[name] = {"kind": "anthropic" if kind == "anthropic" else "openai", **llm}
        old["llm"] = {"use": name, **common}
    for section in ("rewrite", "memory"):  # their Claude model names were only used with Claude
        old.get(section, {}).pop("model", None)
        if section in old and not old[section]:
            del old[section]
    return old


def load() -> Config:
    HOME.mkdir(parents=True, exist_ok=True)
    if not CONFIG_PATH.exists():
        old = HOME / "config.toml"
        _write(_merge(DEFAULTS, _from_toml(old)) if old.exists() else DEFAULTS)
        if old.exists():
            old.unlink()
    return from_raw(json.loads(CONFIG_PATH.read_text()))


def from_raw(raw: dict) -> Config:
    """Settings from a config.json layout (the file, or one the Settings window is trying out)."""
    raw = _without_notes(raw)
    rw, mem, cap = raw.get("rewrite", {}), raw.get("memory", {}), raw.get("capture", {})
    nud = raw.get("nudges", {})
    llm, use = _llm_settings(raw)
    cfg = Config(
        rewrite_key=rw.get("key", "right_alt"),
        rewrite_model=rw.get("model", "claude-opus-5-5"),
        rewrite_effort=rw.get("effort", "low"),
        no_em_dashes=bool(rw.get("no_em_dashes", True)),
        sounds=bool(rw.get("sounds", True)),
        memory_model=mem.get("model", "claude-haiku-5-5"),
        nudges_enabled=bool(nud.get("enabled", True)),
        morning_brief=str(nud.get("morning_brief", "08:45")),
        evening_wrap=str(nud.get("evening_wrap", "")),
        meeting_briefs=bool(nud.get("meeting_briefs", True)),
        followups=bool(nud.get("followups", True)),
        max_followups_per_day=int(nud.get("max_followups_per_day", 3)),
        changes=bool(nud.get("changes", True)),
        max_changes_per_day=int(nud.get("max_changes_per_day", 3)),
        quiet_hours=str(nud.get("quiet_hours", "21:00-08:00")),
        capture_enabled=cap.get("enabled", True),
        probe_interval_s=float(cap.get("probe_interval_s", 1.0)),
        recheck_every_s=float(cap.get("recheck_every_s", 2.0)),
        walk_every_s=float(cap.get("walk_every_s", 20)),
        coalesce_window_s=float(cap.get("coalesce_window_s", 300)),
        idle_after_s=float(cap.get("idle_after_s", 120)),
        max_chars=int(cap.get("max_chars", 60000)),
        redact=bool(cap.get("redact", True)),
        ocr=bool(cap.get("ocr", True)),
        ocr_below_chars=int(cap.get("ocr_below_chars", 200)),
        ocr_languages=[str(x) for x in cap.get("ocr_languages", ["en-US"])] or ["en-US"],
        blocked_apps=list(cap.get("blocked_apps", [])),
        blocked_domains=list(cap.get("blocked_domains", [])),
        user_name=str(raw.get("identity", {}).get("name", "")).strip() or account_name(),
        embeddings=dict(raw.get("embeddings", {})),
        llm_provider=str(llm.get("provider", "anthropic")).lower(),
        llm_endpoint=str(llm.get("endpoint", "")),
        llm_api_key=str(llm.get("api_key", "") or os.environ.get(llm.get("api_key_env", ""), "")),
        llm_temperature=float(llm["temperature"]) if "temperature" in llm else None,
        llm_max_tokens=int(llm.get("max_tokens", 8000)),
        llm_timeout=float(llm.get("timeout", 180)),
        llm_reasoning_effort=str(llm.get("reasoning_effort", "")),
        llm_extra=dict(llm.get("extra", {})),
        llm_fast_extra=dict(llm.get("fast_extra", {})),
        llm_background_extra=dict(llm.get("background_extra", {})),
        llm_headers=dict(llm.get("headers", {})),
    )
    if use or cfg.llm_provider != "anthropic":
        # One model name for everything unless overridden.
        cfg.rewrite_model = llm.get("rewrite_model") or llm.get("model") or cfg.rewrite_model
        cfg.memory_model = llm.get("memory_model") or llm.get("model") or cfg.memory_model
    cfg.llm_use = use
    cfg.chat_model = str(llm.get("chat_model") or raw.get("chat", {}).get("model") or cfg.rewrite_model)
    cfg.chat_models = [str(m) for m in llm.get("models", [])]
    return cfg


def _llm_settings(raw: dict) -> tuple[dict, str]:
    """[llm] merged with the [providers.<use>] block it names (the block wins), and that name.
    An old flat [llm] section (provider/endpoint/api_key/model in [llm] itself) still works."""
    llm = dict(raw.get("llm", {}))
    use = str(llm.pop("use", "")).strip()
    providers = raw.get("providers", {})
    if not use:
        return llm, ""
    if use not in providers:
        import logging
        fallback = next(iter(providers), "")
        logging.getLogger("donkey").warning("[llm] use = %r has no [providers.%s] block; using %r", use, use, fallback)
        if not fallback:
            return llm, ""
        use = fallback
    block = providers[use]
    merged = {**llm, **block}
    merged["provider"] = str(block.get("kind") or ("anthropic" if use == "anthropic" else "openai"))
    return merged, use


def is_local(endpoint: str) -> bool:
    """A server on this PC (LM Studio, Ollama, llama.cpp), which needs no API key."""
    from urllib.parse import urlsplit
    return (urlsplit(endpoint).hostname or "") in ("localhost", "127.0.0.1", "::1", "0.0.0.0")


def read_raw() -> dict:
    """config.json as written, notes included."""
    load()  # creates the file if missing
    return json.loads(CONFIG_PATH.read_text())


def save_model(use: str, block: dict, name: str | None = None) -> None:
    """Point llm > use at one provider block and update that block (keys it doesn't mention are
    kept), and optionally the name. Written by the Settings window."""
    raw = read_raw()
    raw.setdefault("llm", {})["use"] = use
    providers = raw.setdefault("providers", {})
    providers[use] = {**providers.get(use, {}), **block}
    if name is not None:
        raw.setdefault("identity", {})["name"] = name.strip()
    _write(raw)


def set_capture_list(key: str, values: list[str]) -> None:
    """Write one list under "capture" in config.json (blocked_apps / blocked_domains), keeping the rest."""
    load()  # creates the file if missing
    raw = json.loads(CONFIG_PATH.read_text())
    raw.setdefault("capture", {})[key] = list(values)
    _write(raw)
