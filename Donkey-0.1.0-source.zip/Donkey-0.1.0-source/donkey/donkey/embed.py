"""Embeddings for chronicle summaries and wiki pages: search, "related by meaning", and the map layout.

Two providers, set in the [embeddings] section of the config:
- "gemma": Google's open EmbeddingGemma 2 running on this PC (text-only). Best quality in Donkey's
  tests, free and private. It runs ggml-org's 8-bit GGUF in llama.cpp's server, as DigUp does: a
  helper process started on first use and stopped after IDLE_SECS without one, so the app doesn't
  keep the model around. The installed Donkey carries the model and llama-server.exe (donkey/vendor)
  and uses only those: the build refuses to finish without them, and an install missing one is an
  error (EmbedUnavailable), never a quiet switch to keyword-only search. From source it uses a
  llama-server.exe on the PATH (`winget install llama.cpp`) and a download from Hugging Face.
  Measured 2026-10-17 against the PyTorch build it replaced: the same vectors (cosine >= 0.9998),
  0.7 s to start warm, 14 ms a query vs 27, and ~470 MB RAM vs 2.6 GB.
- "openai": any OpenAI-compatible /embeddings endpoint (OpenRouter, Voyage, OpenAI…).

Imported documents (imports.py) are embedded part by part, at most DOC_PARTS_PER_SYNC per pass so a
big export doesn't hold up the memory pass. Raw snapshots are not embedded; full-text search covers them. Vectors are stored as float32
blobs tagged with the model, and searched by brute-force cosine (thousands of rows is instant).
Switching models re-embeds everything on the next sync.
"""
import hashlib
import json
import logging
import os
import threading
import time
import urllib.error
import urllib.request

import numpy as np

from .db import DB

log = logging.getLogger("donkey.embed")

GEMMA_MODEL = "google/embeddinggemma-2"
GGUF_REPO = "ggml-org/embeddinggemma-2-GGUF"
GGUF_REVISION = "bfcd298762cc34d0357ece5ebdd31791a3a374d8"   # pinned: the vectors must not move under the index
GGUF_FILE = "embeddinggemma-2-Q8_0.gguf"                     # text part only, 310 MB
IDLE_SECS = 600
SERVER_BATCH = 16
MAX_PROMPT_CHARS = 6000        # under the 2048 tokens one input may use
WIKI_BODY_CHARS = 600
DOC_CHARS = 2000               # of each imported part (EmbeddingGemma reads ~2k tokens)
DOC_PARTS_PER_SYNC = 400
API_BATCH = 64

_server = None
_lock = threading.Lock()
_settings = None


def settings() -> dict:
    """{provider, model, endpoint, api_key}; API defaults reuse the LLM provider's endpoint and key."""
    global _settings
    if _settings is None:
        from .config import load
        cfg = load()
        e = cfg.embeddings
        provider = (e.get("provider") or "gemma").lower()  # configs without [embeddings] get the best model
        endpoint = e.get("endpoint") or cfg.llm_endpoint.replace("/chat/completions", "/embeddings")
        _settings = {"provider": provider, "model": e.get("model") or "", "endpoint": endpoint,
                     "api_key": e.get("api_key") or cfg.llm_api_key}
        if provider == "gemma":
            _settings["model"] = e.get("model") or GEMMA_MODEL
    return _settings


def model_tag() -> str:
    s = settings()
    return s["model"] if s["provider"] == "gemma" else f"{s['provider']}:{s['model']}"


# Kept for callers that tag rows; always the active model.
def __getattr__(name):
    if name == "MODEL_NAME":
        return model_tag()
    raise AttributeError(name)


class EmbedUnavailable(RuntimeError):
    """Memory search by meaning can't run; the message says why and what fixes it."""


def _installed() -> bool:
    """The built app (PyInstaller), as opposed to running from source."""
    import sys
    return bool(getattr(sys, "frozen", False))


def _vendored(name: str) -> str | None:
    from .config import VENDOR
    path = VENDOR / name
    return str(path) if path.exists() else None


class _LlamaServer:
    """llama-server with the GGUF, on a free local port, stopped after IDLE_SECS unused."""

    def __init__(self, binary: str, gguf: str):
        import socket
        import subprocess
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            self.port = sock.getsockname()[1]
        self.proc = subprocess.Popen(
            [binary, "-m", gguf, "--embedding", "--pooling", "mean", "--host", "127.0.0.1", "--port", str(self.port),
             "-c", "2048", "-b", "2048", "-ub", "2048", "-ngl", "999", "--log-disable"],
            stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            creationflags=subprocess.CREATE_NO_WINDOW)
        # In a job that ends with Donkey: however this process ends (a kill, a crash, quitting
        # without atexit), Windows stops the server too.
        _kill_with_us(self.proc)
        self.used = time.time()
        deadline = time.time() + 60
        while time.time() < deadline:
            if self.proc.poll() is not None:
                raise RuntimeError(f"llama-server exited ({self.proc.returncode})")
            try:
                if b"ok" in urllib.request.urlopen(f"http://127.0.0.1:{self.port}/health", timeout=1).read():
                    break
            except (urllib.error.URLError, OSError):
                pass
            time.sleep(0.05)
        else:
            self.stop()
            raise RuntimeError("llama-server didn't start in 60 s")
        threading.Thread(target=self._reaper, name="embed-idle", daemon=True).start()

    def _reaper(self) -> None:
        global _server
        while self.proc.poll() is None:
            time.sleep(30)
            with _lock:
                if time.time() - self.used > IDLE_SECS:
                    self.stop()
                    if _server is self:
                        _server = None

    def stop(self) -> None:
        if self.proc.poll() is None:
            self.proc.terminate()
            try:
                self.proc.wait(5)
            except Exception:
                self.proc.kill()

    def encode(self, prompts: list[str]) -> np.ndarray:
        self.used = time.time()
        out = []
        for i in range(0, len(prompts), SERVER_BATCH):
            body = json.dumps({"input": [p[:MAX_PROMPT_CHARS] for p in prompts[i:i + SERVER_BATCH]]}).encode()
            req = urllib.request.Request(f"http://127.0.0.1:{self.port}/v1/embeddings", data=body,
                                         headers={"Content-Type": "application/json"})
            data = json.load(urllib.request.urlopen(req, timeout=120))
            out.extend(d["embedding"] for d in sorted(data["data"], key=lambda d: d["index"]))
        self.used = time.time()
        return np.asarray(out, dtype=np.float32)


_job = None


def _kill_with_us(proc) -> None:
    """Put a child process in a job object that closes (killing what's in it) when Donkey ends."""
    global _job
    try:
        import win32api
        import win32con
        import win32job
        if _job is None:
            _job = win32job.CreateJobObject(None, "")
            info = win32job.QueryInformationJobObject(_job, win32job.JobObjectExtendedLimitInformation)
            info["BasicLimitInformation"]["LimitFlags"] |= win32job.JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
            win32job.SetInformationJobObject(_job, win32job.JobObjectExtendedLimitInformation, info)
        h = win32api.OpenProcess(win32con.PROCESS_SET_QUOTA | win32con.PROCESS_TERMINATE, False, proc.pid)
        win32job.AssignProcessToJobObject(_job, h)
        win32api.CloseHandle(h)
    except Exception:
        log.debug("couldn't tie llama-server to Donkey's lifetime", exc_info=True)


def llama_binary() -> str | None:
    """llama-server.exe's path. The installed app uses only the one it ships with for this PC's
    processor; from source, one on the PATH or where winget puts its links (a copy started at
    sign-in may have an older PATH)."""
    import shutil
    shipped = _vendored(f"llama/{native_arch()}/llama-server.exe")
    if shipped or _installed():
        return shipped
    links = os.path.join(os.environ.get("LOCALAPPDATA", ""), "Microsoft", "WinGet", "Links", "llama-server.exe")
    return shutil.which("llama-server") or (links if os.path.exists(links) else None)


def missing() -> str | None:
    """Why EmbeddingGemma can't run here, as a message for the user; None when it can."""
    if settings()["provider"] != "gemma":
        return None
    if settings()["model"] != GEMMA_MODEL:
        return (f"[embeddings] model is {settings()['model']!r}, but the gemma provider only runs "
                f"{GEMMA_MODEL}. Fix config.json, or remove the model line.")
    if llama_binary() is None:
        if _installed():
            return (f"This Donkey install is missing llama-server.exe for {native_arch()} "
                    "(donkey\\vendor\\llama). Reinstall Donkey.")
        return "llama-server isn't installed. Run: winget install llama.cpp"
    if _installed() and _vendored(GGUF_FILE) is None:
        return f"This Donkey install is missing the embedding model ({GGUF_FILE}). Reinstall Donkey."
    return None


def native_arch() -> str:
    """The PC's own processor ("arm64" or "x64"), even while this x64 Python runs emulated on ARM:
    llama-server is a separate program, so it can run natively there."""
    import ctypes
    from ctypes import wintypes
    try:
        k32 = ctypes.WinDLL("kernel32")
        k32.GetCurrentProcess.restype = wintypes.HANDLE   # without it the handle is cut to 32 bits and the call fails
        k32.IsWow64Process2.argtypes = [wintypes.HANDLE, ctypes.POINTER(ctypes.c_ushort), ctypes.POINTER(ctypes.c_ushort)]
        proc, native = ctypes.c_ushort(), ctypes.c_ushort()
        if k32.IsWow64Process2(k32.GetCurrentProcess(), ctypes.byref(proc), ctypes.byref(native)):
            return "arm64" if native.value == 0xAA64 else "x64"
    except (AttributeError, OSError):
        pass
    arch = os.environ.get("PROCESSOR_ARCHITEW6432") or os.environ.get("PROCESSOR_ARCHITECTURE", "")
    return "arm64" if arch.upper() == "ARM64" else "x64"


def _llama_server() -> _LlamaServer:
    """The running server, started if needed. Raises EmbedUnavailable when a piece is missing."""
    global _server
    with _lock:
        if _server is not None and _server.proc.poll() is None:
            return _server
        if why := missing():
            raise EmbedUnavailable(why)
        binary = llama_binary()
        gguf = _vendored(GGUF_FILE)
        if gguf is None:  # from source only: missing() refuses an install without it
            from huggingface_hub import hf_hub_download
            try:
                gguf = hf_hub_download(GGUF_REPO, GGUF_FILE, revision=GGUF_REVISION, local_files_only=True)
            except Exception:
                gguf = hf_hub_download(GGUF_REPO, GGUF_FILE, revision=GGUF_REVISION)
        _server = _LlamaServer(binary, gguf)
        import atexit
        atexit.register(_server.stop)
        return _server


def _api_encode(texts: list[str]) -> np.ndarray:
    s = settings()
    out: list[list[float]] = []
    for i in range(0, len(texts), API_BATCH):
        body = json.dumps({"model": s["model"], "input": texts[i:i + API_BATCH]}).encode()
        req = urllib.request.Request(s["endpoint"], data=body, method="POST", headers={
            "Content-Type": "application/json", "Authorization": f"Bearer {s['api_key']}", "X-Title": "Donkey"})
        try:
            data = json.load(urllib.request.urlopen(req, timeout=60))
        except urllib.error.HTTPError as e:
            raise RuntimeError(f"embeddings API error {e.code}: {e.read().decode(errors='replace')[:200]}")
        out.extend(d["embedding"] for d in sorted(data["data"], key=lambda d: d["index"]))
    return np.asarray(out, dtype=np.float32)


def encode(texts: list[str], kind: str = "document", titles: list[str] | None = None) -> np.ndarray:
    """kind "document" for stored items, "query" for search text. EmbeddingGemma 2 is trained with
    task prefixes, so they're applied here; other providers get plain text."""
    if not texts:
        return np.zeros((0, 1), dtype=np.float32)
    if kind == "query" and len(texts) == 1:   # one reply searches memory and the ledger with the same words
        key = (model_tag(), texts[0])
        if key not in _query_cache:
            if len(_query_cache) > 64:
                _query_cache.clear()
            _query_cache[key] = _encode(texts, kind, titles)
        return _query_cache[key]
    return _encode(texts, kind, titles)


_query_cache: dict = {}


def _encode(texts: list[str], kind: str, titles: list[str] | None) -> np.ndarray:
    provider = settings()["provider"]
    if provider == "gemma":
        if kind == "query":
            prompts = [f"task: search result | query: {t}" for t in texts]
        else:
            prompts = [f"title: {ti or 'none'} | text: {t}" for ti, t in zip(titles or [None] * len(texts), texts)]
        server = _llama_server()   # raises when it can't run; the caller retries next pass
        return _normalized(server.encode(prompts))
    return _normalized(_api_encode(texts))


def _normalized(vecs: np.ndarray) -> np.ndarray:
    norms = np.linalg.norm(vecs, axis=1, keepdims=True)
    return vecs / np.maximum(norms, 1e-9)


def prewarm(db: DB | None = None) -> None:
    """Load the model on a background thread at startup (and catch up stale vectors), so the first
    search or map refresh doesn't wait for the model to load."""
    def run():
        t = time.time()
        try:
            if settings()["provider"] == "gemma":
                encode(["warm-up"], kind="query")
            if db is not None:
                sync(db)
            log.info("embedding model ready: %s (%.1f s)", model_tag(), time.time() - t)
        except EmbedUnavailable as e:
            log.error("memory search can't run: %s", e)
            from . import notify
            notify.send(f"Memory search can't run. {e}")
        except Exception as e:
            log.exception("embedding warm-up failed")
            from . import notify
            notify.send(f"Memory search failed to start: {e}")
    threading.Thread(target=run, name="embed-warmup", daemon=True).start()


def _hash(text: str) -> str:
    return hashlib.sha1(f"{model_tag()}\n{text}".encode()).hexdigest()


def wiki_text(r) -> str:
    aliases = ", ".join(json.loads(r["aliases"]))
    return (f"{r['title']} ({r['page_type']}{'; also ' + aliases if aliases else ''}): {r['summary']}\n"
            f"{r['body'][:WIKI_BODY_CHARS]}")


def claim_text(r) -> str:
    """A ledger claim as it's embedded (claims.py finds threads by meaning with these)."""
    return f"{r['subject']} · {r['topic']}: {r['value']}" + (f" (because {r['why']})" if r["why"] else "")


SEARCHED_KINDS = ("chronicle", "wiki", "document")   # claims are searched on their own (claims.lookup)


def sync(db: DB) -> int:
    """Embed chronicle rows, wiki pages, imported parts and ledger claims whose text (or the model)
    changed since last time."""
    tag = model_tag()
    have = {(r["kind"], r["ref_id"]): r["text_hash"] for r in db.query("SELECT kind, ref_id, text_hash FROM embeddings")}
    todo: list[tuple[str, int, str, str]] = []  # kind, id, title, text
    for r in db.query("SELECT id, period, period_key, summary FROM chronicle"):
        title, text = f"{r['period']} {r['period_key']}", r["summary"]
        if have.get(("chronicle", r["id"])) != _hash(title + "\n" + text):
            todo.append(("chronicle", r["id"], title, text))
    for r in db.query("SELECT id, title, page_type, aliases, summary, body FROM wiki_pages "
                      "WHERE summary != '' OR body != ''"):
        text = wiki_text(r)
        if have.get(("wiki", r["id"])) != _hash(r["title"] + "\n" + text):
            todo.append(("wiki", r["id"], r["title"], text))
    docs = 0
    for r in db.query("""SELECT p.id, p.text, d.title FROM document_parts p JOIN documents d ON d.id = p.doc_id
                         ORDER BY p.id DESC"""):
        text = r["text"][:DOC_CHARS]
        if have.get(("document", r["id"])) != _hash(r["title"] + "\n" + text):
            todo.append(("document", r["id"], r["title"], text))
            docs += 1
            if docs >= DOC_PARTS_PER_SYNC:
                break  # the rest next pass
    for r in db.query("SELECT id, subject, topic, value, why FROM claims"):
        text = claim_text(r)
        if have.get(("claim", r["id"])) != _hash(r["subject"] + "\n" + text):
            todo.append(("claim", r["id"], r["subject"], text))
    if todo:
        vecs = encode([t[3] for t in todo], titles=[t[2] for t in todo])
        for (kind, ref_id, title, text), vec in zip(todo, vecs):
            db.execute("""INSERT INTO embeddings (kind, ref_id, model, text_hash, vec) VALUES (?, ?, ?, ?, ?)
                          ON CONFLICT (kind, ref_id) DO UPDATE SET model = excluded.model,
                          text_hash = excluded.text_hash, vec = excluded.vec""",
                       (kind, ref_id, tag, _hash(title + "\n" + text), vec.tobytes()))
        log.info("embedded %d items with %s", len(todo), tag)
    db.execute("DELETE FROM embeddings WHERE kind = 'chronicle' AND ref_id NOT IN (SELECT id FROM chronicle)")
    db.execute("DELETE FROM embeddings WHERE kind = 'wiki' AND ref_id NOT IN (SELECT id FROM wiki_pages)")
    db.execute("DELETE FROM embeddings WHERE kind = 'document' AND ref_id NOT IN (SELECT id FROM document_parts)")
    db.execute("DELETE FROM embeddings WHERE kind = 'claim' AND ref_id NOT IN (SELECT id FROM claims)")
    return len(todo)


def vectors(db: DB, kind: str) -> tuple[list[int], np.ndarray]:
    rows = db.query("SELECT ref_id, vec FROM embeddings WHERE kind = ? AND model = ?", (kind, model_tag()))
    if not rows:
        return [], np.zeros((0, 1), dtype=np.float32)
    return [r["ref_id"] for r in rows], np.stack([np.frombuffer(r["vec"], dtype=np.float32) for r in rows])


_matrix_cache: dict = {}


def _all_vectors(db: DB):
    """(keys, matrix) for every vector of the active model, cached until the table changes (imports
    can add tens of thousands of rows; re-reading them on every search would cost more than the search)."""
    # Row count, newest row and a checksum of the text hashes: a vector re-embedded in place changes it.
    sig = tuple(db.query("""SELECT COUNT(*) AS n, COALESCE(MAX(rowid), 0) AS m,
                                   COALESCE(SUM(instr('0123456789abcdef', substr(text_hash, 1, 1)) * 4096
                                                + instr('0123456789abcdef', substr(text_hash, 2, 1)) * 256
                                                + instr('0123456789abcdef', substr(text_hash, 3, 1)) * 16
                                                + instr('0123456789abcdef', substr(text_hash, 4, 1))), 0) AS h
                            FROM embeddings WHERE model = ? AND kind IN (?, ?, ?)""",
                         (model_tag(), *SEARCHED_KINDS))[0]) + (model_tag(),)
    if _matrix_cache.get("sig") != sig:
        rows = db.query("SELECT kind, ref_id, vec FROM embeddings WHERE model = ? AND kind IN (?, ?, ?)",
                        (model_tag(), *SEARCHED_KINDS))
        keys = [(r["kind"], r["ref_id"]) for r in rows]
        matrix = np.stack([np.frombuffer(r["vec"], dtype=np.float32) for r in rows]) if rows else None
        _matrix_cache.update(sig=sig, keys=keys, matrix=matrix)
    return _matrix_cache["keys"], _matrix_cache["matrix"]


def nearest(db: DB, query: str, limit: int = 20) -> list[tuple[str, int, float]]:
    keys, matrix = _all_vectors(db)
    if matrix is None:
        return []
    scores = matrix @ encode([query], kind="query")[0]
    order = np.argsort(-scores)[:limit]
    return [(keys[i][0], keys[i][1], float(scores[i])) for i in order]


def relative_floor(sims: np.ndarray, z: float = 1.0) -> float:
    """A similarity cutoff that works for any model: `z` standard deviations above the mean of all
    pairwise similarities. Models spread their scores very differently (Gemini Embedding 2 packs
    them tightly), so a fixed number like 0.3 would mean different things per model."""
    vals = sims[np.triu_indices(sims.shape[0], k=1)]
    return float(vals.mean() + z * vals.std()) if vals.size else 1.0
