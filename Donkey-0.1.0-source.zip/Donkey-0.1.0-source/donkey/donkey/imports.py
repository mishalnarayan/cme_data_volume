"""Import chats and notes into memory: ChatGPT and Claude exports, Markdown folders, Granola.

    donkey import ~/Downloads/chatgpt-export.zip     (or its conversations.json)
    donkey import ~/Downloads/claude-export/         (Claude's conversations.json)
    donkey import ~/Notes/MyVault                    (Obsidian, an unzipped Notion export, any .md)
    donkey import granola                            (Granola's local cache, notes and transcripts)

Each conversation or note becomes a row in `documents`, split into ~PART_CHARS pieces in
`document_parts` (full-text indexed). They're searchable from search_memory, the chat and MCP
(`get_documents` opens them), but kept apart from screen captures, so they never count as time,
hourly activity, page chrome or recent activity, and importing costs no model calls. Importing
the same export again only rewrites what changed. Secrets are masked as in screen capture.
"""
import hashlib
import json
import os
import logging
import re
import time
import zipfile
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from .db import DB
from .filters import redact

log = logging.getLogger("donkey.imports")

PART_CHARS = 4000
MAX_FILE_BYTES = 4_000_000          # a single note larger than this is skipped
NOTE_SUFFIXES = {".md", ".markdown", ".txt"}
SKIP_DIRS = {".git", ".obsidian", ".trash", "node_modules", ".venv", "__pycache__", ".github"}
GRANOLA_CACHE = Path(os.environ.get("APPDATA") or Path.home() / "AppData" / "Roaming") / "Granola"
EXPORT_KIND = {"chatgpt": "ChatGPT export", "claude": "Claude export"}


@dataclass
class Doc:
    source: str
    external_id: str
    title: str
    created_at: float | None
    updated_at: float | None
    path: str
    turns: list[tuple[float | None, str, str]] = field(default_factory=list)   # (time, speaker, text)


# ------------------------------------------------------------------ helpers

def _ts(value) -> float | None:
    """Unix seconds from a number or an ISO date/time; None if it isn't one."""
    if value is None or value == "":
        return None
    if isinstance(value, (int, float)):
        return float(value) / (1000 if value > 1e11 else 1)
    s = str(value).strip()
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00")).timestamp()
    except ValueError:
        pass
    for fmt in ("%Y-%m-%d %H:%M", "%Y-%m-%d", "%d/%m/%Y", "%B %d, %Y"):
        try:
            return datetime.strptime(s, fmt).timestamp()
        except ValueError:
            continue
    return None


def _clean(text: str) -> str:
    return re.sub(r"\n{3,}", "\n\n", (text or "").replace("\r\n", "\n")).strip()


# ------------------------------------------------------------------ ChatGPT

def _chatgpt_text(message: dict) -> str:
    content = message.get("content") or {}
    kind = content.get("content_type")
    if kind in ("text", "multimodal_text"):
        return "\n".join(p for p in content.get("parts") or [] if isinstance(p, str))
    if kind == "code":
        return f"```\n{content.get('text', '')}\n```"
    return ""


def parse_chatgpt(data: list, path: str) -> list[Doc]:
    docs = []
    for conv in data:
        mapping = conv.get("mapping") or {}
        node = conv.get("current_node")
        chain = []
        while node and node in mapping:  # the branch the user ended on, root last
            chain.append(mapping[node])
            node = mapping[node].get("parent")
        turns = []
        for n in reversed(chain):
            m = n.get("message") or {}
            role = (m.get("author") or {}).get("role")
            if role not in ("user", "assistant") or (m.get("metadata") or {}).get("is_visually_hidden_from_conversation"):
                continue
            text = _clean(_chatgpt_text(m))
            if text:
                turns.append((_ts(m.get("create_time")), "Me" if role == "user" else "ChatGPT", text))
        if turns:
            docs.append(Doc("chatgpt", str(conv.get("conversation_id") or conv.get("id") or conv.get("title")),
                            conv.get("title") or "Untitled chat", _ts(conv.get("create_time")),
                            _ts(conv.get("update_time")), path, turns))
    return docs


# ------------------------------------------------------------------ Claude

def parse_claude(data: list, path: str) -> list[Doc]:
    docs = []
    for conv in data:
        turns = []
        for m in conv.get("chat_messages") or []:
            text = m.get("text") or ""
            if not text.strip():
                text = "\n".join(c.get("text", "") for c in m.get("content") or [] if c.get("type") == "text")
            text = _clean(text)
            if text:
                turns.append((_ts(m.get("created_at")), "Me" if m.get("sender") == "human" else "Claude", text))
        if turns:
            docs.append(Doc("claude", str(conv.get("uuid") or conv.get("name")), conv.get("name") or "Untitled chat",
                            _ts(conv.get("created_at")), _ts(conv.get("updated_at")), path, turns))
    return docs


# ------------------------------------------------------------------ Markdown (Obsidian, Notion export, Granola .md)

_FRONT = re.compile(r"\A---\s*\n(.*?)\n---\s*\n", re.S)
_NOTION_ID = re.compile(r"\s+[0-9a-f]{32}$")


def _front_matter(text: str) -> tuple[dict, str]:
    m = _FRONT.match(text)
    if not m:
        return {}, text
    meta = {}
    for line in m.group(1).splitlines():
        if ":" in line and not line.startswith((" ", "-")):
            k, v = line.split(":", 1)
            meta[k.strip().lower()] = v.strip().strip("'\"")
    return meta, text[m.end():]


def parse_note(file: Path, root: Path) -> Doc | None:
    try:
        if file.stat().st_size > MAX_FILE_BYTES:
            log.info("import: %s is too large, skipped", file)
            return None
        raw = file.read_text(errors="replace")
    except OSError:
        return None
    meta, body = _front_matter(raw)
    body = _clean(body)
    if not body:
        return None
    heading = re.search(r"^#\s+(.+)$", body, re.M)
    title = meta.get("title") or (heading.group(1).strip() if heading else _NOTION_ID.sub("", file.stem))
    granola = any("granola" in f"{k} {v}".lower() for k, v in meta.items()) or "granola.ai" in body[-400:].lower()
    created = next((_ts(meta[k]) for k in ("date", "created", "created_at", "meeting_date", "start_time") if k in meta), None)
    stat = file.stat()
    return Doc("granola" if granola else "markdown", str(file.relative_to(root)) if root != file else file.name,
               title, created or getattr(stat, "st_birthtime", None) or stat.st_mtime, stat.st_mtime, str(file),
               [(None, "", body)])


def parse_folder(folder: Path) -> list[Doc]:
    docs = []
    for file in sorted(folder.rglob("*")):
        if not file.is_file() or file.suffix.lower() not in NOTE_SUFFIXES:
            continue
        if any(part in SKIP_DIRS or part.startswith(".") for part in file.relative_to(folder).parts[:-1]):
            continue
        if doc := parse_note(file, folder):
            docs.append(doc)
    return docs


# ------------------------------------------------------------------ Granola's own cache

def _prosemirror_text(node) -> str:
    """Granola stores notes as ProseMirror JSON when there's no markdown copy."""
    if isinstance(node, dict):
        if node.get("type") == "text":
            return node.get("text", "")
        inner = "".join(_prosemirror_text(c) for c in node.get("content") or [])
        return inner + ("\n" if node.get("type") in ("paragraph", "heading", "listItem", "bulletList") else "")
    if isinstance(node, list):
        return "".join(_prosemirror_text(c) for c in node)
    return ""


def parse_granola_cache(file: Path) -> list[Doc]:
    raw = json.loads(file.read_text())
    cache = raw.get("cache", raw)
    if isinstance(cache, str):
        cache = json.loads(cache)
    state = cache.get("state", cache)
    transcripts = state.get("transcripts") or {}
    docs = []
    for doc_id, d in (state.get("documents") or {}).items():
        if not isinstance(d, dict) or d.get("deleted_at"):
            continue
        notes = d.get("notes_markdown") or d.get("notes_plain") or _prosemirror_text(d.get("notes") or {})
        summary = (d.get("last_viewed_panel") or {}).get("content")
        summary = summary if isinstance(summary, str) else _prosemirror_text(summary or {})
        turns = []
        people = [p.get("name") or p.get("email") for p in (d.get("people") or {}).get("attendees", []) or []
                  if isinstance(p, dict)] if isinstance(d.get("people"), dict) else []
        head = f"Attendees: {', '.join(p for p in people if p)}" if any(people) else ""
        if body := _clean("\n\n".join(x for x in (head, notes, summary) if x and x.strip())):
            turns.append((_ts(d.get("created_at")), "", body))
        for seg in transcripts.get(doc_id) or []:
            if text := _clean(seg.get("text", "")):
                turns.append((_ts(seg.get("start_timestamp")), "Me" if seg.get("source") == "microphone" else "Them", text))
        if turns:
            docs.append(Doc("granola", doc_id, d.get("title") or "Untitled meeting", _ts(d.get("created_at")),
                            _ts(d.get("updated_at")), str(file), turns))
    return docs


def granola_cache_file() -> Path | None:
    files = sorted(GRANOLA_CACHE.glob("cache-v*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    return files[0] if files else None


# ------------------------------------------------------------------ detection

def _conversations(data, path: str) -> list[Doc]:
    if isinstance(data, dict):
        data = data.get("conversations") or []
    if not isinstance(data, list) or not data:
        return []
    first = next((c for c in data if isinstance(c, dict)), {})
    if "mapping" in first:
        return parse_chatgpt(data, path)
    if "chat_messages" in first:
        return parse_claude(data, path)
    raise ValueError(f"{path}: a conversations file, but neither ChatGPT's nor Claude's format.")


def detect(target: str) -> tuple[str, list[Doc]]:
    """What `target` is, and its documents. Raises ValueError with a message for the user."""
    if target.strip().lower() == "granola":
        file = granola_cache_file()
        if not file:
            raise ValueError(f"No Granola cache in {GRANOLA_CACHE}. Is Granola installed and signed in?")
        return "Granola", parse_granola_cache(file)
    path = Path(target).expanduser()
    if not path.exists():
        raise ValueError(f"{path} doesn't exist.")
    if path.is_file() and path.suffix.lower() == ".zip":
        with zipfile.ZipFile(path) as z:
            name = next((n for n in z.namelist() if n.endswith("conversations.json")), None)
            if not name:
                raise ValueError(f"{path.name} has no conversations.json (is it a ChatGPT or Claude export?).")
            docs = _conversations(json.loads(z.read(name)), str(path))
        return EXPORT_KIND[docs[0].source] if docs else "Export", docs
    if path.is_file() and path.suffix.lower() == ".json":
        data = json.loads(path.read_text())
        if isinstance(data, dict) and "cache" in data:
            return "Granola", parse_granola_cache(path)
        docs = _conversations(data, str(path))
        return EXPORT_KIND[docs[0].source] if docs else "Export", docs
    if path.is_dir():
        conv = path / "conversations.json"
        if conv.exists():
            return detect(str(conv))
        return "Notes", parse_folder(path)
    if path.is_file() and path.suffix.lower() in NOTE_SUFFIXES:
        doc = parse_note(path, path)
        return "Note", [doc] if doc else []
    raise ValueError(f"Don't know how to import {path.name}: use a ChatGPT/Claude export (.zip or "
                     "conversations.json), a folder of Markdown notes, or 'granola'.")


# ------------------------------------------------------------------ storing

def parts_of(doc: Doc) -> list[tuple[float | None, str]]:
    """Speaker-labelled text cut into ~PART_CHARS pieces at turn (or paragraph) boundaries."""
    pieces: list[tuple[float | None, str]] = []
    for ts, speaker, text in doc.turns:
        label = f"{speaker}: " if speaker else ""
        if len(text) + len(label) <= PART_CHARS:
            pieces.append((ts, label + text))
            continue
        chunk = label
        for para in text.split("\n\n"):
            while len(para) > PART_CHARS:  # one huge paragraph: hard cut
                if chunk.strip():
                    pieces.append((ts, chunk.rstrip()))
                pieces.append((ts, para[:PART_CHARS]))
                para, chunk = para[PART_CHARS:], ""
            if len(chunk) + len(para) + 2 > PART_CHARS and chunk.strip():
                pieces.append((ts, chunk.rstrip()))
                chunk = ""
            chunk += para + "\n\n"
        if chunk.strip():
            pieces.append((ts, chunk.rstrip()))
    parts, cur, cur_ts = [], f"# {doc.title}\n\n", None
    for ts, piece in pieces:
        if len(cur) + len(piece) + 2 > PART_CHARS and cur.strip():
            parts.append((cur_ts, cur.rstrip()))
            cur, cur_ts = "", None
        cur_ts = cur_ts or ts
        cur += piece + "\n\n"
    if cur.strip():
        parts.append((cur_ts, cur.rstrip()))
    return parts


def store(db: DB, docs: list[Doc], mask: bool = True) -> dict:
    """Insert new documents, rewrite changed ones, skip unchanged ones."""
    counts = {"new": 0, "updated": 0, "unchanged": 0, "parts": 0, "chars": 0}
    now = time.time()
    with db.lock, db.conn:
        for doc in docs:
            parts = [(ts, redact(t) if mask else t) for ts, t in parts_of(doc)]
            digest = hashlib.sha1(json.dumps([doc.title, parts], ensure_ascii=False).encode()).hexdigest()
            row = db.conn.execute("SELECT id, hash FROM documents WHERE source = ? AND external_id = ?",
                                  (doc.source, doc.external_id)).fetchone()
            if row and row["hash"] == digest:
                counts["unchanged"] += 1
                continue
            chars = sum(len(t) for _, t in parts)
            if row:
                doc_id = row["id"]
                db.conn.execute("DELETE FROM document_parts WHERE doc_id = ?", (doc_id,))
                db.conn.execute("""UPDATE documents SET title = ?, path = ?, created_at = ?, updated_at = ?, hash = ?,
                                   chars = ?, imported_at = ? WHERE id = ?""",
                                (doc.title, doc.path, doc.created_at, doc.updated_at, digest, chars, now, doc_id))
                counts["updated"] += 1
            else:
                doc_id = db.conn.execute(
                    """INSERT INTO documents (source, external_id, title, path, created_at, updated_at, hash, chars,
                       imported_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (doc.source, doc.external_id, doc.title, doc.path, doc.created_at, doc.updated_at, digest,
                     chars, now)).lastrowid
                counts["new"] += 1
            db.conn.executemany("INSERT INTO document_parts (doc_id, seq, ts, text) VALUES (?, ?, ?, ?)",
                                [(doc_id, i, ts or doc.created_at, t) for i, (ts, t) in enumerate(parts)])
            counts["parts"] += len(parts)
            counts["chars"] += chars
    return counts


def run(db: DB, target: str, mask: bool = True) -> str:
    """Import `target`; returns a one-line report. Raises ValueError for the user."""
    t0 = time.monotonic()
    kind, docs = detect(target)
    if not docs:
        return f"{kind}: nothing to import in {target}."
    c = store(db, docs, mask)
    log.info("import %s from %s: %s", kind, target, c)
    took = time.monotonic() - t0
    return (f"{kind}: {len(docs)} item{'s' if len(docs) != 1 else ''} — {c['new']} new, {c['updated']} updated, "
            f"{c['unchanged']} unchanged ({c['chars'] / 1000:.0f}k characters, {took:.1f} s).")


def remove(db: DB, source: str | None = None, path_prefix: str | None = None) -> int:
    """Delete imported documents by source and/or original path prefix."""
    where, args = [], []
    if source:
        where.append("source = ?")
        args.append(source)
    if path_prefix:
        where.append("path LIKE ?")
        args.append(str(Path(path_prefix).expanduser()) + "%")
    if not where:
        raise ValueError("Say which imports to remove (a source or a path).")
    ids = [r["id"] for r in db.query(f"SELECT id FROM documents WHERE {' AND '.join(where)}", args)]
    with db.lock, db.conn:
        for doc_id in ids:
            db.conn.execute("DELETE FROM document_parts WHERE doc_id = ?", (doc_id,))
            db.conn.execute("DELETE FROM documents WHERE id = ?", (doc_id,))
    return len(ids)


def summary(db: DB) -> list:
    return db.query("""SELECT source, COUNT(*) AS docs, SUM(chars) AS chars, MAX(imported_at) AS last
                       FROM documents GROUP BY source ORDER BY docs DESC""")
