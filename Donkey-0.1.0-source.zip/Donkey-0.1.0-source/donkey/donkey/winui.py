"""Donkey's windowing layer on Windows: the Qt application and event loop, thread hand-offs, web
panels that talk to their page the way the Mac's WKWebView pages did, screen geometry, and a few
shell helpers.

Coordinates: every window position here is in Qt's logical, top-left global coordinates. UI
Automation and Win32 report physical pixels; `from_physical` converts them (per monitor, since
each can have its own scale). Everything that touches a window runs on the main thread; other
threads hand work over with `call_after`.
"""
import ctypes
import json
import logging
import os
import subprocess
import sys
import tempfile
import threading
from ctypes import wintypes
from pathlib import Path

from PySide6.QtCore import QFile, QIODevice, QObject, QPoint, QRect, Qt, QTimer, QUrl, Signal, Slot
from PySide6.QtGui import QAction, QColor, QCursor, QGuiApplication
from PySide6.QtWebChannel import QWebChannel
from PySide6.QtWebEngineCore import QWebEnginePage, QWebEngineScript, QWebEngineSettings
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtWidgets import QApplication, QMenu, QWidget

log = logging.getLogger("donkey.winui")

user32 = ctypes.WinDLL("user32", use_last_error=True)
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
user32.GetWindowLongPtrW.restype = ctypes.c_ssize_t
user32.GetWindowLongPtrW.argtypes = [wintypes.HWND, ctypes.c_int]
user32.SetWindowLongPtrW.restype = ctypes.c_ssize_t
user32.SetWindowLongPtrW.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_ssize_t]
user32.MonitorFromPoint.restype = wintypes.HMONITOR
user32.MonitorFromPoint.argtypes = [wintypes.POINT, wintypes.DWORD]
user32.GetForegroundWindow.restype = wintypes.HWND
user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
user32.SetForegroundWindow.argtypes = [wintypes.HWND]
user32.AttachThreadInput.argtypes = [wintypes.DWORD, wintypes.DWORD, wintypes.BOOL]
user32.IsWindow.argtypes = [wintypes.HWND]
user32.BringWindowToTop.argtypes = [wintypes.HWND]

GWL_EXSTYLE = -20
WS_EX_TRANSPARENT = 0x20
WS_EX_TOOLWINDOW = 0x80
WS_EX_NOACTIVATE = 0x08000000
MONITOR_DEFAULTTONEAREST = 2

ASSETS = Path(__file__).with_name("assets")
# The frosted panel the Mac drew natively, as CSS: a rounded, nearly opaque card (Windows can't blur
# behind a see-through web view). Goes after a page's own styles. The root needs a background of its
# own (an invisible gradient): with none, CSS spreads the body's colour over the whole window and the
# corners outside the rounding come out square.
GLASS_CSS = """
html { background: linear-gradient(transparent, transparent) !important; }
body { background: rgba(249, 246, 242, .97) !important; border-radius: 14px; box-sizing: border-box;
       border: 1px solid rgba(36, 33, 30, .14); }
@media (prefers-color-scheme: dark) {
  body { background: rgba(43, 40, 37, .97) !important; border-color: rgba(255, 255, 255, .12); } }
"""
# Inter and Source Serif 4 (bundled, OFL) stand in for the Mac's San Francisco and New York, which
# Apple licenses for its own platforms only. _FONTS_JS loads them into every page and frame.
FONT = '"Inter", "Segoe UI Variable Text", "Segoe UI", system-ui, sans-serif'
SERIF = '"Source Serif 4", Georgia, serif'
_LATIN = ("U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, "
          "U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD")
_LATIN_EXT = ("U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329, "
              "U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C4, U+2113, U+2C60-2C7F, U+A720-A7FF")


def _fonts_js() -> str:
    faces = [("Inter", "inter", "100 900"), ("Source Serif 4", "sourceserif4", "200 900")]
    calls = []
    for family, stem, weight in faces:
        for part, rng in (("latin", _LATIN), ("latin-ext", _LATIN_EXT)):
            url = QUrl.fromLocalFile(str(ASSETS / "fonts" / f"{stem}-{part}.woff2")).toString()
            calls.append(f"add({json.dumps(family)}, {json.dumps(url)}, {json.dumps(weight)}, {json.dumps(rng)});")
    return ("(function () { if (!document.fonts || !window.FontFace) return;\n"
            "  function add(f, u, w, r) { try { document.fonts.add(new FontFace(f, 'url(\"' + u + '\") format(\"woff2\")',"
            " {weight: w, unicodeRange: r, display: 'block'})); } catch (e) {} }\n  " + "\n  ".join(calls) + "\n})();")


def _software_gpu() -> bool:
    """True when the display adapter can't really draw 3D: a virtual machine's or Windows' basic
    driver. Chromium blocklists those and paints everything on the CPU, which is far slower than
    letting it use Direct3D on Windows' own software renderer."""
    class DISPLAY_DEVICEW(ctypes.Structure):
        _fields_ = [("cb", wintypes.DWORD), ("DeviceName", wintypes.WCHAR * 32), ("DeviceString", wintypes.WCHAR * 128),
                    ("StateFlags", wintypes.DWORD), ("DeviceID", wintypes.WCHAR * 128), ("DeviceKey", wintypes.WCHAR * 128)]
    names, i = [], 0
    while True:
        d = DISPLAY_DEVICEW(cb=ctypes.sizeof(DISPLAY_DEVICEW))
        if not user32.EnumDisplayDevicesW(None, i, ctypes.byref(d), 0):
            break
        if d.StateFlags & 0x1:  # DISPLAY_DEVICE_ATTACHED_TO_DESKTOP
            names.append(d.DeviceString.lower())
        i += 1
    virtual = ("basic render", "basic display", "virtio", "hyper-v", "vmware", "virtualbox", "parallels",
               "qxl", "remote display", "remotefx", "indirect display")
    return bool(names) and all(any(v in n for v in virtual) for n in names)
SET_HTML_LIMIT = 1_500_000  # setHtml caps at 2 MB (after encoding); bigger pages load from a file


class _MONITORINFOEX(ctypes.Structure):
    _fields_ = [("cbSize", wintypes.DWORD), ("rcMonitor", wintypes.RECT), ("rcWork", wintypes.RECT),
                ("dwFlags", wintypes.DWORD), ("szDevice", wintypes.WCHAR * 32)]


# ------------------------------------------------------------------ the application and its thread

_app: QApplication | None = None
_main_thread = threading.main_thread()


class _Invoker(QObject):
    call = Signal(object)

    def __init__(self):
        super().__init__()
        self.call.connect(self._run, Qt.QueuedConnection)

    @Slot(object)
    def _run(self, fn):
        try:
            fn()
        except Exception:
            log.exception("main-thread call")


_invoker: _Invoker | None = None


def app() -> QApplication:
    """The QApplication, made on first use (on the main thread, before any window)."""
    global _app, _invoker
    if _app is None:
        QApplication.setAttribute(Qt.AA_ShareOpenGLContexts)
        flags = "--disable-features=CalculateNativeWinOcclusion"
        try:
            if _software_gpu():
                flags += " --use-angle=d3d11 --ignore-gpu-blocklist --enable-zero-copy"
                log.info("no hardware graphics: web pages use Direct3D's software renderer")
        except Exception:
            log.exception("graphics check")
        os.environ.setdefault("QTWEBENGINE_CHROMIUM_FLAGS", flags)
        _app = QApplication.instance() or QApplication(sys.argv[:1])
        _app.setQuitOnLastWindowClosed(False)
        _app.setApplicationName("Donkey")
        _app.aboutToQuit.connect(lambda: log.info("event loop ending"))
        _invoker = _Invoker()
    return _app


def on_main_thread() -> bool:
    return threading.current_thread() is _main_thread


def call_after(fn, *args) -> None:
    """Run fn(*args) on the main thread, soon (from any thread)."""
    app()
    _invoker.call.emit(lambda: fn(*args))


def call_later(delay: float, fn, *args) -> None:
    """Run fn(*args) on the main thread after `delay` seconds (from any thread)."""
    def arm():
        QTimer.singleShot(max(0, int(delay * 1000)), _guarded(fn, *args))
    if on_main_thread():
        arm()
    else:
        call_after(arm)


def every(seconds: float, fn) -> QTimer:
    """A repeating main-thread timer; `.stop()` it to end."""
    t = QTimer()
    t.setInterval(max(1, int(seconds * 1000)))
    t.timeout.connect(_guarded(fn))
    t.start()
    return t


def _guarded(fn, *args):
    def run():
        try:
            fn(*args)
        except Exception:
            log.exception("timer callback")
    return run


def run() -> None:
    """The event loop; returns once quit() is called."""
    app().exec()


def quit() -> None:  # noqa: A001 - ends run()
    if _app is not None:
        _app.quit()


# ------------------------------------------------------------------ screens

def _monitor(px: int, py: int):
    hmon = user32.MonitorFromPoint(wintypes.POINT(int(px), int(py)), MONITOR_DEFAULTTONEAREST)
    info = _MONITORINFOEX()
    info.cbSize = ctypes.sizeof(info)
    user32.GetMonitorInfoW(hmon, ctypes.byref(info))
    return info


def _screen_for(info: _MONITORINFOEX):
    screens = QGuiApplication.screens()
    for s in screens:
        if s.name() == info.szDevice:
            return s
    r = info.rcMonitor
    for s in screens:
        g = s.geometry()
        if (g.x(), g.y()) == (r.left, r.top):
            return s
    return QGuiApplication.primaryScreen()


def from_physical(x: float, y: float) -> tuple[float, float]:
    """A point in physical screen pixels (UI Automation, Win32) as Qt logical coordinates."""
    info = _monitor(int(x), int(y))
    s = _screen_for(info)
    dpr = s.devicePixelRatio() or 1.0
    g = s.geometry()
    return g.x() + (x - info.rcMonitor.left) / dpr, g.y() + (y - info.rcMonitor.top) / dpr


def rect_from_physical(x: float, y: float, w: float, h: float) -> tuple[float, float, float, float]:
    lx, ly = from_physical(x, y)
    info = _monitor(int(x), int(y))
    dpr = _screen_for(info).devicePixelRatio() or 1.0
    return lx, ly, w / dpr, h / dpr


def to_physical(x: float, y: float) -> tuple[int, int]:
    """A Qt logical point as physical screen pixels."""
    s = QGuiApplication.screenAt(QPoint(int(x), int(y))) or QGuiApplication.primaryScreen()
    dpr = s.devicePixelRatio() or 1.0
    g = s.geometry()
    # Qt keeps each screen's top-left at its native position and scales from there
    return int(round(g.x() + (x - g.x()) * dpr)), int(round(g.y() + (y - g.y()) * dpr))


def screen_at(x: float, y: float):
    return QGuiApplication.screenAt(QPoint(int(x), int(y))) or QGuiApplication.primaryScreen()


def work_area(x: float, y: float) -> tuple[int, int, int, int]:
    """The usable part (no taskbar) of the screen at that point: (x, y, w, h)."""
    g = screen_at(x, y).availableGeometry()
    return g.x(), g.y(), g.width(), g.height()


def clamp_to_screen(x: float, y: float, w: float, h: float) -> tuple[float, float]:
    """Keep a box (top-left x, y) fully inside the work area of the screen that holds its centre."""
    sx, sy, sw, sh = work_area(x + w / 2, y + h / 2)
    x = min(max(x, sx + 2), sx + sw - w - 2)
    y = min(max(y, sy + 2), sy + sh - h - 2)
    return x, y


def cursor() -> tuple[float, float]:
    p = QCursor.pos()
    return float(p.x()), float(p.y())


def taskbar_rect(x: float, y: float) -> tuple[int, int, int, int] | None:
    """The part of the screen at (x, y) that its work area leaves out (the taskbar, usually)."""
    s = screen_at(x, y)
    g, a = s.geometry(), s.availableGeometry()
    if a.bottom() < g.bottom():
        return g.x(), a.bottom() + 1, g.width(), g.bottom() - a.bottom()
    if a.top() > g.top():
        return g.x(), g.y(), g.width(), a.top() - g.top()
    if a.left() > g.left():
        return g.x(), g.y(), a.left() - g.left(), g.height()
    if a.right() < g.right():
        return a.right() + 1, g.y(), g.right() - a.right(), g.height()
    return None


# ------------------------------------------------------------------ theme

def _reg_dword(name: str, default: int = 1) -> int:
    import winreg
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                            r"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize") as k:
            return int(winreg.QueryValueEx(k, name)[0])
    except OSError:
        return default


def taskbar_is_dark() -> bool:
    return _reg_dword("SystemUsesLightTheme") == 0


def apps_are_dark() -> bool:
    return _reg_dword("AppsUseLightTheme") == 0


# ------------------------------------------------------------------ focus

def foreground() -> int:
    return int(user32.GetForegroundWindow() or 0)


def activate(hwnd: int) -> bool:
    """Bring a window to the front with the keyboard. Windows only lets the app that has the user's
    attention do that, so join the front window's input queue for the moment it takes."""
    hwnd = int(hwnd or 0)
    if not hwnd or not user32.IsWindow(hwnd):
        return False
    front = user32.GetForegroundWindow()
    if front == hwnd:
        return True
    me = kernel32.GetCurrentThreadId()
    other = user32.GetWindowThreadProcessId(front, None) if front else 0
    joined = bool(other and other != me and user32.AttachThreadInput(me, other, True))
    try:
        user32.BringWindowToTop(hwnd)
        ok = bool(user32.SetForegroundWindow(hwnd))
        if not ok:
            # Windows lets the process that sent the last input take the foreground: send a key
            # that means nothing (the one keys.py uses to keep Alt from opening menus) and retry
            user32.keybd_event(0xE8, 0, 0, 0)
            user32.keybd_event(0xE8, 0, 2, 0)
            ok = bool(user32.SetForegroundWindow(hwnd))
    finally:
        if joined:
            user32.AttachThreadInput(me, other, False)
    if user32.IsIconic(hwnd):
        user32.ShowWindow(hwnd, 9)  # SW_RESTORE
    return ok or int(user32.GetForegroundWindow() or 0) == hwnd


def _set_exstyle(hwnd: int, add: int = 0, remove: int = 0) -> None:
    ex = user32.GetWindowLongPtrW(hwnd, GWL_EXSTYLE)
    new = (ex | add) & ~remove
    if new != ex:
        user32.SetWindowLongPtrW(hwnd, GWL_EXSTYLE, new)


# ------------------------------------------------------------------ web panels

_SHIM = r"""
(function () {
  if (window.__donkeyShim) return; window.__donkeyShim = true;
  var queue = [], bridge = null;
  function send(name, msg) {
    var body = JSON.stringify(msg === undefined ? null : msg);
    if (bridge) bridge.post(name, body); else queue.push([name, body]);
  }
  var handlers = new Proxy({}, { get: function (_, name) {
    return { postMessage: function (m) { send(String(name), m); } }; } });
  window.webkit = { messageHandlers: handlers };
  function connect() {
    if (!(window.qt && qt.webChannelTransport && window.QWebChannel)) { setTimeout(connect, 10); return; }
    new QWebChannel(qt.webChannelTransport, function (ch) {
      bridge = ch.objects.bridge;
      queue.splice(0).forEach(function (a) { bridge.post(a[0], a[1]); });
    });
  }
  connect();
})();
"""


def _qwebchannel_js() -> str:
    f = QFile(":/qtwebchannel/qwebchannel.js")
    if f.open(QIODevice.ReadOnly):
        try:
            return bytes(f.readAll()).decode("utf-8")
        finally:
            f.close()
    raise RuntimeError("qwebchannel.js is missing from PySide6")


class _Bridge(QObject):
    def __init__(self, panel):
        super().__init__()
        self.panel = panel

    @Slot(str, str)
    def post(self, name: str, body: str) -> None:
        try:
            msg = json.loads(body) if body else None
        except ValueError:
            msg = body
        handler = self.panel._handlers.get(name)
        if handler is None:
            log.debug("no handler for page message %r", name)
            return
        try:
            handler(msg if msg is not None else {})
        except Exception:
            log.exception("page message %s", name)


class _Page(QWebEnginePage):
    """Links open in the browser, not in the panel."""

    def acceptNavigationRequest(self, url, nav_type, is_main_frame):
        if nav_type == QWebEnginePage.NavigationTypeLinkClicked and url.scheme() in ("http", "https", "mailto"):
            open_url(url.toString())
            return False
        return super().acceptNavigationRequest(url, nav_type, is_main_frame)

    def createWindow(self, _type):
        page = _Page(self.profile(), self)  # window.open: hand the url to the browser

        def hand_over(u):
            # web links only: os.startfile would also run a file:// program or any registered protocol
            if u.scheme() in ("http", "https", "mailto"):
                open_url(u.toString())
            page.deleteLater()
        page.urlChanged.connect(hand_over)
        return page

    def javaScriptConsoleMessage(self, level, message, line, source):
        if level == QWebEnginePage.ErrorMessageLevel:
            log.debug("page: %s (%s:%s)", message, source, line)


class _DragStrip(QWidget):
    """A see-through strip over a panel's header that moves the window, as a title bar does."""

    def __init__(self, panel, height: int, right: int, on_moved):
        super().__init__(panel)
        self.panel, self.h, self.right, self.on_moved = panel, height, right, on_moved
        self.setAttribute(Qt.WA_NoSystemBackground)
        self.setCursor(Qt.ArrowCursor)
        self.relayout()

    def relayout(self) -> None:
        self.setGeometry(0, 0, max(0, self.panel.width() - self.right), self.h)
        self.raise_()

    def mousePressEvent(self, ev):
        if ev.button() != Qt.LeftButton:
            return
        before = self.panel.pos()
        handle = self.panel.windowHandle()
        if handle is not None and handle.startSystemMove():
            # On Windows the move runs its own loop; check where it ended a moment later
            QTimer.singleShot(0, lambda: self._ended(before))

    def _ended(self, before) -> None:
        if self.panel.pos() != before and self.on_moved:
            self.on_moved()


class Panel(QWidget):
    """A borderless window holding a web page with a transparent background.

    `focusable=False` makes it a floating panel that never takes the keyboard or activates Donkey
    (clicks still work); `focusable=True` lets it take typing. Page messages sent with
    `window.webkit.messageHandlers.<name>.postMessage(obj)` arrive at the callback given to
    `on_message(name, fn)` as a dict. `set_hit(rects)` makes the rest of the window let clicks
    through to whatever is under it."""

    def __init__(self, w: int, h: int, *, focusable: bool = False, on_top: bool = True,
                 tool: bool = True, frameless: bool = True, translucent: bool = True, title: str = "Donkey"):
        app()
        super().__init__(None)
        flags = Qt.Window
        if frameless:
            flags |= Qt.FramelessWindowHint
        if tool:
            flags |= Qt.Tool
        if on_top:
            flags |= Qt.WindowStaysOnTopHint
        if not focusable:
            flags |= Qt.WindowDoesNotAcceptFocus
        self.setWindowFlags(flags)
        self.setWindowTitle(title)
        if translucent:
            self.setAttribute(Qt.WA_TranslucentBackground)
        if not focusable:
            self.setAttribute(Qt.WA_ShowWithoutActivating)
        self.focusable = focusable
        self._handlers: dict = {}
        self._loaded = False
        self._pending: list[str] = []
        self._hit: list[tuple[float, float, float, float]] | None = None
        self._passing = False
        self._alpha = 1.0
        self._parked = False
        self._strip: _DragStrip | None = None
        self._tmp_html: Path | None = None
        self.on_deactivate = None
        self.on_close_request = None  # a titled window's close button: return True to let it close

        self.web = QWebEngineView(self)
        self.web.setPage(_Page(self.web))
        page = self.web.page()
        if translucent:
            page.setBackgroundColor(Qt.transparent)
        s = page.settings()
        s.setAttribute(QWebEngineSettings.LocalContentCanAccessFileUrls, True)
        s.setAttribute(QWebEngineSettings.LocalContentCanAccessRemoteUrls, True)
        s.setAttribute(QWebEngineSettings.ShowScrollBars, True)
        self.web.setContextMenuPolicy(Qt.NoContextMenu)
        self._bridge = _Bridge(self)
        self._channel = QWebChannel(page)
        self._channel.registerObject("bridge", self._bridge)
        page.setWebChannel(self._channel)
        for name, src in (("qwebchannel", _qwebchannel_js()), ("donkey-shim", _SHIM)):
            script = QWebEngineScript()
            script.setName(name)
            script.setSourceCode(src)
            script.setInjectionPoint(QWebEngineScript.DocumentCreation)
            script.setWorldId(QWebEngineScript.MainWorld)
            script.setRunsOnSubFrames(False)
            page.scripts().insert(script)
        fonts = QWebEngineScript()
        fonts.setName("donkey-fonts")
        fonts.setSourceCode(_fonts_js())
        fonts.setInjectionPoint(QWebEngineScript.DocumentCreation)
        fonts.setWorldId(QWebEngineScript.MainWorld)
        fonts.setRunsOnSubFrames(True)  # chat bubbles live in iframes
        page.scripts().insert(fonts)
        page.loadFinished.connect(self._load_finished)
        self.resize(int(w), int(h))
        self.web.setGeometry(0, 0, int(w), int(h))
        self.winId()  # make the native window now, so its styles can be set
        if not focusable:
            _set_exstyle(self.hwnd, add=WS_EX_NOACTIVATE)

    # -------------------------------------------------------------- page

    @property
    def hwnd(self) -> int:
        return int(self.winId())

    def on_message(self, name: str, fn) -> None:
        self._handlers[name] = fn

    def load(self, html: str, base: Path = ASSETS) -> None:
        """Show this HTML; relative links resolve against `base`."""
        self._loaded = False
        base_url = QUrl.fromLocalFile(str(base) + os.sep)
        if len(html.encode("utf-8")) < SET_HTML_LIMIT:
            self.web.setHtml(html, base_url)
            return
        # Too big for setHtml: write it beside the assets so relative links still resolve
        if self._tmp_html is None:
            fd, name = tempfile.mkstemp(prefix=".donkey-page-", suffix=".html", dir=str(base))
            os.close(fd)
            self._tmp_html = Path(name)
        try:
            self._tmp_html.write_text(html, encoding="utf-8")
        except OSError:  # a read-only install: fall back to the temp folder (fonts may not load)
            fd, name = tempfile.mkstemp(prefix="donkey-page-", suffix=".html")
            os.close(fd)
            self._tmp_html = Path(name)
            self._tmp_html.write_text(html, encoding="utf-8")
        self.web.load(QUrl.fromLocalFile(str(self._tmp_html)))

    def load_url(self, url: str) -> None:
        self._loaded = False
        self.web.load(QUrl(url))

    def _load_finished(self, ok: bool) -> None:
        self._loaded = True
        pending, self._pending = self._pending, []
        for code in pending:
            self.web.page().runJavaScript(code)

    def js(self, code: str, callback=None) -> None:
        """Run script in the page (after it has loaded); `callback(result)` gets its value."""
        if not self._loaded and callback is None:
            self._pending.append(code)
            return
        if callback is None:
            self.web.page().runJavaScript(code)
        else:
            self.web.page().runJavaScript(code, 0, callback)

    # -------------------------------------------------------------- frame

    def frame(self) -> tuple[float, float, float, float]:
        g = self.geometry()
        return float(g.x()), float(g.y()), float(g.width()), float(g.height())

    def origin(self) -> tuple[float, float]:
        p = self.pos()
        return float(p.x()), float(p.y())

    def move_to(self, x: float, y: float) -> None:
        self.move(int(round(x)), int(round(y)))

    def set_frame(self, x: float, y: float, w: float, h: float) -> None:
        self.setGeometry(QRect(int(round(x)), int(round(y)), max(1, int(round(w))), max(1, int(round(h)))))

    def resizeEvent(self, ev):
        self.web.setGeometry(0, 0, self.width(), self.height())
        if self._strip is not None:
            self._strip.relayout()
        super().resizeEvent(ev)

    def alpha(self) -> float:
        return self._alpha

    def set_alpha(self, a: float) -> None:
        self._alpha = max(0.0, min(1.0, float(a)))
        if not self._parked:
            self.setWindowOpacity(self._alpha)

    # -------------------------------------------------------------- showing

    def shown(self) -> bool:
        """On screen (a parked panel is invisible though its window is still up)."""
        return self.isVisible() and not self._parked

    def park(self) -> None:
        """Hide a floating panel without hiding its window: fully transparent and click-through, but
        still drawing. A hidden web view stops painting and, shown again, puts up its last frame for
        a moment before the current one (a flicker); a parked one comes back exactly as it is now."""
        self.setWindowOpacity(0.0)
        if not self.isVisible():
            self.show()
            _set_exstyle(self.hwnd, add=WS_EX_NOACTIVATE)
        self._parked = True
        self._passing = True
        _set_exstyle(self.hwnd, add=WS_EX_TRANSPARENT)

    def present(self, activate: bool = False) -> None:
        """Show it; `activate` also gives it the keyboard (focusable panels only)."""
        if self._parked:
            self._parked = False
            if self._hit is None:  # with hit rects the pass-through timer sorts out clicks
                self._passing = False
                _set_exstyle(self.hwnd, remove=WS_EX_TRANSPARENT)
            self.setWindowOpacity(self._alpha)
        elif not self.isVisible():
            self.show()
            if not self.focusable:
                _set_exstyle(self.hwnd, add=WS_EX_NOACTIVATE)
        self.raise_()
        if activate and self.focusable:
            self.activateWindow()
            if not activate_window(self):
                log.debug("couldn't take the foreground")
            self.web.setFocus()
        _passthrough.track(self)

    def dismiss(self) -> None:
        if self.focusable:
            self.hide()  # a window that can hold the keyboard really goes, so it can't keep focus
        else:
            self.park()

    def changeEvent(self, ev):
        from PySide6.QtCore import QEvent
        if ev.type() == QEvent.ActivationChange and not self.isActiveWindow() and self.on_deactivate:
            QTimer.singleShot(0, self._deactivated)
        super().changeEvent(ev)

    def _deactivated(self) -> None:
        if not self.isActiveWindow() and self.on_deactivate:
            try:
                self.on_deactivate()
            except Exception:
                log.exception("panel deactivated")

    def closeEvent(self, ev):
        if self.on_close_request is not None and not self.on_close_request():
            ev.ignore()
            return
        super().closeEvent(ev)

    # -------------------------------------------------------------- clicks

    def set_hit(self, rects: list[tuple[float, float, float, float]] | None) -> None:
        """Only these window-local rects take the mouse; elsewhere clicks go to what's below.
        None: the whole window takes them."""
        self._hit = rects
        if rects is None and self._passing:
            self._passing = False
            _set_exstyle(self.hwnd, remove=WS_EX_TRANSPARENT)
        _passthrough.track(self)

    def _update_passthrough(self, cx: float, cy: float) -> None:
        if self._hit is None or not self.shown():
            return
        x, y = self.x(), self.y()
        inside = any(x + rx <= cx < x + rx + rw and y + ry <= cy < y + ry + rh for rx, ry, rw, rh in self._hit)
        passing = not inside
        if passing != self._passing:
            self._passing = passing
            _set_exstyle(self.hwnd, add=WS_EX_TRANSPARENT if passing else 0,
                         remove=0 if passing else WS_EX_TRANSPARENT)

    def add_drag_strip(self, height: int, right: int = 0, on_moved=None) -> None:
        """The top `height` px move the window (leaving `right` px free for a close button)."""
        self._strip = _DragStrip(self, height, right, on_moved)
        self._strip.show()

    def cleanup(self) -> None:
        if self._tmp_html is not None:
            try:
                self._tmp_html.unlink()
            except OSError:
                pass


def activate_window(widget: QWidget) -> bool:
    return activate(int(widget.winId()))


class _PassThrough:
    """Clear parts of a window still take clicks on Windows, so for panels with hit rects a timer
    follows the pointer and makes the window click-through whenever it's off those rects."""

    def __init__(self):
        self.panels: list = []
        self.timer: QTimer | None = None

    def track(self, panel: Panel) -> None:
        if panel._hit is None:
            if panel in self.panels:
                self.panels.remove(panel)
            return
        if panel not in self.panels:
            self.panels.append(panel)
        if self.timer is None:
            self.timer = every(1 / 30, self._tick)

    def _tick(self) -> None:
        if not self.panels:
            return
        cx, cy = cursor()
        for p in list(self.panels):
            try:
                p._update_passthrough(cx, cy)
            except RuntimeError:  # deleted
                self.panels.remove(p)


_passthrough = _PassThrough()


# ------------------------------------------------------------------ menus

def context_menu(items: list, at: tuple[float, float] | None = None) -> None:
    """Pop up a small menu at `at` (default: the pointer). Items: (title, callable[, arg]),
    (title, [items]) for a submenu, (title, None) for a disabled line, or None for a separator."""
    menu = build_menu(items)
    x, y = at or cursor()
    menu.exec(QPoint(int(x), int(y)))


def build_menu(items: list, menu: QMenu | None = None) -> QMenu:
    menu = menu or QMenu()
    for entry in items:
        if entry is None:
            menu.addSeparator()
            continue
        title, action, *rest = entry
        if isinstance(action, list):
            build_menu(action, menu.addMenu(title))
            continue
        act = QAction(title, menu)
        if action is None:
            act.setEnabled(False)
        else:
            arg = rest[0] if rest else None
            act.triggered.connect(lambda _=False, f=action, a=arg, has=bool(rest): _guarded(f, a)() if has else _guarded(f)())
        menu.addAction(act)
    return menu


# ------------------------------------------------------------------ shell

def open_url(url: str) -> None:
    try:
        os.startfile(url)
    except OSError:
        log.warning("couldn't open %s", url)


def open_path(path) -> None:
    open_url(str(path))


def reveal(path) -> None:
    """Show a file selected in Explorer."""
    subprocess.Popen(["explorer", "/select,", str(Path(path))])


def edit_text_file(path) -> None:
    """Open a text file (log, config) in Notepad, which every PC has."""
    subprocess.Popen(["notepad.exe", str(path)])


def color(hex_rgb: str, alpha: float = 1.0) -> QColor:
    c = QColor(hex_rgb)
    c.setAlphaF(alpha)
    return c
