"""End-to-end check of the promise: one key press, and the reply knows what memory knows.

scenarios.json holds a made-up person's history (screens from Teams, Outlook, Excel, WhatsApp...)
and key presses that need it: the MD asks "what happened with the model?" three hours after Amit
said it would be ready by 6 PM. `donkey eval --scenarios` builds memory from that history the way
Donkey does (hour summaries, wiki, day and month roll-ups, embeddings, digest, profile) in a
separate home, data/eval/scenario-home, never the real one. Then it presses the key in each
scenario with the real context gathering and prompt, and scores the reply:

- must: every group needs one of its words in the reply; must_not: none of these phrases.
- found: whether the words a good reply needs were in what the model was given (first prompt or
  lookup results). A miss with "found" is a writing problem; without it, a memory problem.
- judge: a model reads the reply against what a good one gets right, including not inventing an
  answer memory doesn't have (honesty scenarios).

The memory is built once and reused until the history in scenarios.json changes (or --rebuild).
"""
import datetime as dt
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from types import SimpleNamespace

from pydantic import BaseModel

DATA = Path(__file__).with_name("scenarios.json")
HOME_NAME = "scenario-home"


def launch(real_home: Path, rebuild: bool, runs: int, only: list[str] | None, model: str | None = None,
           in_chat: bool = False) -> int:
    """Run the scenarios in a child process whose DONKEY_HOME is the scenario home."""
    from . import config
    home = real_home / "eval" / HOME_NAME
    home.mkdir(parents=True, exist_ok=True)
    shutil.copy(config.CONFIG_PATH, home / "config.json")
    os.chmod(home / "config.json", 0o600)
    args = [sys.executable, "-m", "donkey.scenarios", "--runs", str(runs)] + (["--rebuild"] if rebuild else [])
    for o in only or []:
        args += ["--only", o]
    if model:
        args += ["--model", model]
    if in_chat:
        args.append("--chat")
    env = {**os.environ, "DONKEY_HOME": str(home),
           "PYTHONPATH": os.pathsep.join([str(Path(__file__).parent.parent), os.environ.get("PYTHONPATH", "")])}
    return subprocess.call(args, env=env)


# ------------------------------------------------------------------ building memory

_WHEN = re.compile(r"^-(\d+(?:\.\d+)?)(m|h|d)(?:\s+(\d{1,2}):(\d{2}))?$")


def when(spec: str, now: float) -> float:
    m = _WHEN.match(spec.strip())
    if not m:
        raise ValueError(f"bad time {spec!r}")
    n, unit, hh, mm = float(m.group(1)), m.group(2), m.group(3), m.group(4)
    if unit != "d":
        return now - n * (60 if unit == "m" else 3600)
    day = dt.datetime.fromtimestamp(now) - dt.timedelta(days=n)
    if hh is not None:
        day = day.replace(hour=int(hh), minute=int(mm), second=0, microsecond=0)
    return day.timestamp()


def anchor(real_now: float) -> float:
    """The history is written for a key pressed on a Wednesday afternoon ("this Thursday", "by Monday",
    "Sunday 8:30 PM" all lie ahead): the latest Wednesday 15:00 that has passed."""
    d = dt.datetime.fromtimestamp(real_now).replace(hour=15, minute=0, second=0, microsecond=0)
    d -= dt.timedelta(days=(d.weekday() - 2) % 7)
    if d.timestamp() > real_now:
        d -= dt.timedelta(days=7)
    return d.timestamp()


_DATE = re.compile(r"\{(wdmy|md|d)([+-]\d+)\}")
_DATE_FMT = {"wdmy": "%a, %#d %b %Y", "md": "%B %#d", "d": "%#d"}


def expand(obj, now: float):
    """Dates written as {md+20} ("November 3"), {wdmy+10} ("Sat, 24 Oct 2026") or {d+10} ("24"):
    days after the press, so the same history works whenever the eval runs."""
    if isinstance(obj, str):
        return _DATE.sub(lambda m: time.strftime(_DATE_FMT[m.group(1)], time.localtime(now + int(m.group(2)) * 86400)), obj)
    if isinstance(obj, list):
        return [expand(x, now) for x in obj]
    if isinstance(obj, dict):
        return {k: expand(v, now) for k, v in obj.items()}
    return obj


def _data() -> tuple[dict, str]:
    """The scenarios, and a hash of the history alone: editing a scenario keeps the built memory."""
    data = json.loads(DATA.read_bytes())
    return data, hashlib.sha256(json.dumps(data["seen"], sort_keys=True).encode()).hexdigest()[:16]


def build(cfg, db, data: dict, now: float) -> None:
    """Memory from the history, in the order Donkey would have made it."""
    from . import chronicle, embed, profile, wiki
    for ts, s in sorted(((when(s["when"], now), s) for s in data["seen"]), key=lambda x: x[0]):  # in time order,
        # as captured: the same window seen again soon after folds into the earlier screen
        sid = db.upsert_snapshot({"app": s["app"], "window_title": s["title"], "url": s.get("url"),
                                  "domain": re.sub(r"^www\.", "", re.sub(r"^https?://([^/]+).*", r"\1", s["url"]))
                                  if s.get("url") else None, "content": s["content"], "captured_at": ts}, 0)
        end = min(ts + s.get("mins", 5) * 60, now - 60)
        db.execute("UPDATE snapshots SET last_seen_at = ?, duration_s = ? WHERE id = ?", (end, end - ts, sid))
    keys = set()
    for r in db.query("SELECT captured_at, last_seen_at FROM snapshots"):
        t = r["captured_at"]
        while t <= r["last_seen_at"]:
            keys.add(chronicle.hour_key(t))
            t = chronicle.hour_bounds(chronicle.hour_key(t))[1]
    hours = sorted(k for k in keys if chronicle.hour_bounds(k)[1] <= now)
    print(f"building memory: {len(data['seen'])} screens, {len(hours)} hours", flush=True)
    for k in hours:
        chronicle.process_hour(cfg, db, k)
    read_claims(cfg, db)
    today = dt.date.fromtimestamp(now)
    for day in sorted({k[:10] for k in hours if k[:10] < today.isoformat()}):
        chronicle.process_day(cfg, db, day)
    for week in chronicle.pending_weeks(db, today):
        chronicle.process_week(cfg, db, week)
    for month in chronicle.pending_months(db, today):
        chronicle.process_month(cfg, db, month)
    from . import tidy
    tidy.run(cfg, db, batches=100)
    pages = 0
    for _ in range(20):
        n = wiki.regenerate_dirty(cfg, db)
        pages += n
        if not n:
            break
    wiki.refresh_salience(db)
    embedded = embed.sync(db)
    chronicle.refresh_digest(cfg, db, force=True)
    profile.refresh(cfg, db, force=True, now=now)
    print(f"  {len(hours)} hours, {pages} wiki pages written, {embedded} embedded", flush=True)


def read_claims(cfg, db) -> None:
    """The claims ledger for every summarised hour not read yet, oldest first (also on a memory
    built before the ledger existed, so its effect is measured on the same memory)."""
    from . import claims
    keys = [r["period_key"] for r in db.query(
        "SELECT period_key FROM chronicle WHERE period = 'hour' AND period_key NOT IN "
        "(SELECT hour_key FROM claim_hours) ORDER BY period_key")]
    if keys:
        t0 = time.time()
        filed = sum(claims.process_hour(cfg, db, k) for k in keys)
        print(f"  claims: {len(keys)} hours read, {filed} filed ({time.time() - t0:.0f} s)", flush=True)


# ------------------------------------------------------------------ pressing the key

class Verdict(BaseModel):
    correct: bool
    why: str


JUDGE_SYSTEM = """\
You grade one reply that a writing assistant drafted for the user, from the user's memory. You get \
the user's history (the ground truth: everything that happened), the message being answered, what a \
good reply gets right, and the reply. correct is true only when the reply gets every point of the good \
reply right that the message asks about, and states nothing false or made up: a time, number, name, \
or event that the history doesn't support, or a true detail tied to the wrong thing. Details beyond \
the good reply are fine when the history supports them. Extra courtesy, different \
wording, or leaving out side details the message didn't ask about is fine. When the good reply says \
memory has no answer, correct means the reply claims no answer either way (saying they'll check, or \
a [placeholder], is right). A [placeholder] in square brackets is a blank the user fills in before \
sending, never an invented answer; but a placeholder where the history has the answer is not correct. \
why: one short sentence."""


def target_of(press: dict):
    from .field import Target
    draft = press.get("draft", "")
    browser = press["app"] in ("Google Chrome", "Safari", "Arc")
    return Target(app=SimpleNamespace(name=press["app"], is_browser=browser), element=None, role="AXTextArea",
                  label=press.get("label"), window_title=press["title"], domain=press.get("domain"),
                  url=f"https://{press['domain']}/" if press.get("domain") else None, value=draft, caret=len(draft),
                  kind="draft" if draft else "empty", slice_start=0, slice_end=len(draft))


def _words_in(groups: list[list[str]], text: str) -> list[bool]:
    low = text.lower()
    return [any(w.lower() in low for w in g) for g in groups]


def history(data: dict, now: float) -> str:
    return "\n\n".join(f"[{time.strftime('%a %b %#d %Y %H:%M', time.localtime(when(s['when'], now)))}] {s['app']}: "
                       f"{s['title']}\n{s['content']}" for s in data["seen"])


def press(cfg, db, sc: dict, now: float, truth: str) -> dict:
    """One key press in the scenario, through the real context gathering, prompt, and checks."""
    from . import evals, llm, rewrite, web
    p = sc["press"]
    t = target_of(p)
    r = rewrite.Rewriter(cfg, db)
    in_chat_pane = t.app.is_browser and web.is_chat_surface(t.app.name, t.domain)
    r._screen_context = lambda _t: (p["screen"], None) if in_chat_pane else (None, p["screen"])
    r._clipboard = lambda: None
    r._surface = lambda _t: p.get("to")
    system, user, ctx = r._build_prompt(t, now)
    _seen.queries = queries = []
    res = {"id": sc["id"], "lookups": queries}
    try:
        out, final_user = rewrite.generate(cfg, db, t, system, user, ctx, threading.Event())
    except (llm.LLMError, rewrite.FieldError) as e:
        return {**res, "out": None, "pass": False, "problems": [f"error: {e}"]}
    must, must_not = sc.get("must", []), [m.lower() for m in sc.get("must_not", [])]
    got = _words_in(must, out)
    problems = [f"missing {'/'.join(g[:3])}" for g, ok in zip(must, got) if not ok]
    problems += [f"says \"{m}\"" for m in must_not if m in out.lower()]
    if sc.get("honesty") and (nums := evals.invented_numbers(out, final_user + "\n" + t.value)):
        problems.append("invented " + ", ".join(nums))
    try:
        v = llm.parse(cfg.memory_model, "low", JUDGE_SYSTEM,
                      f"<history>\n{truth}\n</history>\n<message>\n{p['screen']}\n</message>\n" + (f"<draft>\n{t.value}\n</draft>\n" if t.value else "")
                      + f"<good_reply>\n{sc['want']}\n</good_reply>\n<reply>\n{out}\n</reply>", Verdict, 800)
        if not v.correct:
            problems.append(f"judge: {v.why}")
    except llm.LLMError as e:
        problems.append(f"judge error: {e}")
    found = all(_words_in(must, final_user)) if must else None
    return {**res, "out": out, "pass": not problems, "problems": problems, "found": found, "prompt": final_user,
            "found_first": all(_words_in(must, user)) if must else None}


_seen = threading.local()  # the lookups of the press running on this thread


def _record_lookups() -> None:
    from . import rewrite
    orig = rewrite.complete_with_lookups
    if getattr(orig, "recording", False):
        return

    def recording(*a, **k):
        raw, qs, u = orig(*a, **k)
        getattr(_seen, "queries", []).extend(qs)
        return raw, qs, u
    recording.recording = True
    rewrite.complete_with_lookups = recording


# ------------------------------------------------------------------ asking in chat

CHAT_JUDGE_SYSTEM = """\
You grade one answer that Donkey, the user's memory assistant, gave in chat. The user showed it a \
message they got and asked what to tell the other person. You get the user's history (the ground \
truth: everything that happened), the message, what a good answer gets right, and the answer. \
correct is true only when the answer gets every point the message asks about right, and states \
nothing false or made up as fact: a time, number, name or event the history doesn't support, or a \
true detail tied to the wrong thing. Details beyond the good answer are fine when the history \
supports them; wording, length and side details don't matter. A guess clearly marked as one \
("probably X; want me to check?") is fine when the history gives a real basis for it and it isn't \
contradicted. When the good answer says memory has no answer, correct means the answer doesn't \
claim one either way. why: one short sentence."""


def _freeze_clock(at: float) -> None:
    """Make chat and its tools see the scenario's clock, still ticking."""
    import datetime as _dt
    from . import chat, loops, mcp_server
    real = time.time
    offset = at - real()
    time.time = lambda: real() + offset

    class Now(_dt.datetime):
        @classmethod
        def now(cls, tz=None):
            return _dt.datetime.fromtimestamp(time.time(), tz)

    class Today(_dt.date):
        @classmethod
        def today(cls):
            return _dt.date.fromtimestamp(time.time())

    shim = SimpleNamespace(**{k: getattr(_dt, k) for k in dir(_dt) if not k.startswith("__")})
    shim.datetime, shim.date = Now, Today
    for m in (chat, loops, mcp_server):
        m.dt = shim


def ask(cfg, db, sc: dict, truth: str) -> dict:
    """The scenario as a chat question: the user shows Donkey the message and asks what to say."""
    from . import chat, llm
    p = sc.get("press") or {"screen": sc["ask"]}
    if "ask" in sc:  # a question for chat itself
        q = sc["ask"]
    else:
        who = p.get("to") or p["app"]
        q = f"{who} sent me this on {p['app']}:\n\n{p['screen']}\n\nWhat should I tell them?"
    res = {"id": sc["id"], "lookups": []}
    try:
        r = chat.run_agent(cfg, db, [{"role": "user", "content": q}], read_only=True)
    except llm.LLMError as e:
        return {**res, "out": None, "pass": False, "problems": [f"error: {e}"]}
    out = r["text"].replace("|||", "\n")
    res.update(ms=r["ms"], usage=r["usage"], lookups=[t["name"] for t in r["tools"]])
    # No must_not words here: in chat, "Friday 11, moved from Thursday 3" is a right answer that
    # names the old time. The judge decides what's stated as fact.
    must = sc.get("must", [])
    problems = [f"missing {'/'.join(g[:3])}" for g, ok in zip(must, _words_in(must, out)) if not ok]
    try:
        v = llm.parse(cfg.memory_model, "low", CHAT_JUDGE_SYSTEM,
                      f"<history>\n{truth}\n</history>\n<message>\n{p['screen']}\n</message>\n"
                      f"<good_answer>\n{sc['want']}\n</good_answer>\n<answer>\n{out}\n</answer>", Verdict, 800)
        if not v.correct:
            problems.append(f"judge: {v.why}")
    except llm.LLMError as e:
        problems.append(f"judge error: {e}")
    return {**res, "out": out, "pass": not problems, "problems": problems}


def run(runs: int, rebuild: bool, only: list[str] | None, model: str | None = None, in_chat: bool = False) -> None:
    from . import config
    from .db import DB
    if config.HOME.name != HOME_NAME:
        sys.exit(f"refusing to run scenarios in {config.HOME}: they write a made-up memory")
    data, digest = _data()
    cfg = config.load()
    if model and in_chat:
        cfg.chat_model = model
    elif model:
        cfg.rewrite_model = model
    db_path = config.HOME / "donkey.db"
    db = DB(db_path) if db_path.exists() else None
    built = db.get_state("scenarios_built") if db else None
    if rebuild or not built or json.loads(built)["hash"] != digest:
        for f in config.HOME.glob("donkey.db*"):
            f.unlink()
        for name in ("digest.txt", "profile.md"):
            (config.HOME / name).unlink(missing_ok=True)
        db, now = DB(db_path), anchor(time.time())
        data = expand(data, now)
        t0 = time.time()
        build(cfg, db, data, now)
        db.set_state("scenarios_built", json.dumps({"hash": digest, "at": now}))
        print(f"  built in {time.time() - t0:.0f} s", flush=True)
    else:
        now = json.loads(built)["at"]
        data = expand(data, now)
        print(f"reusing memory built {time.strftime('%b %#d %H:%M', time.localtime(now))}", flush=True)
        read_claims(cfg, db)
        from . import embed
        embed.sync(db)
    _record_lookups()
    scenarios = [s for s in data["scenarios"] if not only or s["id"] in only]
    at = now + 120  # the key is pressed two minutes after the last screen
    truth = history(data, now)
    if in_chat:  # a draft to fill in is the key's job, not a chat question
        scenarios = [s for s in scenarios if not s.get("press", {}).get("draft")]
        _freeze_clock(at)
    else:
        scenarios = [s for s in scenarios if "press" in s]
    results = []
    t0 = time.time()
    for i in range(runs):
        with ThreadPoolExecutor(4) as pool:
            batch = list(pool.map(lambda s: ask(cfg, db, s, truth) if in_chat else press(cfg, db, s, at, truth),
                                  scenarios))
        for b in batch:
            b["run"] = i
        results += batch
    out = {"at": time.time(), "model": cfg.chat_model if in_chat else cfg.rewrite_model, "runs": runs,
           "secs": round(time.time() - t0), "results": results, "chat": in_chat}
    if in_chat:
        done = [r for r in results if r.get("ms")]
        if done:
            ms = sorted(r["ms"] for r in done)
            out["median_ms"], out["p90_ms"] = ms[len(ms) // 2], ms[int(len(ms) * 0.9)]
            out["tokens"] = [sum(r["usage"]["prompt_tokens"] for r in done) // len(done),
                             sum(r["usage"]["completion_tokens"] for r in done) // len(done)]
    runs_dir = config.HOME / ("chat-runs" if in_chat else "runs")
    runs_dir.mkdir(exist_ok=True)
    (runs_dir / time.strftime("%Y%m%d-%H%M%S.json")).write_text(json.dumps(out, ensure_ascii=False, indent=1))
    print(report(out, scenarios, runs_dir))


def report(run: dict, scenarios: list[dict], runs_dir: Path) -> str:
    res, n = run["results"], run["runs"]
    by = {s["id"]: [r for r in res if r["id"] == s["id"]] for s in scenarios}
    passed = sum(r["pass"] for r in res)
    held = [r for r in res if next((s for s in scenarios if s["id"] == r["id"]), {}).get("heldout")]
    lines = [f"Held out (scenarios not used to tune Donkey): {sum(r['pass'] for r in held)}/{len(held)} right"] if held else []
    lines += [f"Scenarios{' in chat' if run.get('chat') else ''}: {passed}/{len(res)} replies right "
              f"({passed / len(res):.0%}), {len(scenarios)} scenarios x {n} run(s), {run['model']}, {run['secs']} s"
              + (f", median {run['median_ms'] / 1000:.1f} s, p90 {run['p90_ms'] / 1000:.1f} s, "
                 f"{run['tokens'][0]}+{run['tokens'][1]} tokens per answer" if run.get("median_ms") else ""),
             f"  {'scenario':22}{'right':>7}  {'found':>6}  lookups / problem"]
    for sid, rs in by.items():
        ok = sum(r["pass"] for r in rs)
        found = [r.get("found") for r in rs if r.get("found") is not None]
        f = f"{sum(found)}/{len(found)}" if found else "-"
        bad = next((r for r in rs if not r["pass"]), None)
        note = "; ".join(bad["problems"])[:110] if bad else "; ".join(rs[0]["lookups"])[:110]
        lines.append(f"  {sid:22}{ok:>4}/{len(rs):<2}  {f:>6}  {note}")
    prev = sorted(runs_dir.glob("*.json"))[:-1]
    if prev:
        p = json.loads(prev[-1].read_text())
        pr = [r for r in p["results"] if r["id"] in by]
        if pr:
            lines.append(f"  previous run ({time.strftime('%b %#d %H:%M', time.localtime(p['at']))}): "
                         f"{sum(r['pass'] for r in pr)}/{len(pr)} right")
    lines.append("Replies that missed:")
    for r in res:
        if not r["pass"] and r.get("out"):
            lines.append(f"  [{r['id']}] {' '.join(r['out'].split())[:160]}")
    return "\n".join(lines)


if __name__ == "__main__":
    import argparse
    import logging
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", type=int, default=1)
    ap.add_argument("--rebuild", action="store_true")
    ap.add_argument("--only", action="append")
    ap.add_argument("--model", help="rewrite (or with --chat, answer) with this model instead of the configured one")
    ap.add_argument("--chat", action="store_true", help="ask each scenario in chat instead of pressing the key")
    a = ap.parse_args()
    logging.basicConfig(level=logging.WARNING)
    run(a.runs, a.rebuild, a.only, a.model, a.chat)
