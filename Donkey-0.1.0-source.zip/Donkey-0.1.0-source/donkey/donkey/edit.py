"""Edit mode: a command bar over the field; each instruction edits the text in place.

A session belongs to one field. Each round re-reads the field, sends the draft (or the
highlight) plus the instruction and earlier rounds to the model, and writes the result back
with the same delivery path as a rewrite. The bar stays open between rounds.
"""
import logging
import re
import threading
import time

from . import llm, prompt, sends
from .deliver import DeliveryError, deliver
from .field import FieldError, Target, read_target
from .rewrite import EDIT_LOOKUPS, Cancelled, Rewriter, complete_with_lookups, finalize

log = logging.getLogger("donkey.edit")

LONG_DRAFT_CHARS = 1500  # longer drafts: the model returns only the changed passages
BLOCKS_NOTE = """<output_format>
The draft is long. Unless the instruction changes most of it, don't retype it: output only the \
changes, as one block per change:
<<<EDIT
exact text copied from the draft, long enough to occur only once
===
its replacement
EDIT>>>
Output nothing outside the blocks. If the instruction rewrites most of the draft, output the full \
edited draft instead, with no blocks.
</output_format>"""
_BLOCK = re.compile(r"<<<EDIT\n(.*?)\n===\n(.*?)\n?EDIT>>>", re.S)


def apply_edit_blocks(draft: str, out: str) -> str | None:
    """The draft with each block's text replaced; None when the output is a full text (no blocks).
    Raises ValueError when a block's text doesn't occur exactly once."""
    blocks = _BLOCK.findall(out)
    if not blocks:
        if "<<<EDIT" in out:
            raise ValueError("malformed edit block")
        return None
    text = draft
    for old, new in blocks:
        if text.count(old) != 1:
            raise ValueError(f"block text found {text.count(old)} times: {old[:60]!r}")
        text = text.replace(old, new, 1)
    return text


class EditSession:
    def __init__(self, rewriter: Rewriter, target: Target):
        self.rewriter = rewriter
        self.target = target
        self.rounds: list[tuple[str, str]] = []
        self.cancel = threading.Event()
        self.running = False
        # Edit mode works on the whole field unless something is highlighted.
        if target.kind in ("paragraph", "g", "draft"):
            target.kind, target.slice_start, target.slice_end = "draft", 0, len(target.value)
        # (an email draft above a quoted thread stays "above_quote": the quote is never edited)
        self.ctx = None

    @property
    def scope(self) -> str:
        t = self.target
        if t.kind == "selection":
            return "Selected text"
        if not t.readable:
            return "At the cursor"
        if t.kind == "above_quote":
            return "Draft above the quoted thread"
        return "This draft" if t.value.strip() else "New text"

    def _refresh_target(self) -> None:
        """Re-read the field so a round sees what's there now (earlier rounds, the user's own edits)."""
        old = self.target
        try:
            fresh = read_target(old.app)  # not the frontmost app: that may be the edit bar itself
        except FieldError:
            return
        if fresh.app.pid != old.app.pid:
            return
        if old.kind == "selection":
            # Keep editing the same region: it now holds the previous round's output.
            if fresh.value == old.value:
                fresh.kind, fresh.slice_start, fresh.slice_end = "selection", old.slice_start, old.slice_end
            else:
                return  # field changed under us; keep the old target and let delivery's guards decide
        elif fresh.readable and fresh.kind != "above_quote":
            fresh.kind, fresh.slice_start, fresh.slice_end = "draft", 0, len(fresh.value)
        self.target = fresh

    def run_round(self, instruction: str, before_deliver=None) -> str:
        """Apply one instruction. Returns the delivery method; raises FieldError / LLMError / DeliveryError."""
        self.cancel.clear()
        self.running = True
        t0 = time.monotonic()
        try:
            if self.rounds:
                self._refresh_target()
            t = self.target
            if self.ctx is None:
                self.ctx = self.rewriter.context(t)  # the screen around the field doesn't change between rounds
            user = prompt.build_edit_message(t, instruction, self.rounds, self.ctx)
            cfg = self.rewriter.cfg
            blocks = t.readable and t.kind != "selection" and len(t.slice_text) > LONG_DRAFT_CHARS
            budget = EDIT_LOOKUPS if self.ctx.get("memory") else 0
            try:
                raw, _, user = complete_with_lookups(cfg, self.rewriter.db, prompt.EDIT_SYSTEM,
                                                     user + "\n\n" + BLOCKS_NOTE if blocks else user, self.cancel, budget)
                if blocks:
                    try:
                        raw = apply_edit_blocks(t.slice_text, raw) or raw
                    except ValueError as e:
                        log.info("edit blocks failed to apply (%s); asking for the full text", e)
                        raw, _, _ = complete_with_lookups(
                            cfg, self.rewriter.db, prompt.EDIT_SYSTEM,
                            user + "\n\nThe edit blocks didn't match the draft. Output the full edited draft now, "
                                   "with no blocks.", self.cancel, 0)
            except Cancelled:
                raise llm.Cancelled()
            llm_ms = int((time.monotonic() - t0) * 1000)
            out = finalize(t, raw, self.rewriter.cfg.no_em_dashes)
            if not out.strip():
                raise FieldError("The model returned nothing.")
            if out == t.slice_text:
                self.rounds.append((instruction, out))
                return "unchanged"
            if self.cancel.is_set():
                raise llm.Cancelled()
            if before_deliver:
                before_deliver()
            sends.note_donkey_write(out)
            method = deliver(t, out, cancelled=self.cancel.is_set)
            # Track what's in the field now, so the next round edits the new text.
            if t.readable:
                t.value = t.before + out + t.after
                t.slice_end = t.slice_start + len(out)
            self.rounds.append((instruction, out))
            log.info("edit round %d: %r delivered via %s in %d ms (model %d ms)", len(self.rounds),
                     instruction[:60], method, (time.monotonic() - t0) * 1000, llm_ms)
            self.rewriter.db.record_rewrite(app=t.app.name, domain=t.domain, window_title=t.window_title,
                                            surface=sends.surface_of(t.element, t.app, t.domain, t.window_title),
                                            mode="edit", input_text=instruction,
                                            output_text=out, method=method,
                                            latency_ms=int((time.monotonic() - t0) * 1000))
            return method
        finally:
            self.running = False


def open_session(rewriter: Rewriter) -> EditSession:
    """Read the focused field and start a session (raises FieldError with a user-facing message)."""
    try:
        t = read_target()
    except FieldError as e:
        raise FieldError(f"{e} Then hold the key (or double-click the donkey) to edit.") from None
    return EditSession(rewriter, t)


__all__ = ["EditSession", "open_session", "FieldError", "DeliveryError"]
