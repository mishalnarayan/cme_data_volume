"""Thin helpers over Windows UI Automation (via comtypes), shaped like the macOS Accessibility API
the rest of Donkey was written against: `attr(el, "AXRole")`, `attr(el, "AXValue")`,
`attr(app.element, "AXFocusedUIElement")` and so on map to UI Automation properties and patterns.

Rects are physical screen pixels, top-left origin (winui.from_physical turns them into window
coordinates). Text offsets count UTF-16 units in the text as `AXValue` returns it, with every line
break as a single "\\n".

COM: each thread gets its own UI Automation client (worker threads join the multi-threaded
apartment). Calls time out after half a second, so a hung app can't stall Donkey.
"""
import ctypes
import logging
import os
import threading
import time
from ctypes import wintypes
from dataclasses import dataclass, field
from urllib.parse import urlparse

import comtypes
import comtypes.client

log = logging.getLogger("donkey.ax")

_uia_mod = None


def _mod():
    global _uia_mod
    if _uia_mod is None:
        try:
            from comtypes.gen import UIAutomationClient as m
        except ImportError:
            comtypes.client.GetModule("UIAutomationCore.dll")
            from comtypes.gen import UIAutomationClient as m
        _uia_mod = m
    return _uia_mod


# Browsers by executable name (lower case)
BROWSER_BUNDLES = {
    "chrome.exe", "msedge.exe", "brave.exe", "vivaldi.exe", "opera.exe", "opera_gx.exe", "firefox.exe",
    "chromium.exe", "arc.exe", "dia.exe", "comet.exe", "zen.exe", "librewolf.exe", "waterfox.exe",
    "floorp.exe", "thorium.exe", "yandex.exe", "browser.exe", "iexplore.exe", "duckduckgo.exe",
    "perplexity.exe", "mullvadbrowser.exe", "tor.exe",
}

# Roles whose AXValue is the text we want.
VALUE_ROLES = {"AXStaticText", "AXTextArea", "AXTextField", "AXComboBox", "AXSearchField"}
# Leaf roles whose title/description is content rather than UI chrome.
LABEL_ROLES = {"AXHeading", "AXCell", "AXGroup", "AXRow", "AXLink", "AXDisclosureTriangle"}
# Subtrees that are app chrome, never content.
SKIP_ROLES = {
    "AXMenuBar", "AXMenu", "AXMenuItem", "AXMenuBarItem", "AXToolbar", "AXScrollBar", "AXSlider",
    "AXBusyIndicator", "AXProgressIndicator", "AXValueIndicator", "AXImage", "AXRuler", "AXTitleBar",
}
OBJECT_REPLACEMENT = "￼"
BIG_TEXT_CHARS = 20000  # above this, read only the visible part of a text area
TIMEOUT_MS = 500

# UI Automation ids
P_RUNTIME, P_RECT, P_PID, P_TYPE, P_LOCALTYPE, P_NAME = 30000, 30001, 30002, 30003, 30004, 30005
P_HASFOCUS, P_AUTOMATIONID, P_CLASS, P_HELP, P_LABELEDBY, P_PASSWORD = 30008, 30011, 30012, 30013, 30018, 30019
P_HWND, P_OFFSCREEN, P_FRAMEWORK, P_VALUE, P_VALUE_READONLY = 30020, 30022, 30024, 30045, 30046
P_TEXT_AVAILABLE, P_VALUE_AVAILABLE, P_ARIAROLE, P_ARIAPROPS = 30040, 30043, 30101, 30102
PAT_VALUE, PAT_TEXT, PAT_TEXT2, PAT_LEGACY = 10002, 10014, 10024, 10018
SCOPE_ELEMENT, SCOPE_CHILDREN, SCOPE_DESCENDANTS, SCOPE_SUBTREE = 1, 2, 4, 7
UNIT_CHAR = 0
EP_START, EP_END = 0, 1

ROLE_BY_TYPE = {
    50000: "AXButton", 50001: "AXGroup", 50002: "AXCheckBox", 50003: "AXComboBox", 50004: "AXTextField",
    50005: "AXLink", 50006: "AXImage", 50007: "AXRow", 50008: "AXList", 50009: "AXMenu", 50010: "AXMenuBar",
    50011: "AXMenuItem", 50012: "AXProgressIndicator", 50013: "AXRadioButton", 50014: "AXScrollBar",
    50015: "AXSlider", 50016: "AXIncrementor", 50017: "AXGroup", 50018: "AXTabGroup", 50019: "AXRadioButton",
    50020: "AXStaticText", 50021: "AXToolbar", 50022: "AXHelpTag", 50023: "AXOutline", 50024: "AXRow",
    50025: "AXGroup", 50026: "AXGroup", 50027: "AXValueIndicator", 50028: "AXTable", 50029: "AXRow",
    50030: "AXTextArea", 50031: "AXMenuButton", 50032: "AXWindow", 50033: "AXGroup", 50034: "AXGroup",
    50035: "AXCell", 50036: "AXTable", 50037: "AXTitleBar", 50038: "AXSplitter", 50039: "AXGroup",
    50040: "AXToolbar",
}
WEB_FRAMEWORKS = {"chrome", "gecko"}  # Chromium (Chrome, Edge, Electron) and Firefox page content

# what never changes for an element (values, names, places and focus are read fresh each time)
_STABLE = {P_RUNTIME, P_PID, P_TYPE, P_LOCALTYPE, P_AUTOMATIONID, P_CLASS, P_FRAMEWORK, P_ARIAROLE,
           P_ARIAPROPS, P_PASSWORD, P_HWND, P_LABELEDBY}
_CACHED_PROPS = (P_TYPE, P_NAME, P_OFFSCREEN, P_VALUE, P_AUTOMATIONID, P_CLASS, P_HELP, P_FRAMEWORK,
                 P_ARIAROLE, P_ARIAPROPS, P_PASSWORD, P_RECT, P_HWND, P_PID)

user32 = ctypes.WinDLL("user32", use_last_error=True)
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
user32.GetForegroundWindow.restype = wintypes.HWND
user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
user32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
user32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
user32.GetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int]
user32.GetAncestor.argtypes = [wintypes.HWND, wintypes.UINT]
user32.GetAncestor.restype = wintypes.HWND
user32.SendMessageTimeoutW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM,
                                       wintypes.UINT, wintypes.UINT, ctypes.POINTER(ctypes.c_size_t)]
WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
user32.EnumChildWindows.argtypes = [wintypes.HWND, WNDENUMPROC, wintypes.LPARAM]
kernel32.OpenProcess.restype = wintypes.HANDLE
kernel32.QueryFullProcessImageNameW.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR,
                                                ctypes.POINTER(wintypes.DWORD)]
PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
ES_MULTILINE = 0x4

# ------------------------------------------------------------------ the client, per thread

_tls = threading.local()


_setup_lock = threading.Lock()  # threads starting at once raced in comtypes' setup ("Unspecified error")


def _uia():
    c = getattr(_tls, "uia", None)
    if c is None:
        with _setup_lock:
            return _setup()
    return c


def _setup():
    """This thread's client, walker and cache request, kept only once all three are made (a
    half-made client would break the thread for good)."""
    try:
        comtypes.CoInitializeEx(comtypes.COINIT_MULTITHREADED)
    except OSError:
        pass  # this thread already has an apartment (the Qt main thread is single-threaded)
    m = _mod()
    last = None
    for attempt in range(3):
        try:
            try:
                c = comtypes.client.CreateObject(m.CUIAutomation8, interface=m.IUIAutomation2)
                c.TransactionTimeout = TIMEOUT_MS
                c.ConnectionTimeout = 2 * TIMEOUT_MS
            except Exception:
                c = comtypes.client.CreateObject(m.CUIAutomation, interface=m.IUIAutomation)
            walker = c.ControlViewWalker
            req = c.CreateCacheRequest()
            for pid in _CACHED_PROPS:
                req.AddProperty(pid)
            req.TreeFilter = c.ControlViewCondition
        except Exception as e:
            last = e
            time.sleep(0.05 * (attempt + 1))
            continue
        _tls.walker, _tls.cache_req = walker, req
        _tls.uia = c
        if attempt:
            log.info("UI Automation ready on %s after %d tries", threading.current_thread().name, attempt + 1)
        return c
    log.warning("UI Automation setup failed on %s (%s); trying again next time",
                threading.current_thread().name, last)
    raise last


def _walker():
    _uia()
    return _tls.walker


def is_trusted(prompt: bool = False) -> bool:
    """Windows has no Accessibility permission: any app can use UI Automation."""
    return True


# ------------------------------------------------------------------ elements

class El:
    """One UI Automation element. Properties are read live, or from a cache filled by one call
    for a whole subtree (`cached=True`)."""
    __slots__ = ("e", "cached", "_memo")

    def __init__(self, e, cached: bool = False):
        self.e = e
        self.cached = cached
        self._memo: dict = {}

    def prop(self, pid: int, default=None):
        if pid in self._memo:
            return self._memo[pid]
        try:
            if self.cached and pid in _CACHED_PROPS:
                v = self.e.GetCachedPropertyValue(pid)
            else:
                v = self.e.GetCurrentPropertyValue(pid)
        except Exception:
            v = None
        if v is None or (isinstance(v, str) and v == "" and pid not in (P_VALUE, P_NAME)):
            v = default
        if self.cached or pid in _STABLE:
            self._memo[pid] = v
        return v

    def pattern(self, pid: int):
        m = _mod()
        iface = {PAT_VALUE: m.IUIAutomationValuePattern, PAT_TEXT: m.IUIAutomationTextPattern,
                 PAT_TEXT2: m.IUIAutomationTextPattern2,
                 PAT_LEGACY: m.IUIAutomationLegacyIAccessiblePattern}[pid]
        try:
            p = self.e.GetCurrentPattern(pid)
            return p.QueryInterface(iface) if p else None
        except Exception:
            return None

    def children(self) -> list["El"]:
        if self.cached:
            try:
                arr = self.e.GetCachedChildren()
            except Exception:
                arr = None
            return [El(arr.GetElement(i), True) for i in range(arr.Length)] if arr else []
        out, w = [], _walker()
        try:
            c = w.GetFirstChildElement(self.e)
            while c and len(out) < 2000:
                out.append(El(c))
                c = w.GetNextSiblingElement(c)
        except Exception:
            pass
        return out

    def parent(self) -> "El | None":
        try:
            p = _walker().GetParentElement(self.e)
        except Exception:
            return None
        if not p:
            return None
        try:
            if _uia().CompareElements(p, _uia().GetRootElement()):
                return None
        except Exception:
            pass
        return El(p)

    @property
    def pid(self) -> int:
        return int(self.prop(P_PID, 0) or 0)

    @property
    def control_type(self) -> int:
        return int(self.prop(P_TYPE, 0) or 0)

    def __eq__(self, other):
        if not isinstance(other, El):
            return False
        try:
            return bool(_uia().CompareElements(self.e, other.e))
        except Exception:
            return self.e is other.e

    def __hash__(self):
        rid = self.prop(P_RUNTIME)
        return hash(tuple(rid)) if rid else id(self.e)

    def __repr__(self):
        return f"<El {role_of(self)} {str(self.prop(P_NAME) or '')[:30]!r}>"


@dataclass
class AppEl:
    """Stands for an application, like an AXUIElement made from a pid."""
    pid: int
    hwnd: int


def _wrap(e) -> El | None:
    return El(e) if e else None


def from_handle(hwnd: int) -> El | None:
    try:
        return _wrap(_uia().ElementFromHandle(hwnd))
    except Exception:
        return None


def focused_element() -> El | None:
    try:
        return _wrap(_uia().GetFocusedElement())
    except Exception:
        return None


def element_at(x: int, y: int) -> El | None:
    try:
        return _wrap(_uia().ElementFromPoint(wintypes.POINT(int(x), int(y))))
    except Exception:
        return None


# ------------------------------------------------------------------ role and attributes

def _multiline(el: El) -> bool:
    if "multiline=true" in str(el.prop(P_ARIAPROPS, "") or "").lower():
        return True
    hwnd = el.prop(P_HWND)
    if hwnd:
        if user32.GetWindowLongW(int(hwnd), -16) & ES_MULTILINE:  # GWL_STYLE
            return True
        cls = str(el.prop(P_CLASS, "") or "").lower()
        if "richedit" in cls:
            return True
    r = el.prop(P_RECT)
    return bool(r and len(r) == 4 and r[3] > 64)


def role_of(el) -> str | None:
    if not isinstance(el, El):
        return "AXApplication" if isinstance(el, AppEl) else None
    if "role" in el._memo:
        return el._memo["role"]
    ct = el.control_type
    role = ROLE_BY_TYPE.get(ct)
    aria = str(el.prop(P_ARIAROLE, "") or "").lower()
    if ct == 50030:  # Document: a web page, or a word processor's body
        fw = str(el.prop(P_FRAMEWORK, "") or "").lower()
        role = "AXWebArea" if fw in WEB_FRAMEWORKS and not _is_editable_doc(el) else "AXTextArea"
    elif ct == 50004:
        role = "AXSearchField" if aria == "searchbox" else ("AXTextArea" if _multiline(el) else "AXTextField")
    elif aria == "heading" or str(el.prop(P_LOCALTYPE, "") or "").lower() == "heading":
        role = "AXHeading"
    elif aria in ("textbox",) and ct != 50020:
        role = "AXTextArea" if _multiline(el) else "AXTextField"
    el._memo["role"] = role
    return role


def _is_editable_doc(el: El) -> bool:
    """A Chromium/Firefox document that is itself the editor (designMode iframes, some composers)."""
    v = el.prop(P_VALUE_READONLY)
    return v is False and el.prop(P_VALUE_AVAILABLE) is True and not _looks_like_url(el.prop(P_VALUE))


def _looks_like_url(v) -> bool:
    return isinstance(v, str) and ("://" in v[:12] or v.startswith("about:"))


def _norm(s: str) -> str:
    return s.replace("\r\n", "\n").replace("\r", "\n").replace("\x0b", "\n")


def _text_of(el: El) -> str | None:
    """A text element's whole text: the text pattern if there is one, else its value."""
    tp = el.pattern(PAT_TEXT)
    if tp is not None:
        try:
            return _norm(tp.DocumentRange.GetText(-1))
        except Exception:
            pass
    v = el.prop(P_VALUE)
    return _norm(v) if isinstance(v, str) else None


def _value(el: El) -> str | None:
    role = role_of(el)
    if role == "AXStaticText":
        return el.prop(P_NAME) or el.prop(P_VALUE)
    if role in ("AXTextArea", "AXTextField", "AXSearchField", "AXComboBox"):
        if el.prop(P_PASSWORD):
            return None
        return _text_of(el)
    if role == "AXWebArea":
        return None
    v = el.prop(P_VALUE)
    return v if isinstance(v, str) and v else None


def _window_of(el: El) -> El | None:
    hwnd = el.prop(P_HWND)
    if not hwnd:
        node, hops = el, 0
        while node is not None and hops < 60:
            hwnd = node.prop(P_HWND)
            if hwnd:
                break
            node, hops = node.parent(), hops + 1
    if not hwnd:
        return None
    top = user32.GetAncestor(int(hwnd), 2)  # GA_ROOT
    return from_handle(top) if top else None


def _app_focused(app: AppEl) -> El | None:
    el = focused_element()
    if el is None:
        return None
    if el.pid != app.pid and _owner_pid(app.hwnd) != el.pid and not _inside_window(el, app.hwnd):
        return None
    return el


def _inside_window(el: El, hwnd: int | None) -> bool:
    """The element sits in a child window of `hwnd` drawn by another process: WebView2 apps (the
    new Outlook, Teams…) render in msedgewebview2.exe, inside the app's own window."""
    if not hwnd:
        return False
    e, hops = el, 0
    while e is not None and hops < 40:
        h = e.prop(P_HWND)
        if h:
            return int(user32.GetAncestor(int(h), 2) or 0) == int(user32.GetAncestor(int(hwnd), 2) or hwnd)  # GA_ROOT
        e, hops = e.parent(), hops + 1
    return False


def _app_window(app: AppEl) -> El | None:
    return from_handle(app.hwnd) if app.hwnd else None


def _selected_range(el: El) -> tuple[int, int] | None:
    """(start, length) of the selection or caret, in UTF-16 units of the normalised text."""
    tp = el.pattern(PAT_TEXT)
    if tp is None:
        return None
    try:
        sel = tp.GetSelection()
        if not sel or sel.Length == 0:
            return None
        r = sel.GetElement(0)
        doc = tp.DocumentRange
        head = doc.Clone()
        head.MoveEndpointByRange(EP_END, r, EP_START)
        before = _norm(head.GetText(-1))
        inner = _norm(r.GetText(-1))
    except Exception:
        return None
    return _u16(before), _u16(inner)


def _u16(s: str) -> int:
    return len(s.encode("utf-16-le")) // 2


def attr(el, name, default=None):
    """An AX-style attribute of a UI Automation element (or of an app, for the AXFocused* ones)."""
    if el is None:
        return default
    try:
        v = _attr(el, name)
    except Exception:
        log.debug("attr %s failed", name, exc_info=True)
        v = None
    return default if v is None else v


def _attr(el, name):
    if isinstance(el, AppEl):
        if name == "AXFocusedUIElement":
            return _app_focused(el)
        if name in ("AXFocusedWindow", "AXMainWindow"):
            return _app_window(el)
        return None
    if name == "AXRole":
        return role_of(el)
    if name == "AXSubrole":
        return "AXSecureTextField" if el.prop(P_PASSWORD) else None
    if name == "AXValue":
        return _value(el)
    if name == "AXTitle" and el.control_type == 50032 and el.prop(P_HWND):  # a window: its title, as window_title gives it
        return window_title(int(el.prop(P_HWND))) or None
    if name in ("AXTitle", "AXDescription"):
        n = el.prop(P_NAME)
        return n if n else None
    if name in ("AXPlaceholderValue", "AXHelp"):
        h = el.prop(P_HELP)
        return h if h else None
    if name == "AXTitleUIElement":
        lab = el.prop(P_LABELEDBY)
        if lab:
            try:
                return El(lab.QueryInterface(_mod().IUIAutomationElement))
            except Exception:
                return None
        return None
    if name == "AXParent":
        return el.parent()
    if name == "AXChildren":
        return el.children()
    if name == "AXVisibleChildren":
        return [c for c in el.children() if not c.prop(P_OFFSCREEN)]
    if name == "AXVisibleRows":
        return None
    if name == "AXWindow":
        return _window_of(el)
    if name == "AXSelectedTextRange":
        return _selected_range(el)
    if name == "AXNumberOfCharacters":
        if role_of(el) in ("AXTextField", "AXSearchField", "AXComboBox"):
            v = el.prop(P_VALUE)
            return len(v) if isinstance(v, str) else None
        return None
    if name == "AXURL":
        v = el.prop(P_VALUE)
        return v if _looks_like_url(v) else None
    if name == "AXDocument":
        return None
    if name == "AXDOMIdentifier":
        return el.prop(P_AUTOMATIONID) or None
    if name == "AXDOMClassList":
        if str(el.prop(P_FRAMEWORK, "") or "").lower() not in WEB_FRAMEWORKS:
            return None
        cls = el.prop(P_CLASS)
        return cls.split() if cls else None
    if name in ("AXFrame",):
        return element_frame(el)
    if name == "AXFocused":
        return bool(el.prop(P_HASFOCUS))
    if name == "AXInsertionPointLineNumber":
        return None
    return None


def param_attr(el, name, param, default=None):
    """Only what Donkey asks for: AXStringForRange over (location, length)."""
    if not isinstance(el, El):
        return default
    if name == "AXStringForRange" and param:
        text = _text_of(el)
        if text is None:
            return default
        from .field import u16_to_py
        a = u16_to_py(text, param[0])
        b = u16_to_py(text, param[0] + param[1])
        return text[a:b]
    return default


def set_attr(el, name, value) -> bool:
    if el is None:
        return False
    try:
        if isinstance(el, AppEl):
            if name == "AXManualAccessibility":
                return _wake_chromium(el.hwnd)
            return False
        if name == "AXSelectedTextRange":
            return select_range(el, int(value[0]), int(value[1]))
        if name == "AXFocused":
            el.e.SetFocus()
            return True
        if name == "AXValue":
            return set_value(el, str(value))
    except Exception:
        log.debug("set %s failed", name, exc_info=True)
    return False


def value_settable(el) -> bool:
    """The field takes a whole new value (a plain edit box, not a rich editor)."""
    if not isinstance(el, El):
        return False
    return el.prop(P_VALUE_AVAILABLE) is True and el.prop(P_VALUE_READONLY) is False


_RICH_CLASSES = ("richedit", "richtextbox", "_wwg", "richeditbox")  # RichEdit, WPF/XAML rich boxes, Word
_PLAIN_RICH = ("richeditd2dpt",)  # Notepad's: a RichEdit in plain-text mode


def plain_text_field(el) -> bool:
    """A box that holds only plain text (no formatting a whole-value write could wipe): an edit
    control or combo box that isn't a rich editor."""
    if not isinstance(el, El):
        return False
    cls = str(el.prop(P_CLASS, "") or "").lower()
    if cls in _PLAIN_RICH:
        return True
    return el.control_type in (50004, 50003) and not any(r in cls for r in _RICH_CLASSES)  # Edit, ComboBox


def can_select(el) -> bool:
    """The field lets a range of its text be selected (so a paste can replace just that part)."""
    tp = el.pattern(PAT_TEXT) if isinstance(el, El) else None
    try:
        return tp is not None and int(tp.SupportedTextSelection) != 0  # SupportedTextSelection_None
    except Exception:
        return False


def set_value(el: El, text: str) -> bool:
    vp = el.pattern(PAT_VALUE)
    if vp is None:
        return False
    try:
        vp.SetValue(text.replace("\n", "\r\n") if _wants_crlf(el) else text)
        return True
    except Exception:
        log.debug("SetValue failed", exc_info=True)
        return False


def _wants_crlf(el: El) -> bool:
    """Classic Win32 edit boxes break lines with \\r\\n; web and rich editors take \\n."""
    if str(el.prop(P_FRAMEWORK, "") or "").lower() in WEB_FRAMEWORKS:
        return False
    tp = el.pattern(PAT_TEXT)
    try:
        raw = tp.DocumentRange.GetText(-1) if tp is not None else (el.prop(P_VALUE) or "")
    except Exception:
        raw = ""
    return "\r\n" in raw or str(el.prop(P_FRAMEWORK, "") or "").lower() == "win32"


def select_range(el: El, start: int, length: int) -> bool:
    """Select [start, start+length) given in UTF-16 units of the normalised text."""
    tp = el.pattern(PAT_TEXT)
    if tp is None:
        return False
    try:
        doc = tp.DocumentRange
        raw = doc.GetText(-1)
    except Exception:
        return False
    a, b = _raw_offset(raw, start), _raw_offset(raw, start + length)
    try:
        r = doc.Clone()
        r.MoveEndpointByRange(EP_END, doc, EP_START)  # collapse to the start
        if not _move_to(r, doc, raw, a, EP_START):
            return False
        r.MoveEndpointByRange(EP_END, r, EP_START)
        if b > a and not _move_to(r, doc, raw, b, EP_END):
            return False
        r.Select()
        return True
    except Exception:
        log.debug("select_range failed", exc_info=True)
        return False


def _raw_offset(raw: str, target_u16: int) -> int:
    """The index into the raw text (Python chars) where `target_u16` normalised units end."""
    i = n = 0
    while i < len(raw) and n < target_u16:
        ch = raw[i]
        if ch == "\r" and i + 1 < len(raw) and raw[i + 1] == "\n":
            i += 2
            n += 1
            continue
        n += 2 if ord(ch) > 0xFFFF else 1
        i += 1
    return i


def _move_to(r, doc, raw: str, idx: int, endpoint: int) -> bool:
    """Move one end of `r` so that doc-start..end holds raw[:idx]. Apps count characters
    differently (UTF-16 units, code points, \\r\\n as one or two), so check and correct."""
    want = raw[:idx]
    guesses = [idx, _u16(want), idx - want.count("\r\n")]
    for count in dict.fromkeys(g for g in guesses if g >= 0):
        probe = doc.Clone()
        probe.MoveEndpointByRange(EP_END, doc, EP_START)
        if count:
            probe.MoveEndpointByUnit(EP_END, UNIT_CHAR, count)
        if probe.GetText(-1) == want:
            r.MoveEndpointByRange(endpoint, probe, EP_END)
            if endpoint == EP_START:
                r.MoveEndpointByRange(EP_END, probe, EP_END)
            return True
    return False


def as_text(v) -> str | None:
    return str(v) if isinstance(v, str) else None


def url_string(v) -> str | None:
    return v if isinstance(v, str) and v else None


def domain_of(url: str | None) -> str | None:
    if not url:
        return None
    host = urlparse(url).hostname
    if not host:
        return None
    return host[4:] if host.startswith("www.") else host


# ------------------------------------------------------------------ the app in front

@dataclass
class FrontApp:
    pid: int
    name: str
    bundle_id: str | None  # the executable's file name, lower case ("chrome.exe")
    element: object = field(repr=False)
    path: str | None = None

    @property
    def is_browser(self) -> bool:
        return self.bundle_id in BROWSER_BUNDLES


def _owner_pid(hwnd: int) -> int:
    pid = wintypes.DWORD()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    return int(pid.value)


def describe(el) -> str:
    """One line for the log: what an element is (role, UIA class and framework, name)."""
    if el is None:
        return "nothing"
    try:
        return (f"{role_of(el)} class={el.prop(P_CLASS)!r} framework={el.prop(P_FRAMEWORK)!r} "
                f"name={str(el.prop(P_NAME) or '')[:40]!r} focus={el.prop(P_HASFOCUS)!r}")
    except Exception as e:
        return f"unreadable ({e})"


def class_name(hwnd: int) -> str:
    buf = ctypes.create_unicode_buffer(256)
    user32.GetClassNameW(hwnd, buf, 256)
    return buf.value


_ZERO_WIDTH = dict.fromkeys(map(ord, "​‌‍⁠﻿"))  # Edge writes "Microsoft​ Edge"
_browser_modes: dict[int, tuple[int, str | None]] = {}  # window -> (its pid, "Incognito" / "InPrivate" / None)


def window_title(hwnd: int) -> str:
    """The window's title as the Mac would show it. Chrome on Windows titles an Incognito window
    like any other ("Page - Google Chrome"), and Edge an InPrivate one "Page - [InPrivate] -
    Microsoft Edge", so a private browser window gets the mode the Mac's title carries:
    "Page - Google Chrome (Incognito)", which filters.is_private_window recognises."""
    n = user32.GetWindowTextLengthW(hwnd)
    buf = ctypes.create_unicode_buffer(n + 1)
    user32.GetWindowTextW(hwnd, buf, n + 1)
    title = buf.value.translate(_ZERO_WIDTH)
    mode = _browser_mode(hwnd)
    return f"{title} ({mode})" if mode and not title.endswith(f"({mode})") else title


def _browser_mode(hwnd: int) -> str | None:
    """A Chromium browser window's private mode, from its root view, which Chromium names
    "<page> - Google Chrome (Incognito)" / "<page> - Microsoft Edge (InPrivate)" (the window title
    doesn't say). A window keeps its mode for life, so it's asked once per window."""
    if not hwnd or not class_name(hwnd).startswith("Chrome_WidgetWin"):
        return None
    pid = _owner_pid(hwnd)
    known = _browser_modes.get(hwnd)
    if known and known[0] == pid:
        return known[1]
    try:
        win = from_handle(hwnd)
        root = win.e.FindFirst(SCOPE_CHILDREN, _uia().CreatePropertyCondition(P_CLASS, "BrowserRootView")) if win else None
        name = str(El(root).prop(P_NAME) or "").translate(_ZERO_WIDTH) if root else ""
    except Exception:
        return None  # not cached: asked again next time
    from .filters import is_private_window
    mode = name[name.rindex("(") + 1:-1] if is_private_window(name) else None
    if len(_browser_modes) > 500:
        _browser_modes.clear()
    _browser_modes[hwnd] = (pid, mode)
    return mode


def process_path(pid: int) -> str | None:
    h = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
    if not h:
        return None
    try:
        buf = ctypes.create_unicode_buffer(1024)
        size = wintypes.DWORD(1024)
        if kernel32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(size)):
            return buf.value
        return None
    finally:
        kernel32.CloseHandle(h)


_names: dict[str, str] = {}
_paths: dict[str, str] = {}  # exe name -> full path, for apps seen in front this session


def known_path(exe: str) -> str | None:
    return _paths.get((exe or "").lower())


def app_name(path: str | None) -> str:
    """What people call the app: the exe's file description ("Google Chrome"), else its name."""
    if not path:
        return "Unknown"
    if path in _names:
        return _names[path]
    name = None
    try:
        import win32api
        langs = win32api.GetFileVersionInfo(path, r"\VarFileInfo\Translation")
        for lang, cp in langs or []:
            for key in ("FileDescription", "ProductName"):
                v = win32api.GetFileVersionInfo(path, rf"\StringFileInfo\{lang:04x}{cp:04x}\{key}")
                if v and v.strip():
                    name = v.strip()
                    break
            if name:
                break
    except Exception:
        pass
    if not name or name.lower() in ("application frame host",):
        name = os.path.splitext(os.path.basename(path))[0].replace("_", " ").title()
    _names[path] = name
    return name


def _uwp_child_pid(hwnd: int) -> int | None:
    """Store apps run inside ApplicationFrameHost; their own process owns a CoreWindow child."""
    host = _owner_pid(hwnd)
    found: list[int] = []

    def visit(child, _):
        p = _owner_pid(child)
        if p != host:
            found.append(p)
            return False
        return True
    user32.EnumChildWindows(hwnd, WNDENUMPROC(visit), 0)
    return found[0] if found else None


def front_app() -> FrontApp | None:
    """The app whose window is in front (it has the keyboard)."""
    hwnd = user32.GetForegroundWindow()
    if not hwnd:
        return None
    hwnd = int(hwnd)
    pid = _owner_pid(hwnd)
    if class_name(hwnd) == "ApplicationFrameWindow":
        pid = _uwp_child_pid(hwnd) or pid
    if not pid:
        return None
    path = process_path(pid)
    exe = os.path.basename(path).lower() if path else None
    if exe:
        _paths[exe] = path
    return FrontApp(pid, app_name(path) if path else f"pid {pid}", exe, AppEl(pid, hwnd), path)


_enabled_pids: set[int] = set()
WM_GETOBJECT = 0x003D
OBJID_CLIENT = -4
UIA_ROOT_OBJECT_ID = -25


def _wake_chromium(hwnd: int) -> bool:
    """Chromium and Electron build their accessibility tree once something asks a render widget."""
    hosts: list[int] = []

    def visit(child, _):
        if class_name(child) == "Chrome_RenderWidgetHostHWND":
            hosts.append(child)
        return True
    user32.EnumChildWindows(hwnd, WNDENUMPROC(visit), 0)
    res = ctypes.c_size_t()
    for h in hosts:
        for obj in (OBJID_CLIENT, UIA_ROOT_OBJECT_ID):
            user32.SendMessageTimeoutW(h, WM_GETOBJECT, 0, obj, 0x2, 200, ctypes.byref(res))  # SMTO_ABORTIFHUNG
    return bool(hosts)


def ensure_accessibility(app: FrontApp) -> bool:
    """Ask Chromium/Electron apps to build their accessibility tree. True the first time per pid."""
    if app.pid in _enabled_pids:
        return False
    _enabled_pids.add(app.pid)
    if isinstance(app.element, AppEl):
        _wake_chromium(app.element.hwnd)
    return True


@dataclass
class Probe:
    """Cheap per-tick read; the capture loop walks only when `key` changes."""
    window: object = field(repr=False)
    title: str
    focused: object = field(repr=False)
    focused_role: str | None
    key: tuple


def probe(app: FrontApp) -> Probe:
    hwnd = app.element.hwnd if isinstance(app.element, AppEl) else 0
    title = window_title(hwnd) if hwnd else ""
    window = from_handle(hwnd) if hwnd else None
    focused = attr(app.element, "AXFocusedUIElement")
    role = role_of(focused) if focused is not None else None
    nchars = attr(focused, "AXNumberOfCharacters")
    return Probe(window, title, focused, role, (app.pid, title, role, nchars))


def find_web_area(window, focused=None, max_nodes: int = 800):
    """The page (Document) of a browser window: up from the focused element, else breadth-first down."""
    el, hops = focused, 0
    while isinstance(el, El) and hops < 40:
        if role_of(el) == "AXWebArea":
            return el
        el, hops = el.parent(), hops + 1
    if not isinstance(window, El):
        return None
    try:  # one call: the first Chromium/Firefox document in the window
        c = _uia()
        cond = c.CreatePropertyCondition(P_TYPE, 50030)
        hit = window.e.FindFirst(SCOPE_DESCENDANTS, cond)
        if hit:
            d = El(hit)
            if role_of(d) == "AXWebArea":
                return d
    except Exception:
        pass
    return None


def web_text(web) -> str | None:
    """Whole page text in one call, through the document's text pattern."""
    if not isinstance(web, El):
        return None
    tp = web.pattern(PAT_TEXT)
    if tp is None:
        return None
    try:
        return _norm(tp.DocumentRange.GetText(-1))
    except Exception:
        return None


Rect = tuple[float, float, float, float]  # x, y, w, h in physical screen pixels (top-left origin)


def element_frame(el) -> Rect | None:
    if not isinstance(el, El):
        return None
    r = el.prop(P_RECT)
    if not r or len(r) != 4:
        return None
    x, y, w, h = (float(v) for v in r)
    if w <= 0 and h <= 0:
        return None
    return x, y, w, h


def visible_frame(el) -> Rect | None:
    """The element's frame clipped to its window (long documents extend far past the screen)."""
    f = element_frame(el)
    w = element_frame(_window_of(el)) if isinstance(el, El) else None
    if not f or not w:
        return f
    x1, y1 = max(f[0], w[0]), max(f[1], w[1])
    x2, y2 = min(f[0] + f[2], w[0] + w[2]), min(f[1] + f[3], w[1] + w[3])
    return (x1, y1, x2 - x1, y2 - y1) if x2 > x1 and y2 > y1 else None


def caret_bounds(el, utf16_offset: int | None = None) -> Rect | None:
    """Screen rect of the caret (the offset is unused: UI Automation knows where the caret is)."""
    if not isinstance(el, El):
        return None
    tp2 = el.pattern(PAT_TEXT2)
    ranges = []
    try:
        if tp2 is not None:
            res = tp2.GetCaretRange()  # comtypes gives (isActive, range)
            r = next((x for x in (res if isinstance(res, tuple) else (res,)) if hasattr(x, "GetBoundingRectangles")), None)
            if r is not None:
                ranges.append(r)
    except Exception:
        pass
    tp = el.pattern(PAT_TEXT)
    if not ranges and tp is not None:
        try:
            sel = tp.GetSelection()
            if sel and sel.Length:
                ranges.append(sel.GetElement(0))
        except Exception:
            pass
    for r in ranges:
        rect = _range_rect(r)
        if rect is None:
            try:  # an empty range has no box in some apps: measure the next character instead
                wide = r.Clone()
                if wide.MoveEndpointByUnit(EP_END, UNIT_CHAR, 1) == 0:
                    wide.MoveEndpointByUnit(EP_START, UNIT_CHAR, -1)
                rect = _range_rect(wide)
                if rect:
                    rect = (rect[0], rect[1], 1.0, rect[3])
            except Exception:
                rect = None
        if rect and rect[3] > 0 and (rect[0], rect[1]) != (0.0, 0.0):
            return rect
    return None


def _range_rect(r) -> Rect | None:
    try:
        vals = list(r.GetBoundingRectangles() or [])
    except Exception:
        return None
    if len(vals) < 4:
        return None
    x, y, w, h = (float(v) for v in vals[:4])
    return x, y, max(w, 1.0), h


def element_text(el) -> str | None:
    """All text inside one web element, in one call (the page's text pattern), else a short walk."""
    if not isinstance(el, El):
        return None
    node, hops = el, 0
    while node is not None and hops < 40 and role_of(node) != "AXWebArea":
        node, hops = node.parent(), hops + 1
    tp = node.pattern(PAT_TEXT) if node is not None else None
    if tp is not None:
        try:
            text = tp.RangeFromChild(el.e).GetText(-1)
            if text is not None:
                return _norm(text).replace(OBJECT_REPLACEMENT, " ")
        except Exception:
            pass
    w = walk_text(el, max_nodes=600, deadline_s=0.5)
    return "\n".join(w.lines) or None


def dom_id(el) -> str | None:
    return as_text(attr(el, "AXDOMIdentifier"))


def dom_classes(el) -> set[str]:
    classes = attr(el, "AXDOMClassList")
    return {str(c) for c in classes} if classes else set()


@dataclass
class Walk:
    lines: list[str] = field(default_factory=list)
    nodes: int = 0
    exhausted: bool = False


def cached_tree(root):
    """The subtree under `root` with its properties, fetched in one cross-process call."""
    if not isinstance(root, El):
        return root
    try:
        _uia()
        req = _tls.cache_req
        req.TreeScope = SCOPE_SUBTREE
        return El(root.e.BuildUpdatedCache(req), True)
    except Exception:
        return root


def walk_text(root, max_nodes: int = 4000, deadline_s: float = 1.5, max_chars: int = 60000) -> Walk:
    """Depth-first walk collecting visible text in reading order, within a node and time budget."""
    out = Walk()
    stop_at = time.monotonic() + deadline_s
    total = 0
    stack = [cached_tree(root)]
    while stack:
        if out.nodes >= max_nodes or time.monotonic() > stop_at or total >= max_chars:
            out.exhausted = True
            break
        el = stack.pop()
        if not isinstance(el, El):
            continue
        out.nodes += 1
        role = role_of(el)
        if role in SKIP_ROLES or el.prop(P_OFFSCREEN) is True and role != "AXWindow":
            continue
        text = None
        if role in VALUE_ROLES:
            text = _value_text(el, role)
        kids = el.children()
        if text is None and not kids and role in LABEL_ROLES:
            text = as_text(attr(el, "AXTitle"))
        if text:
            text = text.strip()
            if text and (not out.lines or out.lines[-1] != text):
                out.lines.append(text)
                total += len(text)
        if role in ("AXTextArea", "AXTextField") and text:
            continue  # its text is in; its children are the same text again
        stack.extend(reversed(kids))
    return out


def _value_text(el: El, role: str) -> str | None:
    if role == "AXStaticText":
        n = el.prop(P_NAME)
        return n if n else None
    if el.prop(P_PASSWORD):
        return None
    if role == "AXTextArea":
        tp = el.pattern(PAT_TEXT)
        if tp is not None:
            try:
                ranges = tp.GetVisibleRanges()
                text = _norm(tp.DocumentRange.GetText(BIG_TEXT_CHARS + 1))
                if len(text) > BIG_TEXT_CHARS and ranges and ranges.Length:
                    return "\n".join(_norm(ranges.GetElement(i).GetText(-1)) for i in range(ranges.Length))
                return text
            except Exception:
                pass
    v = el.prop(P_VALUE)
    return _norm(v) if isinstance(v, str) and v else None


@dataclass
class Frame:
    app: str
    bundle_id: str | None
    pid: int
    window_title: str
    url: str | None
    domain: str | None
    content: str
    focused_role: str | None
    focused_name: str | None
    walk_ms: int
    nodes: int
    exhausted: bool
    method: str  # "markers" (browser page text) or "walk"


def read_frame(app: FrontApp, p: Probe, max_chars: int = 60000) -> Frame:
    """Read the front window: URL and page text for browsers, a tree walk for everything else."""
    t0 = time.monotonic()
    url, text, method, nodes, exhausted = None, None, "walk", 0, False
    web = find_web_area(p.window, p.focused) if p.window is not None and app.is_browser else None
    if web is not None:
        url = url_string(attr(web, "AXURL"))
        text = web_text(web)
        if text:
            method = "markers"
    if not text and p.window is not None:
        w = walk_text(web or p.window, max_chars=max_chars)
        text, nodes, exhausted = "\n".join(w.lines), w.nodes, w.exhausted
    text = (text or "").replace(OBJECT_REPLACEMENT, " ")
    focused_name = None
    if p.focused is not None:
        focused_name = (as_text(attr(p.focused, "AXTitle")) or as_text(attr(p.focused, "AXPlaceholderValue")))
    return Frame(
        app=app.name, bundle_id=app.bundle_id, pid=app.pid, window_title=p.title,
        url=url, domain=domain_of(url), content=text[:max_chars], focused_role=p.focused_role,
        focused_name=focused_name, walk_ms=int((time.monotonic() - t0) * 1000), nodes=nodes,
        exhausted=exhausted, method=method,
    )
