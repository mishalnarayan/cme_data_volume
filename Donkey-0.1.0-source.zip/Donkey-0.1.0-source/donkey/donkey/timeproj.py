"""Time by project.

Foreground time is credited per window title (db.time_titles). Each title-level row is filed:
  1. by a rule: project + any of app, domain, title_contains, all of which must match. Rules are
     stated by the user (`donkey projects add`) or proposed by the model from time no rule or
     category claims yet, with the hour summaries as context (at most 6 per run). A project is
     something the user works ON, never the tool or site it happens in; proposals that name an
     app or site, or that would match nothing, are dropped in code;
  2. by a built-in category (email, chat, social, video, shopping, search, AI, meetings, news);
  3. otherwise it is unassigned.
Once a month the model looks over the project list: near-duplicates merge into the established
name and things that aren't projects are retired (their learned rules are switched off).
Hours from before title tracking only have app/domain rows; rules without title_contains still
apply to them.
"""
import datetime as dt
import json
import logging
import re
import time

from pydantic import BaseModel, Field

from . import llm
from .config import Config
from .db import DB

log = logging.getLogger("donkey.timeproj")

MAX_RULES_PER_RUN = 6
MIN_UNMATCHED_S = 120          # a title must have this much unclaimed time to be shown to the proposer
PROPOSE_EVERY_S = 2 * 3600
STATE_PROPOSED = "time_rules_proposed_at"
STATE_CURATED = "time_rules_curated_month"

_BROWSER_SUFFIX = re.compile(r"\s+[-–—]\s+(?:Google Chrome|Brave|Comet|Chromium|Microsoft Edge|Vivaldi|Arc|Safari|"
                             r"Mozilla Firefox|Firefox)(?:\s+[-–—]\s+.*)?$")
_UNREAD = re.compile(r"^\(\d+\+?\)\s*")


def time_title(title: str | None) -> str:
    """A window title as time is filed under it: no browser name, no unread counter."""
    t = _UNREAD.sub("", _BROWSER_SUFFIX.sub("", (title or "").strip()))
    return " ".join(t.split())[:160]


# ------------------------------------------------------------------ categories

CATEGORIES = {
    "email": ("mail.google.com", "outlook.live.com", "outlook.office.com", "mail.yahoo.com", "proton.me", "fastmail.com",
              "app:mail", "app:microsoft outlook", "app:spark", "app:superhuman", "app:mimestream"),
    "chat": ("web.whatsapp.com", "slack.com", "app.slack.com", "discord.com", "web.telegram.org", "messenger.com",
             "teams.microsoft.com", "app:whatsapp", "app:slack", "app:messages", "app:telegram", "app:discord",
             "app:signal", "app:microsoft teams"),
    "meetings": ("meet.google.com", "zoom.us", "app:zoom", "app:zoom.us", "app:facetime", "app:webex"),
    "social": ("instagram.com", "facebook.com", "x.com", "twitter.com", "reddit.com", "linkedin.com", "threads.net",
               "tiktok.com", "snapchat.com", "pinterest.com", "quora.com"),
    "video": ("youtube.com", "netflix.com", "primevideo.com", "hotstar.com", "jiocinema.com", "twitch.tv",
              "vimeo.com", "app:tv", "app:iina", "app:vlc"),
    "shopping": ("amazon.com", "amazon.in", "flipkart.com", "myntra.com", "ajio.com", "meesho.com", "ebay.com",
                 "etsy.com", "nykaa.com", "swiggy.com", "zomato.com", "blinkit.com", "zeptonow.com"),
    "search": ("google.com", "bing.com", "duckduckgo.com", "search.brave.com", "new-tab-page"),
    "AI": ("chatgpt.com", "chat.openai.com", "claude.ai", "gemini.google.com", "perplexity.ai", "grok.com",
           "app:chatgpt", "app:claude"),
    "news": ("news.ycombinator.com", "nytimes.com", "theguardian.com", "bbc.com", "bbc.co.uk", "timesofindia.indiatimes.com",
             "hindustantimes.com", "ndtv.com", "thehindu.com", "medium.com", "substack.com"),
}
_CAT_DOMAIN = {d: c for c, items in CATEGORIES.items() for d in items if not d.startswith("app:")}
_CAT_APP = {d[4:]: c for c, items in CATEGORIES.items() for d in items if d.startswith("app:")}


def category(app: str, domain: str) -> str | None:
    if domain:
        parts = domain.lower().split(".")
        for i in range(len(parts)):
            if (c := _CAT_DOMAIN.get(".".join(parts[i:]))):
                return c
        return None
    return _CAT_APP.get(app.lower())


# ------------------------------------------------------------------ rules and filing

def rules(db: DB) -> list:
    """Enabled rules, user rules first, then the most specific."""
    rows = db.query("SELECT * FROM time_rules WHERE enabled = 1")
    return sorted(rows, key=lambda r: (r["source"] != "user", -len(r["title_contains"]), -bool(r["domain"])))


def _hit(rule, app: str, domain: str, title: str) -> bool:
    if rule["app"] and rule["app"].lower() != app.lower():
        return False
    if rule["domain"]:
        d = domain.lower()
        if not (d == rule["domain"] or d.endswith("." + rule["domain"])):
            return False
    if rule["title_contains"] and rule["title_contains"].lower() not in title.lower():
        return False
    return bool(rule["app"] or rule["domain"] or rule["title_contains"])


def file(rule_rows: list, app: str, domain: str, title: str) -> tuple[str, str]:
    """("project", name) | ("category", name) | ("unassigned", "")."""
    for r in rule_rows:
        if _hit(r, app, domain, title):
            return "project", r["project"]
    if c := category(app, domain):
        return "category", c
    return "unassigned", ""


def _rows(db: DB, since: str, until: str | None = None) -> list:
    """Title-level time where it exists; app/domain time for hours from before title tracking."""
    until = until or "9999"
    titled = {r["hour_key"] for r in db.query("SELECT DISTINCT hour_key FROM time_titles WHERE hour_key >= ? AND hour_key < ?",
                                              (since, until))}
    rows = db.query("SELECT hour_key, app, domain, title, seconds FROM time_titles WHERE hour_key >= ? AND hour_key < ?",
                    (since, until))
    rows += [r for r in db.query("SELECT hour_key, app, domain, '' AS title, seconds FROM time_ledger "
                                 "WHERE hour_key >= ? AND hour_key < ?", (since, until)) if r["hour_key"] not in titled]
    return rows


def report(db: DB, since: str, until: str | None = None) -> dict:
    """Seconds per project and per category, plus unassigned time and its top titles."""
    rr = rules(db)
    out = {"projects": {}, "categories": {}, "unassigned": 0.0, "top_unassigned": {}, "total": 0.0,
           "untitled_hours": 0}
    for r in _rows(db, since, until):
        kind, name = file(rr, r["app"], r["domain"], r["title"])
        out["total"] += r["seconds"]
        if kind == "project":
            out["projects"][name] = out["projects"].get(name, 0) + r["seconds"]
        elif kind == "category":
            out["categories"][name] = out["categories"].get(name, 0) + r["seconds"]
        else:
            out["unassigned"] += r["seconds"]
            where = r["domain"] if "." in (r["domain"] or "") else r["app"]  # not an app's internal page id
            label = f"{where}: {r['title']}" if r["title"] else where
            out["top_unassigned"][label] = out["top_unassigned"].get(label, 0) + r["seconds"]
    return out


def format_report(rep: dict, days: float) -> str:
    def h(s):
        return f"{s / 3600:.1f} h" if s >= 3600 else f"{s / 60:.0f} min"
    lines = [f"Time by project, last {days:g} days: {h(rep['total'])} tracked"]
    if rep["projects"]:
        lines.append("Projects:")
        lines += [f"  {h(s):>8}  {p}" for p, s in sorted(rep["projects"].items(), key=lambda x: -x[1])]
    if rep["categories"]:
        lines.append("Categories:")
        lines += [f"  {h(s):>8}  {c}" for c, s in sorted(rep["categories"].items(), key=lambda x: -x[1])]
    if rep["unassigned"]:
        lines.append(f"Unassigned: {h(rep['unassigned'])}, mostly:")
        lines += [f"  {h(s):>8}  {t[:90]}" for t, s in sorted(rep["top_unassigned"].items(), key=lambda x: -x[1])[:8]]
    return "\n".join(lines)


def add_rule(db: DB, project: str, app: str = "", domain: str = "", title_contains: str = "",
             source: str = "user") -> int | None:
    project, app, title_contains = project.strip(), app.strip(), title_contains.strip()
    domain = domain.strip().lower().removeprefix("www.")
    if not project or not (app or domain or title_contains):
        return None
    if db.query("SELECT 1 FROM time_rules WHERE lower(project) = lower(?) AND lower(app) = lower(?) AND domain = ? "
                "AND lower(title_contains) = lower(?) AND enabled = 1", (project, app, domain, title_contains)):
        return None
    return db.execute("INSERT INTO time_rules (project, app, domain, title_contains, source, created_at) "
                      "VALUES (?, ?, ?, ?, ?, ?)", (project, app, domain, title_contains, source, time.time()))


def matched_seconds(db: DB, rule_id: int, days: float = 30) -> float:
    """Tracked time in the last N days that this rule matches (shown when a rule is added, so a
    misspelt app or site shows up as 0 at once)."""
    rule = db.query("SELECT * FROM time_rules WHERE id = ?", (rule_id,))
    since = time.strftime("%Y-%m-%dT%H", time.localtime(time.time() - days * 86400))
    return sum(r["seconds"] for r in _rows(db, since) if rule and _hit(rule[0], r["app"], r["domain"] or "", r["title"] or ""))


def disable_rule(db: DB, rule_id: int) -> bool:
    if not db.query("SELECT 1 FROM time_rules WHERE id = ?", (rule_id,)):
        return False
    db.execute("UPDATE time_rules SET enabled = 0 WHERE id = ?", (rule_id,))
    return True


# ------------------------------------------------------------------ proposing rules

class ProposedRule(BaseModel):
    project: str = Field(description="The project's name. Reuse an existing project name exactly when it is the same work.")
    app: str = Field("", description="App name to match exactly, or empty.")
    domain: str = Field("", description="Site to match (covers subdomains), or empty.")
    title_contains: str = Field("", description="Text the window title must contain (case-insensitive), or empty.")
    examples: list[str] = Field(description="Titles from the list that this rule files.")


class Proposal(BaseModel):
    rules: list[ProposedRule]


PROPOSE_SYSTEM = """\
You file a person's computer time under their projects. You get window titles with time that no \
rule claims yet, what they did in those hours, and the projects that already exist. Propose at \
most 6 rules that file this time under projects.

A project is something the person works ON: a codebase, a product, a client, a deal, a piece of \
writing, a course, a trip. It is never the tool or site the work happens in (VS Code, Terminal, \
GitHub, Figma, Google Docs, Chrome are not projects), and never a pastime (browsing, scrolling, \
shopping). Reuse an existing project's exact name when the work is the same.

Make each rule as narrow as it needs to be: title_contains with a word that names the project in \
the title (a repo, folder, file or document name), plus the app or site when the same word could \
appear elsewhere. Never a rule with only an app or a general site, which would sweep in unrelated \
work. Only propose a rule when the titles and the hour summaries both make the project clear; an \
empty list is fine."""


def _known_projects(db: DB) -> list[str]:
    ruled = [r["project"] for r in db.query("SELECT DISTINCT project FROM time_rules WHERE enabled = 1")]
    wiki = [r["title"] for r in db.query("SELECT title FROM wiki_pages WHERE page_type = 'project' "
                                         "ORDER BY mention_count DESC LIMIT 20")]
    return list(dict.fromkeys(ruled + wiki))


_PASTIMES = {"browsing", "social media", "entertainment", "shopping", "misc", "other", "general", "personal"}
_GENERIC_APPS = {"google chrome", "safari", "firefox", "arc", "brave browser", "microsoft edge", "code", "cursor",
                 "terminal", "iterm2", "finder", "notes", "preview", "xcode"}


def _valid(rule: ProposedRule, rows: list) -> bool:
    p = rule.project.strip().lower()
    if not p or len(p) > 60:
        return False
    names = {r["app"].lower() for r in rows} | {r["domain"].lower() for r in rows if r["domain"]} | _GENERIC_APPS
    if p in names or p in _PASTIMES:
        return False
    if not rule.title_contains.strip():  # an app or site alone sweeps in unrelated work, unless the site is the project's own
        if not rule.domain or rule.domain.lower() in _CAT_DOMAIN or category("", rule.domain):
            return False
    probe = {"app": rule.app.strip(), "domain": rule.domain.strip().lower().removeprefix("www."),
             "title_contains": rule.title_contains.strip()}
    return any(_hit(probe, r["app"], r["domain"], r["title"]) for r in rows)


def propose_rules(cfg: Config, db: DB, now: float | None = None, force: bool = False) -> int:
    """Ask for rules covering recent unclaimed time. Returns how many were added."""
    now = now or time.time()
    last = float(db.get_state(STATE_PROPOSED) or 0)
    if not force and now - last < PROPOSE_EVERY_S:
        return 0
    since = time.strftime("%Y-%m-%dT%H", time.localtime(max(last, now - 3 * 86400)))
    rr = rules(db)
    rows = [r for r in db.query("SELECT hour_key, app, domain, title, seconds FROM time_titles "
                                "WHERE hour_key >= ? AND title != ''", (since,))
            if file(rr, r["app"], r["domain"], r["title"])[0] == "unassigned"]
    db.set_state(STATE_PROPOSED, str(now))
    totals: dict[tuple, float] = {}
    hours: set[str] = set()
    for r in rows:
        totals[(r["app"], r["domain"], r["title"])] = totals.get((r["app"], r["domain"], r["title"]), 0) + r["seconds"]
        hours.add(r["hour_key"])
    top = sorted(((k, s) for k, s in totals.items() if s >= MIN_UNMATCHED_S), key=lambda x: -x[1])[:40]
    if not top:
        return 0
    summaries = db.query(f"SELECT period_key, summary FROM chronicle WHERE period = 'hour' AND period_key IN "
                         f"({','.join('?' * len(hours))}) ORDER BY period_key DESC LIMIT 8", sorted(hours))
    user = ("Existing projects: " + (", ".join(_known_projects(db)) or "(none)") +
            "\n\nUnclaimed time (minutes | app | site | window title):\n" +
            "\n".join(f"{s / 60:.0f} | {a} | {d or '-'} | {t}" for (a, d, t), s in top) +
            "\n\n<hours untrusted=\"true\">\n" +
            "\n\n".join(f"## {h['period_key']}\n{h['summary']}" for h in summaries) + "\n</hours>")
    result: Proposal = llm.parse(cfg.memory_model, "low", PROPOSE_SYSTEM, user, Proposal, max_tokens=2000)
    pool = [{"app": a, "domain": d, "title": t} for (a, d, t), _ in top]
    added = 0
    for rule in result.rules[:MAX_RULES_PER_RUN]:
        if _valid(rule, pool) and add_rule(db, rule.project, rule.app, rule.domain, rule.title_contains, "learned"):
            added += 1
            log.info("time rule learned: %s <- app=%r domain=%r title~%r", rule.project, rule.app, rule.domain,
                     rule.title_contains)
    return added


# ------------------------------------------------------------------ monthly curation

class Merge(BaseModel):
    project: str
    into: str


class Curation(BaseModel):
    merges: list[Merge] = Field(description="Projects that are the same work as another, established one.")
    retire: list[str] = Field(description="Names on the list that aren't projects (tools, sites, pastimes).")


CURATE_SYSTEM = """\
You keep a person's list of projects for time tracking tidy. You get each project with its rules \
and its hours over the last month. Merge a project into another when they are the same work under \
two names (merge the newer or smaller name into the established one). Retire names that aren't \
projects at all: tools, sites, apps or pastimes. Leave everything else alone; empty lists are fine."""


def curate(cfg: Config, db: DB, today: dt.date | None = None, force: bool = False) -> dict:
    """Once a month: merge duplicate projects, retire non-projects. Returns what changed."""
    today = today or dt.date.today()
    month = today.isoformat()[:7]
    if not force and db.get_state(STATE_CURATED) == month:
        return {}
    db.set_state(STATE_CURATED, month)
    rows = db.query("SELECT * FROM time_rules WHERE enabled = 1")
    projects = sorted({r["project"] for r in rows})
    if len(projects) < 2:
        return {}
    since = (today - dt.timedelta(days=30)).isoformat()
    spent = report(db, since)["projects"]
    lines = []
    for p in projects:
        rs = [r for r in rows if r["project"] == p]
        desc = "; ".join(" ".join(f"{k}={r[k]!r}" for k in ("app", "domain", "title_contains") if r[k]) for r in rs)
        lines.append(f"- {p} ({spent.get(p, 0) / 3600:.1f} h): {desc}")
    result: Curation = llm.parse(cfg.memory_model, "low", CURATE_SYSTEM, "\n".join(lines), Curation, max_tokens=1500)
    done = {"merged": 0, "retired": 0}
    first = {p: min(r["created_at"] for r in rows if r["project"] == p) for p in projects}
    for m in result.merges:
        if m.project in projects and m.into in projects and m.project != m.into:
            # the established name wins: more time, then older (the model's direction isn't reliable)
            keep, drop = sorted((m.project, m.into), key=lambda p: (-spent.get(p, 0), first[p]))
            db.execute("UPDATE time_rules SET project = ? WHERE project = ?", (keep, drop))
            done["merged"] += 1
    tools = {r["app"].lower() for r in db.query("SELECT DISTINCT app FROM time_titles")} | \
        {r["domain"].lower() for r in db.query("SELECT DISTINCT domain FROM time_titles WHERE domain != ''")} | \
        _GENERIC_APPS | {c.lower() for c in CATEGORIES} | _PASTIMES
    for name in result.retire:
        # only names that really are an app, site or pastime, and only learned rules (a user's project stays)
        if name in projects and name.strip().lower() in tools:
            db.execute("UPDATE time_rules SET enabled = 0 WHERE project = ? AND source = 'learned'", (name,))
            done["retired"] += 1
    if any(done.values()):
        log.info("time projects curated: %s", json.dumps(done))
    return done
