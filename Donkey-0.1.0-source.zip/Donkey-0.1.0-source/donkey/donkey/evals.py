"""Measure memory and rewrite quality instead of judging by eye.

Memory: a file of real questions about the user's life (data/eval/memory.jsonl), one JSON per
line: {"q": "...", "expect": ["myntra", "H&M"]}. A search hit counts when its wiki slug equals an
expect item, or an expect item appears in its title or snippet. Scores: hit@1, hit@k, MRR, and
which questions missed. Questions are the user's to keep honest: edit the file, never the scores.

Rewrites, two ways:
- Outcomes: how the learning loop graded real rewrites (verbatim and light edits are wins; "survived"
  means still on screen a minute later, not undone).
- Replay (`donkey eval --rewrites`): every rewrite saves what the model saw (the field, screen,
  memory blocks, rules) to data/eval/rewrites/<id>.json. Replay runs those cases again with the
  current prompt and code, and scores the delivered output and the new one with the same checks:
  invented specifics (numbers or names in the text that appear nowhere in what the model was given),
  eight or more words copied from the screen (repeating the post instead of answering it),
  a bare keyword the screen asks for ("Reply STOP"), a draft replaced instead of polished, longer
  than the user's usual messages there, and closeness to what the user actually sent. Each run is
  saved to data/eval/rewrite-runs/ and compared with the previous one.
"""
import json
import logging
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from . import learn
from .config import HOME
from .db import DB
from .search import search

log = logging.getLogger("donkey.evals")

EVAL_DIR = HOME / "eval"
MEMORY_FILE = EVAL_DIR / "memory.jsonl"
CASES_DIR = EVAL_DIR / "rewrites"
RUNS_DIR = EVAL_DIR / "rewrite-runs"
GOOD = {"verbatim", "light-edit"}
SENT_GRADES = ("verbatim", "light-edit", "heavy-edit", "rewritten")


def load_questions(path: Path = MEMORY_FILE) -> list[dict]:
    if not path.exists():
        return []
    out = []
    for line in path.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            out.append(json.loads(line))
    return out


def _matches(db: DB, hit, expect: list[str]) -> bool:
    text = f"{hit.title} {hit.snippet}".lower()
    slug = None
    if hit.kind == "wiki":
        row = db.query("SELECT slug FROM wiki_pages WHERE id = ?", (hit.ref_id,))
        slug = row[0]["slug"] if row else None
    return any(e.lower() == slug or e.lower() in text for e in expect)


def run_memory(db: DB, k: int = 5, questions: list[dict] | None = None) -> dict:
    qs = questions if questions is not None else load_questions()
    res = {"n": len(qs), "hit1": 0, "hitk": 0, "mrr": 0.0, "misses": [], "k": k}
    t0 = time.time()
    for q in qs:
        hits = search(db, q["q"], limit=k)
        rank = next((i for i, h in enumerate(hits, 1) if _matches(db, h, q["expect"])), None)
        if rank == 1:
            res["hit1"] += 1
        if rank:
            res["hitk"] += 1
            res["mrr"] += 1 / rank
        else:
            res["misses"].append({"q": q["q"], "got": [h.title for h in hits[:3]]})
    res["secs"] = round(time.time() - t0, 1)
    return res


def rewrite_stats(db: DB) -> dict:
    grades = learn.report(db)["grades"]
    sent = {g: n for g, n in grades.items() if g in SENT_GRADES + ("rejected",)}
    total = sum(sent.values())
    all_done = sum(n for g, n in grades.items() if g not in ("pending", "superseded"))
    return {"grades": grades, "judged": total, "survived": grades.get("survived", 0),
            "unknown_rate": round(grades.get("unknown", 0) / all_done, 2) if all_done else None,
            "good_rate": round(sum(n for g, n in sent.items() if g in GOOD) / total, 2) if total else None}


def report(db: DB, k: int = 5) -> str:
    lines = []
    m = run_memory(db, k)
    if not m["n"]:
        lines.append(f"No memory questions yet: add some to {MEMORY_FILE}")
    else:
        lines.append(f"Memory search: {m['n']} questions | hit@1 {m['hit1'] / m['n']:.0%} | hit@{k} "
                     f"{m['hitk'] / m['n']:.0%} | MRR {m['mrr'] / m['n']:.2f} | {m['secs']} s")
        for miss in m["misses"]:
            lines.append(f"  miss: {miss['q']}  ->  {', '.join(miss['got']) or 'nothing'}")
    r = rewrite_stats(db)
    if r["judged"] or r["survived"]:
        line = f"Rewrites: {r['judged']} with a seen send or deletion"
        if r["judged"]:
            line += f", {r['good_rate']:.0%} kept or lightly edited"
        line += f"; {r['survived']} still on screen a minute later; {r['unknown_rate']:.0%} outcome unknown"
        lines.append(line + f" ({', '.join(f'{g} {n}' for g, n in sorted(r['grades'].items()))})")
    else:
        lines.append("Rewrites: no outcomes yet (they appear as you use rewrites in message fields)")
    n = len(list(CASES_DIR.glob("*.json"))) if CASES_DIR.exists() else 0
    lines.append(f"Rewrite replay: {n} saved cases. Run `donkey eval --rewrites` to replay them with the current "
                 f"prompt (one model call each).")
    return "\n".join(lines)


# ------------------------------------------------------------------ rewrite cases

_TARGET_FIELDS = ("role", "subrole", "label", "window_title", "url", "domain", "value", "caret", "kind",
                  "slice_start", "slice_end", "readable")


def case_of(t, ctx: dict, ts: float) -> dict:
    """What one rewrite's model saw, enough to rebuild the same prompt later."""
    return {"ts": ts, "app": t.app.name, "is_browser": bool(getattr(t.app, "is_browser", False)),
            "target": {f: getattr(t, f) for f in _TARGET_FIELDS},
            "ctx": {k: (list(v) if isinstance(v, tuple) else v) for k, v in ctx.items()}}


def save_case(case: dict, rewrite_id: int | None) -> None:
    """Keep the case when the model produced text (delivered, left unchanged, or refused after)."""
    if not case or "output" not in case or not rewrite_id:
        return
    try:
        CASES_DIR.mkdir(parents=True, exist_ok=True)
        (CASES_DIR / f"{rewrite_id}.json").write_text(json.dumps({"id": rewrite_id, **case}, ensure_ascii=False))
    except Exception:
        log.exception("could not save rewrite case %s", rewrite_id)


def load_cases(limit: int | None = None) -> list[dict]:
    files = sorted(CASES_DIR.glob("*.json"), key=lambda p: int(p.stem), reverse=True) if CASES_DIR.exists() else []
    return [json.loads(p.read_text()) for p in files[:limit]]


def target_of(case: dict):
    from types import SimpleNamespace

    from .field import Target
    app = SimpleNamespace(name=case["app"], is_browser=case.get("is_browser", False))
    return Target(app=app, element=None, **case["target"])


# ------------------------------------------------------------------ checks

_NUMBER = re.compile(r"\d+(?:[:.]\d+)?")
_SENTENCE = re.compile(r"[^.!?\n]+")
_USUAL = re.compile(r"9 in 10 are under (\d+)")
# Capitalised words that aren't names or facts.
_PLAIN = {"i", "i'm", "i'll", "i've", "i'd", "ok", "okay", "pls", "please", "thanks", "thank", "hey", "hi",
          "hello", "yes", "no", "sure", "sorry", "bro", "bhai", "haan", "nahi", "acha", "accha", "ji"}


def invented_numbers(out: str, given: str) -> list[str]:
    """Numbers (times, amounts, counts, dates) that appear nowhere in what the model was given."""
    return list(dict.fromkeys(n for n in _NUMBER.findall(out)
                              if not re.search(rf"(?<!\d){re.escape(n)}(?!\d)", given)))


def invented(out: str, given: str) -> list[str]:
    """Numbers, and capitalised words inside a sentence (names, places, products), that appear
    nowhere in what the model was given."""
    low = given.lower()
    found = invented_numbers(out, given)
    for sent in _SENTENCE.findall(out):
        words = sent.split()
        for w in words[1:]:
            w = w.strip(",;:()\"'“”‘’*")
            if len(w) >= 3 and w[0].isupper() and w[1:].islower() and w.lower() not in _PLAIN \
                    and not re.search(rf"\b{re.escape(w.lower())}", low):
                found.append(w)
    return list(dict.fromkeys(found))


ECHO_WORDS = 8


def copied(out: str, screen: str) -> str | None:
    """A run of ECHO_WORDS or more words taken from the screen: the reply repeats the post or
    message it should be answering (or writes as its author)."""
    from .sends import norm
    words, have = norm(out).split(), norm(screen)
    if not have:
        return None
    for i in range(len(words) - ECHO_WORDS + 1):
        run = " ".join(words[i:i + ECHO_WORDS])
        if f" {run} " in f" {have} ":
            return run
    return None


REPEAT_SIMILARITY = 0.8


def check(case: dict, out: str, given: str) -> list[str]:
    """Problems with one output for this case (empty list: clean)."""
    from .rewrite import replaced_draft, screen_keyword
    t, ctx = target_of(case), case["ctx"]
    problems = []
    if not out.strip():
        return ["empty"]
    if kw := screen_keyword(out, t.slice_text, ctx.get("conversation"), ctx.get("page")):
        problems.append(f"screen keyword {kw}")
    if t.kind in ("draft", "above_quote") and replaced_draft(t.slice_text, out):
        problems.append("replaced the draft")
    screen = "\n".join(x for x in (ctx.get("conversation"), ctx.get("page"), *(ctx.get("recent") or [])) if x)
    if run := copied(out, screen):
        problems.append(f"copies the screen: \"{run}\"")
    from .rewrite import repeats_rejected, rules_broken
    for rule in rules_broken(out, t.slice_text, ctx.get("checks")):
        problems.append(f"breaks rule: {rule[:60]}")
    if r := repeats_rejected(out, ctx.get("rejected")):
        problems.append(f"repeats a rejected draft: \"{r[:60]}\"")
    if bad := invented(out, given):
        problems.append("invented " + ", ".join(bad[:5]))
    usual = next((int(m.group(1)) for r in ctx.get("rules") or [] if (m := _USUAL.search(r))), None)
    if usual and t.kind == "empty" and len(out.split()) > usual:
        problems.append(f"long ({len(out.split())} words, usually under {usual})")
    return problems


def _given(case: dict, user: str) -> str:
    """Everything the model could have taken a specific from."""
    return user + "\n" + (case["target"].get("value") or "")


# ------------------------------------------------------------------ replay

def _replay_one(cfg, db: DB, case: dict) -> dict:
    from . import llm, prompt
    from .field import FieldError
    from .rewrite import Cancelled, generate, user_message
    t = target_of(case)
    if "memory_hits" not in case["ctx"] and case["ctx"].get("memory", True):
        from .rewrite import memory_search  # cases saved before Donkey searched memory on every press
        case["ctx"]["memory_hits"] = memory_search(db, t, case["ctx"])
    user = user_message(t, case["ctx"], now=case["ts"])
    res = {"id": case["id"], "where": case["target"]["domain"] or case["app"], "old": case["output"], "old_problems": check(case, case["output"], _given(case, user))}
    try:
        out, final_user = generate(cfg, db, t, prompt.SYSTEM, user, case["ctx"], threading.Event())
        res["new"], res["new_problems"] = out, check(case, out, _given(case, final_user))
    except (FieldError, llm.LLMError, Cancelled) as e:
        res["new"], res["new_problems"] = None, [f"error: {e}"]
    row = db.query("SELECT grade, sent_text FROM rewrites WHERE id = ?", (case["id"],))
    if row and row[0]["grade"] in SENT_GRADES and row[0]["sent_text"]:
        res["sent"] = row[0]["sent_text"]
        res["old_sim"] = round(learn.similarity(case["output"], res["sent"]), 2)
        if res["new"]:
            res["new_sim"] = round(learn.similarity(res["new"], res["sent"]), 2)
    return res


def replay(cfg, db: DB, limit: int | None = 30, workers: int = 4) -> dict:
    cases = load_cases(limit)
    t0 = time.time()
    with ThreadPoolExecutor(workers) as pool:
        results = list(pool.map(lambda c: _replay_one(cfg, db, c), cases))
    run = {"at": time.time(), "model": cfg.rewrite_model, "secs": round(time.time() - t0, 1), "results": results}
    if results:
        RUNS_DIR.mkdir(parents=True, exist_ok=True)
        (RUNS_DIR / time.strftime("%Y%m%d-%H%M%S.json")).write_text(json.dumps(run, ensure_ascii=False, indent=1))
    return run


def _summary(results: list[dict], side: str) -> dict:
    probs = [r[f"{side}_problems"] for r in results]
    kinds = {}
    for p in probs:
        for k in {x.split(" ")[0] if not x.startswith("screen") else "screen-keyword" for x in p}:
            kinds[k] = kinds.get(k, 0) + 1
    return {"clean": sum(not p for p in probs), "n": len(probs), "kinds": kinds}


def _previous_run(before: float) -> dict | None:
    runs = sorted(RUNS_DIR.glob("*.json")) if RUNS_DIR.exists() else []
    for p in reversed(runs):
        run = json.loads(p.read_text())
        if run["at"] < before - 1:
            return run
    return None


def replay_report(run: dict) -> str:
    res = run["results"]
    if not res:
        return f"No rewrite cases yet in {CASES_DIR}. They're saved as you use rewrites."
    old, new = _summary(res, "old"), _summary(res, "new")
    lines = [f"Rewrite replay: {len(res)} cases, {run['model']}, {run['secs']} s",
             f"  {'':22}{'as delivered':>14}{'now':>8}",
             f"  {'clean':22}{old['clean'] / old['n']:>14.0%}{new['clean'] / new['n']:>8.0%}"]
    labels = {"copies": "copies the screen", "invented": "invented specifics", "screen-keyword": "screen keyword", "replaced": "replaced the draft", "repeats": "repeats a rejected draft", "breaks": "breaks a stated rule",
              "long": "longer than usual", "empty": "empty", "error:": "error"}
    for k in sorted(set(old["kinds"]) | set(new["kinds"])):
        lines.append(f"  {labels.get(k, k):22}{old['kinds'].get(k, 0):>14}{new['kinds'].get(k, 0):>8}")
    sent = [r for r in res if "new_sim" in r]
    if sent:
        avg = lambda key: sum(r[key] for r in sent) / len(sent)
        closer = sum(r["new_sim"] > r["old_sim"] for r in sent)
        lines.append(f"  vs what you sent ({len(sent)} cases): similarity {avg('old_sim'):.2f} -> {avg('new_sim'):.2f}"
                     f", closer in {closer}")
    prev = _previous_run(run["at"])
    if prev and prev["results"]:
        p = _summary(prev["results"], "new")
        lines.append(f"  previous run ({time.strftime('%b %#d %H:%M', time.localtime(prev['at']))}, "
                     f"{p['n']} cases): clean {p['clean'] / p['n']:.0%}")
    bad = [r for r in res if r["new_problems"]]
    if bad:
        lines.append("Problems now:")
        for r in bad:
            lines.append(f"  #{r['id']} {r['where']}: {'; '.join(r['new_problems'])}  ->  "
                         f"{' '.join((r['new'] or '').split())[:90]}")
    return "\n".join(lines)
