"""First run: the welcome in the Donkey window (journal.html), and how far Donkey has got in
getting to know you (Home's first-days card).

Windows has no privacy switches for what Donkey does (reading other windows through UI
Automation, the keyboard hook, window pictures), so the welcome has no permissions step here;
what's left of that machinery answers "all on" for the pages that still ask."""
import json
import os
import sys
import time
from pathlib import Path

from . import config

STATE_PATH = config.HOME / "onboarding.json"


def state() -> dict:
    try:
        return json.loads(STATE_PATH.read_text())
    except (FileNotFoundError, ValueError):
        return {}


def mark(step: str | None = None, done: bool = False) -> None:
    s = state()
    s.setdefault("started_at", time.time())
    if step:
        s["step"] = "model" if step == "perms" else step
    if done:
        s["done_at"] = time.time()
    STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
    STATE_PATH.write_text(json.dumps(s, indent=1))


def pending(db) -> str | None:
    """The step to open the welcome at, or None. A copy that has never run starts at the beginning;
    one that quit mid-way picks up where it was. An install from before the welcome existed, with
    memory already in it, isn't shown it again."""
    s = state()
    if s.get("done_at"):
        return None
    if s.get("step"):
        return "model" if s["step"] == "perms" else s["step"]
    if db.query("SELECT 1 FROM snapshots LIMIT 1"):
        mark(done=True)
        return None
    return "hello"


# ------------------------------------------------------------------ the Mac's install and permission steps

def offer_move() -> None:
    """The Mac offered to move itself into Applications; the Windows installer puts it in place."""


def forget_old_build() -> None:
    """The Mac cleared stale privacy switches here; Windows has none."""


def note_launch() -> None:
    pass


def holder() -> dict:
    """The program Donkey runs as (the welcome showed it on the Mac, to find in the privacy lists)."""
    path = os.path.realpath(sys.executable)
    return {"name": Path(path).name, "path": path, "icon": None, "app": config.FROZEN}


def permissions(cfg, key_kind: str | None = None) -> dict:
    """Everything Donkey needs is there from the start on Windows."""
    rows = {"accessibility": {"on": True, "needs_restart": False}}
    if cfg.ocr:
        from . import ocr
        rows["screen"] = {"on": ocr.available(), "needs_restart": False}
    return {"perms": rows, "holder": holder()}


def request(which: str) -> None:
    """Text recognition is the one thing that can be missing: its language lives in Windows Settings."""
    if which == "screen":
        from . import winui
        winui.open_url("ms-settings:regionlanguage")


def reset(which: str) -> bool:
    request(which)
    return False


def reveal_holder() -> None:
    from . import winui
    winui.reveal(holder()["path"])

# ------------------------------------------------------------------ getting to know you

def progress(db) -> dict:
    """What Donkey has so far, for Home's first-days card: each thing it builds as you work."""
    one = lambda sql, *a: (db.query(sql, a)[0][0] or 0)
    first = one("SELECT MIN(captured_at) FROM snapshots")
    screens = one("SELECT COUNT(*) FROM snapshots")
    hours = one("SELECT COUNT(*) FROM chronicle WHERE period = 'hour'")
    pages = one("SELECT COUNT(*) FROM wiki_pages")
    rewrites = one("SELECT COUNT(*) FROM rewrites WHERE error IS NULL")
    days = one("SELECT COUNT(DISTINCT substr(period_key, 1, 10)) FROM chronicle WHERE period = 'hour'")
    return {"first": first or None, "screens": screens, "hours": hours, "pages": pages,
            "rewrites": rewrites, "days": days}
