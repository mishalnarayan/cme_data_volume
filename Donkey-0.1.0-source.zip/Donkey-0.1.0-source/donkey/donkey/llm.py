"""Model calls. The provider block in use is kind "anthropic" (Claude; api_key, ANTHROPIC_API_KEY or data/anthropic-key) or
"openai" (any OpenAI-compatible endpoint such as OpenRouter; see openai_compat.py)."""
from __future__ import annotations

import threading

from . import openai_compat
from .config import HOME, is_local, load as load_config

KEY_PATH = HOME / "anthropic-key"
# Models that accept the server-side refusal fallback (`fallbacks: "default"`) on the Claude API.
FALLBACK_MODELS = {"claude-fable-5-1", "claude-opus-5-5", "claude-opus-5", "claude-sonnet-5-5"}



class _Lazy:
    """The anthropic SDK takes half a second to import: load it on first use, not at launch."""
    def __getattr__(self, name):
        import anthropic as sdk
        globals()["anthropic"] = sdk
        return getattr(sdk, name)


anthropic = _Lazy()
_client: anthropic.Anthropic | None = None
_client_lock = threading.Lock()


class Cancelled(Exception):
    pass


class LLMError(Exception):
    """Shown to the user as-is."""


_cfg = None


def settings():
    """Provider settings from the config file, read once per process."""
    global _cfg
    if _cfg is None:
        _cfg = load_config()
    return _cfg


def use(cfg) -> None:
    """Switch to settings just saved (the Settings window): drop the Claude client and pooled connections."""
    global _cfg, _client
    with _client_lock:
        _cfg, _client = cfg, None
    openai_compat.drop_pool()


def provider() -> str:
    return "anthropic" if settings().llm_provider == "anthropic" else "openai"


def prewarm() -> None:
    """Open the model connection ahead of a request (called the moment the key is tapped)."""
    if provider() == "openai":
        openai_compat.prewarm(settings())
    else:
        try:
            client()
        except Exception:
            pass


def key_hint() -> str:
    """Where to put credentials for the configured provider."""
    return "choose one in Settings… from the tray icon (or edit config.json)"


def client() -> anthropic.Anthropic:
    global _client
    with _client_lock:
        if _client is None:
            key = settings().llm_api_key or (KEY_PATH.read_text().strip() if KEY_PATH.exists() else None)
            _client = anthropic.Anthropic(api_key=key, timeout=60.0) if key else anthropic.Anthropic(timeout=60.0)
        return _client


def has_credentials() -> bool:
    if provider() == "openai":
        s = settings()
        return bool(s.llm_endpoint and (s.llm_api_key or is_local(s.llm_endpoint)))
    try:
        c = client()
    except Exception:
        return False
    return bool(c.api_key or c.auth_token) or KEY_PATH.exists()


def parse(model: str, effort: str, system: str, user: str, schema, max_tokens: int = 8000, fast: bool = False):
    """One structured-output call; returns an instance of the Pydantic `schema`. fast = someone is
    waiting on it (chat, writing): the provider block's fast_extra instead of its background_extra."""
    if provider() == "openai":
        try:
            return openai_compat.parse(settings(), model, effort, system, user, schema, max_tokens, fast=fast)
        except openai_compat.ProviderError as e:
            raise LLMError(str(e))
    try:
        response = client().messages.parse(
            model=model,
            max_tokens=max_tokens,
            system=[{"type": "text", "text": system, "cache_control": {"type": "ephemeral"}}],
            output_config={"effort": effort},
            output_format=schema,
            messages=[{"role": "user", "content": user}],
        )
    except anthropic.RateLimitError:
        raise LLMError("rate limited")
    except anthropic.APIStatusError as e:
        raise LLMError(f"API error {e.status_code}: {e.message}")
    except anthropic.APIConnectionError:
        raise LLMError("connection error")
    except TypeError as e:
        if "authentication" not in str(e):
            raise
        raise LLMError("no API key")
    if response.stop_reason == "refusal":
        raise LLMError("declined")
    if response.stop_reason == "max_tokens" or response.parsed_output is None:
        raise LLMError(f"incomplete structured output (stop_reason={response.stop_reason})")
    return response.parsed_output


def complete(model: str, effort: str, system: str, user: str, cancel: threading.Event | None = None,
             max_tokens: int = 16000, fast: bool = False) -> str:
    """One streamed turn; checks `cancel` between chunks so Esc stops it mid-generation. fast as in parse."""
    if provider() == "openai":
        try:
            return openai_compat.complete(settings(), model, effort, system, user, cancel, max_tokens, fast=fast)
        except openai_compat.CancelledStream:
            raise Cancelled()
        except openai_compat.ProviderError as e:
            raise LLMError(str(e))
    kwargs = {}
    if model in FALLBACK_MODELS:
        kwargs = {"betas": ["server-side-fallback-2026-07-01"], "fallbacks": "default"}
    parts: list[str] = []
    try:
        with client().beta.messages.stream(
            model=model,
            max_tokens=max_tokens,
            system=[{"type": "text", "text": system, "cache_control": {"type": "ephemeral"}}],
            output_config={"effort": effort},
            messages=[{"role": "user", "content": user}],
            **kwargs,
        ) as stream:
            for text in stream.text_stream:
                if cancel is not None and cancel.is_set():
                    raise Cancelled()
                parts.append(text)
            message = stream.get_final_message()
    except anthropic.AuthenticationError:
        raise LLMError(f"No valid Anthropic API key. Set ANTHROPIC_API_KEY or put a key in {KEY_PATH}.")
    except anthropic.RateLimitError:
        raise LLMError("Rate limited by the Anthropic API. Try again in a moment.")
    except anthropic.APIStatusError as e:
        raise LLMError(f"Anthropic API error {e.status_code}: {e.message}")
    except anthropic.APIConnectionError:
        raise LLMError("Couldn't reach the Anthropic API. Check your connection.")
    except anthropic.AnthropicError as e:
        raise LLMError(f"Anthropic client error: {e}")
    except TypeError as e:
        if "authentication" not in str(e):
            raise
        raise LLMError(f"No Anthropic API key. Set ANTHROPIC_API_KEY or put a key in {KEY_PATH}.")
    if message.stop_reason == "refusal":
        raise LLMError("Claude declined this request.")
    if message.stop_reason == "max_tokens":
        raise LLMError("The result was too long and got cut off.")
    return "".join(parts)


def _to_anthropic(messages: list[dict]) -> list[dict]:
    """OpenAI-format history (user / assistant with tool_calls / tool) → Messages API turns."""
    import json
    out: list[dict] = []
    for m in messages:
        if m["role"] == "tool":
            block = {"type": "tool_result", "tool_use_id": m["tool_call_id"], "content": m["content"]}
            if out and out[-1]["role"] == "user" and isinstance(out[-1]["content"], list):
                out[-1]["content"].append(block)
            else:
                out.append({"role": "user", "content": [block]})
        elif m["role"] == "assistant" and m.get("tool_calls"):
            blocks = [{"type": "text", "text": m["content"]}] if m.get("content") else []
            blocks += [{"type": "tool_use", "id": c["id"], "name": c["function"]["name"],
                        "input": json.loads(c["function"]["arguments"] or "{}")} for c in m["tool_calls"]]
            out.append({"role": "assistant", "content": blocks})
        else:
            out.append({"role": m["role"], "content": m["content"]})
    return out


def chat(model: str, effort: str, system: str, messages: list[dict], tools: list[dict],
         cancel: threading.Event | None = None, on_text=None, max_tokens: int = 4000,
         tool_choice: str | None = None) -> dict:
    """One streamed turn of a tool-using conversation. `messages` and `tools` use the OpenAI chat
    format; tool_choice "none" keeps the tools visible but forbids calling them. Returns
    {"text", "tool_calls": [{"id", "name", "arguments" (JSON text)}], "usage"}."""
    if provider() == "openai":
        try:
            return openai_compat.chat(settings(), model, effort, system, messages, tools, cancel, on_text,
                                      max_tokens, tool_choice)
        except openai_compat.CancelledStream:
            raise Cancelled()
        except openai_compat.ProviderError as e:
            raise LLMError(str(e))
    import json
    a_tools = [{"name": t["function"]["name"], "description": t["function"].get("description", ""),
                "input_schema": t["function"]["parameters"]} for t in tools]
    if a_tools:
        a_tools[-1]["cache_control"] = {"type": "ephemeral"}
    try:
        with client().messages.stream(
            model=model, max_tokens=max_tokens,
            system=[{"type": "text", "text": system, "cache_control": {"type": "ephemeral"}}],
            output_config={"effort": effort}, tools=a_tools, messages=_to_anthropic(messages),
            **({"tool_choice": {"type": tool_choice}} if tool_choice and a_tools else {}),
        ) as stream:
            for text in stream.text_stream:
                if cancel is not None and cancel.is_set():
                    raise Cancelled()
                if on_text:
                    on_text(text)
            message = stream.get_final_message()
    except anthropic.AuthenticationError:
        raise LLMError(f"No valid Anthropic API key. Set ANTHROPIC_API_KEY or put a key in {KEY_PATH}.")
    except anthropic.RateLimitError:
        raise LLMError("Rate limited by the Anthropic API. Try again in a moment.")
    except anthropic.APIStatusError as e:
        raise LLMError(f"Anthropic API error {e.status_code}: {e.message}")
    except anthropic.APIConnectionError:
        raise LLMError("Couldn't reach the Anthropic API. Check your connection.")
    if message.stop_reason == "refusal":
        raise LLMError("Claude declined this request.")
    text = "".join(b.text for b in message.content if b.type == "text")
    calls = [{"id": b.id, "name": b.name, "arguments": json.dumps(b.input)} for b in message.content
             if b.type == "tool_use"]
    u = message.usage
    return {"text": text, "tool_calls": calls,
            "usage": {"prompt_tokens": u.input_tokens + (u.cache_read_input_tokens or 0)
                      + (u.cache_creation_input_tokens or 0), "completion_tokens": u.output_tokens}}
