"""Command line: `python -m donkey <command>` (or `python donkey\__main__.py <command>`, which the
login item, the donkey:// link handler and MCP clients use)."""
import sys

if not getattr(sys, "frozen", False) and not sys.flags.utf8_mode:
    # Donkey reads and writes its files as UTF-8; on Windows Python only does that by default in
    # UTF-8 mode, so start again in it (the commands Donkey writes for itself already ask for it)
    import subprocess
    sys.exit(subprocess.call([sys.executable, "-X", "utf8", *sys.orig_argv[1:]]))

if not __package__:  # run by path: make the relative imports below work
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    import donkey  # noqa: F401
    __package__ = "donkey"

import argparse  # noqa: E402
import logging  # noqa: E402
import logging.handlers  # noqa: E402
import signal  # noqa: E402
import threading  # noqa: E402
import time  # noqa: E402

from . import config  # noqa: E402


def setup_logging(verbose: bool) -> None:
    config.HOME.mkdir(parents=True, exist_ok=True)
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s", "%H:%M:%S")
    file = logging.handlers.RotatingFileHandler(config.HOME / "donkey.log", maxBytes=5_000_000, backupCount=3,
                                                encoding="utf-8", delay=True)
    file.setFormatter(fmt)
    root = logging.getLogger()
    root.setLevel(logging.DEBUG if verbose else logging.INFO)
    root.addHandler(file)
    if sys.stderr is not None:  # no console under pythonw.exe / Donkey.exe
        console = logging.StreamHandler()
        console.setFormatter(fmt)
        root.addHandler(console)
    for noisy in ("httpx", "httpx2", "httpcore", "httpcore2", "anthropic", "huggingface_hub"):
        logging.getLogger(noisy).setLevel(logging.WARNING)


def require_ax() -> None:
    """Windows needs no permission to read other windows (UI Automation is open to every app)."""


def cmd_run(args) -> None:
    from .capture import Capturer
    from .db import DB
    from .keys import KeyWatcher
    from .rewrite import Rewriter

    require_ax()
    cfg = config.load()
    db = DB()
    stop = threading.Event()
    signal.signal(signal.SIGINT, lambda *_: stop.set())
    signal.signal(signal.SIGTERM, lambda *_: stop.set())

    capture = None
    if not args.no_capture:
        capture = threading.Thread(target=Capturer(cfg, db).run, args=(stop,), name="capture", daemon=True)
        capture.start()
        from .memory import Scheduler
        threading.Thread(target=Scheduler(cfg, db).run, args=(stop,), name="memory", daemon=True).start()
        from .sends import SendWatcher
        threading.Thread(target=SendWatcher(cfg, db).run, args=(stop,), name="sends", daemon=True).start()
    from . import reminders
    threading.Thread(target=reminders.Ticker(cfg, db).run, args=(stop,), name="reminders", daemon=True).start()

    rewriter = Rewriter(cfg, db)
    watcher = KeyWatcher(
        cfg.rewrite_key,
        on_tap=rewriter.trigger,
        on_hold=lambda: logging.getLogger("donkey").info("hold: edit mode is not built yet"),
        on_cancel=rewriter.cancel_current,
    )
    rewriter.on_busy_change = lambda busy: watcher.armed_cancel.set() if busy else watcher.armed_cancel.clear()
    logging.getLogger("donkey").info("tap %s in any text field to rewrite (Esc cancels)", cfg.rewrite_key)
    watcher.run(stop)
    if capture:
        capture.join(timeout=5)


def cmd_map(args) -> None:
    from .memory_map import open_map

    print(f"Opened {open_map()}")


def cmd_app(args) -> None:
    from .app import main as run_app

    run_app(no_capture=args.no_capture, login=getattr(args, "login", False))


def cmd_doctor(args) -> None:
    """Check everything a rewrite needs, step by step. Writes nothing into any field."""
    from . import ax, llm
    from .field import FieldError, read_target
    from .keys import KeyWatcher

    cfg = config.load()
    ok = lambda good, msg, fix="": print(f"{'✓' if good else '✗'} {msg}" + ("" if good or not fix else f"\n    → {fix}"))

    from . import deliver
    if deliver._elevated():
        print("! Donkey is running as administrator. It works, but its windows and the key behave best "
              "when it runs as you normally do.")
    ok(sys.maxsize > 2**32, "64-bit Python")
    ok(bool(sys.flags.utf8_mode), "UTF-8 mode (Donkey's files are UTF-8)",
       "Start Donkey with python -X utf8, or rebuild: donkey.spec sets it for the built app")

    from . import embed
    if embed.settings()["provider"] == "gemma":
        why = embed.missing()
        ok(why is None, "EmbeddingGemma and llama-server (memory search)", why or "")

    if cfg.ocr:
        from . import ocr
        ocr.LANGUAGES = cfg.ocr_languages
        ok(ocr.permitted(), f"Text recognition ({cfg.ocr_languages[0]}) for windows the screen reader can't "
                            "read, like Remote Desktop",
           "Settings → Time & language → Language & region: add that language (with its optical character "
           "recognition feature). Or set capture > ocr to false in config.json.")

    has_key = llm.has_credentials()
    ok(has_key, f"API key ({llm.provider()})", llm.key_hint())
    if has_key:
        try:
            reply = llm.complete(cfg.rewrite_model, "low", "Reply with exactly: OK", "ping", max_tokens=200)
            ok(True, f"Model responds ({cfg.rewrite_model}): {reply.strip()[:20]}")
        except llm.LLMError as e:
            ok(False, f"Claude call failed: {e}")

    print(f"\nTap {cfg.rewrite_key.replace('_', ' ')} once now (10 s)…")
    tapped = threading.Event()
    stop = threading.Event()
    watcher = KeyWatcher(cfg.rewrite_key, on_tap=tapped.set)
    threading.Thread(target=watcher.run, args=(stop,), daemon=True).start()
    tapped.wait(10)
    stop.set()
    ok(getattr(watcher, "src", None) is not None and watcher.src.kind == "keyboard hook", "Keyboard hook (reliable key)",
       "Windows refused the keyboard hook, so the key is polled, which can miss presses. Security software "
       "sometimes blocks hooks; try allowing Donkey there.")
    ok(tapped.is_set(), f"Key tap detected ({cfg.rewrite_key})",
       "If you did tap it: another app may be using that key (some keyboard tools take right Alt). "
       "Pick another key in config.json (rewrite > key).")

    print("\nClick into any text field (a chat box, an email, Notepad…) within 5 s…")
    time.sleep(5)
    try:
        t = read_target()
        ok(True, f"Field read in {t.app.name}{' · ' + t.domain if t.domain else ''}: role {t.role}, "
                 f"{'contents readable' if t.readable else 'contents hidden (will insert at the cursor)'}, "
                 f"mode '{t.kind}', {len(t.value)} chars")
    except FieldError as e:
        ok(False, f"Field read: {e}", "Click inside the box you want to write in, so the cursor blinks there. "
           "Apps running as administrator can't be read unless Donkey runs as administrator too.")
    print("\nAll good? Run `donkey run`, click into a field, and tap the key.")


def cmd_rewrite(args) -> None:
    """Rewrite the focused field once, without the key (for testing)."""
    from .db import DB
    from .rewrite import Rewriter

    require_ax()
    if args.delay:
        print(f"Click into the text field to rewrite; running in {args.delay}s…", file=sys.stderr)
        time.sleep(args.delay)
    Rewriter(config.load(), DB()).run_once()


def cmd_peek(args) -> None:
    """Read the front window once and show what would be stored, without storing it."""
    from . import ax
    from .filters import blocked_reason, is_private_window, load_rules, redact

    require_ax()
    cfg = config.load()
    if args.delay:
        print(f"Switch to the window to read; reading in {args.delay}s…", file=sys.stderr)
        time.sleep(args.delay)
    app = ax.front_app()
    if app is None:
        sys.exit("no frontmost app")
    if ax.ensure_accessibility(app):
        time.sleep(0.5)  # Chromium/Electron build their tree asynchronously
    p = ax.probe(app)
    frame = ax.read_frame(app, p, max_chars=cfg.max_chars)
    rules = load_rules(cfg.blocked_apps, cfg.blocked_domains)
    verdict = blocked_reason(rules, frame.app, frame.url, frame.window_title)
    if not verdict and is_private_window(frame.window_title):
        verdict = "private window"
    print(f"app:      {frame.app} ({frame.bundle_id}, pid {frame.pid})")
    print(f"window:   {frame.window_title}")
    print(f"url:      {frame.url}")
    print(f"focused:  {frame.focused_role} {frame.focused_name or ''}")
    print(f"read:     {frame.method}, {frame.nodes} nodes, {frame.walk_ms} ms"
          f"{' (budget exhausted)' if frame.exhausted else ''}, {len(frame.content)} chars")
    print(f"verdict:  {'BLOCKED: ' + verdict if verdict else 'would store'}")
    if app.is_browser and p.focused is not None:
        from .web import conversation_context
        convo = conversation_context(p.focused, frame.domain)
        print("-" * 72)
        print("conversation (what a rewrite here gets as context):")
        print(redact(convo) if convo else "(no conversation pane found around the focused field: "
                                          "the rewrite would use the whole page instead)")
    print("-" * 72)
    text = redact(frame.content) if cfg.redact else frame.content
    print(text[: args.chars] + ("\n…" if len(text) > args.chars else ""))


def cmd_search(args) -> None:
    from .db import DB
    from .search import format_hits, search

    hits = search(DB(), args.query, args.limit, use_vectors=not args.keyword)
    print(format_hits(hits) if hits else "No matches.")


def cmd_eval(args) -> None:
    from . import config, evals
    from .db import DB

    if args.scenarios:  # its own made-up memory, in a child process with its own home
        from . import scenarios
        raise SystemExit(scenarios.launch(config.HOME, args.rebuild, args.runs, args.only, args.model,
                                                  args.chat))
    db = DB()
    if not args.rewrites:
        print(evals.report(db, k=args.k))
        return
    n = len(evals.load_cases(args.limit))
    print(f"Replaying {n} rewrite cases (one model call each)...", flush=True)
    print(evals.replay_report(evals.replay(config.load(), db, args.limit)))


def cmd_style(args) -> None:
    from . import learn, lessons
    from .db import DB

    db = DB()
    if args.add:
        scope = learn.resolve_scope(db, args.scope)
        rid, note = learn.add_stated_rule(config.load(), db, args.add, scope)  # replaces any rule it contradicts
        print(f"Rule {rid} added for {scope or 'everywhere'}" + (f"; {note}." if note else "."))
    if args.disable:
        print(f"Rule {args.disable} turned off." if learn.disable_rule(db, args.disable) else f"No rule {args.disable}.")
    if args.mine:
        print(f"paired {learn.pair_sends(db)} sends; {learn.check_survival(db)} graded from later screens; "
              f"{learn.mine_rules(config.load(), db, force=True)} rules mined; retries: "
              f"{lessons.learn_from_retries(config.load(), db)}")
    rep = learn.report(db)
    print("Rewrites by outcome: " + (", ".join(f"{k} {v}" for k, v in sorted(rep["grades"].items())) or "none yet"))
    if not rep["rules"]:
        print("No writing rules yet. They're learned from your edits, or add one with --add.")
    from . import rulecheck
    for r in rep["rules"]:
        checks = rulecheck.loads(r.get("checks")) + rulecheck.parse(r["rule"]) if r["source"] != "observed" else []
        print(f"{'  ' if r['enabled'] else 'x '}{r['id']:>3}  [{r['source']}, {r['scope'] or 'everywhere'}, "
              f"evidence {r['evidence']}] {r['rule']}"
              + (f"  (checked: {', '.join(dict.fromkeys(checks))})" if checks else "")
              + (f"  [off: {r['retired']}]" if r.get("retired") and not r["enabled"] else "")
              + (f"  [given {r['shown']}: kept {r['kept']}, undone {r['undone']}]" if r.get("shown") else ""))
    if waiting := lessons.pending(db):
        print("\nSeen in one sitting so far (a rule once seen again):")
        for w in waiting:
            print(f"     [{w['source']}, {w['scope'] or 'everywhere'}] {w['lesson']}")


def cmd_examples(args) -> None:
    from . import learn
    from .db import DB

    db = DB()
    if args.add:
        print(f"saved example {learn.add_user_example(db, args.add, args.scope)}")
    if args.remove:
        db.execute("DELETE FROM user_examples WHERE id = ?", (args.remove,))
    rows = db.query("SELECT * FROM user_examples ORDER BY scope, created_at DESC")
    if not rows:
        print("No examples yet. Add a message you'd like rewrites to sound like with --add (and --scope).")
    for r in rows:
        print(f"{r['id']:>3}  [{r['scope'] or 'everywhere'}] {' '.join(r['text'].split())[:200]}")


def cmd_sends(args) -> None:
    import time as _t

    from .db import DB

    rows = DB().query("SELECT * FROM sends WHERE ts > ? ORDER BY ts", (_t.time() - args.hours * 3600,))
    if not rows:
        print("No sends detected yet. Keep `donkey app` running while you message people.")
    for s in rows:
        print(f"{_t.strftime('%m-%d %H:%M', _t.localtime(s['ts']))}  {s['kind']:9} ({s['proof']:12}) "
              f"{s['app']}{' | ' + s['domain'] if s['domain'] else ''} -> {s['surface'][:40]}: {s['text'][:80]}")


def cmd_memory(args) -> None:
    from .db import DB
    from .memory import run_pass

    if args.rebuild_graph:
        from .memory import rebuild_graph
        done = rebuild_graph(config.load(), DB(), hours=args.hours)
    else:
        done = run_pass(config.load(), DB(), hours_limit=args.hours)
    print(" ".join(f"{k}={v}" for k, v in done.items()))


def cmd_chronicle(args) -> None:
    from .db import DB

    db = DB()
    if args.week or args.month or args.year:
        period = "week" if args.week else "month" if args.month else "year"
        rows = db.query("SELECT period_key, summary FROM chronicle WHERE period = ? ORDER BY period_key DESC LIMIT 4",
                        (period,))
    else:
        day = args.day or time.strftime("%Y-%m-%d")
        rows = db.query("SELECT period_key, summary FROM chronicle WHERE period = 'day' AND period_key = ?", (day,))
        rows += db.query("SELECT period_key, summary FROM chronicle WHERE period = 'hour' AND period_key LIKE ? "
                         "ORDER BY period_key", (day + "T%",))
    for r in rows:
        print(f"## {r['period_key']}\n{r['summary']}\n")
    if not rows:
        print("Nothing summarized for that period yet (run `donkey memory`).")


def cmd_day(args) -> None:
    """The daily summary page: sessions with durations, focus, done, unfinished, next steps."""
    import datetime as dt

    from . import daypage
    from .db import DB

    day = {"today": dt.date.today(), "yesterday": dt.date.today() - dt.timedelta(days=1)}.get(args.day or "today")
    day = (day or dt.date.fromisoformat(args.day)).isoformat()
    page = daypage.get(config.load(), DB(), day)
    print(page or f"Nothing summarized for {day} yet (hours are summarized about 10 minutes after they end).")


def cmd_wiki(args) -> None:
    import json

    from .db import DB

    db = DB()
    if args.tidy:
        from . import config, tidy
        done = tidy.run(config.load(), db, batches=1000)
        print(f"Tidied {done['pages']} pages: {done['retyped']} re-labelled, {done['merged']} merged, "
              f"{done['removed']} removed, {done['relations']} relations.")
        return
    if not args.slug:
        for r in db.query("SELECT slug, page_type, tie, title, summary, mention_count, salience FROM wiki_pages "
                          "ORDER BY salience DESC, last_seen DESC LIMIT ?", (args.limit,)):
            print(f"{r['salience']:>5.1f} {r['mention_count']:>4}  {r['page_type']:<12} {r['tie']:<13} "
                  f"{r['slug']:<30} {r['summary'][:70]}")
        return
    rows = db.query("SELECT * FROM wiki_pages WHERE slug = ?", (args.slug,))
    if not rows:
        sys.exit(f"no page {args.slug!r}")
    p = rows[0]
    print(f"# {p['title']}  ({p['page_type']}" + (f", {p['tie']}" if p["tie"] else "")
          + (f", {p['sphere']}" if p["sphere"] else "") + f", {p['mention_count']} mentions)")
    if json.loads(p["aliases"]):
        print("aka " + ", ".join(json.loads(p["aliases"])))
    print(f"\n{p['summary']}\n\n{p['body'] or '(not written yet: run `donkey memory`)'}")
    if json.loads(p["links"]):
        print("\nLinks: " + ", ".join(json.loads(p["links"])))
    rels = db.query("SELECT b, label FROM wiki_relations WHERE a = ? UNION SELECT a, label FROM wiki_relations "
                    "WHERE b = ?", (p["slug"], p["slug"]))
    if rels:
        print("Relations: " + "; ".join(f"{r['label']} {r['b']}" for r in rels))


def cmd_inbox(args) -> None:
    from .db import DB

    db = DB()
    where = "" if args.all else "WHERE status IN ('delivered', 'seen')"
    rows = db.query(f"SELECT * FROM nudges {where} ORDER BY created_at DESC LIMIT ?", (args.limit,))
    for r in rows:
        when = time.strftime("%a %d %b %H:%M", time.localtime(r["created_at"]))
        new = "•" if r["status"] == "delivered" else " "
        if r["status"] == "skipped":
            print(f"  {when}  {r['kind']}: skipped ({r['skip_reason']})")
            continue
        print(f"{new} {when}  {r['kind']}: {r['title']}\n    " + r["body"].replace("\n", "\n    ") + "\n")
    db.execute("UPDATE nudges SET status = 'seen', seen_at = ? WHERE status = 'delivered'", (time.time(),))
    if not rows:
        print("Inbox is empty.")


def cmd_loops(args) -> None:
    from . import loops
    from .db import DB

    db = DB()
    if args.done or args.drop:
        loop_id = args.done or args.drop
        loops.close_loop(db, loop_id, "done" if args.done else "dropped", "closed by the user")
        print(f"Loop {loop_id} {'done' if args.done else 'dropped'}.")
        return
    rows = loops.open_loops(db)
    for r in rows:
        due = time.strftime("%a %d %b %H:%M", time.localtime(r["due_at"])) if r["due_at"] else "no due date"
        who = f" · {r['person']}" if r["person"] else ""
        print(f"[{r['id']}] {r['kind']:<13} {r['summary']}{who}  ({due})")
    if not rows:
        print("No open loops.")


def cmd_todo(args) -> None:
    from . import loops
    from .db import DB

    db = DB()
    if args.action == "add":
        print(f"Added to-do {loops.add_todo(db, ' '.join(args.text))}.")
    elif args.action == "done":
        for t in args.text:
            print(f"To-do {t} done." if loops.complete_todo(db, int(t)) else f"No to-do {t}.")
    else:
        for r in loops.todos(db, include_done=args.all):
            mark = "x" if r["done"] else " "
            print(f"[{mark}] {r['id']:>3}  {r['text']}{'  (auto)' if r['source'] == 'auto' else ''}")


def cmd_brief(args) -> None:
    import datetime as dt

    from . import nudges
    from .db import DB

    cfg, db = config.load(), DB()
    kind = {"morning": "morning_brief", "evening": "evening_wrap"}[args.which]
    nudges.run_brief(cfg, db, kind, "", dt.datetime.now(), force=True)
    row = db.query("SELECT * FROM nudges WHERE kind = ? ORDER BY id DESC LIMIT 1", (kind,))[0]
    print(f"{row['title']}\n{row['body']}" if row["status"] == "delivered" else f"Skipped: {row['skip_reason']}")


def cmd_meetings(args) -> None:
    import json

    from . import attention
    from .db import DB

    now = time.time()
    rows = attention.upcoming_meetings(DB(), now - 3600, now + args.days * 86400)
    for m in rows:
        when = time.strftime("%a %d %b %H:%M", time.localtime(m["starts_at"]))
        print(f"{when}  {m['title']}  ({', '.join(json.loads(m['participants'])) or 'participants unknown'})")
    if not rows:
        print("No upcoming meetings seen in mail or calendar.")


def cmd_mcp(args) -> None:
    from .mcp_server import main as serve

    serve()


def cmd_mcp_install(args) -> None:
    import json

    from .mcp_install import install, server_spec, uninstall

    if args.client == "print":
        print(json.dumps({"mcpServers": {"donkey": server_spec()}}, indent=2))
    elif args.remove:
        print(uninstall(args.client))
    else:
        print(install(args.client, dry_run=args.dry_run))


def cmd_digest(args) -> None:
    from .chronicle import read_digest, refresh_digest
    from .db import DB

    if args.refresh:
        refresh_digest(config.load(), DB(), force=True)
    print(read_digest() or "No digest yet (run `donkey memory`).")


def cmd_recent(args) -> None:
    from .db import DB

    for r in DB().recent(args.limit):
        when = time.strftime("%H:%M:%S", time.localtime(r["last_seen_at"]))
        print(f"#{r['id']} {when}  {r['duration_s']:>6.0f}s  {r['app']} | {r['window_title'][:70]}"
              f"  ({len(r['content'])} chars)")


def cmd_time(args) -> None:
    from .db import DB

    since = time.strftime("%Y-%m-%dT%H", time.localtime(time.time() - args.hours * 3600))
    rows = DB().time_report(since)
    total = sum(r["seconds"] for r in rows)
    print(f"Foreground time, last {args.hours} h: {total / 3600:.1f} h")
    for r in rows[: args.limit]:
        label = r["app"] + (f" · {r['domain']}" if r["domain"] else "")
        print(f"  {r['seconds'] / 60:7.1f} min  {label}")


def cmd_projects(args) -> None:
    """Time by project, the rules that file it, and adding or removing rules."""
    from . import timeproj
    from .db import DB

    db = DB()
    if args.action == "add":
        if not args.project:
            sys.exit("usage: donkey projects add PROJECT [--app A] [--domain D] [--title T]")
        rid = timeproj.add_rule(db, args.project, args.app or "", args.domain or "", args.title or "")
        if rid:
            print(f"Rule #{rid} added; it matches {timeproj.matched_seconds(db, rid) / 3600:.1f} h of tracked time in the last 30 days.")
        else:
            print("Nothing added (give --app, --domain or --title; or it exists already).")
        return
    if args.action == "remove":
        print("Rule switched off." if timeproj.disable_rule(db, int(args.project)) else "No such rule.")
        return
    if args.action == "rules":
        for r in db.query("SELECT * FROM time_rules ORDER BY project, id"):
            match = " ".join(f"{k}={r[k]!r}" for k in ("app", "domain", "title_contains") if r[k])
            print(f"#{r['id']} {r['project']} <- {match} [{r['source']}{'' if r['enabled'] else ', off'}]")
        return
    since = time.strftime("%Y-%m-%dT%H", time.localtime(time.time() - args.days * 86400))
    print(timeproj.format_report(timeproj.report(db, since), args.days))


def cmd_stats(args) -> None:
    from .db import DB

    for k, v in DB().stats().items():
        print(f"{k}: {v}")


def cmd_ignore(args) -> None:
    """List, add or remove ignore rules. Adding one also deletes the history it matches."""
    from . import forget
    from .db import DB

    cfg = config.load()
    if args.action == "list" or not args.values:
        print("Apps:      " + (", ".join(cfg.blocked_apps) or "(none)"))
        print("Sites etc: " + (", ".join(cfg.blocked_domains) or "(none)"))
        print("Plus Donkey's built-in list (banks, password managers, sign-in pages, Donkey's own windows).")
        print("Add with `donkey ignore add example.com` (or app:Name, url:part, title:part, path:piece).")
        return
    values = [forget.clean_value(v) for v in args.values]
    db = DB()
    if args.action == "remove":
        forget.remove_user_rules(cfg, db, values)
        print("Removed. Donkey reads those again from now on (what was deleted stays deleted).")
        return
    preview = forget.preview(db, values)
    print(f"Matches {preview['screens']} saved screens, {preview['rewrites']} rewrites, {preview['sends']} sent messages and "
          f"{preview['time_rows']} rows of tracked time. The summaries of {preview['hours']} hours would be redone, and "
          f"{preview['pages']} wiki pages built only from them would go.")
    for t in preview["examples"]:
        print(f"  e.g. {t[:100]}")
    if (preview["screens"] or preview["rewrites"] or preview["sends"]) and not args.yes:
        if input("Delete them and stop reading this from now on? [y/N] ").strip().lower() not in ("y", "yes"):
            print("Nothing changed.")
            return
    done = forget.add_user_rules(cfg, db, values)
    print("Ignored from now on (a running Donkey picks it up within seconds).")
    if any(done.values()):
        print("Deleted: " + ", ".join(f"{v} {k.replace('_', ' ')}" for k, v in done.items() if v) +
              (". Summaries of those hours are redone from what's left on the next memory pass." if done["hours"] else "."))


def cmd_writes(args) -> None:
    """Changes AI apps made through Donkey's MCP write tools."""
    from .db import DB

    rows = DB().query("SELECT * FROM tool_writes ORDER BY ts DESC LIMIT ?", (args.limit,))
    if not rows:
        print("No changes from AI apps yet.")
    for r in reversed(rows):
        print(f"{time.strftime('%m-%d %H:%M', time.localtime(r['ts']))}  {r['tool']} {r['args']}\n    -> {r['result']}")


def cmd_pause(args) -> None:
    from .capture import pause

    pause(args.minutes)
    print(f"Capture paused {'for %g min' % args.minutes if args.minutes else 'until `donkey resume`'}.")


def cmd_resume(args) -> None:
    from .capture import resume

    resume()
    print("Capture resumed.")


def cmd_ask(args) -> None:
    from . import chat
    from .db import DB

    cfg, db = config.load(), DB()
    tid = args.thread or chat.new_thread(db)
    out = chat.send(cfg, db, tid, " ".join(args.question),
                    on_event=lambda kind, data=None: print(data, end="", flush=True) if kind == "token" and args.stream else None)
    text = "\n\n".join(p.strip() for p in out["text"].split("|||") if p.strip())
    print(("\n" if args.stream else "") + ("" if args.stream else text))
    used = ", ".join(t["name"] for t in out["tools"]) or "none"
    print(f"\n(thread {tid} · {out['ms'] / 1000:.1f} s · tools: {used})")


def cmd_remind(args) -> None:
    from . import reminders
    from .db import DB

    db = DB()
    if args.delete:
        print(reminders.delete(db, args.delete))
        return
    if not args.text:
        rows = reminders.listing(db, include_done=args.all)
        for r in rows:
            print(reminders.describe(r))
        if not rows:
            print('No reminders. Add one: donkey remind "call mum" --at 5pm')
        return
    try:
        r = reminders.create(db, " ".join(args.text), at=args.at or "", repeat=args.repeat, days=args.days,
                             every_minutes=args.every or 0, ask=args.ask)
    except reminders.ReminderError as e:
        sys.exit(str(e))
    print(f"Set {reminders.describe(r)}" + (f"\n{r['note']}" if r["note"] else ""))


def cmd_import(args) -> None:
    from . import imports
    from .db import DB

    db = DB()
    if args.remove:
        print(f"Removed {imports.remove(db, source=args.remove)} imported documents from {args.remove}.")
        return
    if not args.target:
        rows = imports.summary(db)
        for r in rows:
            print(f"{r['source']:<10} {r['docs']:>6} documents  {r['chars'] / 1000:>8.0f}k chars  "
                  f"(last import {time.strftime('%Y-%m-%d %H:%M', time.localtime(r['last']))})")
        if not rows:
            print("Nothing imported yet. donkey import PATH (a ChatGPT/Claude export, a notes folder) or donkey import granola")
        return
    try:
        print(imports.run(db, args.target, mask=config.load().redact))
    except (ValueError, OSError) as e:
        sys.exit(str(e))


def cmd_facts(args) -> None:
    from . import facts
    from .db import DB

    db = DB()
    if args.forget:
        print(f"Forgot fact {args.forget}." if facts.forget(db, args.forget) else f"No active fact {args.forget}.")
        return
    if args.add:
        fid = facts.add(db, args.add, args.add, "personal", source="cli")
        print(f"Saved fact {fid}." if fid else "Already known.")
        return
    if args.distill:
        print(f"Learned {facts.distill(config.load(), db)} new facts and writing rules from chats.")
    rows = db.query("SELECT * FROM user_facts " + ("" if args.all else "WHERE active = 1 ") + "ORDER BY updated_at DESC")
    for r in rows:
        print(facts.describe(r) + ("" if r["active"] else "  [no longer true]"))
        if args.quotes and r["quote"]:
            print(f"      “{r['quote']}”")
    if not rows:
        print("No facts yet. Tell Donkey about yourself in the chat, or: donkey facts --add 'Is vegetarian.'")


def cmd_claims(args) -> None:
    from . import claims
    from .db import DB

    db = DB()
    if args.read:
        print(f"Read {claims.run_pass(config.load(), db, limit=args.read)} hours for claims.")
    if args.query:
        print(claims.lookup(db, args.query, limit=20) or f"No claims match {args.query!r}.")
        return
    lines = claims.changes(db, args.days)
    print(f"Changed in the last {args.days} days:" if lines else f"Nothing changed in the last {args.days} days.")
    print("\n".join(lines))
    n = db.query("SELECT COUNT(*) AS n, COUNT(DISTINCT thread) AS t FROM claims")[0]
    print(f"\n{n['n']} claims in {n['t']} threads. Search them: donkey claims 'walmart margin'")


def cmd_profile(args) -> None:
    import time as _t
    from . import profile
    from .db import DB

    db = DB()
    if args.undo:
        print("Went back one version." if profile.undo(db) is not None else "No older version.")
        return
    if args.reset:
        profile.reset(db)
        print("Cleared. The next refresh writes it again from the last 14 days (or run: donkey profile --refresh).")
        return
    if args.history:
        for r in profile.history(db):
            print(f"#{r['id']} {_t.strftime('%Y-%m-%d %H:%M', _t.localtime(r['created_at']))} {r['source']:7} {r['chars']} chars")
        return
    if args.refresh:
        profile.note_edit(db)
        out = profile.refresh(config.load(), db, force=True)
        print("Refreshed." if out else "No change (or nothing summarized in the last 14 days yet).")
    text = profile.current(db)
    print(text or "No profile yet. It's written once a day has been summarized; or run: donkey profile --refresh")
    print(f"\n({profile.PROFILE_PATH}: edit it freely; lines you add are kept, lines you delete stay out. "
          f"Your own about-me.md, if any, comes first.)")


def cmd_open(args) -> None:
    """A donkey:// link (a clicked notification): hand it to the running Donkey, or start it."""
    from . import instance
    link = (args.link or "").strip()
    if instance.send_to_running(link or "show"):
        return
    import subprocess
    subprocess.Popen(config.command("app", gui=True), env={**__import__("os").environ, **config.command_env()},
                     creationflags=0x00000008 | 0x00000200)  # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP


def main() -> None:
    parser = argparse.ArgumentParser(prog="donkey")
    parser.add_argument("-v", "--verbose", action="store_true", help="debug logging")
    sub = parser.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("run", help="capture loop + the rewrite key")
    p.add_argument("--no-capture", action="store_true", help="only the rewrite key")
    p.set_defaults(fn=cmd_run)
    sub.add_parser("map", help="open the memory map (graph of people, projects, apps and sites)").set_defaults(fn=cmd_map)
    p = sub.add_parser("app", help="run as a system tray app with the on-screen creature (recommended)")
    p.add_argument("--no-capture", action="store_true", help="only the rewrite key and creature")
    p.add_argument("--login", action="store_true", help=argparse.SUPPRESS)  # started at sign-in
    p.set_defaults(fn=cmd_app)
    p = sub.add_parser("open", help=argparse.SUPPRESS)  # donkey:// links from notifications
    p.add_argument("link", nargs="?")
    p.set_defaults(fn=cmd_open)
    sub.add_parser("doctor", help="check the API key, the key, text recognition and field reading").set_defaults(fn=cmd_doctor)
    p = sub.add_parser("rewrite", help="rewrite the focused field once (no key needed)")
    p.add_argument("--delay", type=float, default=3)
    p.set_defaults(fn=cmd_rewrite)
    p = sub.add_parser("peek", help="read the front window once and print it (stores nothing)")
    p.add_argument("--delay", type=float, default=3)
    p.add_argument("--chars", type=int, default=3000)
    p.set_defaults(fn=cmd_peek)
    p = sub.add_parser("search", help="search snapshots, summaries and the wiki")
    p.add_argument("query")
    p.add_argument("-n", "--limit", type=int, default=10)
    p.add_argument("--keyword", action="store_true", help="keyword only, no vectors")
    p.set_defaults(fn=cmd_search)
    p = sub.add_parser("eval", help="score memory search on your questions file, and how rewrites fared")
    p.add_argument("--k", type=int, default=5, help="count a question as found if a right hit is in the top k")
    p.add_argument("--rewrites", action="store_true", help="replay saved rewrites with the current prompt and check them")
    p.add_argument("--limit", type=int, default=30, help="replay at most this many of the newest cases")
    p.add_argument("--scenarios", action="store_true",
                   help="end to end: build a made-up memory, press the key in each scenario, score the replies")
    p.add_argument("--runs", type=int, default=1, help="with --scenarios: press each scenario this many times")
    p.add_argument("--rebuild", action="store_true", help="with --scenarios: rebuild the made-up memory")
    p.add_argument("--only", action="append", help="with --scenarios: just this scenario id (repeatable)")
    p.add_argument("--model", help="with --scenarios: rewrite (or answer, with --chat) with this model instead of the configured one")
    p.add_argument("--chat", action="store_true", help="with --scenarios: ask each one in chat instead of pressing the key")
    p.set_defaults(fn=cmd_eval)
    p = sub.add_parser("style", help="writing rules learned from your edits (and how rewrites fared)")
    p.add_argument("--add", help="add a rule you state yourself, e.g. 'Write WhatsApp messages in Hinglish'")
    p.add_argument("--scope", default="", help="app or site the added rule applies to (default: everywhere)")
    p.add_argument("--disable", type=int, help="disable a rule by id")
    p.add_argument("--mine", action="store_true", help="pair sends and mine rules now")
    p.set_defaults(fn=cmd_style)
    p = sub.add_parser("examples", help="messages you chose as examples of how you write (shown to rewrites)")
    p.add_argument("--add", help="a message that sounds like you")
    p.add_argument("--scope", default="", help="app or site it's for, e.g. web.whatsapp.com (default: everywhere)")
    p.add_argument("--remove", type=int, help="delete an example by id")
    p.set_defaults(fn=cmd_examples)
    p = sub.add_parser("sends", help="messages Donkey saw you send (and drafts you cleared)")
    p.add_argument("--hours", type=int, default=24)
    p.set_defaults(fn=cmd_sends)
    p = sub.add_parser("memory", help="run pending memory jobs now (summaries, wiki, embeddings, digest)")
    p.add_argument("--hours", type=int, default=24, help="max hours to summarize in this run")
    p.add_argument("--rebuild-graph", action="store_true",
                   help="re-mask stored text and re-extract the knowledge graph from captured screens")
    p.set_defaults(fn=cmd_memory)
    p = sub.add_parser("chronicle", help="show summaries for a day (default today) or recent weeks, months, years")
    p.add_argument("--day", help="YYYY-MM-DD")
    p.add_argument("--week", action="store_true")
    p.add_argument("--month", action="store_true")
    p.add_argument("--year", action="store_true")
    p.set_defaults(fn=cmd_chronicle)
    p = sub.add_parser("day", help="the daily summary page: sessions, focus, done, unfinished, next steps")
    p.add_argument("day", nargs="?", help="today (default), yesterday or YYYY-MM-DD")
    p.set_defaults(fn=cmd_day)
    p = sub.add_parser("wiki", help="list wiki pages, or show one")
    p.add_argument("slug", nargs="?")
    p.add_argument("-n", "--limit", type=int, default=40)
    p.add_argument("--tidy", action="store_true", help="re-label, merge and connect pages now (runs on its own every memory pass)")
    p.set_defaults(fn=cmd_wiki)
    p = sub.add_parser("inbox", help="nudges and briefs Donkey sent (marks them seen)")
    p.add_argument("-n", "--limit", type=int, default=20)
    p.add_argument("--all", action="store_true", help="include skipped ones and why")
    p.set_defaults(fn=cmd_inbox)
    p = sub.add_parser("loops", help="open loops: things owed, questions, blockers")
    p.add_argument("--done", type=int, metavar="ID", help="mark a loop done")
    p.add_argument("--drop", type=int, metavar="ID", help="drop a loop")
    p.set_defaults(fn=cmd_loops)
    p = sub.add_parser("todo", help="to-do list: `todo`, `todo add TEXT`, `todo done ID`")
    p.add_argument("action", nargs="?", choices=["list", "add", "done"], default="list")
    p.add_argument("text", nargs="*")
    p.add_argument("--all", action="store_true", help="include done items")
    p.set_defaults(fn=cmd_todo)
    p = sub.add_parser("brief", help="generate the morning brief or evening wrap now")
    p.add_argument("which", choices=["morning", "evening"])
    p.set_defaults(fn=cmd_brief)
    p = sub.add_parser("meetings", help="upcoming meetings seen in mail/calendar")
    p.add_argument("--days", type=int, default=7)
    p.set_defaults(fn=cmd_meetings)
    sub.add_parser("mcp", help="run the MCP server on stdio (AI apps launch this)").set_defaults(fn=cmd_mcp)
    p = sub.add_parser("mcp-install", help="register the MCP server with an AI app")
    p.add_argument("client", choices=["claude-code", "claude-desktop", "cursor", "print"])
    p.add_argument("--dry-run", action="store_true", help="show what would change")
    p.add_argument("--remove", action="store_true", help="unregister instead")
    p.set_defaults(fn=cmd_mcp_install)
    p = sub.add_parser("digest", help="show the memory digest rewrites get")
    p.add_argument("--refresh", action="store_true")
    p.set_defaults(fn=cmd_digest)
    p = sub.add_parser("recent", help="most recently seen snapshots")
    p.add_argument("-n", "--limit", type=int, default=20)
    p.set_defaults(fn=cmd_recent)
    p = sub.add_parser("time", help="foreground time per app/domain")
    p.add_argument("--hours", type=float, default=24)
    p.add_argument("-n", "--limit", type=int, default=25)
    p.set_defaults(fn=cmd_time)
    p = sub.add_parser("projects", help="time by project; `projects rules`, `projects add NAME --title T`, `projects remove ID`")
    p.add_argument("action", nargs="?", choices=["report", "rules", "add", "remove"], default="report")
    p.add_argument("project", nargs="?", help="project name (add) or rule id (remove)")
    p.add_argument("--app")
    p.add_argument("--domain")
    p.add_argument("--title", help="text the window title must contain")
    p.add_argument("--days", type=float, default=7)
    p.set_defaults(fn=cmd_projects)
    sub.add_parser("stats", help="row counts").set_defaults(fn=cmd_stats)
    p = sub.add_parser("ignore", help="apps and sites Donkey never reads; adding one deletes what it already saved")
    p.add_argument("action", nargs="?", choices=["list", "add", "remove"], default="list")
    p.add_argument("values", nargs="*", help="example.com, app:Name, url:part, title:part or path:piece")
    p.add_argument("-y", "--yes", action="store_true", help="don't ask before deleting")
    p.set_defaults(fn=cmd_ignore)
    p = sub.add_parser("writes", help="changes AI apps made through the MCP write tools")
    p.add_argument("-n", "--limit", type=int, default=30)
    p.set_defaults(fn=cmd_writes)
    p = sub.add_parser("pause", help="pause capture (minutes, or until resume)")
    p.add_argument("minutes", type=float, nargs="?")
    p.set_defaults(fn=cmd_pause)
    sub.add_parser("resume", help="resume capture").set_defaults(fn=cmd_resume)
    p = sub.add_parser("ask", help="ask Donkey about your memory (the chat, in the terminal)")
    p.add_argument("question", nargs="+")
    p.add_argument("--thread", type=int, help="continue a chat thread by id")
    p.add_argument("--stream", action="store_true", help="print the answer as it arrives")
    p.set_defaults(fn=cmd_ask)
    p = sub.add_parser("remind", help='reminders: `remind` lists, `remind "call mum" --at 5pm`, `--delete ID`')
    p.add_argument("text", nargs="*", help="what to remind you about (or, with --ask, the question to answer)")
    p.add_argument("--at", help='"17:00", "5pm", "tomorrow 9am", "friday 10:00", "in 20 minutes"')
    p.add_argument("--repeat", default="once", choices=["once", "daily", "weekdays", "weekly", "interval"])
    p.add_argument("--days", help="for weekly: mon,fri")
    p.add_argument("--every", type=int, help="for interval: minutes")
    p.add_argument("--ask", action="store_true", help="answer the text as a question from memory each time")
    p.add_argument("--delete", type=int, metavar="ID")
    p.add_argument("--all", action="store_true", help="include finished ones")
    p.set_defaults(fn=cmd_remind)
    p = sub.add_parser("facts", help="what you told Donkey in chat about yourself, your people and plans")
    p.add_argument("--forget", type=int, metavar="ID")
    p.add_argument("--add", metavar="FACT", help="e.g. 'Is vegetarian.'")
    p.add_argument("--distill", action="store_true", help="read finished chats for new facts now")
    p.add_argument("--all", action="store_true", help="include replaced and forgotten ones")
    p.add_argument("--quotes", action="store_true", help="show the words each fact came from")
    p.set_defaults(fn=cmd_facts)
    p = sub.add_parser("claims", help="dated claims seen on screen (numbers, plans, promises) and what changed")
    p.add_argument("query", nargs="?", help="show the claim threads matching these words")
    p.add_argument("--days", type=int, default=7, help="changes from the last N days (default 7)")
    p.add_argument("--read", type=int, metavar="HOURS", help="read up to N pending hours for claims first")
    p.set_defaults(fn=cmd_claims)
    p = sub.add_parser("profile", help="the 'About you' profile Donkey keeps up to date from the last 14 days")
    p.add_argument("--refresh", action="store_true", help="rebuild it now")
    p.add_argument("--undo", action="store_true", help="go back one version")
    p.add_argument("--reset", action="store_true", help="start over from the evidence alone")
    p.add_argument("--history", action="store_true", help="list versions")
    p.set_defaults(fn=cmd_profile)
    p = sub.add_parser("import", help="import ChatGPT/Claude exports, Markdown notes or Granola into memory")
    p.add_argument("target", nargs="?", help="an export .zip or conversations.json, a notes folder, or 'granola'")
    p.add_argument("--remove", metavar="SOURCE", help="delete imported documents: chatgpt, claude, markdown or granola")
    p.set_defaults(fn=cmd_import)

    args = parser.parse_args()
    setup_logging(args.verbose)
    args.fn(args)


if __name__ == "__main__":
    main()
