"""What the user wrote in message fields: the final text when a field empties, and whether the
app itself marked it as sent.

While the user types, the draft is the focused field's value. When the field empties (or the
app swaps in a fresh message box, as chat apps do after a send), the final text is recorded:

- sent: the app marks it as the user's own message (WhatsApp Web labels the row "You:").
- cleared: the field emptied but nothing proves it went out; it may have been sent or deleted.
  No guessing from text on screen: short replies and codes appear everywhere.

Switching conversations (the app swaps in another chat's saved draft) is not recorded. Text that
Donkey writes into the field doesn't count as the user clearing it. Only outcomes are stored,
redacted, and never from blocked apps, private windows, password fields or terminals. The final
text is what the learning loop compares with Donkey's rewrite; `sent` rows are ground truth for
memory.
"""
import logging
import os
import re
import threading
import time
import unicodedata
from dataclasses import dataclass, field

from . import ax, web
from .capture import paused_until, screen_locked
from .config import Config
from .db import DB
from .field import NOT_FIELDS, TERMINAL_BUNDLES, TEXT_ROLES, clean_value
from .filters import blocked_reason, is_private_window, load_rules, redact

log = logging.getLogger("donkey.sends")

POLL_S = 0.6
VERIFY_AFTER_S = (1.0, 3.0, 7.0)   # look for the app's own "sent" mark after a field empties
MIN_CHARS = 2
MATCH_CHARS = 160                   # compare at most this much of the normalized draft
DUPLICATE_S = 5.0
SEND_MARKS = {"web.whatsapp.com"}   # sites where Donkey can see the app's own "sent" mark
SEARCH_HINTS = ("search", "find", "filter", "address", "url", "location", "go to")


_donkey_writes: list[tuple[float, str]] = []


def note_donkey_write(text: str) -> None:
    """Called when Donkey puts text into a field, so the watcher doesn't read it as the user
    clearing their draft."""
    _donkey_writes.append((time.time(), norm(text)))
    del _donkey_writes[:-5]


def donkey_wrote(value: str, within_s: float = 15.0) -> bool:
    v = norm(value)
    return bool(v) and any(time.time() - t < within_s and (v == w or w in v) for t, w in _donkey_writes)


@dataclass
class Draft:
    app: str
    pid: int
    bundle_id: str | None
    domain: str | None
    window_title: str
    surface: str
    chat: bool
    element: object = field(repr=False)
    window: object = field(repr=False)
    text: str = ""
    updated_at: float = 0.0


@dataclass
class Pending:
    draft: Draft
    cleared_at: float
    surface_after: str | None
    checks_done: int = 0


def norm(text: str) -> str:
    """Letters and digits only, lowercased: survives timestamps, ticks, emoji images and spacing."""
    text = unicodedata.normalize("NFKC", text).lower()
    return " ".join("".join(c if c.isalnum() else " " for c in text).split())


def contains_message(haystack: str, draft: str) -> bool:
    """True when the draft appears in `haystack` other than as a 'Draft:' preview."""
    needle = norm(draft)[:MATCH_CHARS]
    if len(needle) < MIN_CHARS:
        return False
    hay = norm(haystack)
    start = 0
    while (i := hay.find(needle, start)) >= 0:
        if not hay[max(0, i - 12):i].rstrip().endswith("draft"):
            return True
        start = i + 1
    return False


def surface_of(element, app, domain: str | None, window_title: str) -> str:
    """Who a message goes to: named by the composer ("Type a message to Anna"), else the chat
    header on chat sites, else the window title."""
    for attr in ("AXDescription", "AXPlaceholderValue", "AXTitle"):
        if who := web.recipient_from_label(ax.as_text(ax.attr(element, attr))):
            return who[:120]
    try:
        if web.is_chat_surface(app.name, domain):
            container = web.conversation_container(element, domain)
            kids = ax.attr(container, "AXChildren") or [] if container is not None else []
            header = ax.element_text(kids[0]) if kids else None
            if header and header.strip():
                return " ".join(header.split())[:120]
    except Exception:
        log.debug("surface lookup failed", exc_info=True)
    return window_title[:120]


def _in_web_area(el) -> bool:
    node, hops = ax.attr(el, "AXParent"), 0
    while node is not None and hops < 40:
        if ax.attr(node, "AXRole") == "AXWebArea":
            return True
        node, hops = ax.attr(node, "AXParent"), hops + 1
    return False


def _composer(app: ax.FrontApp, el) -> bool:
    """A field the user writes messages in: not a password, search box, address bar or terminal."""
    if el is None or app.bundle_id in TERMINAL_BUNDLES:
        return False
    role = ax.as_text(ax.attr(el, "AXRole"))
    if role in NOT_FIELDS or role == "AXSearchField" or ax.as_text(ax.attr(el, "AXSubrole")) == "AXSecureTextField":
        return False
    if role not in TEXT_ROLES and ax.attr(el, "AXSelectedTextRange") is None:
        return False
    if app.is_browser and not _in_web_area(el):
        return False  # the address bar and other browser chrome
    label = " ".join(filter(None, (ax.as_text(ax.attr(el, n)) for n in ("AXPlaceholderValue", "AXDescription", "AXTitle"))))
    return not any(h in label.lower() for h in SEARCH_HINTS)


class SendWatcher:
    def __init__(self, cfg: Config, db: DB):
        self.cfg, self.db = cfg, db
        self.rules = load_rules(cfg.blocked_apps, cfg.blocked_domains)
        self.draft: Draft | None = None
        self.pending: list[Pending] = []

    def run(self, stop: threading.Event) -> None:
        log.info("send detection started")
        own = os.getpid()
        while not stop.is_set():
            try:
                self.tick(own)
            except Exception:
                log.exception("send watcher tick failed")
            stop.wait(POLL_S)

    # ------------------------------------------------------------ tracking

    def tick(self, own_pid: int) -> None:
        now = time.time()
        self._verify_due(now)
        if paused_until() or screen_locked() or not self.cfg.capture_enabled:
            self.draft = None
            return
        app = ax.front_app()
        if app is None or app.pid == own_pid:
            return
        el = ax.attr(app.element, "AXFocusedUIElement")
        composer = _composer(app, el)
        here = None  # recipient named by the field that has focus now ("Type a message to Anna")
        if composer:
            here = next((who for a in ("AXDescription", "AXPlaceholderValue", "AXTitle")
                         if (who := web.recipient_from_label(ax.as_text(ax.attr(el, a))))), None)
        d = self.draft
        if d is not None and not (d.pid == app.pid and el is not None and el == d.element):
            self._left_field(d, now, here)
        if not composer:
            return
        window = ax.attr(app.element, "AXFocusedWindow")
        title = ax.as_text(ax.attr(window, "AXTitle")) or ""
        if blocked_reason(self.rules, app.name, None, title) or is_private_window(title):
            self.draft = None
            return
        value = clean_value(el, ax.as_text(ax.attr(el, "AXValue")))
        d = self.draft
        if d is None:
            if value.strip():
                self.draft = self._new_draft(app, el, window, title, value, now)
            return
        if value.strip() == d.text.strip():
            return
        if here and d.surface and here[:120] != d.surface:
            # Same field, other conversation: the app swapped in that chat's saved draft. Not a send.
            self.draft = self._new_draft(app, el, window, title, value, now) if value.strip() else None
            return
        if donkey_wrote(value):
            d.text, d.updated_at = value, now  # Donkey replaced the draft at the user's request
            return
        if not value.strip() or (len(norm(value)) < len(norm(d.text)) / 2 and not norm(d.text).startswith(norm(value))):
            self._cleared(d, now, here)  # emptied (or replaced by something unrelated): a candidate send
            self.draft = self._new_draft(app, el, window, title, value, now) if value.strip() else None
            return
        d.text, d.updated_at = value, now

    def _new_draft(self, app, el, window, title, value, now) -> Draft:
        domain = None
        if app.is_browser:
            w = ax.find_web_area(window, el)
            domain = ax.domain_of(ax.url_string(ax.attr(w, "AXURL"))) if w is not None else None
        if domain and blocked_reason(self.rules, app.name, f"https://{domain}/", title):
            domain = None
        return Draft(app=app.name, pid=app.pid, bundle_id=app.bundle_id, domain=domain, window_title=title,
                     surface=surface_of(el, app, domain, title), chat=web.is_chat_surface(app.name, domain),
                     element=el, window=window, text=value, updated_at=now)

    def _left_field(self, d: Draft, now: float, here: str | None) -> None:
        """Focus moved off the draft's field. Many chat apps swap in a fresh message box after a send,
        so look at what happened to the old one rather than assuming the draft is still there."""
        self.draft = None
        if len(norm(d.text)) < MIN_CHARS:
            return
        gone = ax.attr(d.element, "AXRole") is None
        left = clean_value(d.element, ax.as_text(ax.attr(d.element, "AXValue"))) if not gone else ""
        if not gone and norm(d.text)[:MATCH_CHARS] in norm(left):
            return  # the text is still sitting in that field: an unsent draft, not an event
        self.pending.append(Pending(d, now, surface_after=here))

    def _cleared(self, d: Draft, now: float, here: str | None) -> None:
        if len(norm(d.text)) < MIN_CHARS:
            return
        self.pending.append(Pending(d, now, surface_after=here))

    # ------------------------------------------------------------ verification

    def _verify_due(self, now: float) -> None:
        keep = []
        for p in self.pending:
            if p.checks_done < len(VERIFY_AFTER_S) and now - p.cleared_at >= VERIFY_AFTER_S[p.checks_done]:
                p.checks_done += 1
                outcome = self._check(p)
                if outcome:
                    self._record(p, *outcome)
                    continue
                if p.checks_done == len(VERIFY_AFTER_S):
                    self._finish_unproven(p)
                    continue
            keep.append(p)
        self.pending = keep

    def _check(self, p: Pending) -> tuple[str, str] | None:
        """Sent only when the app itself marks the message as the user's (WhatsApp Web: a "You:" row)."""
        d = p.draft
        if d.domain == "web.whatsapp.com":
            container = web.conversation_container(d.element, d.domain) or web.find_main(d.window)
            if container is not None:
                mine = [ln[4:] for ln in web._whatsapp_transcript(container) if ln.startswith("Me: ")]
                if any(contains_message(m, d.text) for m in mine[-8:]):
                    return "sent", "outgoing"
        return None

    def _finish_unproven(self, p: Pending) -> None:
        d = p.draft
        if p.surface_after and d.surface and p.surface_after[:120] != d.surface:
            log.debug("draft parked: switched from %r to %r", d.surface[:40], p.surface_after[:40])
            return
        # Where the app marks sends, no mark means it wasn't sent; elsewhere we can't tell.
        self._record(p, "cleared", "not_sent" if d.domain in SEND_MARKS else "unknown")

    def _record(self, p: Pending, kind: str, proof: str) -> None:
        d = p.draft
        text = redact(d.text.strip()) if self.cfg.redact else d.text.strip()
        if re.fullmatch(r"\d{4,8}", text):
            text = "[redacted code]"  # a bare 4-8 digit message is almost always a one-time code
        dup = self.db.query("SELECT id, text FROM sends WHERE ts BETWEEN ? AND ? AND app = ? AND surface = ?",
                            (p.cleared_at - DUPLICATE_S, p.cleared_at + DUPLICATE_S, d.app, redact(d.surface)))
        if any(norm(r["text"]) == norm(text) for r in dup):
            return  # the same message seen twice (e.g. a paste and a keystroke clearing the field)
        self.db.execute("INSERT INTO sends (ts, kind, proof, app, domain, window_title, surface, text) "
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                        (p.cleared_at, kind, proof, d.app, d.domain, redact(d.window_title), redact(d.surface), text))
        log.info("send %s (%s) in %s%s: %d chars", kind, proof, d.app, f" | {d.domain}" if d.domain else "",
                 len(text))


def recent(db: DB, start: float, end: float, kinds=("sent",)) -> list:
    marks = ",".join("?" * len(kinds))
    return db.query(f"SELECT * FROM sends WHERE ts >= ? AND ts < ? AND kind IN ({marks}) ORDER BY ts",
                    (start, end, *kinds))


_GREETING = re.compile(r"(?i)^\s*(?:hi|hey|hello|dear|hii+|yo)\s+([^\s,!.]+)")


def greets_someone_else(a: str, b: str) -> bool:
    """Both texts open by greeting a name and the names differ."""
    ma, mb = _GREETING.match(a), _GREETING.match(b)
    return bool(ma and mb and ma.group(1).lower() != mb.group(1).lower())
