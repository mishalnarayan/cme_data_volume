"""Chat: your chats with Donkey, and the inbox of messages it sent you. A tab of the Donkey window
(journal.py), drawn by its own page (PAGE below) in a frame, as the memory map is.

The page posts through the Donkey window's bridge (tagged src "chat"); Python answers with
`dk.<fn>(...)` calls the window passes into the frame. Answers run on a background thread
(chat.send) and stream in as `dk.ev(...)`; everything that touches the page runs on the main thread.
"""
import json
import logging
import threading
import time

from . import chat, llm, overlay, winui

log = logging.getLogger("donkey.chatwindow")

INBOX_LIMIT = 40
TITLE_BAR_H = 44  # the page's header row stands in for the title bar


def install_edit_menu() -> None:
    """Nothing to do on Windows: Ctrl+C / V / X / A / Z work in the pages by themselves."""

class ChatPane:
    """The chat tab's state and its side of the bridge. `call(fn, *args)` reaches the page's `dk`;
    the host passes the page's messages to `on_message`."""

    def __init__(self, cfg, db, call, on_unread=None):
        self.cfg, self.db = cfg, db
        self.call = call
        self.on_unread = on_unread or (lambda n: None)
        self.thread_id: int | None = None
        self.running: dict[int, threading.Event] = {}   # thread id -> cancel event of the reply in flight
        self.ready = False                              # the page has loaded (it asks for everything then)
        self.inbox_sig = None

    def show(self, thread_id: int | None = None, nudge_id: int | None = None, new: bool = False) -> None:
        """Point the tab at a chat: a nudge's, a given one, a fresh one, or the last one."""
        if nudge_id is not None:
            thread_id = chat.thread_for_nudge(self.db, nudge_id)
        if new:
            thread_id = None
            self.thread_id = None
        elif thread_id is None and self.thread_id is None:
            thread_id = chat.recent_thread(self.db)
        if thread_id is not None:
            self.thread_id = thread_id
        if self.ready:
            self.push_all()
            self.call("focus")

    # -------------------------------------------------------------- page bridge

    def _call(self, fn: str, *args) -> None:
        if self.ready:
            self.call(fn, *args)

    def push_all(self) -> None:
        self.push_threads()
        self.push_inbox(force=True)
        self.push_thread()

    def push_threads(self, query: str = "") -> None:
        rows = chat.threads(self.db, 200, query)
        self._call("setThreads", [{"id": r["id"], "title": r["title"] or "New chat", "updated": r["updated_at"],
                                   "inbox": bool(r["nudge_id"]), "last": (r["last"] or "")[:120]} for r in rows],
                   self.thread_id)

    def push_inbox(self, force: bool = False) -> None:
        rows = self.db.query("SELECT id, kind, title, body, status, created_at FROM nudges WHERE status != 'skipped' "
                             "ORDER BY created_at DESC LIMIT ?", (INBOX_LIMIT,))
        sig = tuple((r["id"], r["status"]) for r in rows)
        if not force and sig == self.inbox_sig:
            return
        self.inbox_sig = sig
        self.on_unread(sum(1 for r in rows if r["status"] == "delivered"))
        self._call("setInbox", [{"id": r["id"], "kind": r["kind"], "title": r["title"] or r["kind"].replace("_", " "),
                                 "body": r["body"][:200], "unread": r["status"] == "delivered",
                                 "at": r["created_at"]} for r in rows])

    def push_thread(self) -> None:
        if self.thread_id is None:
            self._call("setThread", None, "", [], False)
            return
        row = self.db.query("SELECT title FROM chat_threads WHERE id = ?", (self.thread_id,))
        if not row:
            self.thread_id = None
            self._call("setThread", None, "", [], False)
            return
        msgs = [{"id": m["id"], "role": m["role"], "content": m["content"], "tools": json.loads(m["tools"] or "[]"),
                 "at": m["created_at"]} for m in chat.messages(self.db, self.thread_id)]
        self._call("setThread", self.thread_id, row[0]["title"] or "New chat", msgs, self.thread_id in self.running)

    def on_message(self, msg: dict) -> None:
        kind = msg.get("type")
        if kind == "ready":
            self.ready = True
            if self.thread_id is None:
                self.thread_id = chat.recent_thread(self.db)
            self.push_all()
            self.call("focus")
        elif kind == "send":
            self._send(str(msg.get("text") or "").strip())
        elif kind == "cancel":
            if (ev := self.running.get(self.thread_id)) is not None:
                ev.set()
        elif kind == "open_thread":
            self.thread_id = int(msg["id"])
            self.push_thread()
            self.push_threads()
        elif kind == "new_thread":
            self.thread_id = None
            self.push_thread()
            self.push_threads()
        elif kind == "open_nudge":
            self.thread_id = chat.thread_for_nudge(self.db, int(msg["id"]))
            self.push_all()
        elif kind == "rename":
            chat.rename(self.db, int(msg["id"]), str(msg.get("title") or ""))
            self.push_threads()
            if int(msg["id"]) == self.thread_id:
                self.push_thread()
        elif kind == "delete":
            chat.delete_thread(self.db, int(msg["id"]))
            if int(msg["id"]) == self.thread_id:
                self.thread_id = None
                self.push_thread()
            self.push_threads()
        elif kind == "search":
            self.push_threads(str(msg.get("q") or ""))
        elif kind == "mark_all_read":
            self.db.execute("UPDATE nudges SET status = 'seen', seen_at = ? WHERE status = 'delivered'", (time.time(),))
            self.push_inbox()
        elif kind == "open_url":
            url = str(msg.get("url") or "")
            if url.startswith(("http://", "https://", "mailto:")):
                winui.open_url(url)
        elif kind == "copy":
            from .deliver import set_clipboard_text
            set_clipboard_text(str(msg.get("text") or ""))
        elif kind == "models":  # the hidden picker opened
            self._call("showModels", chat.model_choices(self.cfg), chat.chat_model(self.cfg, self.db))
        elif kind == "set_model":
            now = chat.pick_model(self.cfg, self.db, str(msg.get("id") or "") or None)
            self._call("modelPicked", next((c["name"] for c in chat.model_choices(self.cfg) if c["id"] == now), now))

    # -------------------------------------------------------------- answering

    def _send(self, text: str) -> None:
        if not text:
            return
        if self.thread_id is None:
            self.thread_id = chat.new_thread(self.db)
        tid = self.thread_id
        if tid in self.running:
            return
        cancel = threading.Event()
        self.running[tid] = cancel
        self._call("started", tid, text)
        self.push_threads()
        llm.prewarm()
        threading.Thread(target=self._answer_bg, args=(tid, text, cancel), name="chat", daemon=True).start()

    def _answer_bg(self, tid: int, text: str, cancel: threading.Event) -> None:
        def on_event(kind, data=None):
            winui.call_after(self._call, "ev", tid, kind, data)
        try:
            out = chat.send(self.cfg, self.db, tid, text, on_event, cancel)
            result = {"ok": True, "text": out["text"], "tools": out["tools"]}
        except llm.Cancelled:
            chat.add_message(self.db, tid, "assistant", "(stopped)")
            result = {"ok": False, "error": "Stopped."}
        except llm.LLMError as e:
            result = {"ok": False, "error": str(e)}
        except Exception as e:
            log.exception("chat reply")
            result = {"ok": False, "error": f"Something went wrong: {e}"}
        winui.call_after(self._finished, tid, result)

    def _finished(self, tid: int, result: dict) -> None:
        self.running.pop(tid, None)
        self._call("finished", tid, result)
        self.push_threads()
        if tid == self.thread_id:
            self.push_thread()


def _html() -> str:
    svg = (overlay.ASSETS / "creature.svg").read_text()
    return (PAGE.replace("/*DONKEY_CSS*/", overlay.DONKEY_CSS).replace("<!--SVG-->", svg))


PAGE = r"""<!doctype html><html><head><meta charset="utf-8">
<meta name="color-scheme" content="light dark">
<style>
:root { --bg:#f7f4ef; --side:#f1ece5; --ink:#24211e; --muted:#7c736a; --line:rgba(36,33,30,.09);
  --me:#8a6e52; --me-ink:#fff; --bubble:#ffffff; --chip:rgba(138,110,82,.10); --chip-ink:#6d5640;
  --hover:rgba(36,33,30,.06); --sel:rgba(138,110,82,.16); --accent:#b0743c; --err:#c0392b; --field:#fff; }
@media (prefers-color-scheme: dark) { :root { --bg:#1a1816; --side:#161412; --ink:#f1ece6; --muted:#a39a90;
  --line:rgba(255,255,255,.08); --me:#9b7b5c; --bubble:#2b2825; --chip:rgba(214,180,140,.12);
  --chip-ink:#dcc3a5; --hover:rgba(255,255,255,.06); --sel:rgba(214,180,140,.16); --field:#2b2825; --err:#ff8a7a; } }
* { box-sizing:border-box; }
html, body { margin:0; height:100%; background:var(--bg); color:var(--ink);
  font:14px/1.45 "Inter", "Segoe UI Variable Text", "Segoe UI", system-ui, sans-serif; overflow:hidden; }
button { font:inherit; color:inherit; background:none; border:0; cursor:default; }
.app { display:flex; height:100%; }
/* sidebar */
.side { width:236px; flex:none; background:var(--side); border-right:1px solid var(--line); display:flex;
  flex-direction:column; padding:12px 10px 10px; -webkit-user-select:none; }
.side.hidden { display:none; }
.side .row { display:flex; gap:6px; margin-bottom:8px; }
.newbtn { flex:1; text-align:left; padding:7px 10px; border-radius:8px; background:var(--chip); color:var(--chip-ink); font-weight:600; }
.newbtn:hover { background:var(--sel); }
.search { width:100%; border:1px solid var(--line); background:var(--field); color:var(--ink); border-radius:8px;
  padding:6px 9px; font:inherit; font-size:13px; outline:none; margin-bottom:10px; }
.lists { overflow-y:auto; flex:1; margin:0 -4px; padding:0 4px; }
.sec { font-size:11px; font-weight:600; text-transform:uppercase; letter-spacing:.06em; color:var(--muted);
  margin:12px 6px 4px; display:flex; justify-content:space-between; align-items:center; }
.sec button { text-transform:none; letter-spacing:0; font-weight:500; color:var(--muted); font-size:11px; }
.sec button:hover { color:var(--ink); }
.item { position:relative; padding:6px 8px; border-radius:8px; margin-bottom:1px; }
.item:hover { background:var(--hover); }
.item.sel { background:var(--sel); }
.item .t { white-space:nowrap; overflow:hidden; text-overflow:ellipsis; font-size:13px; padding-right:34px; }
.item .s { white-space:nowrap; overflow:hidden; text-overflow:ellipsis; font-size:11.5px; color:var(--muted); }
.item.unread .t { font-weight:650; }
.item.unread::before { content:""; position:absolute; left:-1px; top:12px; width:6px; height:6px; border-radius:3px; background:var(--accent); }
.item .acts { position:absolute; right:4px; top:4px; display:none; }
.item:hover .acts { display:flex; }
.item .acts button { width:22px; height:22px; border-radius:6px; color:var(--muted); font-size:12px; }
.item .acts button:hover { background:var(--hover); color:var(--ink); }
.item input { width:100%; font:inherit; font-size:13px; border:1px solid var(--accent); border-radius:6px; padding:2px 5px;
  background:var(--field); color:var(--ink); outline:none; }
.more { font-size:12px; color:var(--muted); padding:4px 8px; }
.more:hover { color:var(--ink); }
/* main */
.main { flex:1; display:flex; flex-direction:column; min-width:0; position:relative; }
.head { height:44px; flex:none; display:flex; align-items:center; gap:8px; padding:0 12px 0 14px; border-bottom:1px solid var(--line);
  -webkit-user-select:none; }
.head .title { flex:1; font-weight:600; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.icon { width:28px; height:28px; border-radius:7px; color:var(--muted); display:flex; align-items:center; justify-content:center; }
.icon:hover { background:var(--hover); color:var(--ink); }
.icon.on { color:var(--accent); }
.icon svg { width:16px; height:16px; }
#critter { width:30px; height:28px; flex:none; }
#models { position:absolute; top:44px; left:50%; transform:translateX(-50%); z-index:20; min-width:340px; padding:6px;
  background:var(--field); border:1px solid var(--line); border-radius:12px; box-shadow:0 12px 32px rgba(0,0,0,.18); }
#models.hidden { display:none; }
#models .cap { font-size:11px; color:var(--muted); padding:4px 8px 6px; }
#models button { display:flex; width:100%; gap:8px; align-items:baseline; padding:6px 8px; border-radius:8px; text-align:left; color:var(--ink); }
#models button:hover { background:var(--hover); }
#models button .n { font-weight:600; white-space:nowrap; } #models button .d { color:var(--muted); font-size:12px; flex:1; white-space:nowrap; text-align:right; }
#models button .ck { width:12px; color:var(--accent); }
.toast { position:absolute; top:52px; left:50%; transform:translateX(-50%); z-index:21; font-size:12px; padding:5px 10px; border-radius:999px;
  background:var(--ink); color:var(--field); opacity:0; transition:opacity .2s; pointer-events:none; }
.toast.on { opacity:.92; }
#critter svg { width:100%; height:100%; overflow:visible; }
/*DONKEY_CSS*/
.msgs { flex:1; overflow-y:auto; padding:18px 18px 8px; -webkit-user-select:text; }
.empty { height:100%; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:10px; color:var(--muted);
  text-align:center; -webkit-user-select:none; }
.empty .big { width:84px; height:80px; }
.empty .big svg { width:100%; height:100%; overflow:visible; }
.empty h2 { margin:4px 0 0; font-size:17px; color:var(--ink); font-weight:650; }
.sugs { display:flex; flex-wrap:wrap; gap:6px; justify-content:center; max-width:460px; margin-top:6px; }
.sug { padding:6px 11px; border-radius:14px; background:var(--chip); color:var(--chip-ink); font-size:13px; }
.sug:hover { background:var(--sel); }
.turn { display:flex; flex-direction:column; margin-bottom:12px; }
.turn.user { align-items:flex-end; }
.turn.assistant { align-items:flex-start; }
.bubble { max-width:min(78%, 620px); padding:8px 12px; border-radius:16px; margin-top:4px; word-wrap:break-word; position:relative; }
.user .bubble { background:var(--me); color:var(--me-ink); border-bottom-right-radius:5px; white-space:pre-wrap; }
.assistant .bubble { background:var(--bubble); border:1px solid var(--line); border-bottom-left-radius:5px; }
.bubble p { margin:0 0 6px; } .bubble p:last-child { margin-bottom:0; }
.bubble ul, .bubble ol { margin:4px 0 6px; padding-left:20px; } .bubble li { margin:2px 0; }
.bubble code { font:12.5px ui-monospace, SFMono-Regular, Menlo, monospace; background:var(--hover); padding:1px 4px; border-radius:4px; }
.bubble pre { background:var(--hover); padding:8px; border-radius:8px; overflow-x:auto; margin:4px 0; }
.bubble pre code { background:none; padding:0; }
.bubble blockquote { margin:4px 0; padding-left:9px; border-left:3px solid var(--line); color:var(--muted); }
.bubble a { color:var(--accent); text-decoration:none; } .bubble a:hover { text-decoration:underline; }
.bubble h3, .bubble h4 { margin:6px 0 4px; font-size:14px; }
.copy { position:absolute; right:-30px; bottom:2px; width:24px; height:24px; border-radius:6px; color:var(--muted);
  display:none; font-size:12px; }
.user .copy { right:auto; left:-30px; }
.bubble:hover .copy { display:block; }
.copy:hover { background:var(--hover); color:var(--ink); }
.tools { display:flex; flex-wrap:wrap; gap:4px; margin:2px 0 2px; max-width:80%; }
.chip { font-size:11.5px; padding:2px 8px; border-radius:10px; background:var(--chip); color:var(--chip-ink); white-space:nowrap;
  overflow:hidden; text-overflow:ellipsis; max-width:280px; }
.chip.run::after { content:"…"; }
.chip.bad { color:var(--err); }
.err { color:var(--err); font-size:13px; margin-top:4px; }
.when { font-size:11px; color:var(--muted); margin-top:3px; }
.typing { display:inline-flex; gap:3px; padding:12px 14px; }
.typing i { width:6px; height:6px; border-radius:3px; background:var(--muted); animation:dot 1.2s infinite ease-in-out; }
.typing i:nth-child(2) { animation-delay:.15s } .typing i:nth-child(3) { animation-delay:.3s }
@keyframes dot { 0%,80%,100% { opacity:.25; transform:translateY(0) } 40% { opacity:1; transform:translateY(-2px) } }
.compose { flex:none; padding:10px 14px 14px; width:100%; max-width:820px; margin:0 auto; }
.turn { width:100%; max-width:780px; margin-left:auto; margin-right:auto; }  /* a readable column in a wide window */
.box { display:flex; align-items:flex-end; gap:8px; border:1px solid var(--line); background:var(--field); border-radius:14px; padding:6px 6px 6px 12px; }
.box:focus-within { border-color:rgba(176,116,60,.55); }
textarea { flex:1; resize:none; border:0; outline:none; background:transparent; color:var(--ink); font:inherit; font-size:14.5px;
  line-height:1.4; max-height:180px; padding:5px 0; }
textarea::placeholder { color:var(--muted); }
.send { width:30px; height:30px; border-radius:9px; background:var(--me); color:#fff; display:flex; align-items:center; justify-content:center; flex:none; }
.send:disabled { opacity:.35; }
.send svg { width:15px; height:15px; }
.hint { font-size:11px; color:var(--muted); margin:5px 4px 0; }
</style></head><body>
<div class="app" id="app">
  <div class="side" id="side">
    <div class="row"><button class="newbtn" id="newbtn">＋ New chat</button></div>
    <input class="search" id="search" placeholder="Search chats" spellcheck="false">
    <div class="lists">
      <div class="sec"><span>Inbox <span id="unread"></span></span><button id="readall">Mark all read</button></div>
      <div id="inbox"></div>
      <div id="threads"></div>
    </div>
  </div>
  <div class="main">
    <div class="head">
      <button class="icon" id="sidebtn" title="Chats and inbox"><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4"><rect x="1.5" y="2.5" width="13" height="11" rx="2"/><path d="M6 2.5v11"/></svg></button>
      <div id="critter"><!--SVG--></div>
      <div class="title" id="title">Donkey</div>
    </div>
    <div id="models" class="hidden"></div><div class="toast" id="toast"></div>
    <div class="msgs" id="msgs"></div>
    <div class="compose">
      <div class="box"><textarea id="ta" rows="1" placeholder="Ask Donkey about anything you've seen or done…"></textarea>
        <button class="send" id="sendbtn" title="Send"><svg viewBox="0 0 16 16" fill="currentColor"><path d="M8 2.2 13.3 7.5l-1 1L8.7 4.9V14H7.3V4.9L3.7 8.5l-1-1z"/></svg></button></div>
      <div class="hint" id="hint">Enter to send · Shift+Enter for a new line · Esc to stop</div>
    </div>
  </div>
</div>
<script>
const $ = id => document.getElementById(id);
// a frame in the Donkey window: messages go through it (journal.html passes them on to Python)
const post = m => parent.postMessage({ donkeyChat: m }, '*');
const S = { threads:[], inbox:[], tid:null, title:'', msgs:[], working:false, live:null, showAllInbox:false };
const SUGS = ["What was I doing an hour ago?", "What do I owe people right now?", "Summarize my day",
              "Remind me tomorrow at 10am to…"];
const TOOL_LABEL = {
  search_memory: a => `Searched “${a.query || ''}”`, get_snapshots: a => `Opened ${(a.ids||[]).length || ''} screen${(a.ids||[]).length === 1 ? '' : 's'}`,
  get_recent_activity: a => 'Checked the last ' + (a.minutes || 30) + ' min', get_working_memory: a => 'Read the last ' + (a.hours || 4) + ' hours',
  get_chronicle: a => `Read the ${a.period || 'day'} summary${a.date ? ' for ' + a.date : ''}`, get_daily_summary: a => 'Read the day page',
  search_wiki: a => `Looked up “${a.query || ''}”`, get_wiki_page: a => `Opened “${a.name || ''}”`, list_wiki: () => 'Listed wiki pages',
  get_sent_messages: () => 'Checked sent messages', get_open_loops: () => 'Checked open loops', get_todos: () => 'Checked to-dos',
  get_upcoming_meetings: () => 'Checked meetings', get_nudge_history: () => 'Checked my earlier messages', get_time_report: () => 'Checked time spent',
  get_documents: a => `Opened ${(a.ids||[]).length || ''} imported doc${(a.ids||[]).length === 1 ? '' : 's'}`, get_signals: () => 'Checked signals',
  get_memory_digest: () => 'Read the digest', create_reminder: a => `Set a reminder${a.at ? ' · ' + a.at : ''}`, list_reminders: () => 'Listed reminders',
  delete_reminder: () => 'Deleted a reminder', add_todo: () => 'Added a to-do', complete_todo: () => 'Ticked a to-do',
  pause_capture: () => 'Paused capture', resume_capture: () => 'Resumed capture', remember_style_rule: () => 'Saved a writing rule',
  ignore_site_or_app: () => 'Ignore preview', get_capture_status: () => 'Checked capture',
};
function label(name, args) { let a = {}; try { a = JSON.parse(args || '{}'); } catch (e) {}
  const f = TOOL_LABEL[name]; return f ? f(a) : name.replace(/_/g, ' '); }
function esc(s) { return String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c])); }
function inline(s) {
  s = esc(s);
  s = s.replace(/`([^`]+)`/g, '<code>$1</code>');
  s = s.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  s = s.replace(/(^|[^*\w])\*([^*\n]+)\*(?!\w)/g, '$1<em>$2</em>');
  s = s.replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, '<a href="$2">$1</a>');
  s = s.replace(/(^|[\s(])(https?:\/\/[^\s<)]+)/g, '$1<a href="$2">$2</a>');
  return s;
}
function md(text) {
  const lines = text.replace(/\r/g, '').split('\n'); let html = '', list = null, para = [], code = null;
  const flush = () => { if (para.length) { html += '<p>' + para.map(inline).join('<br>') + '</p>'; para = []; } };
  const close = () => { if (list) { html += `</${list}>`; list = null; } };
  for (const line of lines) {
    if (code !== null) { if (/^```/.test(line)) { html += '<pre><code>' + esc(code.join('\n')) + '</code></pre>'; code = null; } else code.push(line); continue; }
    if (/^```/.test(line)) { flush(); close(); code = []; continue; }
    let m;
    if ((m = line.match(/^\s*[-*•]\s+(.*)/))) { flush(); if (list !== 'ul') { close(); html += '<ul>'; list = 'ul'; } html += '<li>' + inline(m[1]) + '</li>'; continue; }
    if ((m = line.match(/^\s*\d+[.)]\s+(.*)/))) { flush(); if (list !== 'ol') { close(); html += '<ol>'; list = 'ol'; } html += '<li>' + inline(m[1]) + '</li>'; continue; }
    if ((m = line.match(/^#{1,4}\s+(.*)/))) { flush(); close(); html += '<h4>' + inline(m[1]) + '</h4>'; continue; }
    if ((m = line.match(/^>\s?(.*)/))) { flush(); close(); html += '<blockquote>' + inline(m[1]) + '</blockquote>'; continue; }
    if (!line.trim()) { flush(); close(); continue; }
    close(); para.push(line);
  }
  if (code !== null) html += '<pre><code>' + esc(code.join('\n')) + '</code></pre>';
  flush(); close(); return html;
}
function bubbles(text) { return text.split('|||').map(s => s.trim()).filter(Boolean); }
function ago(t) { const d = (Date.now() / 1000 - t); if (d < 60) return 'now'; if (d < 3600) return Math.floor(d / 60) + 'm';
  if (d < 86400) return Math.floor(d / 3600) + 'h'; const dt = new Date(t * 1000);
  return dt.toLocaleDateString(undefined, { day:'numeric', month:'short' }); }
function clock(t) { return new Date(t * 1000).toLocaleString(undefined, { weekday:'short', hour:'2-digit', minute:'2-digit' }); }
function group(t) { const d = new Date(t * 1000), n = new Date(); const day = x => new Date(x.getFullYear(), x.getMonth(), x.getDate());
  const diff = (day(n) - day(d)) / 86400000; return diff < 1 ? 'Today' : diff < 2 ? 'Yesterday' : diff < 7 ? 'Previous 7 days' : 'Older'; }

function renderSide() {
  const unread = S.inbox.filter(n => n.unread).length;
  $('unread').textContent = unread ? `(${unread})` : '';
  $('readall').style.display = unread ? '' : 'none';
  const shown = S.showAllInbox ? S.inbox : S.inbox.slice(0, 4);
  let h = shown.map(n => `<div class="item${n.unread ? ' unread' : ''}" data-nudge="${n.id}"><div class="t">${esc(n.title)}</div>
    <div class="s">${esc(ago(n.at))} · ${esc(n.body)}</div></div>`).join('');
  if (!S.inbox.length) h = '<div class="more">Nothing yet. Briefs and reminders land here.</div>';
  else if (S.inbox.length > 4) h += `<button class="more" id="moreinbox">${S.showAllInbox ? 'Show less' : 'Show all ' + S.inbox.length}</button>`;
  $('inbox').innerHTML = h;
  let t = '', last = null;
  for (const th of S.threads.filter(x => !x.inbox)) {
    const g = group(th.updated); if (g !== last) { t += `<div class="sec"><span>${g}</span></div>`; last = g; }
    t += `<div class="item${th.id === S.tid ? ' sel' : ''}" data-thread="${th.id}"><div class="t">${esc(th.title)}</div>
      <div class="acts"><button data-rename="${th.id}" title="Rename">✎</button><button data-del="${th.id}" title="Delete">✕</button></div></div>`;
  }
  if (!t && $('search').value.trim()) t = '<div class="more">No chats match.</div>';
  $('threads').innerHTML = t;
}
function toolChips(tools) { if (!tools || !tools.length) return '';
  return '<div class="tools">' + tools.map(t => `<span class="chip${t.ok === false ? ' bad' : ''}${t.run ? ' run' : ''}">${esc(label(t.name, t.arguments))}</span>`).join('') + '</div>'; }
function renderMsgs() {
  const box = $('msgs');
  if (!S.msgs.length && !S.live) {
    box.innerHTML = `<div class="empty"><div class="big">${$('critter').innerHTML}</div><h2>Ask me anything you've seen or done</h2>
      <div>I remember your screen. Ask about people, chats, pages, your day, or set a reminder.</div>
      <div class="sugs">${SUGS.map(s => `<button class="sug">${esc(s)}</button>`).join('')}</div></div>`;
    return;
  }
  let h = '';
  for (const m of S.msgs) {
    if (m.role === 'user') h += `<div class="turn user"><div class="bubble">${esc(m.content)}<button class="copy" data-copy="${esc(m.content)}">⧉</button></div></div>`;
    else h += `<div class="turn assistant">${toolChips(m.tools)}${bubbles(m.content).map(b => `<div class="bubble">${md(b)}<button class="copy" data-copy="${esc(b)}">⧉</button></div>`).join('')}
      <div class="when">${esc(clock(m.at))}</div></div>`;
  }
  if (S.live) {
    const L = S.live;
    h += `<div class="turn assistant">${toolChips(L.tools)}` +
      (L.text.trim() ? bubbles(L.text).map(b => `<div class="bubble">${md(b)}</div>`).join('') : (L.error ? '' : '<div class="bubble typing"><i></i><i></i><i></i></div>')) +
      (L.error ? `<div class="err">${esc(L.error)}</div>` : '') + '</div>';
  }
  const atBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 80;
  box.innerHTML = h;
  if (atBottom || S.stick) box.scrollTop = box.scrollHeight;
}
function renderHead() { $('title').textContent = S.tid ? (S.title || 'New chat') : 'Donkey'; document.body.className = S.working ? 'working' : '';
  $('sendbtn').disabled = !S.working && !$('ta').value.trim();
  $('sendbtn').innerHTML = S.working ? '<svg viewBox="0 0 16 16" fill="currentColor"><rect x="4" y="4" width="8" height="8" rx="1.5"/></svg>'
    : '<svg viewBox="0 0 16 16" fill="currentColor"><path d="M8 2.2 13.3 7.5l-1 1L8.7 4.9V14H7.3V4.9L3.7 8.5l-1-1z"/></svg>'; }
function grow() { const ta = $('ta'); ta.style.height = 'auto'; ta.style.height = Math.min(ta.scrollHeight, 180) + 'px'; renderHead(); }

window.dk = {
  focus() { setTimeout(() => $('ta').focus(), 50); },
  setThreads(list, tid) { S.threads = list; if (tid !== undefined) S.tid = tid; renderSide(); },
  setInbox(list) { S.inbox = list; renderSide(); },
  setThread(tid, title, msgs, working) { const changed = tid !== S.tid; S.tid = tid; S.title = title; S.msgs = msgs; S.working = working;
    if (!working) S.live = null; else if (!S.live || S.live.tid !== tid) S.live = { tid, text:'', tools:[] };
    S.stick = changed || true; renderSide(); renderMsgs(); renderHead(); S.stick = false; },
  started(tid, text) { S.tid = tid; S.msgs.push({ role:'user', content:text, at:Date.now() / 1000 }); S.live = { tid, text:'', tools:[] };
    S.working = true; S.stick = true; renderMsgs(); renderHead(); S.stick = false; },
  ev(tid, kind, data) { if (!S.live || S.live.tid !== tid || tid !== S.tid) return; const L = S.live;
    if (kind === 'token') L.text += data;
    else if (kind === 'reset') L.text = '';
    else if (kind === 'tool_start') L.tools.push({ id:data.id, name:data.name, arguments:data.arguments, run:true });
    else if (kind === 'tool_end') { const t = L.tools.find(x => x.id === data.id); if (t) { t.run = false; t.ok = data.ok; } }
    renderMsgs(); },
  finished(tid, r) { if (tid !== S.tid) return; S.working = false;
    if (!r.ok && S.live) { S.live.error = r.error; S.live.text = ''; renderMsgs(); } else S.live = null;
    renderHead(); document.body.className = r.ok ? 'done' : 'error'; setTimeout(() => { if (!S.working) document.body.className = ''; }, 1400); },
};
function send() { const ta = $('ta'), text = ta.value.trim(); if (!text || S.working) return;
  if (/^\/models?$/i.test(text)) { ta.value = ''; grow(); post({ type:'models' }); return; }
  ta.value = ''; grow(); post({ type:'send', text }); }
// The model picker stays out of sight: Alt-click the donkey up top, or type /model.
dk.showModels = (list, current) => { const m = $('models');
  m.innerHTML = '<div class="cap">Chat answers with</div>' + list.map(c => `<button data-model="${esc(c.id)}"><span class="ck">${c.id === current ? '✓' : ''}</span>`
    + `<span class="n">${esc(c.name)}</span><span class="d">${esc(c.note)}${c.default ? ' · default' : ''}</span></button>`).join('');
  m.classList.remove('hidden'); };
dk.modelPicked = name => { $('models').classList.add('hidden'); const t = $('toast'); t.textContent = `Answering with ${name}`;
  t.classList.add('on'); setTimeout(() => t.classList.remove('on'), 1600); dk.focus(); };
$('critter').addEventListener('click', ev => { if (ev.altKey) { ev.stopPropagation(); post({ type:'models' }); } });
document.addEventListener('keydown', ev => {
  if (ev.key === 'Escape') $('models').classList.add('hidden');
  if ((ev.ctrlKey || ev.metaKey) && /^[1-4,]$/.test(ev.key)) { ev.preventDefault(); post({ type:'nav', key:ev.key }); }  // the window's tab keys
}, true);
$('ta').addEventListener('input', grow);
$('ta').addEventListener('keydown', ev => {
  if (ev.key === 'Enter' && !ev.shiftKey && !ev.isComposing) { ev.preventDefault(); send(); }
  else if (ev.key === 'Escape' && S.working) { ev.preventDefault(); post({ type:'cancel' }); }
});
$('sendbtn').onclick = () => S.working ? post({ type:'cancel' }) : send();
$('newbtn').onclick = () => { post({ type:'new_thread' }); dk.focus(); };
$('readall').onclick = () => post({ type:'mark_all_read' });
$('sidebtn').onclick = () => { $('side').classList.toggle('hidden'); $('app').classList.toggle('noside', $('side').classList.contains('hidden')); };
let st; $('search').addEventListener('input', () => { clearTimeout(st); st = setTimeout(() => post({ type:'search', q:$('search').value }), 150); });
document.addEventListener('click', ev => {
  const pm = ev.target.closest('[data-model]'); if (pm) { post({ type:'set_model', id:pm.dataset.model }); return; }
  if (!ev.target.closest('#models')) $('models').classList.add('hidden');
  const a = ev.target.closest('a'); if (a) { ev.preventDefault(); post({ type:'open_url', url:a.getAttribute('href') }); return; }
  const c = ev.target.closest('[data-copy]'); if (c) { post({ type:'copy', text:c.dataset.copy }); c.textContent = '✓'; setTimeout(() => c.textContent = '⧉', 900); return; }
  const r = ev.target.closest('[data-rename]'); if (r) { ev.stopPropagation(); rename(+r.dataset.rename); return; }
  const d = ev.target.closest('[data-del]'); if (d) { ev.stopPropagation(); post({ type:'delete', id:+d.dataset.del }); return; }
  if (ev.target.id === 'moreinbox') { S.showAllInbox = !S.showAllInbox; renderSide(); return; }
  const n = ev.target.closest('[data-nudge]'); if (n) { post({ type:'open_nudge', id:+n.dataset.nudge }); return; }
  const t = ev.target.closest('[data-thread]'); if (t && !t.querySelector('input')) { post({ type:'open_thread', id:+t.dataset.thread }); return; }
  const s = ev.target.closest('.sug'); if (s) { const ta = $('ta'); ta.value = s.textContent.replace('…', ' '); grow(); ta.focus();
    if (!s.textContent.endsWith('…')) send(); }
});
document.addEventListener('contextmenu', ev => { const t = ev.target.closest('[data-thread]'); if (t) { ev.preventDefault(); rename(+t.dataset.thread); } });
function rename(id) {
  const el = document.querySelector(`[data-thread="${id}"] .t`); if (!el) return;
  const old = el.textContent; el.innerHTML = `<input value="${esc(old)}">`; const inp = el.querySelector('input'); inp.focus(); inp.select();
  let done = false; const finish = save => { if (done) return; done = true; const v = inp.value.trim();
    if (save && v && v !== old) post({ type:'rename', id, title:v }); else el.textContent = old; };
  inp.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); finish(true); } else if (e.key === 'Escape') { e.preventDefault(); finish(false); } e.stopPropagation(); });
  inp.addEventListener('blur', () => finish(true));
}
renderMsgs(); renderHead();
post({ type:'ready' });
</script></body></html>"""
