"""Memory map: an interactive graph of what Donkey knows, as one self-contained HTML page.

It lives in the Donkey window as the Memory tab (journal.py asks build() for a fresh copy when the
tab opens and when the page reloads itself); `donkey map` still writes it to a file to open alone.

Two views: "People & projects" (wiki pages, linked by [[links]] and by appearing in the same
hour) and "Apps & sites" (where foreground time went, apps linked to the sites used in them).
No external scripts: the page (assets/memory_map.html) runs its own small force layout and animation.
"""
import json
import logging
import os
import time
from collections import Counter
from pathlib import Path

from . import wiki
from .config import HOME
from .db import DB

MAP_PATH = HOME / "memory-map.html"
TEMPLATE_PATH = Path(__file__).parent / "assets" / "memory_map.html"
log = logging.getLogger("donkey.map")


SIM_K = 3             # semantic neighbours per page
SIM_Z = 1.0           # a "related by meaning" edge needs similarity this many std-devs above the mean
RELATED_N = 6


def _semantic(db: DB, slugs_by_id: dict[int, str]):
    """Embedding-based layout and neighbours: a 2D projection of
    each page's vector (similar pages land near each other) and nearest-neighbour edges."""
    try:
        import numpy as np

        from . import embed
        embed.sync(db)
        ids, m = embed.vectors(db, "wiki")
    except Exception:
        log.exception("semantic layout unavailable")
        return {}, [], {}
    keep = [k for k, i in enumerate(ids) if i in slugs_by_id]
    if len(keep) < 3:
        return {}, [], {}
    slugs = [slugs_by_id[ids[k]] for k in keep]
    m = m[keep]
    centred = m - m.mean(axis=0)
    _, _, vt = np.linalg.svd(centred, full_matrices=False)
    xy = centred @ vt[:2].T
    xy /= max(1e-6, float(np.abs(xy).max()))
    pos = {slug: [round(float(x), 4), round(float(y), 4)] for slug, (x, y) in zip(slugs, xy)}
    sims = m @ m.T
    floor = embed.relative_floor(sims, SIM_Z)  # per-model: models spread their scores differently
    np.fill_diagonal(sims, -1)
    top = {i: [int(j) for j in np.argsort(-sims[i])[:SIM_K] if sims[i, j] >= floor] for i in range(len(slugs))}
    pairs = {}
    for i, js in top.items():
        for j in js:
            a, b = sorted((i, j))
            pairs[(a, b)] = (float(sims[a, b]), j in top and i in top[j] and j in top[i])
    sim_edges = [{"a": slugs[a], "b": slugs[b], "w": round(w, 3), "mutual": mutual} for (a, b), (w, mutual) in pairs.items()]
    related = {slugs[i]: [(slugs[int(j)], round(float(sims[i, j]), 3)) for j in np.argsort(-sims[i])[:RELATED_N + 4]
                          if sims[i, j] >= floor] for i in range(len(slugs))}
    return pos, sim_edges, related


def _wiki_graph(db: DB) -> dict:
    pages = db.query("SELECT id, slug, title, page_type, tie, sphere, salience, summary, body, body_claims, aliases, "
                     "links, mention_count, last_seen FROM wiki_pages ORDER BY salience DESC, mention_count DESC LIMIT 500")
    slugs = {p["slug"] for p in pages}
    links = {p["slug"]: {s for s in json.loads(p["links"]) if s in slugs and s != p["slug"]} for p in pages}
    labels = {}  # what connects two pages, in a few words (the tidy pass)
    for r in db.query("SELECT a, b, label FROM wiki_relations"):
        labels.setdefault(tuple(sorted((r["a"], r["b"]))), (r["a"], r["label"]))
    together = wiki.together_counts(db)
    # Solid edges: links a claim states, or that the hourly pass or the tidy pass made; "mutual" when
    # both pages link each other. Heavier the more hours the two came up together.
    edges, done = [], set()
    for a, targets in links.items():
        for b in targets:
            key = tuple(sorted((a, b)))
            if key in done:
                continue
            done.add(key)
            mutual = a in links.get(b, set())
            src, label = labels.get(key, (None, ""))
            edges.append({"a": key[0], "b": key[1], "w": 2 if mutual else 1, "mutual": mutual,
                          "n": together.get(key, 0), "label": label, "from": src})
    pos, sim_edges, related = _semantic(db, {p["id"]: p["slug"] for p in pages})
    sim_edges = [e for e in sim_edges if tuple(sorted((e["a"], e["b"]))) not in done]
    titles = {p["slug"]: p["title"] for p in pages}
    nodes = []
    for p in pages:
        rel = [{"id": s, "label": titles[s], "sim": w} for s, w in related.get(p["slug"], [])
               if s in titles and s not in links[p["slug"]]][:RELATED_N]
        nodes.append({"id": p["slug"], "label": p["title"], "group": p["page_type"], "tie": p["tie"], "sphere": p["sphere"],
                      "weight": max(1.0, p["salience"] * 1.5 if p["salience"] else p["mention_count"]),
                      "mentions": p["mention_count"],
                      "summary": p["summary"], "claims": json.loads(p["body_claims"] or "[]"),
                      "body": "" if p["body_claims"] not in (None, "", "[]") else p["body"][:3000],
                      "aliases": json.loads(p["aliases"]), "pos": pos.get(p["slug"]), "related": rel,
                      "when": time.strftime("%Y-%m-%d %H:%M", time.localtime(p["last_seen"])) if p["last_seen"] else "",
                      "seen_at": p["last_seen"] or 0})
    return {"nodes": nodes, "edges": edges, "sim_edges": sim_edges}


def _activity_graph(db: DB, days: int = 7) -> dict:
    since = time.strftime("%Y-%m-%dT%H", time.localtime(time.time() - days * 86400))
    rows = db.query("SELECT app, domain, SUM(seconds) AS s, MAX(hour_key) AS last FROM time_ledger WHERE hour_key >= ? "
                    "GROUP BY app, domain ORDER BY s DESC LIMIT 300", (since,))
    apps: Counter = Counter()
    sites: Counter = Counter()
    last: dict[str, float] = {}  # when each app or site was last used: the map makes those pulse
    edges = []
    for r in rows:
        at = time.mktime(time.strptime(r["last"], "%Y-%m-%dT%H")) + 3599 if r["last"] else 0
        for key in ("app:" + r["app"], "site:" + r["domain"] if r["domain"] else None):
            if key:
                last[key] = max(last.get(key, 0), at)
        apps[r["app"]] += r["s"]
        if r["domain"]:
            sites[r["domain"]] += r["s"]
            edges.append({"a": "app:" + r["app"], "b": "site:" + r["domain"], "w": max(1, r["s"] / 300)})
    fmt = lambda s: f"{s / 3600:.1f} h" if s >= 3600 else f"{s / 60:.0f} min"
    nodes = [{"id": "app:" + a, "label": a, "group": "app", "weight": max(1, s / 120),
              "summary": f"{fmt(s)} in the last {days} days", "body": "", "aliases": [], "when": "",
              "seen_at": min(last.get("app:" + a, 0), time.time())}
             for a, s in apps.most_common(60)]
    nodes += [{"id": "site:" + d, "label": d, "group": "site", "weight": max(1, s / 120),
               "summary": f"{fmt(s)} in the last {days} days", "body": "", "aliases": [], "when": "",
               "seen_at": min(last.get("site:" + d, 0), time.time())}
              for d, s in sites.most_common(120)]
    ids = {n["id"] for n in nodes}
    return {"nodes": nodes, "edges": [e for e in edges if e["a"] in ids and e["b"] in ids]}


def build(db: DB) -> str:
    data = {"wiki": _wiki_graph(db), "activity": _activity_graph(db),
            "generated": time.strftime("%Y-%m-%d %H:%M"), "generated_at": time.time()}
    return TEMPLATE_PATH.read_text().replace("/*DATA*/", json.dumps(data).replace("</", "<\\/"))


def write(db: DB) -> None:
    """Replace the map file in one step, so a page reloading mid-write never reads half of it."""
    tmp = MAP_PATH.with_suffix(".tmp")
    tmp.write_text(build(db))
    tmp.replace(MAP_PATH)


def open_map(db: DB | None = None) -> str:
    """`donkey map`: the map as a file in the browser (the app shows it in its own window)."""
    write(db or DB())
    os.startfile(str(MAP_PATH))
    return str(MAP_PATH)
