"""Deleting history when an ignore rule is added.

Capture skips blocked apps and sites from the moment a rule exists, but what was stored before
stays. Each memory pass (and `donkey ignore add`) compares the current rules with the ones
already applied; for each new rule it deletes the matching history:
  - screens, and mail/calendar items read from them;
  - rewrites and sends typed there, with their saved eval cases;
  - foreground time on that app or site;
  - the hour summaries, signals and wiki evidence of every hour those screens were in, and the
    day and week summaries above them. Those hours are summarized again from what's left.
Learned page chrome for that surface goes too, and the digest is rebuilt.
"""
import json
import logging
import time

from . import chronicle, claims, config
from .config import Config
from .db import DB
from .evals import CASES_DIR
from .filters import BLOCKLIST_PATH, Rules, blocked_reason

log = logging.getLogger("donkey.forget")

APPLIED_KEY = "ignore_rules_applied"
REDO_HOURS_KEY = "redo_hours"   # hours whose summary was dropped and must be redone, even past the backfill window
REDO_DAYS_KEY = "redo_days"


def rule_lines(cfg: Config) -> set[str]:
    """Every ignore rule in force, one normalized line each (the built-in list plus the user's)."""
    lines = set()
    for line in BLOCKLIST_PATH.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            lines.add(_norm(line))
    lines |= {f"app:{a.strip().lower()}" for a in cfg.blocked_apps if a.strip()}
    lines |= {_norm(d) for d in cfg.blocked_domains if d.strip()}
    return lines


def _norm(line: str) -> str:
    kind, sep, value = line.strip().partition(":")
    if sep and kind.strip() in ("app", "url", "path", "title"):
        return f"{kind.strip()}:{value.strip().lower()}"
    return line.strip().lower().removeprefix("www.")


def _rules(lines) -> Rules:
    rules = Rules()
    for line in lines:
        rules.add(line)
    return rules


def _url(domain: str | None) -> str | None:
    return f"https://{domain}/" if domain else None


def _state_set(db: DB, key: str) -> set[str]:
    try:
        return set(json.loads(db.get_state(key) or "[]"))
    except ValueError:
        return set()


def _hours(start: float, end: float) -> set[str]:
    keys, t = set(), start
    while t <= end:
        keys.add(chronicle.hour_key(t))
        t = chronicle.hour_bounds(chronicle.hour_key(t))[1]
    return keys


def forget_matching(db: DB, rules: Rules, dry_run: bool = False) -> dict:
    """Delete everything stored that these rules match. Returns counts per kind (with dry_run, only
    counts what would go, plus a few example window titles)."""
    done = {"screens": 0, "rewrites": 0, "sends": 0, "time_rows": 0, "hours": 0, "pages": 0}
    hit = lambda app, url, title: blocked_reason(rules, app or "", url, title or "")  # noqa: E731

    snaps = [r for r in db.query("SELECT id, app, url, window_title, captured_at, last_seen_at FROM snapshots")
             if hit(r["app"], r["url"], r["window_title"])]
    rw = [r for r in db.query("SELECT id, ts, app, domain, window_title FROM rewrites")
          if hit(r["app"], _url(r["domain"]), r["window_title"])]
    sn = [r for r in db.query("SELECT id, ts, app, domain, window_title FROM sends")
          if hit(r["app"], _url(r["domain"]), r["window_title"])]
    ids = [r["id"] for r in snaps]
    hours = set().union(*(_hours(r["captured_at"], r["last_seen_at"]) for r in snaps)) if snaps else set()
    hours |= {chronicle.hour_key(r["ts"]) for r in rw + sn}  # the hour input quotes rewrites and sends too
    # Everything derived from those hours is dropped and redone from what's left.
    hours &= {r["period_key"] for r in db.query("SELECT period_key FROM chronicle WHERE period = 'hour'")} | \
        {r["hour_key"] for r in db.query("SELECT DISTINCT hour_key FROM wiki_mentions")} | \
        {r["hour_key"] for r in db.query("SELECT DISTINCT hour_key FROM flags")}
    if dry_run:
        titles = list(dict.fromkeys(f"{r['app']}: {r['window_title']}" for r in snaps))
        time_rows = sum(1 for r in db.query("SELECT app, domain FROM time_ledger") if hit(r["app"], _url(r["domain"] or None), ""))
        mentions = {}
        for r in db.query("SELECT slug, hour_key FROM wiki_mentions"):
            mentions.setdefault(r["slug"], set()).add(r["hour_key"])
        pinned = {r["slug"] for r in db.query("SELECT slug FROM wiki_pages WHERE pinned = 1")}
        pages = sum(1 for slug, hs in mentions.items() if hs & hours and hs <= hours and slug not in pinned)
        return {"screens": len(snaps), "rewrites": len(rw), "sends": len(sn), "time_rows": time_rows,
                "hours": len(hours), "pages": pages, "examples": titles[:5]}
    for i in range(0, len(ids), 500):
        chunk = ids[i:i + 500]
        marks = ",".join("?" * len(chunk))
        db.execute(f"DELETE FROM snapshots WHERE id IN ({marks})", chunk)
        db.execute(f"DELETE FROM attention_queue WHERE snapshot_id IN ({marks})", chunk)
        db.execute(f"DELETE FROM attention_items WHERE source_snapshot_id IN ({marks})", chunk)
    done["screens"] = len(ids)

    for r in rw:
        db.execute("DELETE FROM rewrites WHERE id = ?", (r["id"],))
        (CASES_DIR / f"{r['id']}.json").unlink(missing_ok=True)
    done["rewrites"] = len(rw)

    for r in sn:
        db.execute("DELETE FROM sends WHERE id = ?", (r["id"],))
    done["sends"] = len(sn)

    for r in db.query("SELECT hour_key, app, domain, title FROM time_titles"):
        if hit(r["app"], _url(r["domain"] or None), r["title"]):
            db.execute("DELETE FROM time_titles WHERE hour_key = ? AND app = ? AND domain = ? AND title = ?",
                       (r["hour_key"], r["app"], r["domain"], r["title"]))
    for r in db.query("SELECT hour_key, app, domain FROM time_ledger"):
        if hit(r["app"], _url(r["domain"] or None), ""):
            db.execute("DELETE FROM time_ledger WHERE hour_key = ? AND app = ? AND domain = ?",
                       (r["hour_key"], r["app"], r["domain"]))
            done["time_rows"] += 1

    for r in db.query("SELECT DISTINCT surface FROM boilerplate"):
        s = r["surface"]
        if hit(s[4:], None, "") if s.startswith("app:") else hit("", _url(s), ""):
            db.execute("DELETE FROM boilerplate WHERE surface = ?", (s,))
            db.execute("DELETE FROM boilerplate_fit WHERE surface = ?", (s,))

    slugs = set()
    for key in hours:
        slugs |= {r["slug"] for r in db.query("SELECT slug FROM wiki_mentions WHERE hour_key = ?", (key,))}
        db.execute("DELETE FROM wiki_mentions WHERE hour_key = ?", (key,))
        db.execute("DELETE FROM flags WHERE hour_key = ?", (key,))
        db.execute("DELETE FROM chronicle WHERE period = 'hour' AND period_key = ?", (key,))
    claims.forget_hours(db, set(hours))
    days = {k[:10] for k in hours}
    for day in days:
        chronicle.drop_parents(db, day)
        db.execute("DELETE FROM day_pages WHERE day = ?", (day,))
    for slug in slugs:
        db.execute("UPDATE wiki_pages SET mention_count = (SELECT COUNT(*) FROM wiki_mentions WHERE slug = ?), "
                   "is_dirty = 1, regen_failures = 0 WHERE slug = ?", (slug, slug))
        if db.query("SELECT 1 FROM wiki_pages WHERE slug = ? AND pinned = 0 AND mention_count = 0", (slug,)):
            db.execute("DELETE FROM wiki_pages WHERE slug = ?", (slug,))
            done["pages"] += 1
    db.execute("DELETE FROM embeddings WHERE kind = 'chronicle' AND ref_id NOT IN (SELECT id FROM chronicle)")
    db.execute("DELETE FROM embeddings WHERE kind = 'wiki' AND ref_id NOT IN (SELECT id FROM wiki_pages)")
    if hours:
        db.set_state(REDO_HOURS_KEY, json.dumps(sorted(_state_set(db, REDO_HOURS_KEY) | hours)))
        db.set_state(REDO_DAYS_KEY, json.dumps(sorted(_state_set(db, REDO_DAYS_KEY) | days)))
        chronicle.DIGEST_PATH.unlink(missing_ok=True)  # rebuilt on the next pass from what's left
    done["hours"] = len(hours)
    return done


def apply_new_rules(cfg: Config, db: DB) -> dict:
    """Forget the history matching rules added since the last call. Returns counts ({} when nothing is new)."""
    current = rule_lines(cfg)
    new = current - _state_set(db, APPLIED_KEY)
    done = {}
    if new:
        t0 = time.monotonic()
        done = forget_matching(db, _rules(new))
        if any(done.values()):
            log.info("ignore rules %s: forgot %s (%.1fs)", ", ".join(sorted(new)[:5]) + ("…" if len(new) > 5 else ""),
                     " ".join(f"{k}={v}" for k, v in done.items() if v), time.monotonic() - t0)
    # Removed rules leave the applied set too, so adding one back later forgets again.
    db.set_state(APPLIED_KEY, json.dumps(sorted(current)))
    return done


# ------------------------------------------------------------------ the user's own rules (CLI and MCP)

def clean_value(v: str) -> str:
    """A rule as typed: a pasted URL becomes its site."""
    from urllib.parse import urlparse
    v = v.strip()
    if v.startswith(("http://", "https://")):
        v = (urlparse(v).hostname or v).removeprefix("www.")
    return v


def preview(db: DB, values: list[str]) -> dict:
    return forget_matching(db, _rules(_norm(v) for v in values), dry_run=True)


def add_user_rules(cfg: Config, db: DB, values: list[str]) -> dict:
    """Add ignore rules to config.json and forget what they match. Returns what was deleted."""
    apps, other = list(cfg.blocked_apps), list(cfg.blocked_domains)
    for v in values:
        if v.lower().startswith("app:"):
            name = v[4:].strip()
            if name and name.lower() not in {a.lower() for a in apps}:
                apps.append(name)
        elif _norm(v) not in {_norm(d) for d in other}:
            other.append(v)
    config.set_capture_list("blocked_apps", apps)
    config.set_capture_list("blocked_domains", other)
    return apply_new_rules(config.load(), db)


def remove_user_rules(cfg: Config, db: DB, values: list[str]) -> list[str]:
    """Take rules out of config.json (what was deleted stays deleted). Returns the ones removed."""
    low = {_norm(v) for v in values}
    apps = [a for a in cfg.blocked_apps if f"app:{a.lower()}" not in low]
    other = [d for d in cfg.blocked_domains if _norm(d) not in low]
    gone = [f"app:{a}" for a in cfg.blocked_apps if a not in apps] + [d for d in cfg.blocked_domains if d not in other]
    config.set_capture_list("blocked_apps", apps)
    config.set_capture_list("blocked_domains", other)
    apply_new_rules(config.load(), db)
    return gone
