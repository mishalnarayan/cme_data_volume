"""Web chat apps (WhatsApp Web and friends): read the open conversation around the message box.

Instead of the whole page (which includes the chat list with everyone's previews), walk up
from the focused composer to the conversation pane and read only that. On WhatsApp Web,
messages carry `message-in` / `message-out` classes, so the transcript says who wrote what.
"""
import logging
import re
import time

from . import ax, ocr

log = logging.getLogger("donkey.web")

CHAT_DOMAINS = {
    "web.whatsapp.com", "web.telegram.org", "app.slack.com", "discord.com", "messenger.com",
    "teams.microsoft.com", "teams.live.com", "chat.google.com", "x.com", "linkedin.com", "instagram.com",
}
CHAT_APPS = {"whatsapp", "slack", "discord", "telegram", "messages", "signal", "microsoft teams", "messenger"}
# HTML ids of the conversation pane, per site; plus any element with ARIA role="main".
CONVERSATION_IDS = {"web.whatsapp.com": {"main"}}
GENERIC_CONVERSATION_IDS = {"main"}
TRANSCRIPT_CHARS = 8000
MIN_PANE_CHARS = 200
WALK_BUDGET_NODES = 2500
WALK_BUDGET_S = 1.5


def is_chat_surface(app: str, domain: str | None) -> bool:
    if domain and any(domain == d or domain.endswith("." + d) for d in CHAT_DOMAINS):
        return True
    return app.lower() in CHAT_APPS


# Sites with both feeds and private messages: only a message box is a chat ("Write a message…" on
# LinkedIn, "Message…" on Instagram, "Start a new message" on X); a post or comment box is not.
MIXED_DOMAINS = {"linkedin.com", "x.com", "instagram.com"}


def writing_a_message(app: str, domain: str | None, label: str | None) -> bool:
    """Is this field a chat message box? Like is_chat_surface, but on sites with feeds the
    field's own label decides."""
    if domain and any(domain == d or domain.endswith("." + d) for d in MIXED_DOMAINS):
        low = (label or "").lower()
        return "message" in low and not any(w in low for w in ("comment", "post", "reply"))
    return is_chat_surface(app, domain)


# Composer labels that name the recipient: "Type a message to Anna", "Message #general", "Message @sam".
_RECIPIENT = re.compile(r"(?i)^(?:type a message to|write (?:a message )?to|reply to|message)\s+(.{1,80}?)\s*$")


def recipient_from_label(label: str | None) -> str | None:
    m = _RECIPIENT.match((label or "").strip())
    return m.group(1) if m else None


def conversation_container(field_el, domain: str | None):
    """Nearest ancestor of the composer that is the conversation pane, or None."""
    ids = CONVERSATION_IDS.get(domain or "", set()) | GENERIC_CONVERSATION_IDS
    el, hops = ax.attr(field_el, "AXParent"), 0
    while el is not None and hops < 40:
        role = ax.attr(el, "AXRole")
        if role == "AXWebArea":
            return None
        if ax.dom_id(el) in ids or ax.attr(el, "AXSubrole") == "AXLandmarkMain":
            return el
        el, hops = ax.attr(el, "AXParent"), hops + 1
    return None


_SENDER_LABEL = re.compile(r"^(.{1,60}):$")
_TRAILER = re.compile(r"\s*\d{1,2}:\d{2}\s*(?:[ap]m)?\s*(?:Delivered|Read|Sent|Pending|Edited)?\s*$", re.I)


def _row_sender(row, budget: int = 60) -> str | None:
    """WhatsApp labels each message row with its sender ("You:" or "Anna:") on a child group."""
    stack, n = [row], 0
    while stack and n < budget:
        el = stack.pop()
        n += 1
        m = _SENDER_LABEL.match((ax.as_text(ax.attr(el, "AXDescription")) or "").strip())
        if m:
            return m.group(1)
        stack.extend(reversed(list(ax.attr(el, "AXChildren") or [])))
    return None


def _whatsapp_rows(container) -> list[str]:
    """Current WhatsApp Web (2026): messages are AXRows labelled "You:" or "<name>:"."""
    lines: list[str] = []
    stack, nodes = [container], 0
    deadline = time.monotonic() + WALK_BUDGET_S
    while stack and nodes < WALK_BUDGET_NODES and time.monotonic() < deadline:
        el = stack.pop()
        nodes += 1
        if ax.attr(el, "AXRole") == "AXRow":
            sender = _row_sender(el)
            text = " ".join((ax.element_text(el) or "").split())
            if sender and text:
                text = _TRAILER.sub("", text.removeprefix(sender + ":").strip())
                lines.append(f"{'Me' if sender.lower() == 'you' else 'Them'}: {text}")
            continue
        stack.extend(reversed(list(ax.attr(el, "AXChildren") or [])))
    return lines


def find_main(window, max_nodes: int = 400):
    """The conversation pane (#main) of a web chat window, found from the window."""
    web_area = ax.find_web_area(window)
    queue, seen = [web_area] if web_area is not None else [], 0
    while queue and seen < max_nodes:
        el = queue.pop(0)
        seen += 1
        if ax.dom_id(el) == "main":
            return el
        queue.extend(ax.attr(el, "AXChildren") or [])
    return None


def labelled_conversation(window, domain: str | None) -> str | None:
    """The open chat with each line marked Me (the user) or Them, for capture. WhatsApp Web only:
    it is the one site whose rows say who wrote them."""
    if domain != "web.whatsapp.com":
        return None
    main = find_main(window)
    if main is None:
        return None
    lines = _whatsapp_transcript(main)
    if not lines:
        return None
    who, stack, n = None, [main], 0
    while stack and n < 600 and who is None:
        el = stack.pop()
        n += 1
        if ax.attr(el, "AXRole") == "AXTextArea":
            who = recipient_from_label(ax.as_text(ax.attr(el, "AXDescription")))
        stack.extend(ax.attr(el, "AXChildren") or [])
    text = "\n".join(lines)[-TRANSCRIPT_CHARS:]
    return f"[Open conversation with {who or 'unknown'}. 'Me' lines were written by the user, 'Them' by others]\n{text}"


def _whatsapp_transcript(container) -> list[str]:
    """'Me:' / 'Them:' lines for the visible messages, oldest first."""
    rows = _whatsapp_rows(container)
    if rows:
        return rows
    lines: list[str] = []  # older WhatsApp Web: message-in / message-out classes
    stack, nodes = [container], 0
    deadline = time.monotonic() + WALK_BUDGET_S
    while stack and nodes < WALK_BUDGET_NODES and time.monotonic() < deadline:
        el = stack.pop()
        nodes += 1
        classes = ax.dom_classes(el)
        who = "Me" if "message-out" in classes else "Them" if "message-in" in classes else None
        if who:
            text = " ".join((ax.element_text(el) or "").split())
            if text:
                lines.append(f"{who}: {text}")
            continue  # don't descend into a message we've already read
        kids = ax.attr(el, "AXChildren") or []
        stack.extend(reversed(list(kids)))
    return lines


def conversation_context(field_el, domain: str | None) -> str | None:
    """Text of the open conversation, newest last, or None when no conversation pane is found."""
    container = conversation_container(field_el, domain)
    if container is None:
        return None
    t0 = time.monotonic()
    if domain == "web.whatsapp.com":
        lines = _whatsapp_transcript(container)
        if lines:
            kids = ax.attr(container, "AXChildren") or []
            header_text = (ax.element_text(kids[0]) if kids else None) or ""
            header = " ".join(header_text[:160].split()) or "unknown"
            text = "\n".join(lines)
            if len(text) > TRANSCRIPT_CHARS:
                text = "…\n" + text[-TRANSCRIPT_CHARS:]
            log.info("whatsapp transcript: %d messages in %d ms", len(lines), (time.monotonic() - t0) * 1000)
            return (f"Chat header (contact or group name, status): {header}\n\n"
                    f"Messages, oldest first. 'Me' is the user; 'Them' is the other side:\n{text}")
    text = (ax.element_text(container) or "").strip()
    if len(text) < MIN_PANE_CHARS:
        return None  # a landmark around the composer only ("Cancel Comment" on YouTube): read the page instead
    if len(text) > TRANSCRIPT_CHARS:
        text = "…" + text[-TRANSCRIPT_CHARS:]
    log.info("conversation pane: %d chars in %d ms", len(text), (time.monotonic() - t0) * 1000)
    return text


# ------------------------------------------------------------------ any page: who wrote what, from the layout

LAYOUT_NODES = 3000
MIN_LINE_PT = 4  # shorter than this is not a line on screen
LAYOUT_S = 1.0
_TIMES = re.compile(r"\b\d{1,2}:\d{2}\b")


def looks_like_conversation(text: str) -> bool:
    """Two or more clock times: a chat, a comment thread, a mail thread. Cheap, and no list of sites."""
    return len(_TIMES.findall(text or "")) >= 2


def text_boxes(root, window) -> list:
    """Every visible text element under `root` as an ocr.Box at its exact on-screen place, relative
    to `window`: what the OCR would have found, without misreads."""
    win = ax.element_frame(window)
    if not win or win[2] <= 0 or win[3] <= 0:
        return []
    wx, wy, ww, wh = win
    boxes, seen, stack, nodes = [], set(), [root], 0
    stop = time.monotonic() + LAYOUT_S
    while stack and nodes < LAYOUT_NODES and time.monotonic() < stop:
        el = stack.pop()
        nodes += 1
        role = ax.as_text(ax.attr(el, "AXRole"))
        if role in ax.SKIP_ROLES:
            continue
        if role in ax.VALUE_ROLES:
            text = " ".join((ax._value_text(el, role) or "").split())
            f = ax.element_frame(el) if text else None
            # Scrolled out of view, a browser reports an element squashed to its scroll area's edge.
            if f and f[2] > 0 and f[3] >= MIN_LINE_PT and f[1] + f[3] > wy and f[1] < wy + wh and f[0] + f[2] > wx and f[0] < wx + ww:
                spot = (text, round(f[0] / 4), round(f[1] / 4))  # one text at one place: pages often expose it twice
                if spot not in seen:
                    seen.add(spot)
                    boxes.append(ocr.Box(top=(f[1] - wy) / wh, left=(f[0] - wx) / ww, right=(f[0] + f[2] - wx) / ww,
                                         height=f[3] / wh, text=text))
            continue
        stack.extend(reversed(list(ax.attr(el, "AXVisibleChildren") or ax.attr(el, "AXChildren") or [])))
    return boxes


def layout_conversation(window, root, pid: int, title: str | None) -> str | None:
    """The visible conversation with the user's own lines marked, read from where the page puts
    each line and the window's picture (the same rules as a remote desktop's pixels), on any site
    or app. None when the picture shows no bubbles of the user's."""
    t0 = time.monotonic()
    boxes = text_boxes(root, window)
    if len(boxes) < 4:
        return None
    win = ocr._window(pid, title)
    image = ocr._shot(win) if win is not None else None
    if image is None:
        return None
    text = ocr.layout(boxes, image)
    if not any(b.own for b in boxes):
        return None
    log.info("layout conversation: %d lines, %d the user's, in %d ms", len(boxes), sum(b.own for b in boxes),
             (time.monotonic() - t0) * 1000)
    if len(text) > TRANSCRIPT_CHARS:
        text = "…\n" + text[-TRANSCRIPT_CHARS:]
    return ("[Who wrote what, from the page's layout: lines starting with → are the user's own messages; "
            "any other message belongs to the name on the header line above it]\n" + text)
