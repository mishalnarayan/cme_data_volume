"""Windows notifications (toasts) with Donkey's name and icon.

A toast shows an app's name and icon when it is posted under an app id Windows knows: on first use
Donkey registers its own (Donkey.App) under HKCU\\Software\\Classes\\AppUserModelId, which needs no
administrator rights and no Start menu shortcut. Clicking a toast opens a donkey:// link, which
Windows hands to `Donkey open <link>`; that passes it to the running Donkey (see app.py).
"""
import logging
import threading
import winreg
from pathlib import Path
from xml.sax.saxutils import escape

from . import config

log = logging.getLogger("donkey.notify")

HERE = Path(__file__).parent
ICON = HERE / "assets" / "icon.png"
APP_ID = "Donkey.App"
PROTOCOL = "donkey"
_lock = threading.Lock()
_registered = False


def register() -> bool:
    """Make Donkey known to Windows: its notification id (name and icon) and the donkey:// links
    toasts open. Per user; safe to run every launch."""
    global _registered
    with _lock:
        if _registered:
            return True
        try:
            with winreg.CreateKey(winreg.HKEY_CURRENT_USER, rf"Software\Classes\AppUserModelId\{APP_ID}") as k:
                winreg.SetValueEx(k, "DisplayName", 0, winreg.REG_SZ, "Donkey")
                winreg.SetValueEx(k, "IconUri", 0, winreg.REG_SZ, str(ICON))
                winreg.SetValueEx(k, "IconBackgroundColor", 0, winreg.REG_SZ, "FFF4EDE4")
            with winreg.CreateKey(winreg.HKEY_CURRENT_USER, rf"Software\Classes\{PROTOCOL}") as k:
                winreg.SetValueEx(k, "", 0, winreg.REG_SZ, "URL:Donkey")
                winreg.SetValueEx(k, "URL Protocol", 0, winreg.REG_SZ, "")
            with winreg.CreateKey(winreg.HKEY_CURRENT_USER, rf"Software\Classes\{PROTOCOL}\DefaultIcon") as k:
                winreg.SetValueEx(k, "", 0, winreg.REG_SZ, config.command_line(gui=True)[0])
            with winreg.CreateKey(winreg.HKEY_CURRENT_USER, rf"Software\Classes\{PROTOCOL}\shell\open\command") as k:
                winreg.SetValueEx(k, "", 0, winreg.REG_SZ, config.shell_command("open", '"%1"', gui=True))
            _registered = True
            return True
        except OSError:
            log.exception("couldn't register Donkey's notifications")
            return False


def unregister() -> None:
    for key in (rf"Software\Classes\{PROTOCOL}\shell\open\command", rf"Software\Classes\{PROTOCOL}\shell\open",
                rf"Software\Classes\{PROTOCOL}\shell", rf"Software\Classes\{PROTOCOL}\DefaultIcon",
                rf"Software\Classes\{PROTOCOL}", rf"Software\Classes\AppUserModelId\{APP_ID}"):
        try:
            winreg.DeleteKey(winreg.HKEY_CURRENT_USER, key)
        except OSError:
            pass


def send(body: str, title: str = "Donkey", subtitle: str = "", sound: bool = False, nudge_id: int | None = None) -> None:
    """Show a notification. Returns at once; posting happens in the background.
    With a nudge id, clicking it opens that message in the chat."""
    threading.Thread(target=_send, args=(body, title, subtitle, sound, nudge_id), name="notify", daemon=True).start()


def _toast_xml(body: str, title: str, subtitle: str, sound: bool, nudge_id: int | None) -> str:
    launch = f"{PROTOCOL}://nudge/{int(nudge_id)}" if nudge_id else f"{PROTOCOL}://show"
    lines = [f"<text>{escape(title)}</text>"]
    if subtitle:
        lines.append(f"<text>{escape(subtitle)}</text>")
    lines.append(f"<text>{escape(body)}</text>")
    audio = '<audio src="ms-winsoundevent:Notification.Default"/>' if sound else '<audio silent="true"/>'
    return (f'<toast activationType="protocol" launch="{escape(launch)}">'
            f'<visual><binding template="ToastGeneric">{"".join(lines)}</binding></visual>{audio}</toast>')


def _send(body: str, title: str, subtitle: str, sound: bool, nudge_id: int | None = None) -> None:
    register()
    try:
        from winrt.windows.data.xml.dom import XmlDocument
        from winrt.windows.ui.notifications import ToastNotification, ToastNotificationManager
        doc = XmlDocument()
        doc.load_xml(_toast_xml(body, title, subtitle, sound, nudge_id))
        ToastNotificationManager.create_toast_notifier_with_id(APP_ID).show(ToastNotification(doc))
    except Exception:
        log.exception("couldn't show a notification")
