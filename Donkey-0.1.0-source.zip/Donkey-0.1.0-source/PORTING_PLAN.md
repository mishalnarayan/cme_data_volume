# Donkey → Windows port: plan and status

The Mac version (`../donkey`, `../donkey-build`) stays untouched. The Windows version is a separate
copy in `windows/donkey` and `windows/donkey-build` with the same layout. It has no macOS code paths.

## Status: converted and smoke-tested (2026-10-31)

Done:
- [x] `winui.py` (new): Qt app/event loop, `call_after`/`call_later`/`every`, `Panel` (frameless or
      titled web window, QWebChannel shim so pages keep `window.webkit.messageHandlers.donkey`),
      click-through for clear areas, screen geometry (physical ↔ logical), focus (`activate`),
      menus, shell helpers, `GLASS_CSS`
- [x] Platform: `ax.py` (UI Automation with AX-style `attr()`), `field.py`, `keys.py` (LL hooks,
      AltGr, menu mask), `deliver.py` (Value pattern / select + Ctrl+V, clipboard save/restore,
      admin-app check), `capture.py` (idle, lock, audio-session "video", shell skip), `ocr.py`
      (PrintWindow + Windows.Media.Ocr), `notify.py` (toasts + `donkey://`), `instance.py` (new:
      mutex, local socket, restart)
- [x] UI: `overlay.py`, `motion.py`, `editbar.py`, `suggestcard.py`, `bubblechat.py`,
      `chatwindow.py`, `journal.py` (window, exe icons, Chrome/Edge/Brave favicons), `prologue.py`,
      `app.py` (tray, menu, creature, edit mode, sign-in shortcut, restart)
- [x] `config.py` (%APPDATA% when installed, `command()`/`shell_command()`, account name, key
      names), `onboarding.py` (no permission steps), `embed.py` (job object, winget/vendored
      llama-server, native ARM64 llama-server on ARM), `rewrite.py` (sounds, clipboard),
      `mcp_install.py`, `imports.py`, `memory_map.py`, `__main__.py` (UTF-8 mode, run by path,
      `open` command, Windows doctor)
- [x] `%-d` → `%#d` everywhere; Mac wording in prompts/pages/config notes; Segoe UI fonts; Ctrl
      shortcuts; welcome without the `perms` step; Windows key row
- [x] Deleted: `glass.py`, `notifier/`, `setup.sh`, `build.sh`, `make_dmg.sh`, `dmg_*.py`
- [x] Tools ported: `ax_snapshot.py`, `check_layout.py`, `check_delivery.py`
- [x] Packaging: `requirements.txt`, `setup.ps1`, `donkey-build/{build.ps1, donkey.spec,
      app_entry.py, vendor.py (llama.cpp b11669 win-cpu x64 + arm64, sha256-pinned),
      installer.iss, README.md}`
- [x] Docs: README (setup, app, capture/OCR, delivery), CONTRIBUTING, .gitignore

Verified on this PC (x64 Python 3.11.9 under emulation on ARM64, PySide6 6.12):
- every module imports; `compileall` clean; offline checks pass (delivery, loop guards, memory
  jobs, new view, person lines, update)
- Notepad: role, value, selection by UTF-16 offset (emoji included), caret rectangle, Value
  pattern write, window read/walk
- UI: creature (transparent, click-through), edit bar, ideas card, Donkey window (bridge both
  ways), tray icon, full-screen greeting, OCR of a real window (64 lines, 0.2 s), toast posted
- full app start, second launch → "already running", `donkey open donkey://…` handed to the
  running copy

Verified later the same day, with the user at the keyboard (right Option on a Mac keyboard in a VM):
- physical taps of right Alt, and rewrites end to end with a model, in Chrome and Edge
- read + write (Donkey's own field.read_target + deliver.deliver) passing in: Notepad, Chrome and
  Edge (textarea and a contenteditable rich editor), Windows search and Explorer boxes, Windows
  Terminal (paste at the prompt), Sticky Notes (XAML TextBox and the RichEditBox note), and the new
  Outlook's WebView2 sign-in box (stands in for Teams and other WebView2 apps)

Fixed on the way: a lone Alt tap moved Chrome's focus to its ⋮ button (the hook now holds a lone
Alt/Win press back from apps); Windows' key state stuck "down" in the VM made a watchdog invent
presses; an empty clipboard marker made every paste fail; terminals' text area is UIA "Text";
WebView2 content belongs to msedgewebview2.exe, not the app; any unexpected delivery error now
leaves the result on the clipboard.

Review against the Mac version (2026-10-31): Chrome's Incognito and Edge's InPrivate windows weren't
recognised as private (Windows titles don't say so; Chromium's root view does, and ax.window_title
now adds the mode); the ideas card and edit bar had square corners (CSS background propagation);
window.open from a panel could hand any scheme to os.startfile (now web links only). Delivery now
pastes over the selected slice wherever the field can select one (formatting and Ctrl+Z survive,
tested in Sticky Notes and Notepad) and writes a whole value only into plain-text boxes; the
clipboard is saved and restored byte for byte (copied files survive). A half-made UI Automation
client could break a thread for good; it's now kept only once complete, and threads set theirs up
one at a time (starting together they failed with "Unspecified error"). The tray menu opened at
the pointer and ran down over the taskbar, so the next click on the taskbar hit Quit: it now opens
above the taskbar, for left and right clicks alike.

No quiet keyword-only memory search (a deliberate difference from the Mac copy, which falls back):
build.ps1 runs vendor.py and stops (as does donkey.spec) unless the GGUF and both llama-servers are
in vendor\; the installed app uses only its own copies, and a missing one or a failed vector search
is an error: a notification at startup, "Memory search failed: …" on a rewrite, the error in chat
and MCP. `donkey search --keyword` still asks for keywords on purpose. native_arch() had always
failed (GetCurrentProcess's handle cut to 32 bits), so ARM PCs ran the emulated x64 llama-server;
fixed.

Not verified yet:
- Electron apps (Slack, Discord, WhatsApp, VS Code) and Office (Word, Outlook classic): not
  installed on this PC; Teams and the new Outlook signed in
- The installer: `build.ps1` builds dist\Donkey (run 2026-10-31: doctor, UTF-8 mode and vector
  search with the bundled ARM64 llama-server checked), but Inno Setup isn't installed here, so no
  setup.exe yet. The build fixes: mcp.cli left out (it needs typer), the UTF-8 option spelled
  "X utf8" (the bootloader ignored "X utf8_mode=1"), and donkey-cli writes UTF-8 to pipes.

## Decisions made

**Target x64 Windows (Python 3.11 x64).** On Windows ARM64 there's no QtWebEngine, and pywebview's
.NET bridge (pythonnet/ClrLoader) has no ARM64 DLL. x64 builds run on ARM PCs through Windows 11's
emulation (Windows 10 on ARM can't run x64). llama-server ships as both x64 and ARM64 and Donkey
starts the native one.

| macOS | Windows replacement |
|---|---|
| AppKit event loop, `AppHelper.callAfter/callLater`, NSTimer | PySide6 `QApplication`, `winui.call_after/call_later/every` |
| WKWebView + `window.webkit.messageHandlers.donkey` | QWebEngineView + QWebChannel; a DocumentCreation shim defines `window.webkit.messageHandlers.<name>.postMessage` |
| NSPanel non-activating, floating | Frameless `Qt.Tool \| WindowStaysOnTopHint \| WindowDoesNotAcceptFocus` + `WS_EX_NOACTIVATE`; typing panels take the foreground and hand it back |
| Clear panel areas let clicks through | 30 Hz poller toggles `WS_EX_TRANSPARENT` from cursor vs. hit rects |
| NSGlassEffectView / blur | CSS card (`winui.GLASS_CSS`) |
| NSStatusItem menu | `QSystemTrayIcon` + `QMenu` rebuilt on `aboutToShow`; icon inverted for a dark taskbar |
| Pull donkey out of the menu bar | "Bring Donkey out" flies from the tray icon; drop on the taskbar puts it back |
| Accessibility API | UI Automation via comtypes, same `ax.attr(el, "AXRole")` API |
| CGEventTap Donkey key | `WH_KEYBOARD_LL` + `WH_MOUSE_LL`, AltGr's fake Ctrl ignored, vk 0xE8 menu mask, hook watchdog |
| AX write + Cmd+V | `ValuePattern.SetValue` (non-web) / `TextRange.Select` + Ctrl+V via `SendInput` |
| NSPasteboard | `win32clipboard` (all formats saved/restored; our copy kept out of clipboard history) |
| Secure input | foreground app elevated while Donkey isn't (UIPI) |
| ScreenCaptureKit + Vision | `PrintWindow(PW_RENDERFULLCONTENT)` + `Windows.Media.Ocr` |
| Permissions | none on Windows; welcome step removed |
| launchd LaunchAgent | Startup-folder shortcut (`--login`) |
| fcntl lock + distributed notifications | named mutex + `QLocalServer` (`instance.py`) |
| Swift notifier | WinRT toasts, AUMID `Donkey.App`, `donkey://` protocol |
| `pmset` video wake lock | active audio session (pycaw) |
| Bundle IDs | exe names (`chrome.exe`, `msedge.exe`, …) |

## Running from source on this PC

The ARM64 Python on this machine can't run Donkey (no QtWebEngine). Tests used a portable x64
Python in the session scratchpad (temporary). For real use: `windows\donkey\setup.ps1` installs
x64 Python 3.11 with winget and makes `.venv`.

## Syncing later Mac changes

- 2026-11-03: Mac `overlay.py` (dated 2026-10-31 12:44) added seven tricks for the pulled-out
  donkey: bray, graze (grass tuft, blade chewed down), paw, swat (a fly), rest, snort and walk-and-turn.
  The backflip's random weight went to 0, so now it only plays from the menu. The trick CSS, the JS
  (`FX`, `tricks.moves`, the walk's `turns`) and `TRICKS` were copied verbatim; the only Windows
  difference is still the `.zz` font. `creature.svg` was unchanged. All 18 tricks were played in
  QtWebEngine with no console errors.
